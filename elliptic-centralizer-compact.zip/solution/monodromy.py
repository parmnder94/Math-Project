"""Search for an exact finite-field certificate of saturated elliptic image.

The search reads only the just-derived curve and covering, not a saved prime
or saved points. Group operations use the original y^2=4x^3-44 coordinates.
"""
from math import factorial, isqrt


def prime(n):
    return n >= 2 and all(n % d for d in range(2, isqrt(n)+1))


def polynomial(coefficients, t, p):
    result = 0
    for coefficient in reversed(coefficients):
        result = (result*t+coefficient) % p
    return result


def rational(encoded, t, p):
    denominator = polynomial(encoded['den'], t, p)
    if denominator == 0:
        raise ZeroDivisionError
    return polynomial(encoded['num'], t, p)*pow(denominator, -1, p) % p


def add(P, Q, p):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2 and (y1+y2) % p == 0:
        return None
    if P == Q:
        slope = 6*x1*x1*pow(y1, -1, p) % p
    else:
        slope = (y2-y1)*pow(x2-x1, -1, p) % p
    x3 = (slope*slope*pow(4, -1, p)-x1-x2) % p
    y3 = (-y1+slope*(x1-x3)) % p
    return x3, y3


def multiply(k, P, p):
    out = None
    while k:
        if k & 1:
            out = add(out, P, p)
        P = add(P, P, p)
        k >>= 1
    return out


def generated(generators, p):
    group = {None}
    queue = [None]
    for P in queue:
        for Q in generators:
            point = add(P, Q, p)
            if point not in group:
                group.add(point)
                queue.append(point)
    return group


def certificate(result):
    import sympy as s
    E = s.symbols('E')
    h = result['normalized_polynomial']
    curve = result['cover']
    # Coefficients are integral here, but permit rational scalar denominators.
    h_expr = sum(s.Integer(c)*E**i for i, c in enumerate(h['num'])) / h['den'][0]
    functions = []
    for key in ['x', 'y_multiplier']:
        encoded = curve[key]
        expression = s.cancel(sum(s.Integer(c)*E**i for i,c in enumerate(encoded['num'])) /
                              sum(s.Integer(c)*E**i for i,c in enumerate(encoded['den'])))
        numerator, denominator = map(lambda z: s.Poly(z, E, domain=s.QQ), s.fraction(expression))
        leading = denominator.LC()
        functions.append((numerator.mul_ground(1/leading), denominator.monic()))
    for p in range(5, 5000):
        if not prime(p) or 66 % p == 0:
            continue
        if any(s.denom(c) % p == 0 for polynomials in functions for polynomial_ in polynomials for c in polynomial_.all_coeffs()):
            continue
        if any(s.denom(c) % p == 0 for c in s.Poly(h_expr,E).all_coeffs()):
            continue
        hp = s.Poly(h_expr, E, modulus=p)
        if hp.degree() != 9 or hp.gcd(hp.diff()).degree() != 0:
            continue
        squares = {}
        for y in range(p):
            squares.setdefault(y*y % p, []).append(y)
        points = [None]
        for x in range(p):
            points.extend((x, y) for y in squares.get((4*x**3-44) % p, []))
        if len(points) % 36 or sum(multiply(6, P, p) is None for P in points) != 36:
            continue
        def reduce_polynomial(polynomial_):
            return s.Poly.from_list([int(s.numer(c))*pow(int(s.denom(c)),-1,p) % p
                                    for c in polynomial_.all_coeffs()], E, modulus=p)
        reductions = [(reduce_polynomial(n),reduce_polynomial(d)) for n,d in functions]
        if any(n.degree()!=rn.degree() or d.degree()!=rd.degree() or rn.gcd(rd).degree()!=0
               for (n,d),(rn,rd) in zip(functions,reductions)):
            continue
        witnesses, images, subgroup = [], [], {None}
        for energy in range(p):
            roots = squares.get(-rational(h, energy, p) % p, [])
            if not roots:
                continue
            W = roots[0]
            try:
                image = (rational(curve['x'], energy, p), W*rational(curve['y_multiplier'], energy, p) % p)
            except ZeroDivisionError:
                continue
            if image in subgroup:
                continue
            assert (image[1]**2-4*image[0]**3+44) % p == 0
            witnesses.append([energy, W])
            images.append(image)
            subgroup = generated(images, p)
            if len(subgroup) == len(points):
                return {'group_order': factorial(curve['degree']), 'prime': p, 'source_points': witnesses}
            if len(witnesses) == 8:
                break
    raise RuntimeError('No finite-field certificate found below 5000')
