#!/bin/bash
set -euo pipefail
cd /app
python /solution/solve.py --data /app/data/operator.json --output /app/output/centralizer.json
