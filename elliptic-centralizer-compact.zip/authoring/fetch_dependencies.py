#!/usr/bin/env python3
"""Restore the compact release's nine exact wheels, checking every SHA-256.

Run before a Docker/Harbor build. This is authoring setup, never verifier runtime.
Already valid files are reused; incomplete downloads are never installed.
"""
import argparse
import hashlib
import json
import os
import tempfile
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path


def fetch(root):
    root=root.resolve()
    inventory=json.loads((root/'authoring/dependencies.json').read_text())
    assert len(inventory)==9 and len({entry['path'] for entry in inventory})==9
    def restore(entry):
        relative=Path(entry['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        assert relative.parts[:2] in [('environment','wheels'),('tests','wheels')]
        path=root/relative
        digest=entry['sha256']
        if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==digest:
            return {'path':entry['path'],'status':'already verified','bytes':path.stat().st_size}
        url=entry['artifact_source']
        parsed=urllib.parse.urlparse(url)
        assert parsed.scheme=='https' and parsed.hostname=='files.pythonhosted.org'
        path.parent.mkdir(parents=True,exist_ok=True)
        fd,temporary=tempfile.mkstemp(prefix='.download-',dir=path.parent)
        try:
            hasher=hashlib.sha256()
            with os.fdopen(fd,'wb') as output, urllib.request.urlopen(url,timeout=60) as response:
                while chunk:=response.read(1024*1024):
                    hasher.update(chunk);output.write(chunk)
            assert hasher.hexdigest()==digest, 'dependency hash mismatch: '+entry['path']
            os.chmod(temporary,0o644)
            os.replace(temporary,path)
        finally:
            if os.path.exists(temporary):os.unlink(temporary)
        return {'path':entry['path'],'status':'downloaded and verified','bytes':path.stat().st_size}
    with ThreadPoolExecutor(max_workers=3) as pool:
        results=list(pool.map(restore,inventory))
    print(json.dumps({'wheels':len(results),'total_bytes':sum(r['bytes'] for r in results),'results':results},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    fetch(parser.parse_args().root)
