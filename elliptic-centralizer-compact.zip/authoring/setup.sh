#!/bin/bash
# Restore exact wheels once, then install local validation tools offline.
set -euo pipefail
task_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
task_venv=${1:-/tmp/elliptic-centralizer-tools}
python3 "$task_root/authoring/fetch_dependencies.py"
python3 -m venv "$task_venv"
"$task_venv/bin/python" -m pip install --no-cache-dir --no-index --require-hashes \
    --find-links "$task_root/environment/wheels" \
    --find-links "$task_root/tests/wheels" \
    -r "$task_root/environment/requirements.txt" \
    -r "$task_root/tests/requirements.txt"
"$task_venv/bin/python" -c 'import sympy,flint,pytest; print("Ready:",sympy.__version__,flint.__version__,pytest.__version__)'
