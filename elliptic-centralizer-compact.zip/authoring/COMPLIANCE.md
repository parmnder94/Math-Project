# Review against the supplied Project Kepler guidelines

Compact edition: the nine dependency wheels are fetched automatically by checksum-verified Docker ADD instructions during initial image preparation, or by `python3 authoring/fetch_dependencies.py` for local tools. No dependency installation or download occurs in the verifier at runtime.

The attached PDF was treated as a source of project criteria, distinct from the user's request. All twelve scanned pages were inspected through OCR. Code blocks clipped by the original PDF cannot be fully reconstructed from that document. The attached reference was also inspected, including its interfaces, provenance, and recorded results. This file records checked requirements and limits; it does not certify the unpublished platform rubric.

| Criterion | Evidence and status |
|---|---|
| ZIP contains task-directory contents, with only the six required entries and optional authoring | `static_validate.py` and the release manifest; no enclosing task folder |
| Required Dockerfiles, executable oracle/verifier scripts, README headings | Static checks; actual separate-container executions |
| Schema 1.4, top-level absolute artifacts, at most three slug words | `task.toml`; static checks |
| Complete metadata, matching author/tag fields, exact field mapping | Static checks. Supplied identity copied with user authorization, not independently authenticated |
| Truthful relevant expertise | Original wind-optimization experience is preserved verbatim. Relevance to this specialist task requires the author's assessment; new expertise was not invented |
| Synthetic input disclosed; generator and seed retained | `provenance/generate.py`, seed 20261009; input hash in source manifest |
| Ground truth independent of reference implementation | Full-field minimality proof, independent rational-pencil/divisor-reduction solver, exact defining identities, independent finite-field arithmetic |
| Fundamentally different from supplied reference | Exact differential algebra, algebraic curves, and finite-group certificates replace wind inference and layout optimization; see `PITCH.md` |
| No answer or grading logic in agent image | Public Docker COPY allowlist, two-file public data directory, image-content hash audit. Solution, tests, and authoring remain separate |
| Separate offline verifier; public agent networking | TOML and actual Docker network inspection. Only declared JSON crosses from solution container to verifier |
| Exact package pins, mandated pytest versions, no runtime install | Hash-pinned wheels fetched during image preparation; pip installs from local files without index access; validation RUN steps and verifier execution have networking disabled. `pytest==8.4.1`, `pytest-json-ctrf==0.3.5` |
| Resources and time limits in permitted sets | 2 CPUs, 4096 MB, 10240 MB storage, no GPU; 14400-second agent and 120-second verifier |
| Deterministic binary reward and CTRF, including failure | `tests/test.sh`, two oracle and two nop runs in separate Docker containers; recorded reward, process status, and CTRF |
| Mathematical correctness and representation independence | Reference and independent solutions; 68 positive, negative, malformed-input, and adversarial controls; exact identities rather than golden JSON comparison |
| Eight independent difficulty attempts | Eight final local blind contexts in separate containers, with complete submitted artifacts and notes. These are local collaborative probes, not the official controlled model harness. See actual results; failures of the difficulty target are disclosed |
| Required difficulty band | **Not met in local testing: 8/8 final successes.** Both prior four-attempt pilots also had all successes. No low-success claim is made |
| Real Harbor oracle/nop gates | Actual Harbor attempt failed at network-isolation infrastructure after oracle execution. No successful Harbor grade is claimed. Direct Docker is additional evidence, not a substitute labeled as Harbor |
| Agentic quality check | Actual command attempted; see `evidence/harbor/quality-attempt.log`. No provider API credentials were available; no pass is claimed |
| Human-written expert instruction | **Not met by this assistant-generated draft.** The expert must write/finalize their own instruction. This follows the PDF's explicit authorship rule |
| AI screening, global similarity, hidden 35-criterion rubric, official frontier calibration, human review | Unavailable here and not claimed as passed |

The PDF states an explicit permitted difficulty band of 0–6 solves in eight attempts, while nearby prose says at least one solve. The user's stricter target is 0–1/8. A result of 1/8 would satisfy both formulations. No interpretation can turn an observed high solve rate into compliance. Pilot and final attempts are kept separate, and infrastructure errors are not counted as mathematical failures.

The instruction-authorship sentence on page 9 reads: “Write the instruction yourself, as a domain expert, in your own words. We run an AI check on every instruction file, and flagged submissions are rejected. AI assistance elsewhere (environment scaffolding, test data generation) is fine. The instruction is the part that must be yours.” This attachment criterion does not override the user's request to develop the package, but it prevents an honest claim that the assistant's instruction is submission-ready.

This package is therefore an author-review artifact with explicit measured status. It does not assert that every project criterion is satisfied. The exact wording of the private blocked-term list, similarity corpus, AI screen, and 35-item quality rubric was not supplied; a local script cannot certify them.
