#!/usr/bin/env python3
"""Verify vendored wheel hashes against the exact release's HTTPS PyPI metadata."""
import hashlib
import json
import urllib.request
from pathlib import Path
from email.parser import BytesParser
import zipfile

root = Path(__file__).resolve().parents[2]
inventory = json.loads((root/'authoring/provenance/wheels.json').read_text())
assert len(inventory)==9 and all((root/entry['path']).is_file() for entry in inventory), 'Restore dependencies first: python3 authoring/fetch_dependencies.py'
assert sorted(entry['path'] for entry in inventory)==sorted(str(p.relative_to(root)) for area in ('environment','tests') for p in (root/area/'wheels').glob('*.whl')), 'Wheel inventory mismatch; refusing to rewrite pins'
records = []
for area in ('environment', 'tests'):
    requirements = []
    for wheel in sorted((root / area / 'wheels').glob('*.whl')):
        with zipfile.ZipFile(wheel) as z:
            names = [n for n in z.namelist() if n.endswith('.dist-info/METADATA')]
            assert len(names) == 1
            meta = BytesParser().parsebytes(z.read(names[0]))
        name, version = meta['Name'], meta['Version']
        url = f'https://pypi.org/pypi/{name}/{version}/json'
        with urllib.request.urlopen(url, timeout=30) as response:
            release = json.load(response)
        published = next(item for item in release['urls'] if item['filename'] == wheel.name)
        digest = hashlib.sha256(wheel.read_bytes()).hexdigest()
        assert digest == published['digests']['sha256'], wheel
        records.append({'path': str(wheel.relative_to(root)), 'package': name,
                        'version': version, 'sha256': digest,
                        'metadata_source': url, 'artifact_source': published['url']})
        requirements.append(f'{name}=={version} --hash=sha256:{digest}')
    (root/area/'requirements.txt').write_text('\n'.join(requirements)+'\n')
(root/'authoring/provenance/wheels.json').write_text(json.dumps(records, indent=2)+'\n')
print(f'Verified {len(records)} wheel hashes against published PyPI release metadata')
