#!/usr/bin/env python3
"""Seeded data construction, independent of every solving/grading program.

The fixed pole strengths are an exact elliptic finite-gap construction. The
seed chooses the nonsingular curve scale, not a precomputed solution or score.
"""
import argparse
import json
import random
from pathlib import Path

SEED = 20261009
SCALES = [1, 2, 3, 5, 7, 11, 13]


def generate(seed=SEED):
    b = random.Random(seed).choice(SCALES)
    # 5(5+1) at infinity and 1(1+1) at the three nonzero two-torsion
    # points: sum_i wp(z+omega_i)=9*b*x/(x^3-b).
    return {'curve_b': b, 'coefficient_x': 30, 'pole_coefficient': 18*b}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=SEED)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    content = json.dumps(generate(args.seed), indent=2)+'\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content)
    else:
        print(content, end='')
