# Final separate-container validation

Compact-edition reproduction note: these retained results describe the original validated task. Docker builds now fetch the omitted wheels automatically; `python3 authoring/fetch_dependencies.py` prepares local Python tools. Exact URLs and hashes are preserved. The mathematical code and submitted trial artifacts are unchanged.

These are actual direct Docker runs, not Harbor or agent-difficulty trials. Reproduce with `python authoring/evidence/container_validate.py --evidence authoring/evidence/docker-final` from the task root. The runner rebuilds the images, audits their input hashes, and runs two reference solutions, one independent solution, and two empty submissions.

Both image builds used `docker build --network none`; pinned dependencies came from the vendored, hash-verified wheels. Every solver and verifier container also used `--network none`. The independent container installed the pinned FLINT wheel locally before running its separate implementation; the public agent image was unchanged.

Results: reference **2/2 reward 1**, independent **1/1 reward 1**, and no-op **2/2 reward 0**. All five CTRF reports completed without pending tests. The successful verifier runs took approximately 0.19–0.21 seconds; empty submissions failed because the required artifact was absent. Full wall times, image IDs, rewards, CTRF summaries and output hashes are in `summary.json` and the per-run `run.json` files.

`source_input_hashes.json` records the current instruction, build contexts, reference code and independent code. `image_input_audit.json` verifies the actual bytes in the images against the package. The current instruction was copied into each solver container and checked by hash; it is a harness input rather than a public image layer. The relevant source snapshot remained unchanged throughout validation. Python 3.12.15 ran both images; SymPy 1.14.0, FLINT 0.9.0 and pytest 8.4.1 were verified in their respective images.

The first build invocation failed before building because Docker Buildx tried to write state under the read-only `/home/agent/.docker` directory. `initial_build_state_failure.log` retains that infrastructure error. The runner now uses a temporary writable Docker configuration directory. Both subsequent builds and all five validation runs completed successfully. This initial build failure is not a mathematical or agent failure.
