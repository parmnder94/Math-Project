#!/usr/bin/env python3
"""Actual offline Docker fault injection for the verifier wrapper, not agent trials."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import time
import uuid

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def command(args, **kwargs):
    return subprocess.run(args, check=True, text=True, **kwargs)


def report(status="passed", count=1):
    counts = {key: 0 for key in ("passed", "failed", "skipped", "pending", "other")}
    if count:
        counts[status] = count
    return {"results": {"tool": {"name": "fault-injected-pytest"},
        "summary": {"tests": count, **counts, "start": 0, "stop": 0},
        "tests": [{"name": "injected", "status": status, "duration": 0} for _ in range(count)]}}


def main():
    HERE.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="kepler-wrapper-build-") as state:
        env = dict(os.environ, DOCKER_CONFIG=state)
        build = ["docker", "build", "--network", "none", "--progress", "plain",
                 "--tag", "kepler-elliptic-verifier:local", str(ROOT / "tests")]
        print(json.dumps({"event": "build_started", "command": build}), flush=True)
        with (HERE / "docker_build.log").open("w") as log:
            log.write("Command: " + json.dumps(build) + "\n")
            log.flush()
            command(build, env=env, stdout=log, stderr=subprocess.STDOUT)
    image = command(["docker", "image", "inspect", "--format", "{{.Id}}",
                     "kepler-elliptic-verifier:local"], capture_output=True).stdout.strip()
    wrapper_hash = hashlib.sha256((ROOT / "tests/test.sh").read_bytes()).hexdigest()
    verifier_hash = hashlib.sha256((ROOT / "tests/check_submission.py").read_bytes()).hexdigest()
    copied_hashes = json.loads(command(["docker", "run", "--rm", "--network", "none", image,
        "python", "-c", "import hashlib,json,pathlib; print(json.dumps({p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in ['/tests/test.sh','/tests/check_submission.py']}))"],
        capture_output=True).stdout)
    assert copied_hashes == {"/tests/test.sh": wrapper_hash, "/tests/check_submission.py": verifier_hash}
    inconsistent = report()
    inconsistent["results"]["tests"][0]["status"] = "failed"
    cases = [
        ("normal_oracle_artifact", None, 0, 1, False, 0),
        ("normal_missing_artifact", None, 1, 0, False, 1),
        ("pytest_crash_137", "kill -KILL \"$$\"\n", 137, 0, True, 137),
        ("pytest_zero_without_report", "exit 0\n", 1, 0, True, 0),
        ("pytest_zero_malformed_json", ("{", 0), 1, 0, True, 0),
        ("pytest_crash_with_passing_report", (json.dumps(report()), 137), 137, 0, True, 137),
        ("pytest_zero_inconsistent_summary", (json.dumps(inconsistent), 0), 1, 0, True, 0),
        ("pytest_zero_empty_test_report", (json.dumps(report(count=0)), 0), 1, 0, True, 0),
        ("pytest_zero_failed_report", (json.dumps(report("failed")), 0), 1, 0, False, 0),
        ("pytest_zero_skipped_report", (json.dumps(report("skipped")), 0), 1, 0, True, 0),
    ]
    outcomes = []
    for label, injection, expected_exit, expected_reward, expected_fallback, pytest_status in cases:
        dest = HERE / label
        dest.mkdir(exist_ok=True)
        container = "kepler-wrapper-" + uuid.uuid4().hex[:12]
        create = ["docker", "create", "--name", container, "--network", "none", "--cpus", "2",
                  "--memory", "4g"]
        if injection is not None:
            create.extend(["--env", "PATH=/fault:/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/bin:/sbin:/bin"])
        create.extend([image, "bash", "/tests/test.sh"])
        command(create, stdout=subprocess.DEVNULL)
        started = time.perf_counter()
        try:
            if label == "normal_oracle_artifact":
                command(["docker", "cp", str(ROOT / "authoring/evidence/reference-output.json"),
                         container + ":/app/output/centralizer.json"])
            if injection is not None:
                fault = dest / "fault"
                fault.mkdir(exist_ok=True)
                if isinstance(injection, tuple):
                    payload, status = injection
                    injection = "printf '%s\\n' " + shlex.quote(payload) + " > /logs/verifier/ctrf.json\nexit " + str(status) + "\n"
                stub = fault / "pytest"
                stub.write_text("#!/bin/bash\n" + injection)
                stub.chmod(0o755)
                command(["docker", "cp", str(fault), container + ":/fault"])
            with (dest / "container.log").open("w") as log:
                cli_status = subprocess.run(["docker", "start", "-a", container], text=True,
                                            stdout=log, stderr=subprocess.STDOUT).returncode
            state = json.loads(command(["docker", "inspect", "--format", "{{json .State}}", container],
                                       capture_output=True).stdout)
            network = command(["docker", "inspect", "--format", "{{.HostConfig.NetworkMode}}", container],
                              capture_output=True).stdout.strip()
            command(["docker", "cp", container + ":/logs/verifier/.", str(dest)])
            reward = int((dest / "reward.txt").read_text().strip())
            ctrf = json.loads((dest / "ctrf.json").read_text())
            wrapper = json.loads((dest / "wrapper_status.json").read_text())
            summary = ctrf["results"]["summary"]
            assert cli_status == state["ExitCode"] == expected_exit, (label, cli_status, state)
            assert reward == expected_reward, (label, reward)
            assert wrapper["pytest_exit_status"] == pytest_status, (label, wrapper)
            assert wrapper["fallback_report_written"] == expected_fallback, (label, wrapper)
            assert wrapper["accepted"] == bool(expected_reward), (label, wrapper)
            assert network == "none" and not state["OOMKilled"]
            assert summary["tests"] == 1 and summary["passed"] == expected_reward
            assert summary["failed"] == 1 - expected_reward
            assert len(ctrf["results"]["tests"]) == 1
            outcome = {"case": label, "container_exit_status": state["ExitCode"],
                "pytest_exit_status": pytest_status, "reward": reward,
                "fallback_report_written": expected_fallback, "ctrf": summary,
                "network_mode": network, "elapsed_seconds": time.perf_counter() - started,
                "all_expected": True}
            (dest / "result.json").write_text(json.dumps(outcome, indent=2) + "\n")
            outcomes.append(outcome)
            print(json.dumps(outcome), flush=True)
        finally:
            subprocess.run(["docker", "rm", "-f", container], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, check=False)
    assert hashlib.sha256((ROOT / "tests/test.sh").read_bytes()).hexdigest() == wrapper_hash
    assert hashlib.sha256((ROOT / "tests/check_submission.py").read_bytes()).hexdigest() == verifier_hash
    summary = {"scope": "Actual offline Docker verifier-wrapper fault injection, not agent calibration",
        "image_id": image, "base_image": (ROOT / "tests/Dockerfile").read_text().splitlines()[0],
        "test_sh_sha256": wrapper_hash, "check_submission_sha256": verifier_hash,
        "cases": len(outcomes), "all_expected_outcomes": True, "outcomes": outcomes}
    (HERE / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
