# Verifier wrapper fault injection

`run.py` rebuilt the current verifier from its digest-pinned Python base with build networking disabled, checked the actual wrapper and algebra-verifier file hashes in the image, and ran ten separate offline Docker cases. These are wrapper reliability checks, not agent-difficulty trials.

All ten cases matched the expected result:

| Case | pytest status | container status | reward |
|---|---:|---:|---:|
| Actual valid reference artifact | 0 | 0 | 1 |
| Actual missing artifact | 1 | 1 | 0 |
| Actual SIGKILL of the pytest stub | 137 | 137 | 0 |
| False success with no report | 0 | 1 | 0 |
| False success with malformed JSON | 0 | 1 | 0 |
| Crash with a syntactically valid passing report | 137 | 137 | 0 |
| False success with inconsistent summary/test results | 0 | 1 | 0 |
| False success with an empty test list | 0 | 1 | 0 |
| False success with a valid failed report | 0 | 1 | 0 |
| False success with only a skipped test | 0 | 1 | 0 |

The wrapper requires both pytest status zero and a valid, nonempty, entirely passing CTRF report before awarding reward one. Existing valid failure reports are retained; missing, malformed, empty, or misleading reports are replaced with a valid failure report. Original nonzero pytest exit codes are preserved. `wrapper_status.json` records whether a fallback report was necessary.

The normal oracle case exercises the actual mathematical verifier and passes. The no-op case fails for the required missing artifact. Fault cases replace only the `pytest` command inside their disposable containers through a private PATH directory; the public image, algebra verifier, and submitted artifacts are not altered by fault injection. Each case retains its injected stub where applicable, Docker log, CTRF, reward, wrapper diagnostic, and result record. `summary.json` records the exact rebuilt image ID and source hashes.
