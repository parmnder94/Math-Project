# Geometric monodromy of the Abel covering: exact independent certificate

The degree-eighteen cover α:C→B has C:W²=−h(E), genus four, and B:y²=4(x³−11), genus one. It sends the rational point at infinity of C to O on B. Its exact coordinate map and differential pullback are established independently by the Cantor computation.

## 1. Six distinct simple branch values

The pullback of the nonvanishing differential dx/y is

 α*(dx/y)=9(E³−120582)dE/W.

The three roots of E³−120582 are distinct and are not roots of h; each has two lifts on C. Each resulting zero of the pullback is simple, and there are no other zeros, so all six ramification indices are two. To determine whether the corresponding local monodromies are individual transpositions, one must also check that their branch **values** are distinct.

Reduction of the covering functions modulo E³−120582 gives

 X(E)=−(195908029/4747761216) E,
 Y(E,W)=(2523287022071/42507719813867616000) W,
 W²=−22103805403968750.

Both rational multipliers and W are nonzero. The three different E-values therefore give three different x-coordinates, and the two W signs above each give two different y-coordinates. Thus the six images are distinct. Every branch loop acts as exactly one transposition on the eighteen sheets.

## 2. An imprimitive block quotient would be an unramified elliptic factor

The complex analytic monodromy is transitive because C is connected. Suppose a nontrivial block system exists, with block size between two and seventeen. A transposition preserving this block system cannot exchange letters in two different blocks: the image of either block would share all but one of its elements with the original block, contrary to the disjoint-or-equal block condition. Every local transposition therefore fixes each block as a set. The induced connected cover of B on blocks is consequently unramified. Its compactification is a genus-one curve, and after selecting the point above O determined by infinity on C, the unramified map is an isogeny. Its degree is a nontrivial divisor of eighteen, hence is divisible by two or three.

This argument uses the fact that the six branch values are distinct; simple ramification points alone would not suffice if their images coincided.

## 3. Why excluding the canonical rational isogeny factor excludes all geometric ones

Let J=Jac(C), using infinity as basepoint. The map α induces a surjective homomorphism f:J→B defined over Q. Its identity-component kernel K⁰ is an abelian subvariety defined over Q. Define B'=J/K⁰, with the induced isogeny φ:B'→B. This factorization and its pointed lift β:C→B' are defined over Q.

It is maximal also after extending scalars to Qbar or C. Indeed, if α=ψ∘γ through any pointed isogeny ψ:T→B, the induced Jacobian homomorphism g:J→T satisfies f=ψg. Since ψ is finite, (ker g)⁰=(ker f)⁰=K⁰. Thus g descends to an isogeny B'→T, and ψ is a factor of φ. In particular, any nontrivial geometric unramified factor forces φ to be nontrivial. Since α=φβ, deg φ divides eighteen.

## 4. Exact finite-field certificate at p=229

The curves have good reduction at 229: the elliptic cubic is squarefree, and gcd(h,h')=1 modulo 229. The reduced rational X has coprime numerator and denominator and degree eighteen, so the displayed covering is nonconstant after reduction. The exact finite-field computation gives

 #B(F_229)=252,
 #B[2](F_229)=4,
 #B[3](F_229)=9.

The two points of C(F_229)

 P₁=(E,W)=(1,48),  P₂=(2,111)

have covering images

 Q₁=α(P₁)=(16,9),  Q₂=α(P₂)=(2,149).

Both Q_i have order 42. Their multiples are

 21Q₁=(202,0), 21Q₂=(46,0),
 14Q₁=(0,177), 14Q₂=(43,210).

The two displayed 2-torsion points are distinct and nonzero, and the two displayed 3-torsion points are independent (their order-three cyclic subgroups have different x-coordinates). Thus Q₁,Q₂ generate the full 2- and 3-primary quotients. Direct group enumeration also gives |<Q₁,Q₂>|=252, the whole target group.

For completeness, suppose the canonical isogeny φ were nontrivial. Both B and B' have good reduction at 229 because they are Q-isogenous, and φ has degree prime to 229. The pointed lift β extends at this prime: a morphism from the smooth model of C to the generic fiber of an abelian scheme extends by the Néron mapping property. Hence every α-image of an F_229-point belongs to φ(B'(F_229)).

Choose a prime l in {2,3} dividing deg φ. The kernel of the dual isogeny contains a subgroup H of order l in B[l]. Since B[l] is fully rational over F_229, H and the associated quotient isogeny θ:B→B/H are defined over F_229. Dualizing the factorization through H shows that φ factors through the dual θ^∨:B/H→B as its final isogeny. The kernel of θ^∨ is Cartier dual to H. Here the l-th roots of unity are rational (229≡1 modulo l), so this kernel has l rational points. Since isogenous elliptic curves over a finite field have equal cardinalities, the image θ^∨((B/H)(F_229)) has index l in B(F_229). Thus φ(B'(F_229)) lies in a proper subgroup of index divisible by l. This contradicts the two certified α-images generating all of B(F_229).

Therefore φ is trivial. No nontrivial geometric unramified factor exists, and the covering monodromy is primitive.

## 5. Monodromy conclusion

A primitive permutation group containing a transposition is the full symmetric group. One proof takes the graph whose edges are all conjugates of the transposition: its connected components form a block system, so primitivity makes the graph connected, and its edge transpositions generate the full symmetric group. Since the degree is eighteen, the geometric monodromy group is **S₁₈**.

This conclusion was not assumed during the finite-field search. A failure of the image points to generate the full primary quotients would have left isogeny compositeness possible. The actual exact certificate excludes it.

## Reproducibility and separation of implementations

`independent_monodromy.py` contains the exact small-field checker used by the independent solver. It uses only Python's standard library and works on the short-Weierstrass model v=y/2, v²=x³−11. It validates the independently discovered witness p=229 and the two source points every time; it does not import the reference implementation or verifier. It also confirms all thirty-six target 6-torsion points are rational, both coordinate rational functions retain their degrees and coprimeness modulo p, and the source curve has good reduction. The independent solver separately checks the exact characteristic-zero branch-value reductions using polynomial extended GCD over Q[E]. Its monodromy artifact stores only the required group order, prime, and source points.

The reference's prime/point search is a different production route; the independently found certificate was validated first on the original y²=4x³−44 model and then on the short-Weierstrass model. No finite-field point counts, torsion claims, or subgroup-generation claims are accepted on trust. The order reported is 18!=6402373705728000, deduced from the preceding geometric argument, rather than inferred from a finite-field Frobenius permutation.
