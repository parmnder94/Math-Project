# Independent geometric validation of the degree-18 Abel covering

Write d=x³−11, S=4d, N(E,x)=dF(E,x), V=EW and W²=−h(E), where P(E)=E²h(E). Work initially over the generic field Q(E,V). Since N has degree eight in x and is squarefree over this field, the equation

 t₀(x)=−2d(x)·N_x(E,x)^−1 mod N(E,x)

is well defined. The eight selected points P_i=(x_i,y_i) satisfy y_i=Vt₀(x_i), equivalently y_iN_x(E,x_i)=−2Vd(x_i). The spectral identity evaluated at F=0 gives S(x_i)=−Pt₀(x_i)². Thus N divides −Pt₀²−S exactly.

The function F has pole divisor 10O+2T₁+2T₂+2T₃ as an elliptic function; its numerator representation has eight x-roots selecting one point above each x. The corresponding Baker–Akhiezer half-divisor has pole divisor 5O+T₁+T₂+T₃ of degree eight. The Abel sum of this fixed pole divisor is zero because T₁+T₂+T₃=O in the elliptic group. Thus subtracting that pole divisor introduces no translation: the requested covering is α=Σ_iP_i with the group law's identity O. The varying sum α itself is not zero.

## Cantor reduction and its sign

Start U₀=N/lc_x(N), t₀ as above. At each step compute

 U_next = monic((−Pt²−S)/U),
 t_next = −t mod U_next.

The quotient is exact, and direct FLINT rational-function arithmetic obtains the degrees 8→6→4→2→1. The function y−Vt has divisor consisting of the current points and the complementary intersections, minus its pole divisor at O. Thus their elliptic sums are opposites. Negating the y-coordinate of each complementary intersection preserves the desired divisor class; this is the explicit minus sign in t_next. At the final step U=x−X(E), t=T(E) is constant in x, giving

 α(E,W)=(X(E), V T(E))=(X(E), W·E T(E)).

The exact calculated identity is −P(E)T(E)²=4X(E)³−44. The reduced numerator and denominator degrees of X(E) are 18 and 17. Its denominator, up to a nonzero rational scalar, factors as

 E²(E³−551232)(E⁶+902286E³−836509234176)².

The integrated exact computation is `abel_cover_from_pencil` in `independent.py`; its output coordinates are in `independent-output.json`. That solver recomputes the divisor from the public input. The separate-container log records the runtime of the complete independent solution.

## Agreement with the Hermite interpolation certificate

Suppose a(x),b(x) have degrees at most four and three, with b having nonzero cubic coefficient, and satisfy N_x a−2db=0 mod N. Then f=Va+yb vanishes at every P_i. Its pole at O has order nine; its ninth zero R therefore satisfies Σ_iP_i+R=O, so R=−α. The norm identity

 −Pa²−Sb²=c(E)N(E,x)(x−X(E))

fixes the common x-coordinate. Since f(X,−Y)=0, the sign is Y=Va(X)/b(X). This is the same α as the Cantor result, not its negative or an unspecified torsion translate. Equality follows from the divisor class construction; direct equality of rational functions is an additional independent computational check when the interpolation output is available.

## Degree and global regularity

The exact curve identity gives a nonconstant map of function fields from the target elliptic curve to the smooth normalization C:W²=−h(E). A rational map from a smooth projective curve to a projective smooth curve extends uniquely at every apparent affine pole. Consequently the formulas define a morphism everywhere, including E=0 and infinity; no generic-point restriction remains in the final statement.

The hyperelliptic map E:C→P¹ has degree two, and the reduced rational function X(E) has degree eighteen. Hence X∘E has degree thirty-six. The target elliptic x-coordinate map has degree two, so deg(α)=36/2=18.

For a further check, the fiber over O consists of the unique point at infinity; the two points over E=0; the three branch points with E³=551232; and the twelve points over the six roots of E⁶+902286E³−836509234176. At all these points X has a pole of order two, so α is unramified there. The fiber contains eighteen points, as required.

## Pullback and all ramification

Differentiating the rational expression gives the exact identity

 α*(dx/y) = X'(E)/(E T(E)) · dE/W
           = 9(E³−120582) dE/W.

On the genus-four odd-degree hyperelliptic curve, dE/W has a zero of order six at infinity and no other zero or pole. Multiplication by the degree-three polynomial cancels this order-six zero at infinity. Its three distinct roots are not roots of h, so each lifts to two points, and the pullback has precisely six simple zeros. Because dx/y is nowhere vanishing on the elliptic target, these are exactly the ramification points, each with ramification index two. There is no ramification elsewhere. Total ramification six agrees with Riemann–Hurwitz: 2·4−2=18(2·1−2)+6.

## Distinguishing the required physical spectral cover from an incidental quotient

Since h(E) is a cubic polynomial H(E³), the normalized curve also has an immediate degree-three elliptic quotient β(E,W)=(E³,W), with equation W²=−H(z). Finding this quotient does not solve the Abel-cover reconstruction: it has a different target curve and a different divisor-class meaning. For a cube root of unity ζ, β(ζE,W)=β(E,W), whereas the required map satisfies X(ζE)=ζX(E) and Y(ζE,W)=Y(E,W), so α(ζE,W) is the image of α(E,W) under the nontrivial complex-multiplication automorphism (x,y)↦(ζx,y) of the target. In particular α does not factor through β. The degree-eighteen Abel map tracks the sum of the selected Baker–Akhiezer divisor points and therefore recovers their Bloch/elliptic phase; the obvious quotient alone does not recover that phase.

The computed Cantor X and Y/W were compared exactly, by rational-function subtraction over Q(E), with the independently constructed Hermite-interpolation expressions. Both differences are identically zero, including the y-coordinate sign. The comparison results are saved in `cover_independent_comparison.json`. The integrated independent solver recomputes the pencil vector and the Cantor reduction from the public input and does not read the interpolation output.
