#!/usr/bin/env python3
"""Independent exact solution by the global-pole-bounded squared-eigenfunction pencil.
No imports from solution/ or tests/.  SymPy solves the rational pencil; a separate
small FLINT rational/Ore implementation expands the delivered differential operator.
"""
import argparse, json, math, time
from pathlib import Path
import sympy as sp
from flint import fmpq_poly, fmpq

class RF:
    __slots__=('n','d')
    def __init__(self,n=0,d=1):
        if isinstance(n,RF): self.n,self.d=n.n,n.d; return
        self.n=n if isinstance(n,fmpq_poly) else fmpq_poly(n if isinstance(n,list) else [fmpq(n) if isinstance(n,str) else n])
        self.d=d if isinstance(d,fmpq_poly) else fmpq_poly(d if isinstance(d,list) else [d])
        if not self.d: raise ZeroDivisionError('zero rational-function denominator')
        if not self.n: self.d=fmpq_poly([1]); return
        g=self.n.gcd(self.d); self.n//=g;self.d//=g
        lead=self.d.leading_coefficient(); self.n/=lead; self.d/=lead
    def __add__(self,o):
        o=RF(o);return RF(self.n*o.d+o.n*self.d,self.d*o.d)
    __radd__=__add__
    def __neg__(self):return RF(-self.n,self.d)
    def __sub__(self,o):return self+-RF(o)
    def __rsub__(self,o):return RF(o)+-self
    def __mul__(self,o):
        o=RF(o);return RF(self.n*o.n,self.d*o.d)
    __rmul__=__mul__
    def __truediv__(self,o):
        o=RF(o);return RF(self.n*o.d,self.d*o.n)
    def __bool__(self):return bool(self.n)
    def diff(self):return RF(self.n.derivative()*self.d-self.n*self.d.derivative(),self.d*self.d)
    def dump(self):
        cs=list(self.n)+list(self.d); z=1
        for c in cs:z=math.lcm(z,int(c.q))
        return {'num':[int(c*z) for c in self.n] or [0], 'den':[int(c*z) for c in self.d]}

def from_expr(f,x):
    n,d=sp.fraction(sp.cancel(f))
    def poly(z):
        p=sp.Poly(z,x); return fmpq_poly([fmpq(str(p.nth(i))) for i in range(p.degree()+1)]) if z else fmpq_poly([])
    return RF(poly(n),poly(d))

class Ore:
    def __init__(self,b):
        self.S=RF([-4*b,0,0,4]);self.half_Sprime=RF([0,0,6]);self.zero=(RF(),RF());self.one=(RF(1),RF())
    def add(self,a,b):return (a[0]+b[0],a[1]+b[1])
    def neg(self,a):return (-a[0],-a[1])
    def mul(self,a,b):return (a[0]*b[0]+self.S*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
    def scale(self,a,k):return (a[0]*k,a[1]*k)
    def inverse(self,a):
        d=a[0]*a[0]-self.S*a[1]*a[1];return (a[0]/d,-a[1]/d)
    def deriv(self,a):return (self.S*a[1].diff()+self.half_Sprime*a[1],a[0].diff())
    def trim(self,a):
        while len(a)>1 and not (a[-1][0] or a[-1][1]):a.pop()
        return a
    def opadd(self,a,b):return self.trim([self.add(a[i] if i<len(a) else self.zero,b[i] if i<len(b) else self.zero) for i in range(max(len(a),len(b)))])
    def opneg(self,a):return [self.neg(t) for t in a]
    def opmul(self,a,b):
        ans=[self.zero]*(len(a)+len(b)-1)
        for j,bj in enumerate(b):
            ds=[bj]
            for k in range(1,len(a)):ds.append(self.deriv(ds[-1]))
            for i,ai in enumerate(a):
                if not (ai[0] or ai[1]):continue
                for k in range(i+1):
                    if ds[k][0] or ds[k][1]:ans[i+j-k]=self.add(ans[i+j-k],self.scale(self.mul(ai,ds[k]),math.comb(i,k)))
        return self.trim(ans)
    def opeval(self,p,L):
        ans=[self.zero]
        for c in reversed(p):ans=self.opadd(self.opmul(ans,L),[(RF(c),RF())])
        return ans
    def divide(self,a,b):
        r=list(a);q=[self.zero]*max(1,len(a)-len(b)+1)
        while len(r)>=len(b) and any(z[0] or z[1] for z in r):
            k=len(r)-len(b);c=self.mul(r[-1],self.inverse(b[-1]));q[k]=self.add(q[k],c)
            t=[self.zero]*k+[c];r=self.opadd(r,self.opneg(self.opmul(t,b)))
        return self.trim(q),self.trim(r)
    def dump(self,a):return [{'a':z[0].dump(),'b':z[1].dump()} for z in a]

def abel_cover_from_pencil(vec,b,P,genus):
    """Genus-one Cantor reduction of the selected degree-eight divisor.
    vec is the primitive pencil vector over Q(E). All x-polynomial arithmetic
    here uses independently implemented long division over FLINT RFs in E.
    """
    zero=RF();one=RF(1)
    def trim(a):
        while len(a)>1 and not a[-1]:a.pop()
        return a
    def add(a,z):return trim([(a[i] if i<len(a) else zero)+(z[i] if i<len(z) else zero) for i in range(max(len(a),len(z)))])
    def neg(a):return [-v for v in a]
    def sub(a,z):return add(a,neg(z))
    def scale(a,c):return trim([v*c for v in a])
    def mul(a,z):
        c=[zero]*(len(a)+len(z)-1)
        for i,u in enumerate(a):
            if u:
                for j,v in enumerate(z):
                    if v:c[i+j]+=u*v
        return trim(c)
    def divide(a,z):
        a=list(a);q=[zero]*max(1,len(a)-len(z)+1)
        while len(a)>=len(z) and any(a):
            i=len(a)-len(z);v=a[-1]/z[-1];q[i]+=v
            for j,w in enumerate(z):a[i+j]-=v*w
            trim(a)
        return trim(q),trim(a)
    def rem(a,z):return divide(a,z)[1]
    def inverse(a,z):
        oldr,r=z,a;oldc,c=[zero],[one]
        while any(r):
            q,rr=divide(oldr,r);oldr,r=r,rr;oldc,c=c,sub(oldc,mul(q,c))
        assert len(oldr)==1 and oldr[0]
        return scale(oldc,one/oldr[0])
    def monic(a):return scale(a,one/a[-1])
    d=[RF(-b),zero,zero,one];S=scale(d,RF(4))
    N=add(mul(vec[:6],d),vec[6:]);Nx=[N[i]*i for i in range(1,len(N))]
    U=monic(N);t=rem(scale(mul(d,inverse(Nx,N)),RF(-2)),N)
    degrees=[len(U)-1]
    while len(U)>2:
        numerator=sub(scale(mul(t,t),-P),S);Un,rr=divide(numerator,U)
        assert not any(rr)
        Un=monic(Un);t=rem(neg(t),Un);U=Un;degrees.append(len(U)-1)
    assert degrees==[8,6,4,2,1] and len(t)==1
    X=-U[0];Y=RF([0,1])*t[0]
    h=P/RF([0,0,1]);assert not (-h*Y*Y-(4*X*X*X-4*b))
    pullback=X.diff()/Y
    assert pullback.d.degree()==0
    ramification=pullback/RF(pullback.n.leading_coefficient())
    degree=max(X.n.degree(),X.d.degree())
    infinity_order=2*genus-2-2*pullback.n.degree()
    assert degree==18 and infinity_order==0
    assert not (pullback-RF([-1085238,0,0,9]))
    return {'x':X.dump(),'y_multiplier':Y.dump(),'degree':degree,'pullback':pullback.dump(),'ramification_polynomial':ramification.dump(),'infinity_ramification_order':infinity_order}

def solve(data):
    b=int(data['curve_b']); c=int(data['coefficient_x']); p=int(data['pole_coefficient'])
    x,E=sp.symbols('x E'); S=4*(x**3-b);u=c*x+p*x/(x**3-b)
    basis=[x**i for i in range(6)]+[x**i/(x**3-b) for i in range(3)]
    def T(f):return S*sp.diff(f,x,3)+sp.Rational(3,2)*sp.diff(S,x)*sp.diff(f,x,2)+(sp.diff(S,x,2)/2-4*u+4*E)*sp.diff(f,x)-2*sp.diff(u,x)*f
    cols=[sp.Poly(sp.cancel(T(f)*(x**3-b)**3),x) for f in basis]
    M=sp.Matrix([[p.nth(i) for p in cols] for i in range(max(p.degree() for p in cols)+1)])
    ns=M.nullspace();assert len(ns)==1
    den=sp.lcm([sp.denom(sp.cancel(z)) for z in ns[0]])
    vec=[sp.cancel(z*den) for z in ns[0]];gcd=sp.gcd_list(vec);vec=[sp.cancel(z/gcd) for z in vec]
    F=sp.cancel(sum(z*f for z,f in zip(vec,basis)))
    lead=sp.Poly(sp.numer(F),E).LC()/sp.denom(F);F=sp.cancel(F/lead);vec=[sp.cancel(z/lead) for z in vec]
    degree=int(sp.degree(sp.numer(F),E));assert degree==5
    assert sp.cancel(T(F))==0
    DD=sp.diff(F,x,2)*S+sp.diff(F,x)*sp.diff(S,x)/2
    P=sp.cancel((E-u)*F**2+F*DD/2-S*sp.diff(F,x)**2/4)
    assert not P.has(x)
    factors=sp.factor_list(P,E)[1];q=sp.prod(f**(m//2) for f,m in factors);q=sp.Poly(q,E).monic().as_expr();h=sp.cancel(P/q**2)
    assert sp.gcd(h,sp.diff(h,E))==1
    coeffs=[sp.cancel(sp.diff(F,E,j).subs(E,0)/sp.factorial(j)) for j in range(degree+1)]
    calc=Ore(b);L=[(from_expr(u,x),RF()),calc.zero,(RF(-1),RF())]
    powers=[[calc.one]]
    for j in range(degree):powers.append(calc.opmul(powers[-1],L))
    A=[calc.zero]
    for j,f in enumerate(coeffs):
        r=from_expr(f,x);first=[(RF(),-r.diff()/2),(r,RF())]
        A=calc.opadd(A,calc.opmul(first,powers[j]))
    if degree%2:A=calc.opneg(A)
    def pc(poly):return [str(sp.Poly(poly,E).nth(i)) for i in range(sp.degree(poly,E)+1)]
    divisor=calc.opeval(pc(q),L);Q,R=calc.divide(A,divisor)
    assert len(A)==12 and not A[-1][1] and not (A[-1][0]-1)
    assert len(R)<len(divisor) and any(a or z for a,z in R)
    def iszero(op):return all(not (a or z) for a,z in op)
    assert iszero(calc.opadd(calc.opmul(A,L),calc.opneg(calc.opmul(L,A))))
    assert iszero(calc.opadd(calc.opmul(A,A),calc.opeval(pc(P),L)))
    assert iszero(calc.opadd(A,calc.opneg(calc.opadd(calc.opmul(Q,divisor),R))))
    adjoint=[calc.zero];signed_power=[calc.one];minus_D=[calc.zero,(RF(-1),RF())]
    for ai in A:
        adjoint=calc.opadd(adjoint,calc.opmul(signed_power,[ai]));signed_power=calc.opmul(signed_power,minus_D)
    assert iszero(calc.opadd(A,adjoint))
    out={'operator':calc.dump(A),'spectral_polynomial':from_expr(P,E).dump(),'square_factor':from_expr(q,E).dump(),'normalized_polynomial':from_expr(h,E).dump(),'genus':(int(sp.degree(h,E))-1)//2,'quotient':calc.dump(Q),'remainder':calc.dump(R)}
    out['cover']=abel_cover_from_pencil([from_expr(z,E) for z in vec],b,from_expr(P,E),out['genus'])
    from independent_monodromy import build_certificate
    out['monodromy']=build_certificate(out,RF)
    M0=M.subs(E,0);_,ci=M0.rref();N=M0[:,list(ci)];_,ri=N.T.rref();det=N[list(ri),:].det()
    cert={'method':'global meromorphic pole bounds followed by a rational matrix pencil','curve_b':b,'basis':['1','x','x^2','x^3','x^4','x^5','1/(x^3-b)','x/(x^3-b)','x^2/(x^3-b)'],'matrix_definition':'rows: coefficients x^i; columns: (x^3-b)^3 T_E(basis_j)','matrix_shape':list(M.shape),'specialization_E':0,'minor_rows':list(ri),'minor_columns':list(ci),'minor_determinant':str(det),'primitive_nullvector':[from_expr(z,E).dump() for z in vec],'nonzero_constant_component_index':5,'nonzero_constant_component':str(vec[5]),'polynomial_degree_E':degree,'minimal_odd_order':2*degree+1}
    assert det and vec[5].is_number and vec[5]!=0
    return out,cert

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',required=True);ap.add_argument('--output',required=True);ap.add_argument('--certificate');args=ap.parse_args()
    t=time.perf_counter();out,cert=solve(json.loads(Path(args.data).read_text()));Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
    if args.certificate:Path(args.certificate).write_text(json.dumps(cert,indent=2)+'\n')
    print(json.dumps({'status':'passed','method':'independent rational pencil','elapsed_seconds':round(time.perf_counter()-t,3),'operator_order':len(out['operator'])-1,'normalization_genus':out['genus'],'output':args.output}))
if __name__=='__main__':main()
