#!/usr/bin/env python3
"""Run the installed Harbor CLI with only its cache redirected to a writable path.

Harbor0.24 hardcodes ~/.cache/harbor and this cloud machine mounts that home
read-only. Task loading, agents, containers, artifact collection, and grading
are untouched. This is a local infrastructure adapter, not a verifier wrapper.
"""
import os
from pathlib import Path
import harbor.constants as constants
cache = Path(os.environ.get('KEPLER_HARBOR_CACHE', '/workspace/kepler-tools/harbor-cache'))
constants.CACHE_DIR = cache
constants.TASK_CACHE_DIR = cache/'tasks'
constants.PACKAGE_CACHE_DIR = cache/'tasks/packages'
constants.DATASET_CACHE_DIR = cache/'datasets'
constants.NOTIFICATIONS_PATH = cache/'notifications.json'
from harbor.cli.main import app
if __name__ == '__main__':
    app()
