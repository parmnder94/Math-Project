import operators as m
import json, os
p='/app/output/centralizer.json'
with open(p) as f: data=json.load(f)
assert set(data)=={'operator','spectral_polynomial','square_factor','normalized_polynomial','genus','quotient','remainder'}
assert os.path.getsize(p)<=2097152

def decfrac(v):
    assert set(v)=={'num','den'}
    assert 0<len(v['den'])<=129 and len(v['num'])<=129
    for k in ['num','den']:
        assert all(type(n) is int and abs(n)<2**2048 for n in v[k])
    a=sum(m.K(n)*m.x**i for i,n in enumerate(v['num']))
    b=sum(m.K(n)*m.x**i for i,n in enumerate(v['den']))
    assert b
    return a/b

def decop(v):
    assert len(v)<=33
    out=[]
    for a in v:
        assert set(a)=={'a','b'}
        out.append((decfrac(a['a']),decfrac(a['b'])))
    return m.trim(out)
for name,expected in [('operator',m.A),('quotient',m.Q),('remainder',m.R)]:
    assert decop(data[name])==expected
for name,expected in [('spectral_polynomial',m.P),('square_factor',m.q),('normalized_polynomial',m.h)]:
    assert decfrac(data[name])==m.co(expected.subs(m.E,m.sx))
assert type(data['genus']) is int and data['genus']==4
print('Saved artifact decodes exactly and satisfies all shape/size bounds.')
