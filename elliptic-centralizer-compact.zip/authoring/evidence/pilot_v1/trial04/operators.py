import sympy as s, pickle, json, math, time
from sympy.polys.fields import field
with open('/app/computed.pkl','rb') as h: sx,E,sr,su,fs,dfs,c,fg,F,P,g,M=pickle.load(h)
K,x=field('x',s.QQ); r=x**3-11; z=K.zero; one=K.one

def co(e): return K.from_expr(e)
def ka(a=z,b=z): return (K(a),K(b))
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def neg(a): return (-a[0],-a[1])
def mul(a,b): return (a[0]*b[0]+4*r*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,c): return (a[0]*c,a[1]*c)
def der(a): return (4*r*a[1].diff(x)+6*x*x*a[1],a[0].diff(x))
zero=(z,z)
def trim(A):
    while A and A[-1]==zero: A.pop()
    return A

def opadd(A,B): return trim([add(A[i] if i<len(A) else zero,B[i] if i<len(B) else zero) for i in range(max(len(A),len(B)))])
def opneg(A): return [neg(a) for a in A]
def opscale(A,c): return trim([scale(a,c) for a in A])
def compose(A,B):
    if not A or not B: return []
    ders=[]
    for b in B:
        ds=[b]
        for k in range(len(A)-1): ds.append(der(ds[-1]))
        ders.append(ds)
    C=[zero]*(len(A)+len(B)-1)
    for i,a in enumerate(A):
        if a==zero: continue
        for j in range(len(B)):
            for k in range(i+1):
                if ders[j][k]==zero: continue
                n=i+j-k
                C[n]=add(C[n],scale(mul(a,ders[j][k]),math.comb(i,k)))
    return trim(C)
def adjoint(A):
    C=[zero]*len(A)
    for i,a in enumerate(A):
        ds=a
        for k in range(i+1):
            C[i-k]=add(C[i-k],scale(ds,(-1)**i*math.comb(i,k)))
            ds=der(ds)
    return trim(C)
def polynomial(p,L):
    coeff=s.Poly(p,E).all_coeffs(); C=[]
    for a in coeff: C=opadd(compose(C,L),[ka(K(s.Rational(a)))])
    return C

def rf(v):
    # Normalize rational coefficients to integral polynomials.
    n,d=v.numer,v.denom
    den=1
    for pol in [n,d]:
        for coeff in pol.values(): den=s.ilcm(den,int(s.denom(coeff)))
    def arr(pol):
        if not pol: return []
        return [int(pol.get((i,),0)*den) for i in range(pol.degree()+1)]
    return {'num':arr(n),'den':arr(d)}
def enc(A): return [{'a':rf(a),'b':rf(b)} for a,b in A]
def rfe(p):
    coeff=s.Poly(p,E)
    den=s.ilcm(*[s.denom(a) for a in coeff.all_coeffs()])
    return {'num':[int(coeff.nth(i)*den) for i in range(coeff.degree()+1)],'den':[int(den)]}

L=[ka(co(su)),zero,ka(-1)]
blocks=[]
for f in fg:
    k=ka(co(f))
    blocks.append([scale(der(k),s.Rational(-1,2)),k])
B=blocks[0]
for j in range(1,g+1):
    if j==g: Q=opneg(B)
    B=opadd(compose(B,L),blocks[j])
A=opneg(B); R=opneg(blocks[-1]); q=E; h=s.cancel(P/E**2)
assert A[-1]==ka(1)
print('A,Q,R orders',len(A)-1,len(Q)-1,len(R)-1,flush=True)
print('R',[(a.as_expr(),b.as_expr()) for a,b in R],flush=True)
t0=time.time()
assert opadd(A,adjoint(A))==[]
print('Skew adjoint OK',time.time()-t0,flush=True)
assert opadd(compose(A,L),opneg(compose(L,A)))==[]
print('Commutation OK',time.time()-t0,flush=True)
assert opadd(A,opneg(opadd(compose(Q,L),R)))==[]
print('Right division OK',time.time()-t0,flush=True)
assert s.gcd(h,s.diff(h,E))==1
assert s.expand(P-q*q*h)==0
assert s.Poly(P,E).LC()==s.Poly(h,E).LC()==s.Poly(q,E).LC()==1
print('Spectral factorization and squarefreeness OK',flush=True)
assert opadd(compose(A,A),polynomial(P,L))==[]
print('Spectral operator relation OK',time.time()-t0,flush=True)
result={'operator':enc(A),'spectral_polynomial':rfe(P),'square_factor':rfe(q),'normalized_polynomial':rfe(h),'genus':4,'quotient':enc(Q),'remainder':enc(R)}
with open('/app/output/centralizer.json','w') as f: json.dump(result,f,separators=(',',':')); f.write('\n')
print('Saved /app/output/centralizer.json',flush=True)
