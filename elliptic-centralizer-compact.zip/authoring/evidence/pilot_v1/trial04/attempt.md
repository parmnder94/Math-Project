# Exact attempt and reproducibility

I used only `/instruction.md`, `/app/data/README.md`, and `/app/data/operator.json` as input. All calculations were carried out with Python and SymPy inside the assigned container. No online source, hidden grader, other container, other agent, or host task file was used.

The output is `/app/output/centralizer.json`. The exact calculation and checks can be reproduced by running:

```
python /app/solve.py
python /app/operators.py
python /app/verify_encoding.py
```

`solve.py` writes the intermediate symbolic data `/app/computed.pkl`. `operators.py` builds the operators, verifies the identities, and writes the output. `verify_encoding.py` reruns that computation and confirms that the saved JSON decodes to precisely the checked mathematical objects and satisfies all serialization bounds.

## Construction

Put r=x^3-11 and u=30x+198x/r. Starting with f_0=1, construct the canonical stationary KdV densities using the formal identity

(E-u)F^2 + (1/2) F D^2(F) - (1/4) D(F)^2 = E,

where F=1+sum_{n>=1} f_n E^{-n}. Comparing successive coefficients determines f_n algebraically, with no integration ambiguity. These densities obey

D(f_{j+1})=u D(f_j)+(1/2)D(u)f_j-(1/4)D^3(f_j).

The first linear dependence is

D(f_6)-552123 D(f_3)=0.

Take g=5 and c_0=1, c_3=-552123, all the other c_j=0. The stationary coefficients a_j=sum_{k=0}^j c_k f_{j-k}, for j=0,...,5, are

```
a_0=1
a_1=3x(5x^3-22)/r
a_2=63x^2(5x^3+11)/r
a_3=63(100x^6-7414x^3+96679)/r
a_4=3969x(5x^3-121)(5x^3-88)/r
a_5=35721x^2(5x^3-88)^2/r.
```

The monic operator in the output is

A=-sum_{j=0}^5 (a_j D - (1/2)D(a_j)) L^{5-j}.

Its order is 11. The minus sign makes it monic because the leading coefficient of D L^5 is -1.

## Global minimality

The derivation constants of Q(x,y) are exactly Q. Indeed, D(a+yb)=0 implies a'=0 and 4r b'+6x^2 b=0. A nonzero solution of the latter equation would satisfy b^2 r=constant, impossible for rational b because r has simple roots.

For any odd-order commuting operator, its formally skew part has the same odd order and leading coefficient. Coefficient comparison after expansion in the basis D L^j, L^j gives the stationary recurrence above, with rational integration constants. Thus an operator of order 2m+1 exists only if D(f_{m+1}) is a constant linear combination of D(f_1),...,D(f_m). This argument covers all of K; it assumes no denominator or polynomial ansatz.

In this instance the rational x-derivatives f_1',...,f_5' are linearly independent. They have common denominator r^2, with numerator degrees 6,7,8,9,10 and respective leading coefficients 15,630,18900,396900,4465125. Their strictly increasing degrees prove independence. Multiplication by nonzero y transfers this independence to D(f_j). The computed relation at f_6 is therefore the first relation, proving the smallest odd order is 11.

## Spectral polynomial and normalization

For F(E,x)=sum_{j=0}^5 a_j E^{5-j}, the invariant

P=(E-u)F^2 + (1/2)F D^2(F) - (1/4)D(F)^2

is independent of x and equals

P(E)=E^2(E^3-551232)(E^6-553014E^3+816903549)

= E^11 -1104246E^8 +305655916797E^5 -450303377122368E^2.

The exact operator calculation also verifies A^2+P(L)=0. The greatest monic square divisor is q^2=E^2, so q=E. The normalized polynomial is

h(E)=E^9-1104246E^6+305655916797E^3-450303377122368.

Exact polynomial gcd gives gcd(h,h')=1. Its degree is 9, so the smooth projective curve W^2+h(E)=0 has geometric genus 4.

## Right division

Because q(L)=L, the right quotient and remainder are directly

Q=-sum_{j=0}^4 (a_j D-(1/2)D(a_j))L^{4-j},

R=-(a_5 D-(1/2)D(a_5)).

The saved arrays have orders 9 and 1. Since a_5 is nonzero, R is nonzero. Consequently the normalized spectral generator A/q(L) is not a differential operator in K[D].

## Exact checks and errors encountered

The operator arithmetic uses pairs of exact elements of Q(x), with y^2=4r. Composition implements the full binomial Leibniz rule. The following checks passed:

- A is monic of order 11.
- A+A*=0.
- AL-LA=0.
- A^2+P(L)=0.
- A=QL+R and ord(R)=1<2.
- P=q^2 h, all three polynomials are monic, and gcd(h,h')=1.
- The JSON's seven fields, integral coefficients, denominator validity, array lengths, byte size, and integer size bounds are valid.
- Decoding the artifact produces exactly the checked operators and polynomials.

One nonmathematical error occurred on the first run of `operators.py`: after the JSON was successfully written, an optional attempt to pickle SymPy fraction-field operator objects raised `RuntimeError: dictionary changed size during iteration`. That unnecessary pickle operation was removed, and the complete script was rerun successfully. The output artifact and its exact checks were unaffected. No mathematical check failed.
