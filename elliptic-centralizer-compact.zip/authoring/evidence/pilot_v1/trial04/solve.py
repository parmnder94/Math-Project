import sympy as s, json, pickle, time
x,E=s.symbols('x E'); r=x**3-11; u=30*x+198*x/r
can=s.cancel
u=can(u)
def d2(f): return can(4*r*s.diff(f,x,2)+6*x*x*s.diff(f,x))
f=[s.S.One]; df=[s.S.Zero]; ddf=[s.S.Zero]
for n in range(1,13):
    t0=time.time()
    value=u*sum(f[i]*f[n-1-i] for i in range(n))
    value-=sum(f[i]*f[n-i] for i in range(1,n))
    value-=sum(f[i]*ddf[n-1-i] for i in range(n))/2
    value+=r*sum(df[i]*df[n-1-i] for i in range(n))
    fn=can(value/2); f.append(fn); df.append(can(s.diff(fn,x))); ddf.append(d2(fn))
    print('f',n,'degrees', tuple(s.degree(a,x) for a in s.fraction(fn)), 'time',time.time()-t0,flush=True)
    denom=s.lcm([s.denom(v) for v in df[1:]])
    polys=[s.Poly(can(v*denom),x) for v in df[1:]]
    deg=max(p.degree() for p in polys)
    M=s.Matrix([[p.nth(k) for p in polys] for k in range(deg+1)])
    null=M.nullspace()
    if null:
        rel=null[0]; print('DEPENDENCE',n,list(rel),flush=True)
        g=n-1
        c=[s.S.One]+list(reversed(list(rel[:-1]/rel[-1]))) if False else [s.S.One]+[rel[n-1-j]/rel[-1] for j in range(1,n)]
        print('g,c',g,c,flush=True)
        fg=[can(sum(c[j]*f[k-j] for j in range(k+1))) for k in range(g+1)]
        F=sum(fg[j]*E**(g-j) for j in range(g+1))
        # squared eigenfunction spectral invariant
        P=can((E-u)*F**2+F*d2(F)/2-r*s.diff(F,x)**2)
        print('P=',s.factor(P),flush=True)
        with open('/app/computed.pkl','wb') as h: pickle.dump((x,E,r,u,f,df,c,fg,F,P,g,M),h)
        break
