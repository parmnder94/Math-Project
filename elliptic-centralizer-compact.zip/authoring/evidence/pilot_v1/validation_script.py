#!/usr/bin/env python3
"""Reproduce exact acceptance, mutation and parser checks without containers.

Run from any directory with the task's pinned python-flint installed:
  python authoring/evidence/validate.py
The two input artifacts were produced by distinct implementations. This file
imports only the verifier, never either solver; mathematical mutations are
checked for their intended error, not merely any rejection.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "tests"))
import check_submission as c
import flint


def rf_json(value):
    return {"num": [int(v * value.d.denom()) for v in value.n.numer().coeffs()],
            "den": [int(v * value.n.denom()) for v in value.d.numer().coeffs()]}


def operator_json(values):
    return [{"a": rf_json(v.a), "b": rf_json(v.b)} for v in values]


def multiply(a, b):
    if not a or not b:
        return []
    values = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            values[i + j] += x * y
    return values


def main():
    results = []

    def record(name, action, expected, reason=""):
        start = time.perf_counter()
        try:
            metrics = action()
            accepted, error = True, ""
        except c.VerificationError as exc:
            accepted, error, metrics = False, str(exc), None
        elapsed = time.perf_counter() - start
        assert accepted == expected, (name, accepted, expected, error)
        if reason:
            assert reason in error, (name, reason, error)
        results.append({"name": name, "accepted": accepted, "expected_accepted": expected,
                        "seconds": elapsed, "error": error[:400], "metrics": metrics})

    reference_path = HERE / "reference-output.json"
    independent_path = HERE / "independent-output.json"
    base = json.loads(reference_path.read_text())
    independent = json.loads(independent_path.read_text())
    for i in range(3):
        record(f"reference_repeat_{i + 1}", lambda: c.verify_path(reference_path), True)
    record("independent_implementation", lambda: c.verify_path(independent_path), True)

    # Check canonical mathematical equality without comparing raw serialization.
    for name in ("operator", "quotient", "remainder"):
        assert c.parse_operator(base[name], name) == c.parse_operator(independent[name], name)
    for name in ("spectral_polynomial", "square_factor", "normalized_polynomial"):
        assert c.parse_rf(base[name], name) == c.parse_rf(independent[name], name)

    equivalent = copy.deepcopy(base)
    for name in ("operator", "quotient", "remainder"):
        for coefficient in equivalent[name]:
            for ab in ("a", "b"):
                for nd in ("num", "den"):
                    coefficient[ab][nd] = [-3 * v for v in multiply(coefficient[ab][nd], [1, 1])] + [0, 0]
        equivalent[name].append({"a": {"num": [], "den": [1]}, "b": {"num": [0, 0], "den": [2, 0]}})
    for name in ("spectral_polynomial", "square_factor", "normalized_polynomial"):
        for nd in ("num", "den"):
            equivalent[name][nd] = [7 * v for v in multiply(equivalent[name][nd], [2, 0, 1])] + [0]
    record("equivalent_nonconstant_cancellation_scaling_and_padding", lambda: c.verify_object(equivalent), True)
    maxpadding = copy.deepcopy(base)
    zero = {"a": {"num": [], "den": [1]}, "b": {"num": [0], "den": [1 << 2047]}}
    for name in ("operator", "quotient", "remainder"):
        maxpadding[name].extend(copy.deepcopy(zero) for _ in range(c.MAX_OPERATOR - len(maxpadding[name])))
        for coefficient in maxpadding[name]:
            for ab in ("a", "b"):
                for nd in ("num", "den"):
                    coefficient[ab][nd].extend([0] * (c.MAX_RAW_POLY - len(coefficient[ab][nd])))
    record("valid_published_array_and_integer_boundaries", lambda: c.verify_object(maxpadding), True)

    mutations = [
        ("wrong_genus", lambda z: z.update(genus=5), "incorrect genus"),
        ("boolean_genus", lambda z: z.update(genus=True), "JSON integer"),
        ("float_genus", lambda z: z.update(genus=4.0), "JSON integer"),
        ("negative_genus", lambda z: z.update(genus=-1), "nonnegative"),
        ("missing_key", lambda z: z.pop("quotient"), "exactly the keys"),
        ("extra_key", lambda z: z.update(extra=0), "exactly the keys"),
        ("zero_operator", lambda z: z.update(operator=[]), "minimum nonzero odd operator order"),
        ("nonmonic_operator", lambda z: z["operator"][-1]["a"].update(num=[2]), "must be monic"),
        ("zero_denominator", lambda z: z["operator"][0]["a"].update(den=[0, 0]), "zero polynomial"),
        ("empty_denominator", lambda z: z["operator"][0]["a"].update(den=[]), "zero polynomial"),
        ("excess_raw_polynomial_length", lambda z: z["operator"][0]["a"].update(num=[0] * 130), "raw coefficients"),
        ("excess_integer_bits", lambda z: z["operator"][0]["a"].update(num=[1 << 2048]), "2048-bit"),
        ("boolean_coefficient", lambda z: z["operator"][0]["a"].update(num=[True]), "JSON integer"),
        ("numeric_string_coefficient", lambda z: z["operator"][0]["a"].update(num=["0"]), "JSON integer"),
        ("excess_operator_length", lambda z: z["operator"].extend([zero] * 34), "33 raw coefficients"),
        ("noncommuting_perturbation", lambda z: z["operator"][0]["a"].update(num=[0, 1], den=[1]), "does not commute"),
        ("inconsistent_spectral_factorization", lambda z: z["spectral_polynomial"]["num"].__setitem__(0, 1), "factorization"),
        ("wrong_quotient", lambda z: z["quotient"][0]["a"].update(num=[1], den=[1]), "right-division identity"),
        ("wrong_remainder", lambda z: z["remainder"][0]["a"].update(num=[1], den=[1]), "right-division identity"),
        ("zero_remainder", lambda z: z.update(remainder=[]), "remainder must be nonzero"),
        ("nonpolynomial_spectral_fraction", lambda z: z["spectral_polynomial"].update(den=[1, 1]), "reduce to a polynomial"),
    ]
    for name, mutate, reason in mutations:
        value = copy.deepcopy(base)
        mutate(value)
        record(name, lambda value=value: c.verify_object(value), False, reason)

    A = c.parse_operator(base["operator"], "operator")
    Q = c.parse_operator(base["quotient"], "quotient")
    R = c.parse_operator(base["remainder"], "remainder")
    value = copy.deepcopy(base)
    value["operator"] = operator_json(c.add(A, [c.ONE]))
    c.check_commutator(c.parse_operator(value["operator"], "operator"))
    record("commuting_but_not_skew_A_plus_one", lambda: c.verify_object(value), False, "not formally skew-adjoint")

    value = copy.deepcopy(base)
    q = c.parse_rf(value["square_factor"], "q").polynomial("q")
    h = c.parse_rf(value["normalized_polynomial"], "h").polynomial("h") + 1
    assert h.gcd(h.derivative()).degree() == 0
    value["normalized_polynomial"] = rf_json(c.RF(h))
    value["spectral_polynomial"] = rf_json(c.RF(q * q * h))
    record("coherent_but_false_spectral_identity", lambda: c.verify_object(value), False, "spectral identity")

    value = copy.deepcopy(base)
    value["square_factor"] = rf_json(c.RF(1))
    value["normalized_polynomial"] = copy.deepcopy(value["spectral_polynomial"])
    value["genus"] = 5
    record("arithmetic_curve_mistaken_for_normalization", lambda: c.verify_object(value), False, "not squarefree")

    value = copy.deepcopy(base)
    left_q, left_r = c.scale(c.adjoint(Q), -1), c.scale(c.adjoint(R), -1)
    assert not c.add(c.add(c.compose(c.L, left_q), left_r), c.scale(A, -1))
    value["quotient"], value["remainder"] = operator_json(left_q), operator_json(left_r)
    record("valid_left_division_is_not_right_division", lambda: c.verify_object(value), False, "right-division identity")

    value = copy.deepcopy(base)
    value["operator"] = operator_json(Q)
    record("divide_by_square_factor_to_claim_order_nine", lambda: c.verify_object(value), False,
           "minimum nonzero odd operator order")

    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "candidate.json"
        record("no_op_missing_artifact", lambda: c.verify_path(path), False, "missing submission artifact")
        malformed = [
            ("duplicate_top_level_key", '{"genus":4,"genus":4}', "duplicate JSON"),
            ("duplicate_nested_key", '{"a":{"num":[0],"num":[1],"den":[1]}}', "duplicate JSON"),
            ("nan", '{"genus":NaN}', "nonfinite"),
            ("infinity", '{"genus":Infinity}', "nonfinite"),
            ("malformed_json", "[", "invalid UTF-8 JSON"),
            ("invalid_utf8", b"\xff", "invalid UTF-8 JSON"),
            ("deep_nesting", "[" * 2000 + "]" * 2000, "JSON"),
            ("excess_artifact_size", " " * (c.MAX_BYTES + 1), "exceeds"),
            ("excess_integer_digits", '{"genus":' + "9" * 1000 + "}", "exceeds"),
        ]
        for name, data, reason in malformed:
            path.write_bytes(data if isinstance(data, bytes) else data.encode())
            record(name, lambda: c.verify_path(path), False, reason)

    x, y = c.K(c.RF([0, 1])), c.K(0, 1)
    assert x.derivative() == y and y.derivative() == c.K(c.RF([0, 0, 6]))
    assert y * y == c.K(c.S)
    assert c.compose([c.ZERO, c.ONE], [x]) == [y, x]
    assert c.adjoint([c.ZERO, c.ONE]) == [c.ZERO, c.K(-1)]
    assert c.compose(c.L, c.L) == c.evaluate_polynomial(c.fmpq_poly([0, 0, 1]))
    report = {"python_version": sys.version.split()[0], "python_flint_version": flint.__version__,
              "scope": "Local exact verifier validation; not frontier-agent calibration or a Harbor run.",
              "reference_sha256": hashlib.sha256(reference_path.read_bytes()).hexdigest(),
              "independent_sha256": hashlib.sha256(independent_path.read_bytes()).hexdigest(),
              "cases": len(results), "all_expected": True,
              "accepted": sum(r["accepted"] for r in results),
              "rejected": sum(not r["accepted"] for r in results),
              "slowest_seconds": max(r["seconds"] for r in results),
              "arithmetic_smoke_assertions": 6, "results": results}
    (HERE / "validation_results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "results"}, indent=2))


if __name__ == "__main__":
    main()
