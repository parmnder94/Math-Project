import sys,json,pickle,sympy as s,os
sys.path.insert(0,'/app')
from operators import x,E,C,of,ef,zero
x,E,u,H,fs,cs,ff,P=pickle.load(open('/app/result.pkl','rb'))
L,A,P,q,h,Q,R=pickle.load(open('/app/operators.pkl','rb'))
print('f5 factor:',s.factor(ff[-1]))
print('R0 factor:',s.factor(R[0][1]))
print('R1 factor:',s.factor(R[1][0]))
print('h squarefree gcd:',s.gcd(s.Poly(h,E),s.Poly(s.diff(h,E),E)).as_expr())
dfs=[C(s.diff(f,x)) for f in fs[1:6]]
den=s.lcm([s.denom(f) for f in dfs]);polys=[s.Poly(C(f*den),x) for f in dfs]
deg=max(p.degree() for p in polys)
M=s.Matrix([[p.nth(i) for p in polys] for i in range(deg+1)])
pivotrows=list(M.T.rref()[1]);minor=M[pivotrows,:]
print('minimality common denominator:',s.factor(den))
print('minimality pivot rows:',pivotrows)
print('minimality determinant:',minor.det())
output=json.load(open('/app/output/centralizer.json'))
assert set(output)=={'operator','spectral_polynomial','square_factor','normalized_polynomial','genus','quotient','remainder'}
assert output['operator']==of(A) and output['quotient']==of(Q) and output['remainder']==of(R)
assert output['spectral_polynomial']==ef(P) and output['square_factor']==ef(q) and output['normalized_polynomial']==ef(h)
ints=[]
def check_rf(a):
    assert set(a)=={'num','den'}
    for k in a:
        assert len(a[k])<=129 and all(type(z) is int and abs(z)<2**2048 for z in a[k]);ints.extend(a[k])
    assert a['den'] and any(a['den'])
for name in ('operator','quotient','remainder'):
    assert len(output[name])<=33
    for c in output[name]:
        assert set(c)=={'a','b'}
        check_rf(c['a']);check_rf(c['b'])
for name in ('spectral_polynomial','square_factor','normalized_polynomial'):check_rf(output[name])
assert type(output['genus']) is int and output['genus']==4
size=os.path.getsize('/app/output/centralizer.json');assert size<=2097152
print('artifact schema valid; bytes:',size,'max integer bits:',max(abs(i).bit_length() for i in ints))
