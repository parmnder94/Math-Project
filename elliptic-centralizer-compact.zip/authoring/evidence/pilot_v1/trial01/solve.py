import sympy as s
import pickle, time
x,E=s.symbols('x E')
t=time.monotonic()
b=11; H=4*(x**3-b)
u=30*x+198*x/(x**3-b)
C=s.cancel
p=lambda a:C(s.diff(a,x))
def dd(a): return C(H*s.diff(a,x,2)+6*x*x*s.diff(a,x))
f=[s.Integer(1)]
for n in range(1,10):
    z=sum(f[i]*f[n-i] for i in range(1,n))
    z-=u*sum(f[i]*f[n-1-i] for i in range(n))
    z+=s.Rational(1,2)*sum(f[i]*dd(f[n-1-i]) for i in range(n))
    z-=s.Rational(1,4)*H*sum(p(f[i])*p(f[n-1-i]) for i in range(n))
    fn=C(-z/2); f.append(fn)
    ds=[p(a) for a in f[1:]]
    den=s.lcm([s.denom(a) for a in ds])
    polys=[s.Poly(C(a*den),x) for a in ds]
    deg=max(a.degree() for a in polys)
    M=s.Matrix([[pol.nth(i) for pol in polys] for i in range(deg+1)])
    null=M.nullspace()
    print('n',n,'degree',s.degree(s.numer(fn),x),s.degree(s.denom(fn),x),'rank',M.rank(),'null',null,'seconds',round(time.monotonic()-t,2),flush=True)
    if null:
        g=n-1
        v=null[0]/null[0][-1]
        # v_i is coefficient of canonical f_(i+1); c_(g-j+1)=v_(j-1)
        constants=[s.Integer(1)]+list(reversed(list(v[:-1])))
        ff=[C(sum(constants[k]*f[j-k] for k in range(j+1))) for j in range(g+1)]
        F=sum(ff[j]*E**(g-j) for j in range(g+1))
        P=C((E-u)*F**2+F*dd(F)/2-H*p(F)**2/4)
        P=s.Poly(P,E).as_expr()
        print('g',g,'constants',constants,flush=True)
        print('P',s.factor(P),flush=True)
        with open('/app/result.pkl','wb') as out: pickle.dump((x,E,u,H,f,constants,ff,P),out)
        break
