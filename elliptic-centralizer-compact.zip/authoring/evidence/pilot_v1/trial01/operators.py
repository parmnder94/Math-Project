import sympy as s
import pickle, time, json, math, functools
x,E,u,H,fs,cs,ff,P=pickle.load(open('/app/result.pkl','rb'))
C=s.cancel
zero=(s.Integer(0),s.Integer(0))
one=(s.Integer(1),s.Integer(0))
def fc(a): return (C(a[0]),C(a[1]))
def add(a,b): return fc((a[0]+b[0],a[1]+b[1]))
def neg(a): return (-a[0],-a[1])
def scale(a,b): return (C(a[0]*b),C(a[1]*b))
def mul(a,b): return fc((a[0]*b[0]+H*a[1]*b[1],a[0]*b[1]+a[1]*b[0]))
@functools.lru_cache(maxsize=None)
def deriv(a,k=1):
    if k==0: return a
    if k>1: return deriv(deriv(a,k-1))
    return fc((H*s.diff(a[1],x)+6*x*x*a[1],s.diff(a[0],x)))
def trim(a):
    while a and a[-1]==zero:a.pop()
    return a

def oa(a,b):
    return trim([add(a[i] if i<len(a) else zero,b[i] if i<len(b) else zero) for i in range(max(len(a),len(b)))])
def os(a,b):return oa(a,[neg(c) for c in b])
def om(a,b):
    if not a or not b:return []
    z=[[s.Integer(0),s.Integer(0)] for _ in range(len(a)+len(b)-1)]
    for i,ai in enumerate(a):
        if ai==zero:continue
        for j,bj in enumerate(b):
            if bj==zero:continue
            for k in range(i+1):
                bk=deriv(bj,k)
                if bk==zero:continue
                v=mul(ai,bk); m=math.comb(i,k); pos=i+j-k
                z[pos][0]+=m*v[0];z[pos][1]+=m*v[1]
    return trim([fc(c) for c in z])
def adj(a):
    z=[zero for _ in a]
    for i,ai in enumerate(a):
        for k in range(i+1):
            z[i-k]=add(z[i-k],scale(deriv(ai,k),(-1)**i*math.comb(i,k)))
    return trim(z)
def opoly(poly,L):
    z=[]
    for c in s.Poly(poly,E).all_coeffs():z=oa(om(z,L),[(c,s.Integer(0))])
    return z

def rightdiv(a,b):
    a=a[:];q=[zero]*max(0,len(a)-len(b)+1)
    # Here divisor's leading coefficient is a rational constant.
    assert b[-1][1]==0 and not b[-1][0].has(x)
    while len(a)>=len(b):
        k=len(a)-len(b); v=scale(a[-1],1/b[-1][0]);q[k]=add(q[k],v)
        a=os(a,om([zero]*k+[v],b))
    return trim(q),trim(a)
def rf(v):
    n,d=s.fraction(C(v));n=s.Poly(n,x);d=s.Poly(d,x)
    den=s.ilcm(*[int(z.q) for z in n.all_coeffs()+d.all_coeffs()])
    n=n.mul_ground(den);d=d.mul_ground(den)
    return {'num':[int(z) for z in reversed(n.all_coeffs())] if n else [],'den':[int(z) for z in reversed(d.all_coeffs())]}
def ef(v):return rf(v.subs(E,x))
def of(a):return [{'a':rf(c[0]),'b':rf(c[1])} for c in a]
def main():
    t=time.monotonic();L=[(C(u),s.Integer(0)),zero,(-s.Integer(1),s.Integer(0))]
    powers=[[one]]
    for i in range(1,len(ff)):powers.append(om(powers[-1],L))
    print('L powers constructed',round(time.monotonic()-t,2),flush=True)
    A=[];g=len(ff)-1
    for j,f in enumerate(ff):
        first=[scale(deriv((f,s.Integer(0))),-s.Rational(1,2)),(f,s.Integer(0))]
        A=oa(A,om(first,powers[g-j]))
    if g%2:A=[neg(c) for c in A]
    assert A[-1]==one
    print('A order',len(A)-1,'built',round(time.monotonic()-t,2),flush=True)
    factors=s.factor_list(P,E)[1];q=s.prod(v**(m//2) for v,m in factors);h=s.cancel(P/q**2)
    divisor=opoly(q,L);Q,R=rightdiv(A,divisor)
    assert not os(A,oa(om(Q,divisor),R))
    print('division exact; remainder',R,'seconds',round(time.monotonic()-t,2),flush=True)
    with open('/app/operators.pkl','wb') as out:pickle.dump((L,A,P,q,h,Q,R),out)
    assert not oa(adj(A),A)
    print('A is skew-adjoint',round(time.monotonic()-t,2),flush=True)
    assert not os(om(A,L),om(L,A))
    print('commutator zero',round(time.monotonic()-t,2),flush=True)
    output={'operator':of(A),'spectral_polynomial':ef(P),'square_factor':ef(q),'normalized_polynomial':ef(h),'genus':int((s.degree(h,E)-1)//2),'quotient':of(Q),'remainder':of(R)}
    import os as osp
    osp.makedirs('/app/output',exist_ok=True)
    with open('/app/output/centralizer.json','w') as out:json.dump(output,out,separators=(',',':'))
    print('JSON written',round(time.monotonic()-t,2),flush=True)
    square=om(A,A)
    print('A squared',round(time.monotonic()-t,2),flush=True)
    PL=opoly(P,L)
    print('P(L) computed',round(time.monotonic()-t,2),flush=True)
    assert not oa(square,PL)
    print('A^2+P(L)=0 exactly',round(time.monotonic()-t,2),flush=True)
if __name__=='__main__': main()
