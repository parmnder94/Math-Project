"""Independent artifact parsing and operator multiplication by iterated left D."""
import json, sympy as s, math, os
from sympy.polys.fields import field
from sympy.polys.domains import QQ
K,x=field('x',QQ); T=4*(x**3-11); z=(K.zero,K.zero); one=(K.one,K.zero)
path='/app/output/centralizer.json'
data=json.load(open(path))
assert set(data)=={'operator','spectral_polynomial','square_factor','normalized_polynomial','genus','quotient','remainder'}
assert os.path.getsize(path)<=2*1024*1024

def readrf(v):
    assert set(v)=={'num','den'}
    for a in v.values():
        assert len(a)<=129
        assert all(type(k) is int and abs(k)<2**2048 for k in a)
    n=sum((c*x**j for j,c in enumerate(v['num'])),K.zero)
    d=sum((c*x**j for j,c in enumerate(v['den'])),K.zero)
    assert d
    return n/d

def readop(a):
    assert len(a)<=33
    result=[]
    for b in a:
        assert set(b)=={'a','b'}
        result.append((readrf(b['a']),readrf(b['b'])))
    return trim(result)
def trim(a):
    while a and a[-1]==z:a.pop()
    return a
def plus(a,b):return(a[0]+b[0],a[1]+b[1])
def times(a,b):return(a[0]*b[0]+T*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def minus(a):return(-a[0],-a[1])
def der(a):return(T*a[1].diff(x)+6*x*x*a[1],a[0].diff(x))
def add(a,b):
    n=max(len(a),len(b)); a=a+[z]*(n-len(a)); b=b+[z]*(n-len(b))
    return trim([plus(c,d) for c,d in zip(a,b)])
def sub(a,b):return add(a,[minus(c) for c in b])
def leftD(a):
    if not a:return []
    return trim([der(a[0])]+[plus(der(a[i]),a[i-1]) for i in range(1,len(a))]+[a[-1]])
def multiply(a,b):
    result=[]; current=b
    for c in a:
        if c!=z:result=add(result,[times(c,v) for v in current])
        current=leftD(current)
    return result
A=readop(data['operator']); Q=readop(data['quotient']); R=readop(data['remainder'])
L=[(30*x+198*x/(x**3-11),K.zero),z,(-K.one,K.zero)]
assert len(A)==12 and A[-1]==one
assert not sub(multiply(A,L),multiply(L,A))
print('artifact commutator verified independently',flush=True)
At=[]
for j,c in enumerate(A):
    term=[c]
    for k in range(j):term=[minus(t) for t in leftD(term)]
    At=add(At,term)
assert not add(At,A)
print('artifact skew adjoint verified independently',flush=True)
E=s.symbols('E')
def energy(k):
    f=readrf(data[k]); assert f.denom==1
    return s.Poly(f.as_expr().subs(s.Symbol('x'),E),E)
P=energy('spectral_polynomial'); q=energy('square_factor'); h=energy('normalized_polynomial')
assert all(p.LC()==1 for p in [P,q,h])
assert (P-q*q*h).is_zero
assert s.gcd(h,h.diff()).degree()==0
_,fs=s.factor_list(P)
qr=s.Poly(1,E)
for p,m in fs:qr*=p.monic()**(m//2)
assert (q-qr).is_zero
assert type(data['genus']) is int and data['genus']==(h.degree()-1)//2
print('spectral normalization verified independently',flush=True)
def subst(p):
    a=[]
    for c in p.all_coeffs():
        a=multiply(L,a)
        a=add(a,[(K.from_expr(c),K.zero)])
    return a
assert not add(multiply(A,A),subst(P))
print('artifact full spectral identity verified independently',flush=True)
assert not sub(A,add(multiply(Q,subst(q)),R))
assert len(R)-1 < 2*q.degree()
print('artifact right division verified independently',flush=True)
print('A order',len(A)-1,'Q order',len(Q)-1,'R order',len(R)-1)
for j,c in enumerate(R):print('R D^'+str(j),tuple(str(v.as_expr()) for v in c))
print('All independent exact checks passed.',flush=True)
