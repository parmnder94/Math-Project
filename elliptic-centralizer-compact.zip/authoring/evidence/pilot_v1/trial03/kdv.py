import sympy as s, pickle, time
x=s.symbols('x'); t=x**3-11; u=30*x+198*x/t
f=[s.S(1)]; r=[]
for j in range(14):
    a=f[-1]
    da=s.cancel(-t*s.diff(a,x,3)-s.Rational(9,2)*x*x*s.diff(a,x,2)+(u-3*x)*s.diff(a,x)+s.diff(u,x)*a/2)
    r.append(da)
    print('j',j,'derivative degrees',[s.degree(z,x) for z in s.fraction(da)], flush=True)
    common=s.lcm([s.denom(w) for w in r])
    nums=[s.fraction(s.cancel(z*common))[0] for z in r]
    mat=s.polys.polytools.parallel_poly_from_expr(nums,x)[0]
    deg=max(z.degree() for z in mat)
    M=s.Matrix([[z.nth(k) for z in mat] for k in range(deg+1)])
    null=M.nullspace()
    if null:
        print('STATIONARY',j,null,flush=True)
        pickle.dump((f,r,null),open('/app/recursion.pkl','wb'))
        break
    v=s.integrate(da,x,risch=True)
    print('integrated',s.simplify(v),flush=True)
    if v.has(s.Integral,s.log): raise ValueError(v)
    f.append(s.cancel(v))
