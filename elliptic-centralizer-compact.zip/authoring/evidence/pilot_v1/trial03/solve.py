import sympy as s, pickle, json, math, time
from sympy.polys.fields import field
from sympy.polys.domains import QQ
X,E=s.symbols('x E')
f,r,null=pickle.load(open('/app/recursion.pkl','rb'))
g=len(f)-1
constants=[s.S(1)]+[s.S(0)]*g
v=null[0]
for i in range(g): constants[g-i]=v[i]
ff=[s.cancel(sum(constants[k]*f[j-k] for k in range(j+1))) for j in range(g+1)]
print('g',g,'constants',constants,flush=True)
F=sum(ff[j]*E**(g-j) for j in range(g+1))
F0=F.subs(X,0); F1=s.diff(F,X).subs(X,0); F2=s.diff(F,X,2).subs(X,0)
P=s.Poly(s.expand(E*F0**2-22*F0*F2+11*F1**2),E)
print('P',P.as_expr(),flush=True)
print('factor',s.factor(P.as_expr()),flush=True)
_,factors=s.factor_list(P)
q=s.Poly(1,E); h=s.Poly(1,E)
for fac,m in factors:
    q*=fac.monic()**(m//2)
    if m%2:h*=fac.monic()
assert (P-q*q*h).is_zero
K,x=field('x',QQ); t=x**3-11; y2=4*t
Z=(K.zero,K.zero); ONE=(K.one,K.zero)
def sc(a):return (K.from_expr(a),K.zero)
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[0],-a[1])
def sub(a,b):return add(a,neg(b))
def mul(a,b):return (a[0]*b[0]+y2*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,k):return (a[0]*k,a[1]*k)
def inv(a):
    d=a[0]**2-y2*a[1]**2
    return (a[0]/d,-a[1]/d)
def D(a):return (y2*a[1].diff(x)+6*x*x*a[1],a[0].diff(x))
def trim(a):
    while a and a[-1]==Z:a.pop()
    return a
def oa(a,b):return trim([add(a[i] if i<len(a) else Z,b[i] if i<len(b) else Z) for i in range(max(len(a),len(b)))])
def os(a,b):return oa(a,[neg(z) for z in b])
def om(a,b):
    if not a or not b:return []
    out=[Z]*(len(a)+len(b)-1)
    ds=[b]
    for k in range(1,len(a)):ds.append([D(z) for z in ds[-1]])
    for i,ai in enumerate(a):
        if ai==Z:continue
        for j in range(len(b)):
            for k in range(i+1):
                z=ds[k][j]
                if z!=Z:out[i+j-k]=add(out[i+j-k],scale(mul(ai,z),math.comb(i,k)))
    return trim(out)
def opoly(p,L):
    out=[]
    for c in p.all_coeffs():out=oa(om(out,L),[sc(c)])
    return out
L=[sc(30*X+198*X/(X**3-11)),Z,sc(-1)]
A=[]
for j in range(g+1):
    a=sc(ff[j]); piece=[scale(D(a),-QQ(1,2)),a]
    A=oa(om(A,L),piece)
if g%2:A=[neg(z) for z in A]
print('A constructed order',len(A)-1,flush=True)
assert A[-1]==ONE
assert not os(om(A,L),om(L,A))
print('commutator exactly zero',flush=True)
def adj(a):
    out=[]
    for j,c in enumerate(a):
        ds=c
        for k in range(j+1):
            term=[Z]*(j-k)+[scale(ds,(-1)**j*math.comb(j,k))]
            out=oa(out,term)
            ds=D(ds)
    return out
assert not oa(adj(A),A)
print('skew adjoint exactly',flush=True)
assert not oa(om(A,A),opoly(P,L))
print('spectral identity exactly zero',flush=True)
ql=opoly(q,L)
Q=[]; R=A[:]
while R and len(R)>=len(ql):
    j=len(R)-len(ql); c=mul(R[-1],inv(ql[-1]))
    term=[Z]*j+[c]
    Q=oa(Q,term); R=os(R,om(term,ql))
assert len(R)<len(ql)
assert A==oa(om(Q,ql),R)
print('right division exact: Q order',len(Q)-1,'R order',len(R)-1,flush=True)
def encode_rf(z):
    n=z.numer; d=z.denom
    nd=[n.get((k,),QQ.zero) for k in range(n.degree()+1)] if n else []
    dd=[d.get((k,),QQ.zero) for k in range(d.degree()+1)]
    lcm=s.ilcm(*([int(v.denominator) for v in nd+dd]+[1]))
    return {'num':[int(v*lcm) for v in nd],'den':[int(v*lcm) for v in dd]}
def enc_coeff(z):return {'a':encode_rf(z[0]),'b':encode_rf(z[1])}
def enc_op(z):return [enc_coeff(a) for a in z]
def enc_ep(z):return encode_rf(K.from_expr(z.as_expr().subs(E,X)))
out={'operator':enc_op(A),'spectral_polynomial':enc_ep(P),'square_factor':enc_ep(q),'normalized_polynomial':enc_ep(h),'genus':(h.degree()-1)//2,'quotient':enc_op(Q),'remainder':enc_op(R)}
with open('/app/output/centralizer.json','w') as w:json.dump(out,w,separators=(',',':'))
pickle.dump(([[a.as_expr(),b.as_expr()] for a,b in A],P,q,h,[[a.as_expr(),b.as_expr()] for a,b in Q],[[a.as_expr(),b.as_expr()] for a,b in R],ff),open('/app/solution_work.pkl','wb'))
print('written /app/output/centralizer.json',flush=True)
print('q=',q.as_expr(),'h=',h.as_expr(),'genus=',out['genus'],flush=True)
