# Independent solution attempt

Read only `/instruction.md`, `/app/data/README.md`, and `/app/data/operator.json`.

Plan: use stationary KdV recursion for rational even functions, solve the first stationary relation including integration constants, build the odd commuting operator, derive its spectral polynomial, factor it, and perform exact right division. All calculations remain in this container. Global minimality will be checked through the universal recursion, rather than a restricted operator ansatz.

Reproducible computation scripts will be recorded here.

## Result and reproducibility

The final artifact is `/app/output/centralizer.json`. Scripts:

- `/app/kdv.py`: generates the universal stationary KdV recursion and finds its first relation; saves `/app/recursion.pkl`.
- `/app/solve.py`: constructs all seven requested fields, verifies exact operator identities, performs right division, and serializes the artifact.
- `/app/validate.py`: independently reloads the JSON and uses a different operator multiplication implementation (iterated left multiplication by D, rather than the binomial formula) to verify every algebraic identity and all encoding/size limits.

Run `python /app/kdv.py`, `python /app/solve.py`, and `python /app/validate.py` inside this container. All three scripts completed successfully after the implementation corrections below. The independent validator reported all exact checks passed.

Put t=x^3-11 and u=30x+198x/t. Set f_0=1 and define

    d f_(j+1)/dx = -t f_j''' -(9/2)x^2 f_j'' +(u-3x)f_j' +(u_x/2)f_j.

Primes in this display are x derivatives. Taking rational antiderivatives gives f_1 through f_5. The first stationary relation is

    d f_6/dx - 397782 d f_3/dx = 0.

Consequently set F_j=f_j for j<3 and F_j=f_j-397782 f_(j-3) for 3<=j<=5. The required monic operator is

    A = - sum_(j=0)^5 (F_j D - (D F_j)/2) L^(5-j).

Its order is 11. Direct exact operator computations give [A,L]=0, A*=-A, and A^2+P(L)=0, with

    P(E) = E^2 (E^3-551232)(E^6-553014 E^3+816903549).

The greatest monic square divisor is E^2, so q(E)=E and

    h(E)=E^9-1104246 E^6+305655916797 E^3-450303377122368.

The independent validator checked gcd(h,h')=1 and factor multiplicities, giving geometric genus 4.

## Global minimality argument

The constants of K under D are exactly Q: the function field of the geometrically integral elliptic curve has no new algebraic constants, and the kernel of its nonzero derivation has transcendence degree zero.

Any operator B of order 2m+1 admits a unique expansion

    B=sum_(j=0)^m (a_j D+b_j)L^(m-j).

The commutation equation [B,L]=0 first forces a_0 to be a nonzero constant, then b_j=-(D a_j)/2+k_j with constant k_j, and recursively

    D a_(j+1)=u D a_j+(D u)a_j/2-D^3 a_j/4,

ending with the stationary equation for a_m. Thus, after rescaling the leading coefficient and subtracting a polynomial in L, every odd commutant is governed by this same recursion with constant integration parameters. This deduction imposes no denominator or polynomial ansatz on K.

The five rational functions d f_(j+1)/dx for j=0,...,4 are linearly independent over Q. Their polynomial parts at x=infinity are respectively

    15,
    630x,
    18900x^2,
    396900x^3+2910600,
    4465125x^4+207380250x.

They have distinct degrees and nonzero leading coefficients. No stationary relation can therefore occur for m<5, even allowing all integration constants in K. The constructed order-11 operator is globally minimal among nonzero odd-order commutants.

## Right division and obstruction

Since q(L)=L, the exact right remainder is

    R = (D F_5)/2 - F_5 D,
    F_5 = 35721 x^2 (5x^3-88)^2/(x^3-11).

This is a nonzero operator of order 1; the quotient has order 9. In expanded form the scalar coefficient of R is y times

    35721 x(5x^3-88)(25x^6-352x^3+1936)/(2(x^3-11)^2).

The coefficient of D is -F_5. Both implementations verified A=QL+R exactly. Therefore the normalized generator A/L is not a differential operator.

## Implementation corrections

An initial shell heredoc was quoted incorrectly and was replaced before running the valid recursion script. Comparing SymPy Poly objects from different coefficient domains with `==` gave a false mismatch despite equal expressions; this was replaced by testing that their difference is the zero polynomial. SymPy's FracField objects could not be pickled directly, so the optional intermediate pickle stores ordinary SymPy expressions instead. The independent validator initially called an unavailable FracField conversion method; it was corrected to `from_expr`. None of these implementation issues changed the mathematical result. The final artifact was regenerated and independently validated after corrections.
