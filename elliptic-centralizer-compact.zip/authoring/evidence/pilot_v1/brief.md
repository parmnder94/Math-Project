# Elliptic Differential Centralizer

## Task

An exact spectral calculation for an elliptic Schrödinger operator is being audited. Recover its primitive odd differential symmetry and the normalization of its spectral curve. Determine whether the normalized spectral generator is itself a differential operator by computing its right-division obstruction.

Work in the differential field
\[
K=\mathbb Q(x,y),\qquad y^2=4(x^3-11),\qquad D(x)=y,\quad D(y)=6x^2,
\]
and the operator ring \(K[D]\), with coefficients written on the left and multiplication defined by \(Dc=cD+D(c)\). The operator is
\[
L=-D^2+30x+\frac{198x}{x^3-11}.
\]
The inputs and the output encoding are also specified in `/app/data/README.md` and `/app/data/operator.json`.

## Files to submit

Write `/app/output/centralizer.json` as one JSON object containing exactly these seven fields:

1. `operator`: a monic, nonzero, formally skew-adjoint operator \(A\in K[D]\) of the **smallest positive odd order** among all nonzero odd-order operators commuting with \(L\). Require \([A,L]=0\).
2. `spectral_polynomial`: the monic polynomial \(P\in\mathbb Q[E]\) satisfying \(A^2+P(L)=0\).
3. `square_factor`: the monic polynomial \(q\in\mathbb Q[E]\) such that \(q^2\) is the greatest monic square divisor of \(P\).
4. `normalized_polynomial`: the monic squarefree polynomial \(h\in\mathbb Q[E]\) with \(P=q^2h\). Thus \(V^2+P(E)=0\) has normalization \(W^2+h(E)=0\), with \(V=q(E)W\).
5. `genus`: the geometric genus of the smooth projective normalization over \(\overline{\mathbb Q}\).
6. `quotient` and 7. `remainder`: the unique right-division pair \(Q,R\in K[D]\) satisfying \(A=Qq(L)+R\) and \(\operatorname{ord}R<2\deg q\). If \(q=1\), use \(Q=A\) and \(R=0\). The zero operator has order \(-\infty\).

Here \(E\) is a constant indeterminate. Monic refers to the coefficient of the highest power. The formal adjoint fixes \(K\), sends \(D\) to \(-D\), and reverses multiplication: \((cD^j)^*=(-D)^jc\). It is algebraic, without complex conjugation. Formally skew-adjoint means \(A^*=-A\). Minimality is over the full field \(K\), not a chosen polynomial or denominator ansatz.

## Encoding and evaluation

The exact JSON encoding, size limits, and treatment of equivalent fractions are in `/app/data/README.md`. Operator arrays run from the coefficient of \(D^0\) upward. Each coefficient is encoded as \(a(x)+yb(x)\); energy polynomials use the same rational-function encoding with variable \(E\). All arithmetic is exact over the rationals. No floating-point values are accepted.

A submission passes only if all seven fields satisfy these definitions, including global minimality and every differential-operator identity. Algebraic normalization and right division are distinct requirements; neither substitutes for the other. No particular construction method or unreduced representation is required.

You have 14400 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
