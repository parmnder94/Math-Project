import sympy as S
import pickle,time
x,E=S.symbols("x E")
s=x**3-11
u=30*x+198*x/s
basis=[x**i for i in range(6)]+[x**i/s for i in range(3)]
cols=[]
for f in basis:
    v=S.cancel(s**3*(4*s*S.diff(f,x,3)+18*x*x*S.diff(f,x,2)+(12*x-4*u+4*E)*S.diff(f,x)-2*S.diff(u,x)*f))
    cols.append(S.Poly(v,x))
M=S.Matrix([[v.nth(i) for v in cols] for i in range(max(v.degree() for v in cols)+1)])
print("Matrix dimensions",M.shape,flush=True)
N=M.nullspace()
print("Nullity",len(N),flush=True)
assert len(N)==1
v=N[0]
f=S.factor(sum(a*b for a,b in zip(v,basis)))
# Clear energy denominators and normalize highest energy coefficient.
num,den=S.fraction(f)
f=S.cancel(f*S.Poly(den,E).monic().as_expr())
p=S.Poly(f,E)
f=S.cancel(f/p.LC())
print("F",S.factor(f),flush=True)
print("E degree",S.degree(f,E),flush=True)
assert S.cancel(4*s*S.diff(f,x,3)+18*x*x*S.diff(f,x,2)+(12*x-4*u+4*E)*S.diff(f,x)-2*S.diff(u,x)*f)==0
fp=S.diff(f,x)
fpp=4*s*S.diff(f,x,2)+6*x*x*fp
P=S.factor((E-u)*f*f+S.Rational(1,2)*f*fpp-s*fp*fp)
print("P",P,flush=True)
assert not P.has(x)
with open("/app/work/F.pkl","wb") as h: pickle.dump((f,P),h)
with open("/app/work/F.txt","w") as h: h.write(str(f)+"\n"+str(P)+"\n")
