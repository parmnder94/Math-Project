import sympy as S
import pickle,json,math,time
from functools import lru_cache
x,E=S.symbols("x E")
K=S.QQ.frac_field(x)
X=K.gens[0]; Z=K.zero; O=K.one
s=X**3-11
ZERO=(Z,Z); ONE=(O,Z)

def add(a,b): return (a[0]+b[0],a[1]+b[1])
def neg(a): return (-a[0],-a[1])
def mul(a,b): return (a[0]*b[0]+4*s*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,k): return (k*a[0],k*a[1])
def der(a): return (4*s*a[1].diff(X)+6*X**2*a[1],a[0].diff(X))
def trim(a):
    while a and a[-1]==ZERO: a.pop()
    return a

def opadd(a,b):
    return trim([add(a[i] if i<len(a) else ZERO,b[i] if i<len(b) else ZERO) for i in range(max(len(a),len(b)))])
def opneg(a): return [neg(t) for t in a]

def opmul(a,b):
    if not a or not b:return []
    ans=[ZERO]*(len(a)+len(b)-1)
    db=[b]
    for k in range(1,len(a)): db.append([der(c) for c in db[-1]])
    for i,c in enumerate(a):
        if c==ZERO:continue
        for j,d in enumerate(b):
            for k in range(i+1):
                if db[k][j]!=ZERO:
                    ans[i+j-k]=add(ans[i+j-k],scale(mul(c,db[k][j]),math.comb(i,k)))
    return trim(ans)

def adj(a):
    ans=[ZERO]*len(a)
    for i,c in enumerate(a):
        v=scale(c,(-1)**i)
        for k in range(i+1):
            ans[i-k]=add(ans[i-k],scale(v,math.comb(i,k)))
            v=der(v)
    return trim(ans)

def Rf(r):
    n,d=r.numer.to_dict(),r.denom.to_dict()
    vals=list(n.values())+list(d.values())
    lc=S.ilcm(*[int(c.denominator) for c in vals]) if len(vals)>1 else int(vals[0].denominator)
    def coeff(p):
        return [int(p.get((i,),0)*lc) for i in range(max([k[0] for k in p],default=-1)+1)]
    return {"num":coeff(n),"den":coeff(d)}

def encop(a):return [{"a":Rf(c[0]),"b":Rf(c[1])} for c in a]
def encpoly(p):
    pp=S.Poly(p,E)
    den=S.ilcm(*[S.denom(c) for c in pp.all_coeffs()])
    return {"num":[int(den*pp.nth(i)) for i in range(pp.degree()+1)],"den":[int(den)]}

def log(*args): print(*args,flush=True)

start=time.monotonic()
with open("/app/work/F.pkl","rb") as h: f,P=pickle.load(h)
g=S.degree(f,E); assert g==5
fs=[(K.from_sympy(S.Poly(f,E).nth(g-j)),Z) for j in range(g+1)]
u=30*X+198*X/s
L=[(u,Z),ZERO,(-O,Z)]
LP=[[ONE]]
for i in range(1,12):
    LP.append(opmul(LP[-1],L))
    log("L power",i,"seconds",time.monotonic()-start)
A=[]; Q=[]
for j,fj in enumerate(fs):
    Mf=[scale(der(fj),S.Rational(-1,2)),fj]
    A=opadd(A,opneg(opmul(Mf,LP[g-j])))
    if j<g:Q=opadd(Q,opneg(opmul(Mf,LP[g-1-j])))
R=[scale(der(fs[-1]),S.Rational(1,2)),neg(fs[-1])]
assert A[-1]==ONE
log("A built order",len(A)-1,"seconds",time.monotonic()-start)
assert not opadd(opmul(A,L),opneg(opmul(L,A)))
log("[A,L]=0 exact")
assert not opadd(A,adj(A))
log("A*=-A exact")
assert not opadd(A,opneg(opadd(opmul(Q,L),R)))
log("A=QL+R exact; remainder order",len(R)-1)
PofL=[]
for i in range(S.degree(P,E)+1):
    ci=S.Poly(P,E).nth(i)
    if ci: PofL=opadd(PofL,[scale(t,ci) for t in LP[i]])
log("Built P(L); calculating A squared",time.monotonic()-start)
assert not opadd(opmul(A,A),PofL)
log("A^2+P(L)=0 exact",time.monotonic()-start)
q=S.Integer(1); h=S.Integer(1)
for fac,m in S.factor_list(P,E)[1]:
    q*=fac**(m//2);h*=fac**(m%2)
q=S.Poly(q,E).monic().as_expr(); h=S.Poly(h,E).monic().as_expr()
assert S.expand(P-q*q*h)==0
assert S.gcd(h,S.diff(h,E))==1
assert q==E
out={"operator":encop(A),"spectral_polynomial":encpoly(P),"square_factor":encpoly(q),"normalized_polynomial":encpoly(h),"genus":(S.degree(h,E)-1)//2,"quotient":encop(Q),"remainder":encop(R)}
out["genus"]=int(out["genus"])
with open("/app/output/centralizer.json","w") as file: json.dump(out,file,separators=(",",":"))
with open("/app/work/operators.txt","w") as file: file.write(str([[(a.as_expr(),b.as_expr()) for a,b in op] for op in (A,Q,R,L)]))
log("Saved output, genus",out["genus"])
log("Q order",len(Q)-1,"R order",len(R)-1)
log("R",[(str(a),str(b)) for a,b in R])
with open("/app/attempt.md","a") as file:
    file.write("\n## Exact computation results\n\n")
    file.write("`/app/work/solve_F.py` computed a unique squared eigenfunction of energy degree 5 and verified its differential equation exactly. Its spectral polynomial is `"+str(P)+"`.\n\n")
    file.write("`/app/work/build_and_check.py` implements arithmetic in Q(x)+y Q(x) and Ore differential-operator multiplication. It checked `[A,L]=0`, `A*=-A`, `A^2+P(L)=0`, and `A=QL+R` exactly, coefficient by coefficient. A is monic of order 11, Q has order 9, and the nonzero R has order 1.\n\n")
    file.write("Factorization yields q=E, squarefree h=P/E^2 of degree 9 and geometric genus 4. Output saved to `/app/output/centralizer.json`.\n")
