import sympy as S
import json,os,pickle
x,E=S.symbols("x E")
p="/app/output/centralizer.json"
raw=open(p).read()
def unique(pairs):
 d={}
 for k,v in pairs:
  assert k not in d
  d[k]=v
 return d
out=json.loads(raw,object_pairs_hook=unique)
assert set(out)=={"operator","spectral_polynomial","square_factor","normalized_polynomial","genus","quotient","remainder"}
assert len(raw.encode())<=2097152

def rf(c,z):
 assert isinstance(c,dict) and set(c)=={"num","den"}
 for k in c:
  assert isinstance(c[k],list) and len(c[k])<=129
  assert all(type(a) is int and abs(a)<2**2048 for a in c[k])
 n=sum(v*z**i for i,v in enumerate(c["num"]))
 d=sum(v*z**i for i,v in enumerate(c["den"]))
 assert d!=0
 return S.cancel(n/d)

def op(c):
 assert type(c) is list and len(c)<=33
 ans=[]
 for f in c:
  assert set(f)=={"a","b"}
  ans.append((rf(f["a"],x),rf(f["b"],x)))
 return ans

# Use ordinary symbolic rational expressions for round-trip comparison, independently
# of the fraction-field serialization routine.
expected=S.sympify(open("/app/work/operators.txt").read(),locals={"x":x})
for k,ex in zip(("operator","quotient","remainder"),expected):
 got=op(out[k]); assert len(got)==len(ex)
 assert all(S.cancel(a-b)==0 for ca,cb in zip(got,ex) for a,b in zip(ca,cb))
polys={k:rf(out[k],E) for k in ("spectral_polynomial","square_factor","normalized_polynomial")}
for v in polys.values(): assert S.Poly(v,E).LC()==1
P,q,h=[polys[k] for k in ("spectral_polynomial","square_factor","normalized_polynomial")]
assert S.expand(P-q*q*h)==0
assert S.gcd(h,S.diff(h,E))==1
assert q==E
assert type(out["genus"]) is int and out["genus"]==4
assert S.degree(h,E)==9
with open("/app/work/F.pkl","rb") as file:f,pf=pickle.load(file)
assert S.expand(pf-P)==0
f5=S.Poly(f,E).nth(0)
print("f5 =",S.factor(f5))
print("Serialized output checked exactly; bytes",len(raw.encode()))
print("Largest encoded integer bits",max(abs(v).bit_length() for obj in out.values() if type(obj) is list for c in obj for r in c.values() for arr in r.values() for v in arr))
print("Operator coefficient counts",*[len(out[k]) for k in ("operator","quotient","remainder")])
with open("/app/attempt.md","a") as file:
 file.write("\n`/app/work/check_artifact.py` parsed the written JSON with duplicate-key rejection, validated every resource/encoding bound, and compared all decoded coefficients to the computed operators using independent ordinary SymPy rational expressions. Spectral factorization and genus were rechecked from serialized values. Artifact size: "+str(len(raw.encode()))+" bytes.\n")
