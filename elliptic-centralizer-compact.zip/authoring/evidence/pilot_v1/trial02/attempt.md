# Independent blind attempt

Only `/instruction.md` and `/app/data` are used as benchmark inputs. All calculations and scripts are created inside this container.

## Approach

Write the potential as `u=30*x+198*x/(x^3-11)`. Seek an even elliptic squared eigenfunction F(E,x), satisfying

`4*(x^3-11)*F_xxx + 18*x^2*F_xx + (12*x-4*u+4*E)*F_x -2*u_x*F=0`.

At infinity the local potential coefficient is 5*6, and at the three half periods it is 1*2. This motivates the finite vector space spanned by `1,x,...,x^5,1/s,x/s,x^2/s`, where `s=x^3-11`. Solving the exact linear system provides F; minimality will be checked independently using the local singularity recursion, rather than inferred only from the ansatz.

Planned checks: exact squared-eigenfunction identity; full noncommutative commutator, adjoint, spectral and right-division identities; polynomial factorization and genus.

## Implementation errors and fixes

An initial exploration tried FracElement.diff with a SymPy Symbol; the API requires the fraction-field generator. Corrected to `.diff(X)`. The first operator run passed all four exact identities and wrote the JSON, then an optional pickle of SymPy fraction-field objects failed (`dictionary changed size during iteration`). Replaced that optional debug pickle with a textual dump; this did not change the mathematics or JSON encoding.

## Exact computation results

`/app/work/solve_F.py` computed a unique squared eigenfunction of energy degree 5 and verified its differential equation exactly. Its spectral polynomial is `E**2*(E**3 - 551232)*(E**6 - 553014*E**3 + 816903549)`.

`/app/work/build_and_check.py` implements arithmetic in Q(x)+y Q(x) and Ore differential-operator multiplication. It checked `[A,L]=0`, `A*=-A`, `A^2+P(L)=0`, and `A=QL+R` exactly, coefficient by coefficient. A is monic of order 11, Q has order 9, and the nonzero R has order 1.

Factorization yields q=E, squarefree h=P/E^2 of degree 9 and geometric genus 4. Output saved to `/app/output/centralizer.json`.

`/app/work/check_artifact.py` parsed the written JSON with duplicate-key rejection, validated every resource/encoding bound, and compared all decoded coefficients to the computed operators using independent ordinary SymPy rational expressions. Spectral factorization and genus were rechecked from serialized values. Artifact size: 3407 bytes.

## Explicit construction and global minimality

Put `s=x^3-11` and `M(f)=f*D-(D f)/2`. The computed squared eigenfunction is

`F = E^5 + f1 E^4 + f2 E^3 + f3 E^2 + f4 E + f5`, where

- `f1=(15*x^4-66*x)/s`,
- `f2=(315*x^5+693*x^2)/s`,
- `f3=(6300*x^6-467082*x^3+6090777)/s`,
- `f4=(99225*x^7-4147605*x^4+42261912*x)/s`,
- `f5=35721*x^2*(5*x^3-88)^2/s`.

With `f0=1`, the submitted operator is `A=-sum(j=0..5) M(fj)*L^(5-j)`. Its leading term is `D^11`. Its squared-eigenfunction integral is

`P=(E-u)*F^2 + F*(D^2 F)/2 - (D F)^2/4`

` = E^2*(E^3-551232)*(E^6-553014*E^3+816903549)`.

To establish minimality over the full field, take any commuting operator B of odd order `2g+1`. Successive right division by L gives the unique expansion `B=sum(j=0..g)(a_j D+b_j)L^(g-j)`. Comparison in `[B,L]=0` gives `D a_0=0`, `b_j=-D a_j/2 + constant`, and

`D a_(j+1)=u D a_j+(D u)*a_j/2-(D^3 a_j)/4`,

with terminal expression `D a_(g+1)=0`. The leading a0 is nonzero and constant, so normalize it to 1. This argument allows arbitrary elements of K in B and makes no rational denominator or parity ansatz.

At the elliptic point at infinity, choose the formal uniformizer z with `D=d/dz`. Then `x=z^-2+O(z^4)` and `u=30*z^-2+O(z^4)`. The recurrence forces the most singular term `a_j=c_j*z^(-2j)+less singular terms`, where

`c_0=1`, `c_(j+1)=(2j+1)/(2j+2)*(30-j(j+1))*c_j`.

The arbitrary integration constants only alter less singular terms. For `j=0,1,2,3,4` every displayed multiplier is nonzero. Hence when `g<5`, the terminal expression `D a_(g+1)` has the nonzero pole `-(2g+2)c_(g+1)*z^(-2g-3)`, contradicting stationarity. Thus every positive odd commuting order is at least 11, attained by A.

The exact factorization has `q=E` and squarefree `h=(E^3-551232)*(E^6-553014*E^3+816903549)`. Its degree 9 gives genus `(9-1)/2=4`. Since the divisor is `q(L)=L`, the exact right-division pair is

`Q=-sum(j=0..4) M(fj)*L^(4-j)`,

`R=-f5*D+(D f5)/2`.

The coefficient `-f5` is nonzero, so R has order 1, below the order 2 of L. Consequently `A/L` is not a differential operator; the normalization of the spectral algebra does not itself provide a differential generator in K[D].

## Reproduction

Run, inside this container:

1. `python /app/work/solve_F.py`
2. `python /app/work/build_and_check.py`
3. `python /app/work/check_artifact.py`

The final file is `/app/output/centralizer.json`.
