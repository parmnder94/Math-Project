#!/usr/bin/env python3
"""Score completed local blind attempts; this is not official calibration.

Container names and metadata are supplied by the trial controller. A trial is
scored only after the independent agent declares completion. No feedback or
answer material is sent to a running solver.
"""
import argparse
import hashlib
import importlib.util
import json
import shutil
import subprocess
import time
from pathlib import Path


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('trials',type=int,nargs='+')
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument('--metadata-root',type=Path,default=Path('/workspace/kepler-probes'))
    args=parser.parse_args()
    root=args.root
    evidence=root/'authoring/evidence/final_probes';evidence.mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('local_probe_verifier',root/'tests/check_submission.py')
    verifier=importlib.util.module_from_spec(spec);spec.loader.exec_module(verifier)
    instruction=root/'instruction.md'
    shutil.copy2(instruction,evidence/'brief.md')
    for i in args.trials:
        metadata=json.loads((args.metadata_root/f'final-{i:02d}/metadata.json').read_text())
        assert metadata['instruction_sha256']==hashlib.sha256(instruction.read_bytes()).hexdigest()
        destination=evidence/f'trial{i:02d}'
        destination.mkdir(exist_ok=True)
        subprocess.run(['docker','cp',metadata['container']+':/app/.',str(destination)],check=True,capture_output=True)
        for directory in list(destination.rglob('__pycache__')):
            shutil.rmtree(directory)
        artifact=destination/'output/centralizer.json'
        started=time.perf_counter()
        try:
            metrics=verifier.verify_path(artifact)
            reward=1
            error=None
        except verifier.VerificationError as exc:
            metrics=None;reward=0;error=str(exc)
        metadata.update(reward=reward,metrics=metrics,error=error,verification_seconds=time.perf_counter()-started,
                        recorded_unix=time.time(),infrastructure_failure=False,
                        artifact_sha256=hashlib.sha256(artifact.read_bytes()).hexdigest() if artifact.exists() else None,
                        verifier_sha256=hashlib.sha256((root/'tests/check_submission.py').read_bytes()).hexdigest())
        (destination/'trial_result.json').write_text(json.dumps(metadata,indent=2)+'\n')
        print(json.dumps({'trial':i,'reward':reward,'error':error}))
    records=[json.loads(p.read_text()) for p in sorted(evidence.glob('trial*/trial_result.json'))]
    summary={'version':3,'attempts':len(records),'successes':sum(r['reward'] for r in records),
             'complete_eight_attempt_set':len(records)==8,
             'target_met':len(records)==8 and sum(r['reward'] for r in records)<=1,
             'official_platform_trials':False,
             'independence_limitations':'Fresh conversation contexts and separate containers; no reference/verifier access authorized. Collaborative tool runs are not a hostile-access security boundary, exact model revision and effort are unavailable, and trial02 used a theory subagent. This is local evidence only.',
             'timing_note':'started_unix is container provisioning time; recorded_unix is scoring time, not exact solver completion. All attempts had a 14400-second budget and finished voluntarily. No artificial early deadline was applied.',
             'instruction_sha256':hashlib.sha256(instruction.read_bytes()).hexdigest(),'trials':records}
    (evidence/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')


if __name__=='__main__':
    main()
