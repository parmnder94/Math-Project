#!/usr/bin/env python3
"""Run real, separate Docker oracle/independent/nop checks without Harbor.

Only declared JSON artifacts cross the boundary. The verifier always runs
with Docker --network none. This is explicitly not a Harbor result.
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path


def run(command, **kwargs):
    return subprocess.run(command, check=True, text=True, **kwargs)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot(root):
    paths=[root/'instruction.md']
    for directory in ['environment','tests','solution']:
        paths.extend(p for p in (root/directory).rglob('*') if p.is_file()
                     and '__pycache__' not in p.parts and p.suffix!='.pyc')
    paths.extend(root/'authoring/evidence'/name for name in ['independent.py','independent_monodromy.py'])
    return {str(p.relative_to(root)):digest(p) for p in sorted(paths)}


def build_and_audit(root,evidence):
    images={};builds=[];audits={}
    build_environment=dict(os.environ)
    build_state=Path(tempfile.mkdtemp(prefix='task-docker-build-'))
    build_environment['DOCKER_CONFIG']=str(build_state)
    for flavor,context in [('agent','environment'),('verifier','tests')]:
        build_context=root/context
        if (root/'authoring/compact.json').exists():
            build_context=build_state/context
            shutil.copytree(root/context,build_context,ignore=shutil.ignore_patterns('*.whl','__pycache__','*.pyc'))
            assert not list(build_context.rglob('*.whl'))
        command=['docker','build','--network','none','--progress','plain','--tag',f'task-elliptic-{flavor}:local',str(build_context)]
        started=time.perf_counter()
        print(json.dumps({'event':'build_started','flavor':flavor,'command':command}),flush=True)
        with (evidence/f'docker_build_{flavor}.log').open('w') as log:
            log.write('Command: '+json.dumps(command)+'\n');log.flush()
            run(command,stdout=log,stderr=subprocess.STDOUT,env=build_environment)
        image=run(['docker','image','inspect','--format','{{.Id}}',f'task-elliptic-{flavor}:local'],capture_output=True).stdout.strip()
        images[flavor]=image
        builds.append({'flavor':flavor,'image_id':image,'command':command,'elapsed_seconds':time.perf_counter()-started,'status':'passed'})
        if flavor=='agent':
            expected={'/app/data/'+str(p.relative_to(root/'environment/data')):digest(p)
                      for p in (root/'environment/data').rglob('*') if p.is_file()}
            packages=['sympy','mpmath']
        else:
            expected={'/tests/'+name:digest(root/'tests'/name) for name in
                      ['check_submission.py','test_submission.py','test.sh','cover_witness.json','requirements.txt']}
            packages=['python-flint','pytest','pytest-json-ctrf']
        code=('import hashlib,json,pathlib,importlib.metadata,sys; '
              'expected=json.loads(sys.argv[1]); '
              'actual={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in expected}; '
              'assert actual==expected,(actual,expected); '
              'print(json.dumps({"hashes":actual,"python":sys.version.split()[0],'
              '"packages":{p:importlib.metadata.version(p) for p in json.loads(sys.argv[2])}}))')
        audits[flavor]=json.loads(run(['docker','run','--rm','--network','none',image,'python','-c',code,json.dumps(expected),json.dumps(packages)],capture_output=True).stdout)
        print(json.dumps(builds[-1]),flush=True)
    (evidence/'builds.json').write_text(json.dumps(builds,indent=2)+'\n')
    (evidence/'image_input_audit.json').write_text(json.dumps(audits,indent=2)+'\n')
    shutil.rmtree(build_state)
    return images


def validate(root, evidence, repetitions=2):
    evidence.mkdir(parents=True, exist_ok=True)
    if (root/'authoring/compact.json').exists():
        with (evidence/'dependency_restore.log').open('w') as log:
            run([sys.executable,'-B',str(root/'authoring/fetch_dependencies.py'),'--root',str(root)],stdout=log,stderr=subprocess.STDOUT)
    inputs=snapshot(root)
    (evidence/'source_input_hashes.json').write_text(json.dumps(inputs,indent=2)+'\n')
    images=build_and_audit(root,evidence)
    assert snapshot(root)==inputs,'task inputs changed during the image builds'
    records=[]
    for flavor, count in [('oracle',repetitions),('independent',1),('nop',repetitions)]:
        for attempt in range(1,count+1):
            name=f'task-validate-{flavor}-{attempt}-{int(time.time())}'
            dest=evidence/f'{flavor}-{attempt}';dest.mkdir(exist_ok=True)
            agent=f'{name}-agent';verifier=f'{name}-verifier'
            started=time.perf_counter()
            artifact=dest/'centralizer.json'
            if artifact.exists():artifact.unlink()
            expected=0 if flavor=='nop' else 1
            if flavor=='oracle':
                run(['docker','create','--name',agent,'--network','none','--cpus','2','--memory','4g',images['agent'],'bash','/solution/solve.sh'],stdout=subprocess.DEVNULL)
                run(['docker','cp',str(root/'solution'),agent+':/solution'])
                run(['docker','cp',str(root/'instruction.md'),agent+':/app/instruction.md'])
                run(['docker','cp',agent+':/app/instruction.md',str(dest/'instruction.delivered.md')])
                assert digest(dest/'instruction.delivered.md')==inputs['instruction.md']
                with (dest/'agent.log').open('w') as log:
                    run(['docker','start','-a',agent],stdout=log,stderr=subprocess.STDOUT)
                run(['docker','cp',agent+':/app/output/centralizer.json',str(artifact)])
                run(['docker','rm',agent],stdout=subprocess.DEVNULL)
            elif flavor=='independent':
                run(['docker','create','--name',agent,'--network','none','--cpus','2','--memory','4g',images['agent'],'bash','/independent/run.sh'],stdout=subprocess.DEVNULL)
                temporary=dest/'independent';temporary.mkdir(exist_ok=True)
                for file in ['independent.py','independent_monodromy.py']:
                    shutil.copy2(root/'authoring/evidence'/file,temporary/file)
                wheels=list((root/'tests/wheels').glob('python_flint-0.9.0-*.whl'))
                assert len(wheels)==1
                wheel=wheels[0]
                (temporary/'wheels').mkdir(exist_ok=True)
                shutil.copy2(wheel,temporary/'wheels'/wheel.name)
                (temporary/'flint-requirements.txt').write_text('python-flint==0.9.0 --hash=sha256:'+digest(wheel)+'\n')
                (temporary/'run.sh').write_text('#!/bin/bash\nset -euo pipefail\n'
                    'python -m pip install --no-cache-dir --no-index --no-deps --find-links=/independent/wheels '
                    '--require-hashes -r /independent/flint-requirements.txt\n'
                    'python /independent/independent.py --data /app/data/operator.json --output /app/output/centralizer.json\n')
                (dest/'offline_dependency.json').write_text(json.dumps({'wheel':wheel.name,'sha256':digest(wheel),
                    'installation':'disposable independent container only; no public-image changes; --no-index --require-hashes'},indent=2)+'\n')
                run(['docker','cp',str(temporary),agent+':/independent'])
                run(['docker','cp',str(root/'instruction.md'),agent+':/app/instruction.md'])
                run(['docker','cp',agent+':/app/instruction.md',str(dest/'instruction.delivered.md')])
                assert digest(dest/'instruction.delivered.md')==inputs['instruction.md']
                with (dest/'agent.log').open('w') as log:
                    run(['docker','start','-a',agent],stdout=log,stderr=subprocess.STDOUT)
                run(['docker','cp',agent+':/app/output/centralizer.json',str(artifact)])
                run(['docker','rm',agent],stdout=subprocess.DEVNULL)
                shutil.rmtree(temporary)
            run(['docker','create','--name',verifier,'--network','none','--cpus','2','--memory','4g',images['verifier'],'bash','/tests/test.sh'],stdout=subprocess.DEVNULL)
            network=run(['docker','inspect','--format','{{.HostConfig.NetworkMode}}',verifier],capture_output=True).stdout.strip()
            assert network=='none'
            if artifact.exists():
                run(['docker','cp',str(artifact),verifier+':/app/output/centralizer.json'])
            with (dest/'verifier.log').open('w') as log:
                status=subprocess.run(['docker','start','-a',verifier],stdout=log,stderr=subprocess.STDOUT).returncode
            run(['docker','cp',verifier+':/logs/verifier/.',str(dest)])
            run(['docker','rm',verifier],stdout=subprocess.DEVNULL)
            reward=(dest/'reward.txt').read_text().strip()
            ctrf=json.loads((dest/'ctrf.json').read_text())
            assert reward==str(expected), (flavor,reward)
            assert status==(0 if expected else 1), (flavor,status)
            summary=ctrf['results']['summary']
            assert summary['tests']>=1 and summary['pending']==0
            assert summary['passed']==(1 if expected else 0)
            assert summary['failed']==(0 if expected else 1)
            record={'flavor':flavor,'attempt':attempt,'reward':int(reward),'verifier_exit_status':status,'network_mode':network,'agent_network_mode':'none' if flavor!='nop' else None,'agent_image_id':images['agent'],'verifier_image_id':images['verifier'],'elapsed_seconds':time.perf_counter()-started,'ctrf':summary,'artifact_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest() if artifact.exists() else None}
            (dest/'run.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
            print(json.dumps(record),flush=True)
    assert snapshot(root)==inputs,'task inputs changed during Docker validation'
    summary={'runner':'direct separate Docker containers, not Harbor','records':records,'all_expected_outcomes':True,'input_snapshot_unchanged':True,
             'instruction_delivery':'current instruction.md copied and byte-hash checked in each solver container; data/tests image bytes independently checked'}
    (evidence/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument('--evidence',type=Path)
    parser.add_argument('--repetitions',type=int,default=2)
    args=parser.parse_args()
    validate(args.root,args.evidence or args.root/'authoring/evidence/docker',args.repetitions)
