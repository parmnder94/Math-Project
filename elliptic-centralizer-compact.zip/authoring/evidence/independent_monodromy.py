#!/usr/bin/env python3
"""Independent small-field audit, standard-library only; no solver/test imports."""
import argparse,json,math,time
from pathlib import Path
H=[-450303377122368,0,0,305655916797,0,0,-1104246,0,0,1]

def trim(a):
 while len(a)>1 and a[-1]==0:a.pop()
 return a

def modpoly(a,p):return trim([c%p for c in a])
def rempoly(a,b,p):
 a=modpoly(a,p);b=modpoly(b,p)
 if b==[0]:raise ZeroDivisionError
 while len(a)>=len(b) and a!=[0]:
  d=len(a)-len(b);c=a[-1]*pow(b[-1],-1,p)%p
  for j,z in enumerate(b):a[d+j]=(a[d+j]-c*z)%p
  trim(a)
 return a

def gcdpoly(a,b,p):
 a=modpoly(a,p);b=modpoly(b,p)
 while b!=[0]:a,b=b,rempoly(a,b,p)
 return [(c*pow(a[-1],-1,p))%p for c in a]

def peval(a,z,p):
 r=0
 for c in a[::-1]:r=(r*z+c)%p
 return r

def rational(a,z,p):
 de=peval(a['den'],z,p)
 assert de,'certificate point lies at an affine pole'
 return peval(a['num'],z,p)*pow(de,-1,p)%p

def plus(A,B,p):
 # Use the isomorphic short-Weierstrass model v=y/2, v²=x³−11.
 if A is None:return B
 if B is None:return A
 x,v=A;z,w=B
 if x==z and (v+w)%p==0:return None
 slope=((3*x*x if A==B else w-v)*pow((2*v if A==B else z-x)%p,-1,p))%p
 xx=(slope*slope-x-z)%p;vv=(slope*(x-xx)-v)%p
 return (xx,vv)

def multiple(A,n,p):
 R=None
 while n:
  if n&1:R=plus(R,A,p)
  A=plus(A,A,p);n//=2
 return R

def closure(gens,p):
 group={None}
 for A in gens:
  enlarged=set(group);B=A
  while B not in group:
   enlarged.update(plus(C,B,p) for C in group);B=plus(B,A,p)
  group=enlarged
 return group

def verify(artifact,certificate):
 t=time.perf_counter();p=certificate['prime'];assert type(p)is int and 5<=p<=4999 and all(p%d for d in range(2,math.isqrt(p)+1));assert p not in (2,3,11)
 cover=artifact['cover'];h=artifact['normalized_polynomial'];assert h['den']==[1]
 hh=h['num'];assert gcdpoly(hh,[i*hh[i] for i in range(1,len(hh))],p)==[1]
 xx=cover['x']
 for coordinate in (xx,cover['y_multiplier']):
  assert len(modpoly(coordinate['num'],p))==len(coordinate['num']) and len(modpoly(coordinate['den'],p))==len(coordinate['den'])
  assert gcdpoly(coordinate['num'],coordinate['den'],p)==[1]
 assert len(modpoly(xx['num'],p))==19
 roots={}
 for v in range(p):roots.setdefault(v*v%p,[]).append(v)
 allpoints={None}|{(x,v) for x in range(p) for v in roots.get((x*x*x-11)%p,[])}
 tors2=[P for P in allpoints if multiple(P,2,p)is None];tors3=[P for P in allpoints if multiple(P,3,p)is None]
 tors6=[P for P in allpoints if multiple(P,6,p)is None]
 assert len(tors2)==4 and len(tors3)==9 and len(tors6)==36 and p%3==1
 assert 1<=len(certificate['source_points'])<=8
 images=[];reported_images=[]
 for e,w in certificate['source_points']:
  assert type(e)is int and type(w)is int and 0<=e<p and 0<=w<p
  assert (w*w+peval(hh,e,p))%p==0
  X=rational(xx,e,p);Y=w*rational(cover['y_multiplier'],e,p)%p
  assert (Y*Y-4*X**3+44)%p==0
  images.append((X,Y*pow(2,-1,p)%p));reported_images.append([X,Y])
 group=closure(images,p);assert group==allpoints
 orders=[]
 for P in images:
  for n in range(1,len(allpoints)+1):
   if multiple(P,n,p)is None:orders.append(n);break
 result={'status':'passed','prime':p,'target_cardinality':len(allpoints),'rational_2torsion_cardinality':len(tors2),'rational_3torsion_cardinality':len(tors3),'rational_6torsion_cardinality':len(tors6),'source_points':certificate['source_points'],'image_points':reported_images,'image_orders':orders,'image_subgroup_cardinality':len(group),'source_good_reduction':True,'target_good_reduction':True,'cover_degree_after_reduction':18,'elapsed_seconds':time.perf_counter()-t}
 return result


def build_certificate(artifact,RF):
 """Use the independently discovered p=229 witness and recheck everything.
 The reference implementation searches primes and points independently. This
 alternative validates a previously found exact witness, using coordinates
 v=y/2 and a standard-library group law rather than reference arithmetic.
 """
 certificate={'prime':229,'source_points':[[1,48],[2,111]]}
 audit=verify(artifact,certificate)
 cover=artifact['cover']
 def rational_field(z):return RF(z['num'],z['den'])
 rho=rational_field(cover['ramification_polynomial'])
 assert rho.d.degree()==0 and rho.n.degree()==3
 assert rho.n.gcd(rho.n.derivative()).degree()==0
 def residue(z):
  value=rational_field(z);g,a,_=value.d.xgcd(rho.n)
  assert g.degree()==0 and g[0]
  return (value.n*a/g[0])%rho.n
 xr=residue(cover['x']);yr=residue(cover['y_multiplier']);hr=residue(artifact['normalized_polynomial'])
 # These conditions prove the three ramification energies have distinct x
 # images, and the two W signs above each have distinct y images.
 assert xr.degree()==1 and not xr[0] and xr[1]
 assert yr.degree()==0 and yr[0]
 assert hr.degree()==0 and hr[0]
 assert cover['degree']==18 and cover['infinity_ramification_order']==0
 pb=rational_field(cover['pullback'])
 assert not (pb/rho-RF(9))
 certificate={'group_order':math.factorial(18),**certificate}
 return certificate
