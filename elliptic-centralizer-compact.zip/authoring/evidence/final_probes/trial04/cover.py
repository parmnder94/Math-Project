import sympy as s,pickle,time
from sympy.external.gmpy import GROUND_TYPES
print(GROUND_TYPES,flush=True)
x,E,d,u,F,P=pickle.load(open('/app/basic.pkl','rb')); h=s.cancel(P/E**2)
K=s.QQ.frac_field(E)
U=s.Poly(s.cancel(d*F),x,domain=K).monic(); H=K.from_sympy(h)
print('invert begin',time.time(),flush=True)
V=(-E*s.Poly(d,x,domain=K)*s.invert(U.diff(),U)).rem(U) # original N leading constant 893025
# U=N/893025, hence inverse N'=inverse U'/893025
V=V.mul_ground(s.Rational(1,893025))
print('invert done',time.time(),flush=True)
original=(U,V)
steps=[]
while U.degree()>1:
 print('reduction degree',U.degree(),'begin',time.time(),flush=True)
 VV=(V*V).mul_ground(-h)-s.Poly(d,x,domain=K)
 UN,R=VV.div(U); assert R.is_zero
 UN=UN.monic()
 VN=(-V).rem(UN)
 steps.append((UN,VN));U,V=UN,VN
 print('reduced',U.degree(),'at',time.time(),flush=True)
 pickle.dump((original,steps),open('/app/cover_progress.pkl','wb'))
X=s.factor(-U.nth(0));Y=s.factor(2*V.nth(0))
print('X=',X,flush=True);print('Y=',Y,flush=True)
print('curve check',s.cancel(-h*Y**2-4*(X**3-11)),flush=True)
r=s.factor(s.diff(X,E)/Y);print('r=',r,flush=True)
pickle.dump((X,Y,r,original,steps),open('/app/cover.pkl','wb'))
