import sympy as s,json,pickle,math
j=json.load(open('/app/output/centralizer.json'));x,E=s.symbols('x E')
assert set(j)=={'operator','spectral_polynomial','square_factor','normalized_polynomial','genus','quotient','remainder','cover','monodromy'}

def rf(a,t):
 assert set(a)=={'num','den'} and a['den']
 assert len(a['num'])<=129 and len(a['den'])<=129
 for n in a['num']+a['den']:assert type(n) is int and abs(n)<2**2048
 return s.cancel(sum(c*t**i for i,c in enumerate(a['num']))/sum(c*t**i for i,c in enumerate(a['den'])))
def op(a):
 assert len(a)<=33
 for c in a:assert set(c)=={'a','b'}
 return [(rf(c['a'],x),rf(c['b'],x)) for c in a]
A,Q,R=map(lambda k:op(j[k]),('operator','quotient','remainder'))
AA,QQ,RR=pickle.load(open('/app/operators.pkl','rb'))
for p,q in zip((A,Q,R),(AA,QQ,RR)):
 assert len(p)==len(q)
 assert all(s.cancel(c-d)==0 for ab,cd in zip(p,q) for c,d in zip(ab,cd))
P,q,h=map(lambda k:rf(j[k],E),('spectral_polynomial','square_factor','normalized_polynomial'))
assert s.expand(P-q*q*h)==0 and q==E
assert s.gcd(s.Poly(h,E),s.Poly(s.diff(h,E),E)).degree()==0
assert j['genus']==(s.degree(h,E)-1)//2==4
c=j['cover'];assert set(c)=={'x','y_multiplier','degree','pullback','ramification_polynomial','infinity_ramification_order'}
X,Y,r,rho=map(lambda k:rf(c[k],E),('x','y_multiplier','pullback','ramification_polynomial'))
assert s.cancel(-h*Y*Y-4*(X**3-11))==0
assert s.cancel(s.diff(X,E)-r*Y)==0
assert rho==E**3-120582 and c['infinity_ramification_order']==0
assert c['degree']==max(map(lambda a:s.degree(a,E),s.fraction(X)))==18
m=j['monodromy'];assert set(m)=={'group_order','prime','source_points'}
p=m['prime'];assert s.isprime(p) and 5<=p<5000 and 66%p
assert m['group_order']==math.factorial(18)
def coeff(c):return int(s.numer(c))*pow(int(s.denom(c)),-1,p)%p
def poly(a):return s.Poly.from_list([coeff(c) for c in s.Poly(a,E).all_coeffs()],E,modulus=p)
assert poly(h).degree()==s.degree(h,E)
assert s.gcd(poly(h),poly(s.diff(h,E))).degree()==0
for f in (X,Y):
 n,d=s.fraction(f);lc=s.Poly(d,E).LC();n=s.Poly(n/lc,E);d=s.Poly(d/lc,E)
 assert all(int(s.denom(a))%p for a in n.all_coeffs()+d.all_coeffs())
 nn,dd=poly(n),poly(d)
 assert nn.degree()==n.degree() and dd.degree()==d.degree()
 assert s.gcd(nn,dd).degree()==0

def evalf(f,e):
 n,d=map(lambda a:poly(a).eval(e)%p,s.fraction(f))
 return int(n*pow(int(d),-1,p)%p)
def add(a,b):
 if a is None:return b
 if b is None:return a
 x1,y1=a;x2,y2=b
 if x1==x2 and (y1+y2)%p==0:return None
 slope=(6*x1*x1*pow(y1,-1,p) if x1==x2 else (y2-y1)*pow(x2-x1,-1,p))%p
 x3=(slope*slope*pow(4,-1,p)-x1-x2)%p
 return x3,(-y1+slope*(x1-x3))%p
def mult(a,k):
 ans=None
 while k:
  if k&1:ans=add(ans,a)
  a=add(a,a);k//=2
 return ans
T={None}|{(a,b) for a in range(p) for b in range(p) if (b*b-4*(a*a*a-11))%p==0}
assert len(T)==252 and sum(mult(a,6) is None for a in T)==36
S={None};images=[]
for e,w in m['source_points']:
 assert 0<=e<p and 0<=w<p and (w*w+evalf(h,e))%p==0
 a=(evalf(X,e),w*evalf(Y,e)%p);assert a in T;images.append(a)
 C={None};b=a
 while b is not None:C.add(b);b=add(b,a)
 S={add(aa,bb) for aa in S for bb in C}
assert S==T
print('All output encoding, algebraic, curve, degree, ramification, and certificate checks passed.')
print('Finite-field images in original y convention:',images)
print('Target points:',len(T),'6-torsion points:',sum(mult(a,6) is None for a in T))
