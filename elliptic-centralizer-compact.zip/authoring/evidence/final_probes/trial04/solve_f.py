import sympy as s, pickle,time
x,E=s.symbols('x E'); d=x**3-11; u=30*x+198*x/d
cols=[]
for i in range(9):
 f=x**i/d
 z=s.cancel(d**3*(4*d*s.diff(f,x,3)+18*x*x*s.diff(f,x,2)+(12*x-4*u+4*E)*s.diff(f,x)-2*s.diff(u,x)*f))
 print(i,s.denom(z),flush=True)
 cols.append(s.Poly(z,x))
M=s.Matrix([[p.nth(k) for p in cols] for k in range(max(p.degree() for p in cols)+1)])
print('matrix',M.shape,flush=True)
v=M.nullspace()[0]; print('nullspace',flush=True)
N=sum(v[i]*x**i for i in range(9)); N=s.factor(N*s.lcm([s.denom(a) for a in v])); F=s.cancel(N/d)
print('F=',F,flush=True)
print('degE',s.degree(N,E),flush=True)
g=s.degree(N,E); lead=s.cancel(s.Poly(N,E).LC()/d); F=s.cancel(F/lead)
print('F normalized',s.factor(F),flush=True)
DF2=4*d*s.diff(F,x,2)+6*x*x*s.diff(F,x)
P=s.cancel((E-u)*F*F+s.Rational(1,2)*F*DF2-d*s.diff(F,x)**2)
print('P=',s.factor(P),flush=True)
pickle.dump((x,E,d,u,F,P),open('/app/basic.pkl','wb'))
