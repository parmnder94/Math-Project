import sympy as s,pickle,json,os
x,E,d,u,F,P=pickle.load(open('/app/basic.pkl','rb'));h=s.cancel(P/E**2)
X,Y,r,*_=pickle.load(open('/app/cover.pkl','rb'))
A,Q,R=pickle.load(open('/app/operators.pkl','rb'))

def rf(f,t):
 n,d=map(lambda g:s.Poly(g,t,domain=s.QQ),s.fraction(s.cancel(f)))
 lc=s.ilcm(*[int(s.denom(c)) for c in n.all_coeffs()+d.all_coeffs()])
 def co(p):return [int(lc*p.nth(k)) for k in range(p.degree()+1)] if not p.is_zero else []
 return {'num':co(n),'den':co(d)}
def op(A):return [{'a':rf(a,x),'b':rf(b,x)} for a,b in A]
assert s.gcd(s.Poly(h,E),s.Poly(s.diff(h,E),E)).degree()==0
assert s.degree(h,E)==9
rho=E**3-120582
assert s.gcd(s.Poly(rho,E),s.Poly(h,E)).degree()==0
assert s.cancel(s.diff(X,E)/Y-r)==0
# At finite ramification E^3=120582, show X=lambda E, Y=mu with nonzero constants.
Kr=s.QQ.alg_field if False else s.QQ
red=lambda f:s.rem(s.Poly(s.numer(s.cancel(f)),E),s.Poly(rho,E)).as_expr()*s.invert(s.Poly(s.denom(s.cancel(f)),E),s.Poly(rho,E)).as_expr()
xr=s.rem(s.Poly(red(X),E),s.Poly(rho,E)).as_expr();yr=s.rem(s.Poly(red(Y),E),s.Poly(rho,E)).as_expr();hr=s.rem(s.Poly(h,E),s.Poly(rho,E)).as_expr()
print('Branch coordinates:',xr,yr,'W^2=',-hr,flush=True)
assert xr!=0 and yr!=0 and hr!=0
print('Degree X numerator/denominator:',[s.degree(a,E) for a in s.fraction(s.cancel(X))])
print('h=',s.expand(h))
out={'operator':op(A),'spectral_polynomial':rf(P,E),'square_factor':rf(E,E),'normalized_polynomial':rf(h,E),'genus':4,'quotient':op(Q),'remainder':op(R),'cover':{'x':rf(X,E),'y_multiplier':rf(Y,E),'degree':18,'pullback':rf(r,E),'ramification_polynomial':rf(rho,E),'infinity_ramification_order':0},'monodromy':json.load(open('/app/certificate.json'))}
json.dump(out,open('/app/output/centralizer.json','w'),indent=2)
print('Output bytes',os.stat('/app/output/centralizer.json').st_size)
pickle.dump((xr,yr,hr),open('/app/branch.pkl','wb'))
