import sympy as s,pickle,math,time,json
x,E,d,u,F,P=pickle.load(open('/app/basic.pkl','rb'))
K=s.QQ.frac_field(x); xx=K.gens[0]; dd=xx**3-11; zero=K.zero;one=K.one
z=(zero,zero);o=(one,zero)
def field(a,b=0):return (K.from_sympy(a),K.from_sympy(b))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[0],-a[1])
def mul(a,b):return(a[0]*b[0]+4*dd*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,b):return(a[0]*b,a[1]*b)
def der(a):return(4*dd*a[1].diff(xx)+6*xx**2*a[1],a[0].diff(xx))
def trim(A):
 A=list(A)
 while A and A[-1]==z:A.pop()
 return A
def oadd(A,B):return trim([add(A[i] if i<len(A) else z,B[i] if i<len(B) else z) for i in range(max(len(A),len(B)))])
def oneg(A):return [neg(a) for a in A]
def omul(A,B):
 if not A or not B:return []
 C=[z]*(len(A)+len(B)-1)
 derivatives=[list(B)]
 for i in range(1,len(A)):derivatives.append([der(a) for a in derivatives[-1]])
 for i,a in enumerate(A):
  if a==z:continue
  for j,b in enumerate(B):
   if b==z:continue
   for k in range(i+1):C[i+j-k]=add(C[i+j-k],scale(mul(a,derivatives[k][j]),math.comb(i,k)))
 return trim(C)
def opow(A,n):
 R=[o]
 for j in range(n):R=omul(R,A)
 return R
def adj(A):
 R=[]
 for i,a in enumerate(A):
  T=omul([z]*i+[scale(o,(-1)**i)],[a]);R=oadd(R,T)
 return R
L=[field(u),z,field(-1)]
fs=[field(s.cancel(s.Poly(s.cancel(F*d),E).nth(5-j)/d)) for j in range(6)]
A=[];Q=[]
for j in range(6):
 term=[scale(der(fs[j]),s.Rational(1,2)),neg(fs[j])]
 A=oadd(A,omul(term,opow(L,5-j)))
 if j<5:Q=oadd(Q,omul(term,opow(L,4-j)))
R=[scale(der(fs[5]),s.Rational(1,2)),neg(fs[5])]
print('A computed order',len(A)-1,flush=True)
assert A[-1]==o
assert oadd(omul(A,L),oneg(omul(L,A)))==[]
print('commutator zero',flush=True)
assert oadd(A,adj(A))==[]
print('skew check zero',flush=True)
assert oadd(A,oneg(oadd(omul(Q,L),R)))==[]
print('division exact',flush=True)
PL=[]
for (k,),c in s.Poly(P,E).terms():PL=oadd(PL,[scale(a,K.from_sympy(c)) for a in opow(L,k)])
print('P(L) computed',time.time(),flush=True)
assert oadd(omul(A,A),PL)==[]
print('spectral identity zero',time.time(),flush=True)
pickle.dump(tuple([tuple(K.to_sympy(c) for c in a) for a in op] for op in (A,Q,R)),open('/app/operators.pkl','wb'))
print('R',[(s.factor(K.to_sympy(a)),s.factor(K.to_sympy(b))) for a,b in R],flush=True)
