import sympy as s,pickle,json,math
x,E,d,u,F,P=pickle.load(open('/app/basic.pkl','rb'));h=s.cancel(P/E**2)
X,Y,r,*_=pickle.load(open('/app/cover.pkl','rb'))

def canonical(f):
 n,d=map(lambda g:s.Poly(g,E,domain=s.QQ),s.fraction(s.cancel(f)))
 return n.mul_ground(1/d.LC()),d.monic()
polys=[s.Poly(h,E)]+sum([list(canonical(f)) for f in (X,Y)],[])
def peval(a,e,p):
 v=0
 for c in a.all_coeffs():v=(v*e+int(s.numer(c))*pow(int(s.denom(c)),-1,p))%p
 return v

def good(p):
 for a in polys:
  if any(int(s.denom(c))%p==0 for c in a.all_coeffs()):return False
  aa=s.Poly.from_list([int(s.numer(c))*pow(int(s.denom(c)),-1,p)%p for c in a.all_coeffs()],E,modulus=p)
  if aa.degree()!=a.degree():return False
 hp=s.Poly(h,E,modulus=p)
 if s.gcd(hp,hp.diff()).degree()>0:return False
 for a,b in zip(polys[1::2],polys[2::2]):
  aa=s.Poly.from_list([int(s.numer(c))*pow(int(s.denom(c)),-1,p)%p for c in a.all_coeffs()],E,modulus=p)
  bb=s.Poly.from_list([int(s.numer(c))*pow(int(s.denom(c)),-1,p)%p for c in b.all_coeffs()],E,modulus=p)
  if s.gcd(aa,bb).degree()>0:return False
 return True

for p in s.primerange(5,5000):
 p=int(p)
 if 66%p==0 or p%3!=1:continue
 if pow(11,(p-1)//3,p)!=1 or pow(44,(p-1)//3,p)!=1:continue
 if pow(-11%p,(p-1)//2,p)!=1 or pow(33,(p-1)//2,p)!=1:continue
 if not good(p):continue
 sqrt={a*a%p:a for a in range(p)}
 points={None}
 for e in range(p):
  rhs=(e**3-11)%p
  if rhs in sqrt:
   w=sqrt[rhs];points.add((e,w));points.add((e,-w%p))
 def add(a,b):
  if a is None:return b
  if b is None:return a
  xx,yy=a;xx2,yy2=b
  if xx==xx2 and (yy+yy2)%p==0:return None
  if xx==xx2:lam=3*xx*xx*pow(2*yy,-1,p)%p
  else:lam=(yy2-yy)*pow(xx2-xx,-1,p)%p
  xxx=(lam*lam-xx-xx2)%p;yyy=(lam*(xx-xxx)-yy)%p
  return xxx,yyy
 def times(a,n):
  r=None
  while n:
   if n%2:r=add(r,a)
   a=add(a,a);n//=2
  return r
 tors=[a for a in points if times(a,6) is None]
 assert len(tors)==36
 print('prime',p,'target order',len(points),flush=True)
 S={None};witness=[];images=[]
 for e in range(p):
  hm=peval(polys[0],e,p)
  if -hm%p not in sqrt:continue
  a,b,c,dd=[peval(f,e,p) for f in polys[1:]]
  if not b or not dd:continue
  w=sqrt[-hm%p]
  image=(a*pow(b,-1,p)%p,w*c*pow(2*dd,-1,p)%p)
  assert image in points
  if image in S:continue
  witness.append([e,w]);images.append(image)
  cyclic=[None];cur=image
  while cur is not None:cyclic.append(cur);cur=add(cur,image)
  S={add(aa,bb) for aa in S for bb in cyclic}
  print('witness',witness[-1],'image z',image,'order',len(cyclic),'subgroup',len(S),flush=True)
  if S==points:
   assert len(witness)<=8
   json.dump({'group_order':math.factorial(18),'prime':p,'source_points':witness},open('/app/certificate.json','w'),indent=2)
   pickle.dump((p,points,tors,witness,images),open('/app/certificate.pkl','wb'))
   raise SystemExit
  if len(witness)>=8:break
raise RuntimeError('no witness found')
