# Independent attempt 04

Input read only from `/instruction.md` and `/app/data`. All calculations and scripts are under `/app` in this container. No external solutions or task-specific hints used.

The potential is an even elliptic Treibich–Verdier potential with local integer indices (5,1,1,1), since the sum of the three half-period shifts of x is 99x/(x^3-11). I will compute the stationary squared-eigenfunction polynomial directly, then its odd operator, normalization, divisor sum, and a monodromy certificate.

## Exact stationary calculation and global minimality

Write d=x^3-11 and u=30x+198x/d. A squared-eigenfunction coefficient satisfies

    4d F_xxx + 18x^2 F_xx + (12x-4u+4E) F_x - 2u_x F = 0.

This is D^3 F - 4(u-E) D F - 2(Du)F=0 divided by y. The ansatz used here is globally exhaustive, not a guess at denominators. At an ordinary point the stationary ODE permits no pole. At a pole of u with local coefficient n(n+1)/z^2 its indicial polynomial is

    (a-1)(a+2n)(a-2n-2).

The indices of this u are 5 at the identity and 1 at each nontrivial 2-torsion point. The involution fixes all four poles and changes the sign of the local parameter. Thus the odd part of any rational stationary solution cannot have a pole (the only negative indicial root is even). It is globally holomorphic and odd, hence zero. Its even part is a rational function of x, with degree at infinity at most 5 and at most simple poles in x at the three roots of d. Consequently F=N/d with deg_x N<=8 is the complete space, including solutions over the full original field K.

`solve_f.py` forms the 14-by-9 matrix of this ODE on x^i/d, 0<=i<=8, over Q(E). It has a one-dimensional kernel. Normalizing the leading energy coefficient gives

    N = E^5*x^3 - 11*E^5 + 15*E^4*x^4 - 66*E^4*x
      + 315*E^3*x^5 + 693*E^3*x^2 + 6300*E^2*x^6
      - 467082*E^2*x^3 + 6090777*E^2 + 99225*E*x^7
      - 4147605*E*x^4 + 42261912*E*x + 893025*x^8
      - 31434480*x^5 + 276623424*x^2.

The coefficients in x of N have no nonconstant common factor in Q[E] (the x^8 coefficient is the nonzero constant 893025). Therefore the polynomial-in-energy stationary generator has minimal energy degree 5. Any odd commuting operator of order 2m+1 has a nonzero stationary coefficient of energy degree m in its right remainder modulo L-E; alternatively one can first take its skew-adjoint part without changing its leading term. Thus m>=5 for every odd commutant in the full K[D]. The constructed monic order-11 operator is globally minimal.

Write F=sum_{j=0}^5 f_j E^(5-j). The constructed operator is

    A = sum_{j=0}^5 (-f_j D + (D f_j)/2) L^(5-j).

Its leading coefficient is +1, and its right remainder modulo L-E is -F D+(DF)/2, fixing the required sign. `operators.py` implements exact arithmetic in Q(x)+yQ(x) and noncommutative operator composition using the binomial derivative formula. It separately verifies [A,L]=0, A+A*=0, and A^2+P(L)=0, all as complete rational identities. The spectral invariant used independently to obtain P was

    P=(E-u)F^2 + (F D^2F)/2 - (DF)^2/4
     =E^2 (E^3-551232)(E^6-553014E^3+816903549).

Consequently q=E,

    h=E^9-1104246E^6+305655916797E^3-450303377122368,

and h is squarefree by an exact gcd calculation. The geometric genus is 4.

For right division by q(L)=L, omit the j=5 term and reduce the exponent of L by one to obtain Q. The exact nonzero remainder is

    R = y * 35721*x*(5x^3-88)*(25x^6-352x^3+1936)/(2d^2)
        - 35721*x^2*(5x^3-88)^2/d * D.

The identity A=QL+R is separately checked. Its nonzero D coefficient is the differential-division obstruction: the repeated spectral factor does not permit dividing the primitive differential operator by L.

## Specified elliptic divisor sum

This is computed from the problem's actual points, not inferred from a curve identity. Use z=y/2 on z^2=x^3-11 and let U=N/893025 be monic. The initial interpolation polynomial is

    z = W v(x),  v = -E*d*(N_x)^(-1) mod U.

At every root of N this is exactly the specified point's y-coordinate divided by two, because V=EW. `cover.py` computes this modular inverse over Q(E). It then carries out exact elliptic divisor reduction: given (U,Wv), set

    U_new = monic((-h*v^2-d)/U),
    v_new = -v mod U_new.

Every division has zero remainder, checked exactly. The consecutive U degrees are 8,6,4,2,1. The divisor of z-Wv proves at each step that the new divisor represents the same elliptic group sum: the complementary intersections have negative sum, and the sign change in v negates them. At degree one, U=x-X(E), v is constant, and Y=2v. Thus the exact rational X,Y saved in `cover.pkl` and encoded in the JSON are the required group sum, including its sign. All intermediate pairs are stored in `cover_progress.pkl` and `cover.pkl` for reproducibility.

The independently checked curve and differential identities are

    -h Y^2=4(X^3-11),
    X'/Y=9(E^3-120582).

The numerator and denominator of reduced X have degrees 18 and 17. Comparing the two degree-two hyperelliptic projections proves that the degree of alpha is 18.

## Complete ramification

Since h is squarefree of degree 9, dE/W has divisor 6 times the unique point at infinity. The pullback multiplier 9(E^3-120582) has a pole of order 6 there, so infinity is unramified. The ramification polynomial is exactly rho=E^3-120582. It is relatively prime to h and squarefree, so its finite zero divisor consists of six points, each of multiplicity one. These account for all 2g-2=6 ramification multiplicities.

There are six distinct branch values. Modulo rho, the coordinates reduce to

    X = -195908029*E/4747761216,
    Y = 2523287022071/42507719813867616000,
    W^2 = -22103805403968750.

All displayed constants are nonzero. The three distinct energies therefore have distinct target x coordinates, and each pair of W signs gives distinct target y coordinates. Each branch value has exactly one simple ramification point, so every inertia permutation is a transposition.

## Geometric monodromy proof

Let G be the transitive geometric monodromy on 18 sheets, and T its normal subgroup generated by all conjugates of these branch transpositions. The graph whose edges are these transpositions has T-orbits as components, with T equal to the product of full symmetric groups on its components. If there were k>1 components, their block action would define a connected unramified intermediate cover B -> E of degree k dividing 18. Conversely the absence of any nontrivial unramified intermediate factor makes T transitive and gives G=S_18.

The maximal unramified intermediate factor is canonical and descends to Q. The unique rational source point at infinity maps to the target identity, providing a rational origin on B; thus B->E is an isogeny over Q. At p=229, both source and target have good reduction (checked in `certificate.py` and again from the serialized output), and any isogenous B has good reduction as well. The hypothetical factorization therefore reduces over F_229, with isogeny degree k prime to 229.

Here all 36 points of E[6] are F_229-rational. If a nontrivial isogeny B->E of degree dividing 18 existed, choose a prime ell in {2,3} dividing its degree. The kernel of its dual has a nonzero cyclic ell subgroup inside the fully rational E[ell]. Factoring the dual through that subgroup and dualizing produces a last degree-ell isogeny into E. Its kernel is rational: it is Cartier dual to a rational cyclic subgroup, and F_229 contains the ell-th roots of unity. The two elliptic curves have the same number of F_229-points, so the image of this last isogeny is a proper subgroup of E(F_229) of index ell. Every rational source-point image would have to lie in this subgroup.

The certificate contradicts that conclusion: the images of two rational source points generate all E(F_229). Hence k=1, and the geometric monodromy is S_18, of order 18!=6402373705728000. This identifies geometric monodromy, without substituting an arithmetic Galois group.

## Finite-field certificate and final checks

The prime is 229. The source points are (E,W)=(1,181),(2,118). In the original target y convention their images are (16,220),(2,80). Each image has order 42, and together they generate the full group of order 252. Exhaustive elliptic group arithmetic finds exactly 36 points killed by 6.

`certificate.py` checks primality, degree preservation, squarefreeness of h, invertibility of canonical rational coefficient denominators, numerator/denominator coprimality, both source-point equations, definedness of coordinates, target membership, full 6-torsion, and generation. `check_output.py` performs these checks again from the actual JSON; its group law is written directly in the original y-coordinate, independently of the z-coordinate implementation used to find the certificate. It also validates encoding/size bounds, operator agreement with the exact checked operators, normalization, genus, curve identity, pullback, cover degree, and ramification. Output is `/app/output/centralizer.json` (14057 bytes).

## Computational errors and corrections

An initial nested-shell heredoc had quoting damage and was replaced immediately by a literal docker-stdin heredoc; it produced no mathematical result. Installing python-flint initially hit the environment's self-signed certificate chain; using the public package hosts as pip trusted hosts installed it. The first operator-save attempt hit a SymPy FracElement pickle mutation error after all identities had passed; converting field elements to ordinary SymPy expressions before saving fixed it, and the entire operator check was rerun. The first certificate run used a ZZ polynomial where canonical monic-denominator normalization required QQ; setting the explicit rational domain fixed it. No mathematical checks failed.

All computations, outputs, proofs and reproducible scripts remain inside this container. No external task-specific solutions, other attempts, hidden reference, or hidden verifier were inspected.
