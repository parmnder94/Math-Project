import sympy as s,pickle,time
x,E=s.symbols('x E');d=x**3-11
b=pickle.load(open('/app/basic.pkl','rb'));F=b['F'];h=b['h'];q=b['q']
K=s.QQ.frac_field(E)
N=s.Poly(s.cancel(d*F),x,domain=K)
U=N.monic()
print('inverse start',flush=True);t=time.time()
v0=-(s.Poly(q*d,x,domain=K)*s.invert(N.diff(),N)).rem(N)
print('inverse seconds',time.time()-t,flush=True)
f=s.Poly(d,x,domain=K)
seq=[]
while U.degree()>1:
 print('reduce',U.degree(),v0.degree(), 'time',time.time()-t,flush=True)
 V=(f+h*v0*v0).exquo(U).monic()
 v0=(-v0).rem(V)
 seq.append((U,v0))
 U=V
X=-U.nth(0)/U.nth(1)
Y=2*v0.nth(0)
print('X=',s.factor(X),flush=True)
print('Y=',s.factor(Y),flush=True)
r=s.factor(s.diff(X,E)/Y)
print('r=',r,flush=True)
assert s.cancel(-h*Y**2-4*(X**3-11))==0
b.update(X=X,Y=Y,r=r)
pickle.dump(b,open('/app/basic.pkl','wb'))
pickle.dump(seq,open('/app/divisor.pkl','wb'))
