# Independent attempt 02

## Result and scope

The completed artifact is `/app/output/centralizer.json` (14,056 bytes). It has exactly the requested nine fields. All calculations and helper files are inside Docker container `kepler-final-02`; only the public `/instruction.md` and `/app/data` task inputs were used. No reference answer or hidden verifier was inspected. The final check script below was written independently from the public specification.

The primitive monic skew-adjoint symmetry has order 11. Its spectral polynomial is

P(E) = E² (E³ − 551232)(E⁶ − 553014 E³ + 816903549).

Thus q(E)=E, h(E)=(E³−551232)(E⁶−553014 E³+816903549), and the normalization has genus 4. The prescribed group-sum cover has degree 18, pullback 9(E³−120582)dE/W, ramification polynomial E³−120582, and no ramification at infinity. The geometric monodromy is S18, of order 6402373705728000. The arithmetic certificate is p=229 with source points (1,48) and (2,111).

## Reproduction

Python 3 and SymPy 1.14.0 suffice; the computations use exact rational arithmetic. Run the following commands inside this container, in order:

```sh
python /app/solve.py
python /app/spectral.py
python /app/cover.py
python /app/operators.py
python /app/certificate.py
python /app/serialize.py
python /app/verify_output.py
```

An additional independent pullback check is `python /app/trace.py`; it writes only `/app/trace.pkl`.

- `/app/solve.py` constructs the stationary Lenard coefficients in rational x-functions. It finds a stationary relation at index 5 and saves `/app/basic.pkl`.
- `/app/spectral.py` computes P from (E−u)F² + F D²F/2 − (DF)²/4, checks the rational identity in x, and factors P.
- `/app/cover.py` starts with N=(x³−11)F, U=N/LC(N), and the polynomial v representing −q(x³−11)/N_x modulo N. On the auxiliary model z²=x³−11, the divisor has z=Wv. The repeated exact reduction U_new=(x³−11+h v²)/U, v_new=−v mod U_new decreases degrees 8→6→4→2→1 and gives the required group sum. It saves X,Y,r in `/app/basic.pkl` and intermediate data in `/app/divisor.pkl`.
- `/app/operators.py` implements the differential field and operator multiplication, constructs the monic order-11 A from F, divides it on the right by L, and checks all exact operator identities. It saves `/app/ops.pkl`.
- `/app/certificate.py` enumerates finite elliptic groups and source images, finds the certificate, and writes `/app/certificate.pkl` and `/app/certificate_checks.json`.
- `/app/serialize.py` writes the submission in the specified integer-array rational-function encoding.
- `/app/verify_output.py` reparses the actual submitted JSON, verifies its size-related encoding constraints, independently recovers F by reducing A modulo L−E, recomputes the specified divisor sum, and exhaustively checks the certificate.

The rational right-division remainder is nonzero. In left-coefficient notation it is

R = [35721 x(5x³−88)(25x⁶−352x³+1936)/(2(x³−11)²)] y
    − [35721 x²(5x³−88)²/(x³−11)] D.

This explicitly obstructs dividing A by the repeated spectral factor q(L)=L in the differential operator ring.

## Executed checks

Both the construction and independent JSON validation passed the following exact checks:

- Leading coefficient 1, order 11, A* = −A, and [A,L]=0.
- A²+P(L)=0; q and h monic; P=q²h; h squarefree of degree 9.
- A=Q L+R and ord(R)=1<2.
- The D coefficient of the remainder modulo L−E is −F, with constant coefficient DF/2.
- Divisor reduction recovers exactly the submitted X and Y with the required sign.
- −hY²=4(X³−11), X'/Y=9(E³−120582), cover degree 18, and full ramification of degree 6.
- Six distinct simple branch values, from exact reductions of X,Y,h modulo the ramification polynomial.
- Good reduction at p=229, preservation of degrees and coprimality, and rational coefficient denominators invertible modulo p.
- The reduced target has 252 points; precisely 36 are killed by 6.
- (1,48) maps to (16,9), which generates a subgroup of size 42; adding the image (2,149) of (2,111) generates all 252 target points.
- JSON keys, coefficient integer bounds, operator lengths, and rational-function array limits pass; file size is far below 2 MiB.

The final validator printed:

```text
JSON encoding, exact differential identities and division all pass
Recovered F and divisor reduction [8, 6, 4, 2, 1] verify cover, sign, degree and full ramification
Certificate source [1, 48] image (16, 9) generated group order 42
Certificate source [2, 111] image (2, 149) generated group order 252
All independent artifact checks passed; target order 252 full 6-torsion confirmed
```

## Errors and repairs

An optional attempt to install python-flint failed because the package index TLS certificate could not be verified. Verification was not bypassed; no extra package was needed and all computations completed using the existing SymPy installation.

During parallel proof checking, the trace helper briefly overwrote the shared basic pickle from a stale snapshot. The exact cover computation was rerun to restore X,Y,r before construction and serialization. The trace helper now writes a separate `/app/trace.pkl`, so the documented reproduction has no such collision. The submitted artifact was independently validated after repair.

## Mathematical proofs

The remaining proof details follow. They establish global minimality independently of the construction ansatz and establish geometric, rather than arithmetic, monodromy.

# Proof notes: minimality, covering differential, ramification, and geometric monodromy

These notes concern only the supplied public operator and the explicit computations in this container.

## Minimal odd order over the full differential field

At the original elliptic curve origin choose a local parameter t normalized by D=d/dt. Then x=t^(-2)+O(t^4), y=-2t^(-3)+O(t^3), and u=30t^(-2)+O(t^4).

Every differential operator of odd order 2m+1 has a unique expansion as a sum of (b_j D+c_j)L^j. Comparing the coefficients in its commutator with L shows that b_m is a nonzero constant, c_j=-D(b_j)/2 plus a constant, and, after reindexing b_j as f_(m-j),

D(f_(j+1))=u D(f_j)+D(u) f_j/2-D^3(f_j)/4,
D(f_(m+1))=0.

The constants in the c_j give a polynomial in L and do not affect the odd order. Thus this reduction applies to every odd commuting operator in K[D], without any rational-function denominator ansatz. Equivalently one may first take the skew-adjoint part, whose odd leading term is unchanged.

Normalize f_0=1. The leading Laurent terms forced by this recursion are f_j=a_j t^(-2j)+less singular terms, where

a_0=1,
a_(j+1)=(2j+1)/(2j+2) * (30-j(j+1)) * a_j.

Arbitrary integration constants affect only less singular terms. For m<5 every factor 30-j(j+1) occurring through the putative terminal derivative is nonzero. Consequently D(f_(m+1)) has a nonzero pole and cannot vanish. Every positive odd commuting order is therefore at least 11. The explicitly verified order-11 operator attains this bound, establishing global minimality over K.

## Independent proof of the specified divisor sum pullback

Write N=dF, q=E, V=qW, and let xi run through the eight generic roots of N. Implicit differentiation gives dxi/dE=-N_E(xi)/N_x(xi). The stipulated y-coordinate is yi=-2Vd(xi)/N_x(xi). Since the invariant elliptic differential adds under the group law,

alpha*(dx/y) = sum_i dxi/yi
              = [sum_i N_E(xi)/d(xi)] dE/(2qW).

The exact trace computation in trace.py gives

r(E)=9(E^3-120582).

It matches X'(E)/Y(E) computed from the exact divisor reduction. This trace formula is independent of the particular reduction algorithm and has the required sign.

## Degree and complete ramification

The normalized polynomial h has degree nine and is squarefree, so the source genus is four. The reduced X(E) has numerator degree 18 and denominator degree 17; the rational map E -> X therefore has degree 18. Both source E-coordinate and target x-coordinate have degree two, hence alpha has degree 18.

The source has a unique rational point over E=infinity. Since X has a simple pole as a rational function of E at infinity, alpha takes this source point to the elliptic origin.

The differential r(E)dE/W has simple finite zeros at both points above each of the three roots of rho=E^3-120582. The polynomial rho is coprime to h. It has no other finite zeros or poles. At infinity, E=t^(-2), W is a nonzero constant times t^(-9)(1+...), and r is a nonzero constant times t^(-6)(1+...). Hence r dE/W is nonzero and regular at infinity. The full ramification consists of six points of index two, with no infinity ramification. Its degree six equals 2g-2.

Exact reduction modulo rho gives

X = -195908029 E/4747761216,
Y = 2523287022071/42507719813867616000,
h = 22103805403968750.

All constants are nonzero, and the denominators of X and Y are coprime to rho. Thus the three ramification E-values have distinct nonzero target x-coordinates. The two source points over each give opposite nonzero target y-coordinates. There are six distinct branch values, each with exactly one ramification point and local monodromy a transposition.

## Excluding every geometric unramified factor

The supplied finite-field certificate uses p=229. Direct enumeration gives |E(F_229)|=252 and |E[6](F_229)|=36. The source points (1,48) and (2,111) map to target points (16,9) and (2,149), respectively. Their images generate E(F_229): the first generates a subgroup of size 42, and adjoining the second gives size 252. The certificate script also verifies all specified good-reduction, squarefreeness, degree, and coprimality conditions.

Suppose alpha had a nontrivial geometric unramified factor. Its maximal unramified factor descends to Q: let B be the identity component of the kernel of alpha_*:J(C)->E, form the elliptic quotient E'=J(C)/B, and compose the Abel-Jacobi map based at the rational source infinity point with the quotient. This gives alpha=phi beta, with phi:E'->E an isogeny over Q and beta(infinity)=O. Equivalently this is the maximal isogeny through which alpha factors. The degree k of phi divides deg(alpha)=18.

Both elliptic curves have good reduction at 229: good reduction is invariant under isogeny. Since 229 does not divide k, phi reduces to an isogeny of the same degree. The source has good reduction by the squarefreeness of h, and beta extends over the local base by the Neron mapping property. Thus the reduction of every alpha-image of a rational source point belongs to the subgroup phi(E'(F_229)).

If k>1, choose a prime ell dividing k; then ell is 2 or 3. The kernel of the dual isogeny contains a subgroup H of order ell in E[ell]. Every point of E[ell] is rational over F_229 by the full 6-torsion condition, so H is defined over F_229. Quotienting by H and dualizing factors phi through an isogeny psi:E''->E of degree ell. The kernel of psi is the Cartier dual of H. It is also rational over F_229, because 229 is 1 modulo ell. Consequently psi has ell rational kernel points. Isogenous elliptic curves over a finite field have equal point counts, so psi(E''(F_229)) has index ell in E(F_229). All alpha-images lie in this proper subgroup, contradicting their certified generation of E(F_229). Therefore k=1, and alpha has no nontrivial geometric unramified factor.

## Geometric monodromy

Let G be the transitive monodromy subgroup of S_18 and let T be the normal subgroup generated by the local inertia transpositions. A subgroup generated by transpositions is the product of symmetric groups on the connected components of its transposition graph. Its orbits are a G-invariant partition. Killing inertia makes the corresponding quotient cover unramified over the elliptic target; if there were more than one orbit this would give a nontrivial isogeny factor. The arithmetic argument excludes that possibility. Therefore T is transitive, its graph is connected, and T=S_18. Hence G=S_18 and its order is

18! = 6402373705728000.
