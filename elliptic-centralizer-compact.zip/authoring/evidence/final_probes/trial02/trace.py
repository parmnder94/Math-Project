import sympy as s, pickle
x,E=s.symbols("x E");d=x**3-11
b=pickle.load(open("/app/basic.pkl","rb"));F=b["F"];q=b["q"]
N=s.cancel(d*F)
np=s.Poly(N,x); n=np.degree()
print("N degree",n,flush=True)
inv=s.invert(d,N,x)
T=s.Poly(s.cancel(s.rem(s.diff(N,E)*inv,N,x)),x)
np=np.monic(); cs=np.all_coeffs(); pw=[s.Integer(n)]
for k in range(1,n):
 pw.append(s.cancel(-sum(cs[i]*pw[k-i] for i in range(1,k))-k*cs[k]))
r=s.factor(sum(T.nth(k)*pw[k] for k in range(n))/(2*q))
print("r",r,flush=True)
pickle.dump({"r":r},open("/app/trace.pkl","wb"))
