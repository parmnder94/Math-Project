import sympy as s,pickle,json,math,os
x,E=s.symbols('x E');b=pickle.load(open('/app/basic.pkl','rb'));ops=pickle.load(open('/app/ops.pkl','rb'));cert=pickle.load(open('/app/certificate.pkl','rb'))
def rf(f,t):
 n,d=s.cancel(f).as_numer_denom();pn=s.Poly(n,t);pd=s.Poly(d,t)
 vals=pn.all_coeffs()+pd.all_coeffs();z=s.ilcm(*[a.q for a in vals]);
 num=[int(a*z) for a in reversed(pn.all_coeffs())];den=[int(a*z) for a in reversed(pd.all_coeffs())]
 if num==[0]:num=[]
 return {'num':num,'den':den}
def op(a):return [{'a':rf(aa,x),'b':rf(bb,x)} for aa,bb in a]
out={'operator':op(ops['A']),'spectral_polynomial':rf(b['P'],E),'square_factor':rf(b['q'],E),'normalized_polynomial':rf(b['h'],E),'genus':4,'quotient':op(ops['Q']),'remainder':op(ops['R']),'cover':{'x':rf(b['X'],E),'y_multiplier':rf(b['Y'],E),'degree':18,'pullback':rf(b['r'],E),'ramification_polynomial':rf(E**3-120582,E),'infinity_ramification_order':0},'monodromy':{'group_order':math.factorial(18),**cert}}
os.makedirs('/app/output',exist_ok=True)
path='/app/output/centralizer.json';json.dump(out,open(path,'w'),indent=2)
print('wrote',path,'size',os.path.getsize(path),'bytes')
print('R0=',s.factor(ops['R'][0][1]),'*y')
print('R1=',s.factor(ops['R'][1][0]))
print('gcd(h,hprime)',s.gcd(b['h'],s.diff(b['h'],E)))
