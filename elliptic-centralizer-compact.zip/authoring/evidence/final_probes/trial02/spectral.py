exec(open('/app/solve.py').read().split('fs=[s.Integer(1)]')[0])
b=pickle.load(open('/app/basic.pkl','rb'));F=b['F']
D2F=4*d*s.diff(F,x,2)+6*x*x*s.diff(F,x)
P0=(E-u)*F**2+F*D2F/2-d*s.diff(F,x)**2
P=s.factor(P0.subs(x,0))
print('P',P,flush=True)
print('verify derivative identity',s.cancel(P0-P)==0,flush=True)
q=s.Integer(1);h=s.Integer(1)
for z,m in s.factor_list(P,E)[1]:
 q*=z**(m//2);h*=z**(m%2)
q=s.Poly(q,E).monic().as_expr();h=s.Poly(h,E).monic().as_expr()
print('q',q,'h',s.factor(h),flush=True)
b.update(P=P,q=q,h=h)
pickle.dump(b,open('/app/basic.pkl','wb'))
