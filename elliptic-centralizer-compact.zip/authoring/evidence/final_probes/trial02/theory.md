# Proof notes: minimality, covering differential, ramification, and geometric monodromy

These notes concern only the supplied public operator and the explicit computations in this container.

## Minimal odd order over the full differential field

At the original elliptic curve origin choose a local parameter t normalized by D=d/dt. Then x=t^(-2)+O(t^4), y=-2t^(-3)+O(t^3), and u=30t^(-2)+O(t^4).

Every differential operator of odd order 2m+1 has a unique expansion as a sum of (b_j D+c_j)L^j. Comparing the coefficients in its commutator with L shows that b_m is a nonzero constant, c_j=-D(b_j)/2 plus a constant, and, after reindexing b_j as f_(m-j),

D(f_(j+1))=u D(f_j)+D(u) f_j/2-D^3(f_j)/4,
D(f_(m+1))=0.

The constants in the c_j give a polynomial in L and do not affect the odd order. Thus this reduction applies to every odd commuting operator in K[D], without any rational-function denominator ansatz. Equivalently one may first take the skew-adjoint part, whose odd leading term is unchanged.

Normalize f_0=1. The leading Laurent terms forced by this recursion are f_j=a_j t^(-2j)+less singular terms, where

a_0=1,
a_(j+1)=(2j+1)/(2j+2) * (30-j(j+1)) * a_j.

Arbitrary integration constants affect only less singular terms. For m<5 every factor 30-j(j+1) occurring through the putative terminal derivative is nonzero. Consequently D(f_(m+1)) has a nonzero pole and cannot vanish. Every positive odd commuting order is therefore at least 11. The explicitly verified order-11 operator attains this bound, establishing global minimality over K.

## Independent proof of the specified divisor sum pullback

Write N=dF, q=E, V=qW, and let xi run through the eight generic roots of N. Implicit differentiation gives dxi/dE=-N_E(xi)/N_x(xi). The stipulated y-coordinate is yi=-2Vd(xi)/N_x(xi). Since the invariant elliptic differential adds under the group law,

alpha*(dx/y) = sum_i dxi/yi
              = [sum_i N_E(xi)/d(xi)] dE/(2qW).

The exact trace computation in trace.py gives

r(E)=9(E^3-120582).

It matches X'(E)/Y(E) computed from the exact divisor reduction. This trace formula is independent of the particular reduction algorithm and has the required sign.

## Degree and complete ramification

The normalized polynomial h has degree nine and is squarefree, so the source genus is four. The reduced X(E) has numerator degree 18 and denominator degree 17; the rational map E -> X therefore has degree 18. Both source E-coordinate and target x-coordinate have degree two, hence alpha has degree 18.

The source has a unique rational point over E=infinity. Since X has a simple pole as a rational function of E at infinity, alpha takes this source point to the elliptic origin.

The differential r(E)dE/W has simple finite zeros at both points above each of the three roots of rho=E^3-120582. The polynomial rho is coprime to h. It has no other finite zeros or poles. At infinity, E=t^(-2), W is a nonzero constant times t^(-9)(1+...), and r is a nonzero constant times t^(-6)(1+...). Hence r dE/W is nonzero and regular at infinity. The full ramification consists of six points of index two, with no infinity ramification. Its degree six equals 2g-2.

Exact reduction modulo rho gives

X = -195908029 E/4747761216,
Y = 2523287022071/42507719813867616000,
h = 22103805403968750.

All constants are nonzero, and the denominators of X and Y are coprime to rho. Thus the three ramification E-values have distinct nonzero target x-coordinates. The two source points over each give opposite nonzero target y-coordinates. There are six distinct branch values, each with exactly one ramification point and local monodromy a transposition.

## Excluding every geometric unramified factor

The supplied finite-field certificate uses p=229. Direct enumeration gives |E(F_229)|=252 and |E[6](F_229)|=36. The source points (1,48) and (2,111) map to target points (16,9) and (2,149), respectively. Their images generate E(F_229): the first generates a subgroup of size 42, and adjoining the second gives size 252. The certificate script also verifies all specified good-reduction, squarefreeness, degree, and coprimality conditions.

Suppose alpha had a nontrivial geometric unramified factor. Its maximal unramified factor descends to Q: let B be the identity component of the kernel of alpha_*:J(C)->E, form the elliptic quotient E'=J(C)/B, and compose the Abel-Jacobi map based at the rational source infinity point with the quotient. This gives alpha=phi beta, with phi:E'->E an isogeny over Q and beta(infinity)=O. Equivalently this is the maximal isogeny through which alpha factors. The degree k of phi divides deg(alpha)=18.

Both elliptic curves have good reduction at 229: good reduction is invariant under isogeny. Since 229 does not divide k, phi reduces to an isogeny of the same degree. The source has good reduction by the squarefreeness of h, and beta extends over the local base by the Neron mapping property. Thus the reduction of every alpha-image of a rational source point belongs to the subgroup phi(E'(F_229)).

If k>1, choose a prime ell dividing k; then ell is 2 or 3. The kernel of the dual isogeny contains a subgroup H of order ell in E[ell]. Every point of E[ell] is rational over F_229 by the full 6-torsion condition, so H is defined over F_229. Quotienting by H and dualizing factors phi through an isogeny psi:E''->E of degree ell. The kernel of psi is the Cartier dual of H. It is also rational over F_229, because 229 is 1 modulo ell. Consequently psi has ell rational kernel points. Isogenous elliptic curves over a finite field have equal point counts, so psi(E''(F_229)) has index ell in E(F_229). All alpha-images lie in this proper subgroup, contradicting their certified generation of E(F_229). Therefore k=1, and alpha has no nontrivial geometric unramified factor.

## Geometric monodromy

Let G be the transitive monodromy subgroup of S_18 and let T be the normal subgroup generated by the local inertia transpositions. A subgroup generated by transpositions is the product of symmetric groups on the connected components of its transposition graph. Its orbits are a G-invariant partition. Killing inertia makes the corresponding quotient cover unramified over the elliptic target; if there were more than one orbit this would give a nontrivial isogeny factor. The arithmetic argument excludes that possibility. Therefore T is transitive, its graph is connected, and T=S_18. Hence G=S_18 and its order is

18! = 6402373705728000.
