import sympy as s,pickle
E=s.symbols("E");rho=E**3-120582
b=pickle.load(open("/app/basic.pkl","rb"))
for k in ("X","Y","h"):
 n,d=s.fraction(s.cancel(b[k]));v=s.rem(n*s.invert(d,rho,E),rho,E)
 print(k,"modrho=",s.factor(v))
X=b["X"];Y=b["Y"];h=b["h"]
xn,xd=s.fraction(X); yn,yd=s.fraction(Y)
print("branch finite gcds",s.gcd(rho,xd),s.gcd(rho,yd),s.gcd(rho,h))
print("branch x cube",s.factor(s.rem(xn**3*s.invert(xd**3,rho,E),rho,E)))
print("branch y squared",s.factor(s.rem(-h*yn**2*s.invert(yd**2,rho,E),rho,E)))
