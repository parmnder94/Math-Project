import sympy as s
from pathlib import Path
import pickle
x,E=s.symbols('x E')
d=x**3-11
u=30*x+198*x/d

def T(f):
 return s.cancel(u*s.diff(f,x)+s.diff(u,x)*f/2-d*s.diff(f,x,3)-s.Rational(9,2)*x*x*s.diff(f,x,2)-3*x*s.diff(f,x))

def integ(g,j):
 cs=s.symbols('c:'+str(j+4))
 f=sum(cs[i]*x**i for i in range(j+1))+sum(cs[j+1+i]*x**i for i in range(3))/d
 eq=s.Poly(s.cancel(s.diff(f,x)-g).as_numer_denom()[0],x)
 sol=s.solve(eq.all_coeffs()+[cs[0]],cs)
 if not sol: return None
 return s.factor(f.subs(sol))
fs=[s.Integer(1)]
for j in range(1,9):
 tj=T(fs[-1]); fj=integ(tj,j)
 print('j',j,'f',fj,flush=True)
 if fj is None: break
 fs.append(fj)
 ts=[T(f) for f in fs]
 ds=s.symbols('a:'+str(j))
 comb=ts[-1]+sum(ds[k]*ts[k] for k in range(j))
 eq=s.Poly(s.cancel(comb).as_numer_denom()[0],x)
 sol=s.solve(eq.all_coeffs(),ds)
 print('stationary',sol,flush=True)
 if sol:
  F=sum((fs[k]+sum(sol.get(ds[j-l],0)*fs[k-l] for l in range(1,k+1)))*E**(j-k) for k in range(j+1))
  print('F=',s.factor(F),flush=True)
  with open('/app/basic.pkl','wb') as h:pickle.dump({'g':j,'fs':fs,'F':s.factor(F),'sol':sol},h)
  break
