import json,sys,math,sympy as s
import operators as o
x,E=s.symbols('x E')
p='/app/output/centralizer.json';b=json.load(open(p))
assert set(b)==set('operator spectral_polynomial square_factor normalized_polynomial genus quotient remainder cover monodromy'.split())
assert set(b['cover'])==set('x y_multiplier degree pullback ramification_polynomial infinity_ramification_order'.split())
assert set(b['monodromy'])=={'group_order','prime','source_points'}
def rf(j,t):
 assert set(j)=={'num','den'}
 assert len(j['num'])<=129 and 1<=len(j['den'])<=129
 for a in j['num']+j['den']:assert type(a)==int and abs(a)<2**2048
 n=sum(a*t**i for i,a in enumerate(j['num']));d=sum(a*t**i for i,a in enumerate(j['den']));assert d!=0
 return s.cancel(n/d)
def decop(a):
 assert len(a)<=33
 r=[]
 for z in a:
  assert set(z)=={'a','b'}
  r.append((o.K.from_sympy(rf(z['a'],x)),o.K.from_sympy(rf(z['b'],x))))
 return o.trim(r)
A=decop(b['operator']);Q=decop(b['quotient']);R=decop(b['remainder']);u=30*x+198*x/(x**3-11);L=[o.c(u),o.Z,o.c(-1)]
assert len(A)==12 and A[-1]==o.O
assert o.oa(o.adj(A),A)==[]
assert o.oa(o.om(A,L),o.on(o.om(L,A)))==[]
P=rf(b['spectral_polynomial'],E);q=rf(b['square_factor'],E);h=rf(b['normalized_polynomial'],E)
assert s.Poly(P,E).LC()==s.Poly(q,E).LC()==s.Poly(h,E).LC()==1
assert s.expand(P-q*q*h)==0
assert s.gcd(h,s.diff(h,E))==1
assert b['genus']==(s.degree(h,E)-1)//2==4
powers=[[o.O]]
for i in range(s.degree(P,E)):powers.append(o.om(powers[-1],L))
def polyL(p):
 a=[]
 for (i,),z in s.Poly(p,E).terms():a=o.oa(a,[o.mul(o.c(z),v) for v in powers[i]])
 return a
assert o.oa(o.om(A,A),polyL(P))==[]
assert o.oa(o.om(Q,polyL(q)),R)==A and len(R)-1<2*s.degree(q,E)
assert len(R)==2 and R[-1]!=o.Z
print('JSON encoding, exact differential identities and division all pass',flush=True)
# Recover F independently from the submitted A by reducing powers D^j.
o.K=s.QQ.frac_field(x,E);o.xx=o.K.gens[0];o.dd=o.xx**3-11;o.Z=(o.K.zero,o.K.zero);o.O=(o.K.one,o.K.zero)
A=decop(b['operator']);rem=[o.O,o.Z];total=[o.Z,o.Z]
for ai in A:
 for k in range(2):total[k]=o.add(total[k],o.mul(ai,rem[k]))
 rem=[o.add(o.D(rem[0]),o.mul(o.c(u-E),rem[1])),o.add(rem[0],o.D(rem[1]))]
assert total[1][1]==0
F=-total[1][0].as_expr();assert total[0]==o.mul(o.c(s.Rational(1,2)),o.D(o.c(F)))
# Recover the group sum by exact reduction on y_half^2=x^3-11.
K=s.QQ.frac_field(E);d=x**3-11;N=s.Poly(s.cancel(d*F),x,domain=K);U=N.monic()
assert U.degree()==8 and s.gcd(U,U.diff()).degree()==0
v=-(s.Poly(q*d,x,domain=K)*s.invert(N.diff(),N)).rem(N)
f=s.Poly(d,x,domain=K);degs=[U.degree()]
while U.degree()>1:
 U1=(f+h*v*v).exquo(U).monic();v=(-v).rem(U1);U=U1;degs.append(U.degree())
X=rf(b['cover']['x'],E);Y=rf(b['cover']['y_multiplier'],E);r=rf(b['cover']['pullback'],E);rho=rf(b['cover']['ramification_polynomial'],E)
assert s.cancel(X+U.nth(0)/U.nth(1))==0 and s.cancel(Y-2*v.nth(0))==0
assert s.cancel(-h*Y*Y-4*(X**3-11))==0
assert s.cancel(s.diff(X,E)/Y-r)==0
nn,dd=s.cancel(X).as_numer_denom();assert max(s.degree(nn,E),s.degree(dd,E))==b['cover']['degree']==18
assert r==9*rho and s.Poly(rho,E).LC()==1 and s.gcd(rho,h)==1 and s.gcd(rho,s.diff(rho,E))==1
assert b['cover']['infinity_ramification_order']==2*b['genus']-2-2*s.degree(rho,E)==0
print('Recovered F and divisor reduction',degs,'verify cover, sign, degree and full ramification',flush=True)
# Distinct branch values: reduce rational functions modulo rho.
def modrho(f):
 n,d=s.cancel(f).as_numer_denom();return s.rem(n*s.invert(d,rho,E),rho,E)
xbr=modrho(X);ybr=modrho(Y);hbr=s.rem(h,rho,E)
assert s.degree(xbr,E)==1 and xbr.coeff(E)!=0 and xbr.subs(E,0)==0 and ybr!=0 and hbr!=0
# Finite field certificate, independent exhaustive checks.
p=b['monodromy']['prime'];assert s.isprime(p) and 5<=p<5000 and 66%p!=0
hp=s.Poly(h,E,modulus=p);assert hp.degree()==9 and s.gcd(hp,hp.diff()).degree()==0

def canon(f):
 n,d=s.cancel(f).as_numer_denom();lc=s.Poly(d,E).LC();n=s.Poly(n/lc,E);d=s.Poly(d/lc,E)
 assert all(int(a.q)%p for a in n.all_coeffs()+d.all_coeffs())
 mn=s.Poly(n.as_expr(),E,modulus=p);md=s.Poly(d.as_expr(),E,modulus=p)
 assert mn.degree()==n.degree() and md.degree()==d.degree() and s.gcd(mn,md).degree()==0
 return mn,md
# Rational coefficients must be reduced using modular inverses explicitly.
def canon_mod(f):
 n,d=s.cancel(f).as_numer_denom();lc=s.Poly(d,E).LC();n=s.Poly(n/lc,E);d=s.Poly(d/lc,E)
 def conv(poly):
  cs=poly.all_coeffs();assert all(int(a.q)%p for a in cs)
  return s.Poly.from_list([int(a.p)*pow(int(a.q),-1,p)%p for a in cs],E,modulus=p)
 mn,md=conv(n),conv(d)
 assert mn.degree()==n.degree() and md.degree()==d.degree() and s.gcd(mn,md).degree()==0
 return mn,md
xn,xd=canon_mod(X);yn,yd=canon_mod(Y);canon_mod(h)
sq={}
for z in range(p):sq.setdefault(z*z%p,[]).append(z)
pts={None}|{(z,w) for z in range(p) for w in sq.get((z**3-11)%p,[])}
def add(P,Q):
 if P is None:return Q
 if Q is None:return P
 a,b=P;c,d=Q
 if a==c and (b+d)%p==0:return None
 m=((d-b)*pow(c-a,-1,p) if a!=c else 3*a*a*pow(2*b,-1,p))%p
 xx=(m*m-a-c)%p;return(xx,(m*(a-xx)-b)%p)
def mul(n,P):
 Q=None
 while n:
  if n&1:Q=add(Q,P)
  P=add(P,P);n//=2
 return Q
assert sum(mul(6,P) is None for P in pts)==36
sources=b['monodromy']['source_points'];assert 1<=len(sources)<=8
H={None}
for pair in sources:
 assert len(pair)==2 and all(type(z)==int and 0<=z<p for z in pair)
 e,w=pair;assert (w*w+int(hp.eval(e)))%p==0
 dx=int(xd.eval(e))%p;dy=int(yd.eval(e))%p;assert dx and dy
 T=(int(xn.eval(e))*pow(dx,-1,p)%p,w*int(yn.eval(e))*pow(2*dy,-1,p)%p);assert T in pts
 S=[];Q0=T
 while Q0 not in H:S.append(Q0);Q0=add(Q0,T)
 H=H|{add(R,T0) for R in H for T0 in S}
 print('Certificate source',pair,'image',(T[0],2*T[1]%p),'generated group order',len(H),flush=True)
assert H==pts
assert b['monodromy']['group_order']==math.factorial(18)
print('All independent artifact checks passed; target order',len(pts),'full 6-torsion confirmed',flush=True)
