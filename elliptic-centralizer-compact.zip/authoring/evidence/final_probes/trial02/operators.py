import sympy as s,pickle,time
x,E=s.symbols('x E');K=s.QQ.frac_field(x);xx=K.gens[0];dd=xx**3-11
Z=(K.zero,K.zero);O=(K.one,K.zero)
def c(z):return (K.from_sympy(s.sympify(z)),K.zero)
def add(v,w):return(v[0]+w[0],v[1]+w[1])
def neg(v):return(-v[0],-v[1])
def sub(v,w):return add(v,neg(w))
def mul(v,w):return(v[0]*w[0]+4*dd*v[1]*w[1],v[0]*w[1]+v[1]*w[0])
def D(v):return(4*dd*v[1].diff(xx)+6*xx**2*v[1],v[0].diff(xx))
def trim(a):
 while a and a[-1]==Z:a.pop()
 return a

def oa(a,b):
 out=[Z]*max(len(a),len(b))
 for i,z in enumerate(a):out[i]=add(out[i],z)
 for i,z in enumerate(b):out[i]=add(out[i],z)
 return trim(out)
def om(a,b):
 out=[Z]*max(0,len(a)+len(b)-1)
 for j,v in enumerate(b):
  deriv=[v]
  for k in range(len(a)-1):deriv.append(D(deriv[-1]))
  for i,w in enumerate(a):
   if w==Z:continue
   for k in range(i+1):out[i+j-k]=add(out[i+j-k],mul(w,mul(c(s.binomial(i,k)),deriv[k])))
 return trim(out)
def on(a):return [neg(v) for v in a]
def adj(a):
 out=[]
 for i,v in enumerate(a):
  z=[v] if i%2==0 else [neg(v)]
  out=oa(out,om([Z]*i+[O],z))
 return out

def expr(a):return [(v[0].as_expr(),v[1].as_expr()) for v in a]

if __name__=='__main__':
 b=pickle.load(open('/app/basic.pkl','rb'));F=b['F'];g=b['g'];u=30*x+198*x/(x**3-11)
 L=[c(u),Z,c(-1)];powers=[[O]]
 for i in range(11):powers.append(om(powers[-1],L))
 A=[]
 for j in range(g+1):
  f=c(s.expand(F).coeff(E,g-j));Bj=[mul(c(-s.Rational(1,2)),D(f)),f]
  A=oa(A,on(om(Bj,powers[g-j])))
 print('A order',len(A)-1,flush=True)
 assert A[-1]==O
 assert oa(adj(A),A)==[]
 print('adjoint check passed',flush=True)
 assert oa(om(A,L),on(om(L,A)))==[]
 print('commutator check passed',flush=True)
 Q=[Z]*max(0,len(A)-2);R=A[:]
 while len(R)>2:
  k=len(R)-3;t=neg(R[-1]);Q[k]=t
  R=oa(R,on(om([Z]*k+[t],L)))
 assert oa(om(Q,L),R)==A
 print('right division checked; remainder order',len(R)-1,flush=True)
 PP=s.Poly(b['P'],E);PofL=[]
 for (i,),a in PP.terms():PofL=oa(PofL,[mul(c(a),v) for v in powers[i]])
 assert oa(om(A,A),PofL)==[]
 print('A^2+P(L) checked',flush=True)
 pickle.dump({'A':expr(A),'Q':expr(Q),'R':expr(R)},open('/app/ops.pkl','wb'))
