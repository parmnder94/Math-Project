import sympy as s,pickle,json,time
E=s.symbols('E');b=pickle.load(open('/app/basic.pkl','rb'))
def arrays(f):
 n,d=s.cancel(f).as_numer_denom();n=s.Poly(n,E);d=s.Poly(d,E)
 z=s.ilcm(*[a.q for a in n.all_coeffs()+d.all_coeffs()])
 return [int(a*z) for a in reversed(n.all_coeffs())],[int(a*z) for a in reversed(d.all_coeffs())]
ha=arrays(b['h'])[0];xn,xd=arrays(b['X']);yn,yd=arrays(b['Y'])
def ev(a,e,p):
 z=0
 for c in reversed(a):z=(z*e+c)%p
 return z

def add(P,Q,p):
 if P is None:return Q
 if Q is None:return P
 x,y=P;z,t=Q
 if x==z and (y+t)%p==0:return None
 m=((t-y)*pow(z-x,-1,p) if x!=z else 3*x*x*pow(2*y,-1,p))%p
 xx=(m*m-x-z)%p
 return(xx,(m*(x-xx)-y)%p)
def mul(n,P,p):
 Q=None
 while n:
  if n&1:Q=add(Q,P,p)
  P=add(P,P,p);n//=2
 return Q

def enlarge(H,P,p):
 if P in H:return H
 C=[];Q=P
 while Q not in H:C.append(Q);Q=add(Q,P,p)
 return H|{add(T,R,p) for T in H for R in C}
for p0 in s.primerange(5,5000):
 p=int(p0)
 if 66%p==0 or p%3!=1:continue
 sq={}
 for w in range(p):sq.setdefault(w*w%p,[]).append(w)
 pts=[None]+[(x,w) for x in range(p) for w in sq.get((x**3-11)%p,[])]
 ker=[P for P in pts if mul(6,P,p) is None]
 if len(ker)!=36:continue
 hp=s.Poly(b['h'],E,modulus=p)
 if hp.degree()!=9 or s.gcd(hp,hp.diff()).degree()!=0:continue
 ok=True
 for nu,de in [(xn,xd),(yn,yd)]:
  pn=s.Poly.from_list(list(reversed(nu)),E,modulus=p);pd=s.Poly.from_list(list(reversed(de)),E,modulus=p)
  if pn.degree()!=len(nu)-1 or pd.degree()!=len(de)-1 or s.gcd(pn,pd).degree()!=0:ok=False
 if not ok:continue
 print('admissible p',p,'target size',len(pts),flush=True)
 H={None};sources=[];images=[]
 for e in range(p):
  ws=sq.get((-ev(ha,e,p))%p,[])
  if not ws:continue
  xd0=ev(xd,e,p);yd0=ev(yd,e,p)
  if not xd0 or not yd0:continue
  w=ws[0];P=(ev(xn,e,p)*pow(xd0,-1,p)%p,w*ev(yn,e,p)*pow(2*yd0,-1,p)%p)
  assert P in pts
  Hnew=enlarge(H,P,p)
  if len(Hnew)>len(H):
   H=Hnew;sources.append([e,w]);images.append(P)
   print('source',sources[-1],'image half-y',P,'size generated',len(H),flush=True)
  if len(H)==len(pts):break
 if len(H)==len(pts) and len(sources)<=8:
  cert={'prime':p,'source_points':sources}
  pickle.dump(cert,open('/app/certificate.pkl','wb'))
  json.dump({'certificate':cert,'target_order':len(pts),'kernel6_order':len(ker),'images_half_y':images},open('/app/certificate_checks.json','w'),indent=2)
  break
else:raise RuntimeError('no certificate found')
