import sympy as s,pickle,json,math
with open("/app/spectral.pkl","rb") as o:x,E,d,u,F,P=pickle.load(o)
with open("/app/cover.pkl","rb") as o:X,Y,r=pickle.load(o)
h=s.cancel(P/E**2)
def pair(f):
    a,b=map(lambda z:s.Poly(z,E),s.fraction(s.cancel(f)))
    return a,b
ph=s.Poly(h,E)
px,py=pair(X),pair(Y)

def evaluate(poly,e,p):
    out=0
    for c in poly.all_coeffs(): out=(out*e+int(c))%p
    return out

def add(P,Q,p):
    if P is None:return Q
    if Q is None:return P
    a,b=P;c,d=Q
    if a==c and (b+d)%p==0:return None
    slope=((d-b)*pow(c-a,-1,p) if a!=c else 3*a*a*pow(2*b,-1,p))%p
    z=(slope*slope-a-c)%p
    return z,(slope*(a-z)-b)%p

def mul(P,n,p):
    Q=None
    while n:
        if n%2:Q=add(Q,P,p)
        P=add(P,P,p);n//=2
    return Q

for p in s.primerange(5,5000):
    if p%6!=1 or 66%p==0:continue
    polys=[ph,*px,*py]
    if any(int(a.LC())%p==0 for a in polys):continue
    if s.gcd(s.Poly(ph,E,modulus=p),s.Poly(ph.diff(),E,modulus=p)).degree()>0:continue
    if any(s.gcd(s.Poly(a,E,modulus=p),s.Poly(b,E,modulus=p)).degree()>0 for a,b in [px,py]):continue
    roots={}
    for t in range(p):roots.setdefault(t*t%p,[]).append(t)
    ec=[None]+[(a,b) for a in range(p) for b in roots.get((a*a*a-11)%p,[])]
    if len(ec)%36:continue
    if sum(mul(P,6,p) is None for P in ec)!=36:continue
    print("eligible p",p,"order",len(ec),flush=True)
    subgroup={None}; witnesses=[]
    for e in range(p):
        ws=roots.get(-evaluate(ph,e,p)%p,[])
        if not ws:continue
        xd,yd=evaluate(px[1],e,p),evaluate(py[1],e,p)
        if xd==0 or yd==0:continue
        w=ws[0]
        im=(evaluate(px[0],e,p)*pow(xd,-1,p)%p,w*evaluate(py[0],e,p)*pow(2*yd,-1,p)%p)
        if im in subgroup:continue
        cyclic=[];v=im
        while v is not None:cyclic.append(v);v=add(v,im,p)
        subgroup|={add(P,Q,p) for P in subgroup for Q in cyclic}
        witnesses.append([e,w])
        print("witness",witnesses[-1],"im",im,"generated",len(subgroup),flush=True)
        if len(subgroup)==len(ec):break
    if len(subgroup)==len(ec) and len(witnesses)<=8:
        out={"group_order":math.factorial(18),"prime":int(p),"source_points":witnesses}
        with open("/app/certificate.json","w") as o:json.dump(out,o)
        print(out,flush=True);break
