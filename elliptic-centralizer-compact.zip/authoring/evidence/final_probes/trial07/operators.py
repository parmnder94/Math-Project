import sympy as s,pickle,json,time
from math import comb
with open("/app/spectral.pkl","rb") as o:x,E,d,u,F,P=pickle.load(o)
zero=(s.S(0),s.S(0));one=(s.S(1),s.S(0))
def kc(a):return (s.cancel(a[0]),s.cancel(a[1]))
def ka(a,b):return kc((a[0]+b[0],a[1]+b[1]))
def kn(a):return (-a[0],-a[1])
def km(a,b):return kc((a[0]*b[0]+4*d*a[1]*b[1],a[0]*b[1]+a[1]*b[0]))
def ks(a,c):return (s.cancel(a[0]*c),s.cancel(a[1]*c))
from functools import lru_cache
@lru_cache(None)
def kd(a,n=1):
    if n==0:return a
    a=kd(a,n-1)
    return kc((4*d*s.diff(a[1],x)+6*x*x*a[1],s.diff(a[0],x)))
def trim(A):
    while A and A[-1]==zero:A.pop()
    return A
def oa(A,B):return trim([ka(A[i] if i<len(A) else zero,B[i] if i<len(B) else zero) for i in range(max(len(A),len(B)))])
def on(A):return [kn(c) for c in A]
def om(A,B):
    C=[zero]*(len(A)+len(B)-1)
    for i,a in enumerate(A):
      if a==zero:continue
      for j,b in enumerate(B):
       if b==zero:continue
       for k in range(i+1):
        t=ks(km(a,kd(b,k)),comb(i,k))
        C[i+j-k]=ka(C[i+j-k],t)
    return trim(C)
def adj(A):
    B=[zero]*len(A)
    for j,a in enumerate(A):
      for k in range(j+1):B[j-k]=ka(B[j-k],ks(kd(a,k),(-1)**j*comb(j,k)))
    return trim(B)
L=[(u,0),zero,(-s.S(1),s.S(0))]
Lp=[[one]]
for i in range(11):
    Lp.append(om(Lp[-1],L));print("power",i+1,flush=True)
A=[];Q=[]
for j in range(6):
    f=s.cancel(s.Poly(F,E).nth(5-j))
    T=[(0,s.diff(f,x)/2),(-f,0)]
    A=oa(A,om(T,Lp[5-j]))
    if j<5:Q=oa(Q,om(T,Lp[4-j]))
    else:R=T
print("orders",len(A)-1,len(Q)-1,len(R)-1,flush=True)
assert oa(om(A,L),on(om(L,A)))==[]
print("commutator OK",flush=True)
assert oa(adj(A),A)==[]
print("adjoint OK",flush=True)
assert oa(oa(om(Q,L),R),on(A))==[]
print("division OK",flush=True)
AA=om(A,A)
for (i,),c in s.Poly(P,E).terms(): AA=oa(AA,[ks(v,c) for v in Lp[i]])
assert AA==[]
print("spectral identity OK",flush=True)

def rf(f,var):
    a,b=map(lambda z:s.Poly(z,var),s.fraction(s.cancel(f)))
    den=s.ilcm(*[c.q for c in a.all_coeffs()+b.all_coeffs()])
    return {"num":[int(a.nth(i)*den) for i in range(a.degree()+1)] if not a.is_zero else [],"den":[int(b.nth(i)*den) for i in range(b.degree()+1)]}
def op(A):return [{"a":rf(a,x),"b":rf(b,x)} for a,b in A]
with open("/app/cover.pkl","rb") as o:X,Y,r=pickle.load(o)
with open("/app/certificate.json") as o:cert=json.load(o)
out={"operator":op(A),"spectral_polynomial":rf(P,E),"square_factor":rf(E,E),"normalized_polynomial":rf(P/E**2,E),"genus":4,"quotient":op(Q),"remainder":op(R),"cover":{"x":rf(X,E),"y_multiplier":rf(Y,E),"degree":18,"pullback":rf(r,E),"ramification_polynomial":rf(E**3-120582,E),"infinity_ramification_order":0},"monodromy":cert}
with open("/app/output/centralizer.json","w") as o:json.dump(out,o,separators=(",",":"))
with open("/app/operators.pkl","wb") as o:pickle.dump((A,Q,R),o)
print("artifact written",flush=True)
