import sympy as s,pickle,time
with open("/app/spectral.pkl","rb") as o:x,E,d,u,F,P=pickle.load(o)
K=s.QQ.frac_field(E)
U=s.Poly(s.cancel(d*F),x,domain=K).monic()
v=(-2*s.Poly(d,x,domain=K)*s.invert(U.diff(),U)/s.LC(s.Poly(s.cancel(d*F),x)))%U
# U derivative was normalized: actual N derivative has leading coefficient n; account n above.
print("initial",U.degree(),v.degree(),flush=True)
assert (v*v*(-P)-s.Poly(4*d,x,domain=K)).rem(U).is_zero
while U.degree()>1:
    start=time.time()
    T=(v*v*(-P)-s.Poly(4*d,x,domain=K)).exquo(U).monic()
    v=-(v%T)
    U=T
    print("reduced",U.degree(),v.degree(),time.time()-start,flush=True)
    with open("/app/reduction.pkl","wb") as o:pickle.dump((U,v),o)
X=s.factor(-U.nth(0))
Y=s.factor(E*v.nth(0)) # V=E W
print("X",X,flush=True)
print("Y",Y,flush=True)
r=s.factor(s.diff(X,E)/Y)
print("r",r,flush=True)
h=s.cancel(P/E**2)
assert s.cancel(-h*Y**2-4*(X**3-11))==0
with open("/app/cover.pkl","wb") as o:pickle.dump((X,Y,r),o)
