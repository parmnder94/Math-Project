import sympy as s
x,E=s.symbols("x E")
d=x**3-11
u=30*x+198*x/d
basis=[x**i/d for i in range(9)]
def ode(f):
    return s.cancel(4*d*s.diff(f,x,3)+18*x*x*s.diff(f,x,2)+(12*x-4*(u-E))*s.diff(f,x)-2*s.diff(u,x)*f)
cols=[s.Poly(s.cancel(ode(f)*d**2),x) for f in basis]
M=s.Matrix([[c.nth(i) for c in cols] for i in range(max(c.degree() for c in cols)+1)])
print("M",M.shape,flush=True)
ns=M.nullspace()
print("null",ns,flush=True)
f=s.cancel(sum(b*a for b,a in zip(basis,ns[0])))
f=s.cancel(f/s.LC(s.Poly(s.fraction(f)[0],E))*s.LC(s.Poly(s.fraction(f)[1],E)))
print("F",s.factor(f),flush=True)
P=s.cancel((E-u)*f*f+f*(4*d*s.diff(f,x,2)+6*x*x*s.diff(f,x))/2-d*s.diff(f,x)**2)
print("P",s.factor(P),flush=True)
import pickle
with open("/app/spectral.pkl","wb") as o:pickle.dump((x,E,d,u,f,P),o)
