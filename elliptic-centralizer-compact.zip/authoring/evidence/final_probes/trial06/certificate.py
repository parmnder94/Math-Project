import sympy as s, pickle, json, math
with open('/app/core.pkl','rb') as f:x,E,d,u,F,P=pickle.load(f)
with open('/app/cover.pkl','rb') as f:X,Y,r=pickle.load(f)
h=s.cancel(P/E**2)
def pp(f,p):
 f=s.Poly(f,E); return [int(c.p)%p*pow(int(c.q),-1,p)%p for c in f.all_coeffs()]
def ev(c,e,p):
 a=0
 for b in c:a=(a*e+b)%p
 return a
def add(a,b,p):
 if a is None:return b
 if b is None:return a
 xa,ya=a; xb,yb=b
 if xa==xb and (ya+yb)%p==0:return None
 slope=((yb-ya)*pow((xb-xa)%p,-1,p) if xa!=xb else 3*xa**2*pow(2*ya,-1,p))%p
 xx=(slope*slope-xa-xb)%p
 return (xx,(slope*(xa-xx)-ya)%p)
def mul(k,a,p):
 c=None
 while k:
  if k&1:c=add(c,a,p)
  a=add(a,a,p);k//=2
 return c
for p in s.primerange(5,5000):
 if p in [11] or p%3!=1:continue
 squares={}
 for y in range(p):squares.setdefault(y*y%p,[]).append(y)
 ep=[(xx,zz) for xx in range(p) for zz in squares.get((xx**3-11)%p,[])]+[None]
 if sum(mul(6,a,p) is None for a in ep)!=36:continue
 print('full6 candidate',p,'order',len(ep),flush=True)
 polys=[h,*s.fraction(X),*s.fraction(Y)]
 try:cs=[pp(f,p) for f in polys]
 except ValueError:continue
 if any(c[0]==0 for c in cs):continue
 if s.degree(s.gcd(s.Poly(h,E,modulus=p),s.Poly(s.diff(h,E),E,modulus=p)))>0:continue
 if any(s.degree(s.gcd(s.Poly(a,E,modulus=p),s.Poly(b,E,modulus=p)))>0 for a,b in [s.fraction(X),s.fraction(Y)]):continue
 hc,xc,xd,yc,yd=cs
 subgroup={None}; chosen=[]; images=[]
 for e in range(p):
  hv=ev(hc,e,p); ws=squares.get(-hv%p,[])
  if not ws:continue
  ddx=ev(xd,e,p);ddy=ev(yd,e,p)
  if ddx==0 or ddy==0:continue
  w=ws[0]; a=(ev(xc,e,p)*pow(ddx,-1,p)%p,w*ev(yc,e,p)*pow(2*ddy,-1,p)%p)
  if a in subgroup:continue
  chosen.append([e,w]);images.append(a)
  old=list(subgroup); multiples=[None]; t=a
  while t is not None:multiples.append(t);t=add(t,a,p)
  subgroup={add(b,t,p) for b in old for t in multiples}
  print('added',chosen[-1],'image in z coords',a,'generated',len(subgroup),flush=True)
  if len(subgroup)==len(ep):break
 if len(subgroup)==len(ep) and len(chosen)<=8:
  json.dump({'group_order':math.factorial(18),'prime':int(p),'source_points':chosen},open('/app/monodromy.json','w'))
  print('CERTIFICATE',p,chosen,'Eorder',len(ep),'images',images,flush=True);break
