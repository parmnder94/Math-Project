import sympy as s, pickle, time
with open('/app/core.pkl','rb') as f:x,E,d,u,F,P=pickle.load(f)
K=s.QQ.frac_field(E)
U=s.Poly(s.cancel(d*F),x,domain=K).monic(); delta=s.Poly(d,x,domain=K)
t0=time.time(); print('inverse begin',flush=True)
t=(-delta*s.invert(U.diff(),U)).mul_ground(1/s.Poly(s.cancel(d*F),x).LC()).rem(U)
print('inverse done',time.time()-t0,flush=True)
# inv dN, since U=N/leading N
assert ((-P*t*t-delta).rem(U)).is_zero
for i in range(10):
 print('step',i,'degree',U.degree(),'time',time.time()-t0,flush=True)
 if U.degree()==1: break
 Unew=(-P*t*t-delta).exquo(U).monic()
 t=(-t).rem(Unew)
 U=Unew
X=s.factor(-U.nth(0)); Y=s.factor(2*E*t.nth(0))
print('X=',X,flush=True); print('Y=',Y,flush=True)
h=s.cancel(P/E**2)
assert s.cancel(-h*Y**2-4*(X**3-11))==0
r=s.factor(s.diff(X,E)/Y)
print('r=',r,flush=True)
with open('/app/cover.pkl','wb') as f: pickle.dump((X,Y,r),f)
