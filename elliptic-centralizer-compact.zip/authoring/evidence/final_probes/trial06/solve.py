import sympy as s
x,E=s.symbols('x E'); d=x**3-11; u=30*x+198*x/d
basis=[x**k/d for k in range(9)]
express=[]
for f in basis:
 expr=s.cancel(d**3*(4*d*s.diff(f,x,3)+18*x**2*s.diff(f,x,2)+(12*x-4*u+4*E)*s.diff(f,x)-2*s.diff(u,x)*f))
 assert s.denom(expr)==1
 express.append(s.Poly(expr,x))
M=s.Matrix([[p.nth(k) for p in express] for k in range(max(p.degree() for p in express)+1)])
ns=M.nullspace(); print('nullity',len(ns),flush=True)
N=s.cancel(sum(a*b*x**0 for a,b in zip(ns[0], [x**k for k in range(9)])))
N=s.Poly(s.expand(N*s.lcm([s.denom(c) for c in s.Poly(N,x).all_coeffs()])),x,E).as_expr()
F=s.cancel(N/d); deg=s.degree(N,E); lc=s.cancel(s.Poly(N,E).LC()/d); F=s.cancel(F/lc)
print('E degree',deg,'N=',s.factor(F*d),flush=True)
P=s.cancel((E-u)*F**2+s.Rational(1,2)*F*(4*d*s.diff(F,x,2)+6*x**2*s.diff(F,x))-d*s.diff(F,x)**2)
print('P=',s.factor(P),flush=True)
import pickle
with open('/app/core.pkl','wb') as out:pickle.dump((x,E,d,u,F,P),out)
