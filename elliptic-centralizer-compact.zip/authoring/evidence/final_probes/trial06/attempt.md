# Independent local solution and reproducibility

All mathematical input came from /app/instruction.md and /app/data/{README.md,operator.json}. No task-specific external material, host task files, other containers, solutions, or verifiers were consulted. All scripts and output below are inside this container. This is a local solver attempt, not an official evaluation.

The scripts are:

- `/app/solve.py`: compute the polynomial solution of the third-order commuting equation and its spectral invariant; writes core.pkl.
- `/app/cover.py`: perform exact elliptic divisor reduction of the specified group sum; writes cover.pkl.
- `/app/certificate.py`: search primes and directly enumerate finite groups to obtain the arithmetic certificate; writes monodromy.json.
- `/app/operators.py`: construct differential operators, check all ring identities, and serialize centralizer.json.
- `/app/proof_checks.py`: supplementary exact checks for minimality, degrees, and branch values.

Run them in that order with Python (SymPy 1.14.0); only standard Python and SymPy are needed. An attempted optional installation of python-flint failed due to the public package mirror certificate; no additional package is used.

## Commuting operator and spectral equation

Write d=x^3-11 and u=30x+198x/d. A polynomial F(E,x) associated to a commuting odd operator obeys

    4d F_xxx + 18x^2 F_xx + (12x-4u+4E)F_x -2u_x F = 0.

The monic energy polynomial F=N/d is given by

    N = E^5 x^3 -11E^5 +15E^4 x^4 -66E^4 x
        +315E^3 x^5 +693E^3 x^2
        +6300E^2 x^6 -467082E^2 x^3 +6090777E^2
        +99225E x^7 -4147605E x^4 +42261912E x
        +893025x^8 -31434480x^5 +276623424x^2.

Let F=sum_{j=0}^5 f_j E^{5-j}. Define

    A = sum_{j=0}^5 (-f_j D + (D f_j)/2) L^{5-j}.

Its leading term is D^11. The computed invariant

    P=(E-u)F^2 + F D^2(F)/2 -(DF)^2/4
     = E^2 (E^3-551232)(E^6-553014E^3+816903549)

is independent of x. The script verifies A*=-A, [A,L]=0 and A^2+P(L)=0 using exact coefficient arithmetic in K[D], with D(a+yb)=4d b_x+6x^2 b+y a_x.

The square factor is q=E; h=(E^3-551232)(E^6-553014E^3+816903549) is degree 9 and gcd(h,h')=1. Thus the geometric genus is 4.

## Global minimality over the full field K

For any odd-order operator B commuting with L, its right remainder modulo L-E has the form b(E)D+c(E), polynomial in E. The coefficient b is nonzero and has energy degree m if ord(B)=2m+1. The commutation relations force c=-Db/2+k(E) for an x-constant k and force b to satisfy the same third-order equation as F. Its leading coefficient is constant in K.

Equating energy coefficients gives the usual recursive identity

    D f_{j+1} = u D f_j + (Du) f_j/2 -D^3 f_j/4.

Inversion of the elliptic curve sends (x,y) to (x,-y), fixes u, and anticommutes with D. Starting with the constant top coefficient, induction shows every coefficient is inversion-even: an odd part would have derivative zero and hence must vanish. Thus these coefficients belong to Q(x), with no y part.

There can be no pole away from poles of u: the highest pole of the third derivative cannot be canceled there. At a pole with u=n(n+1)t^{-2}+regular, the indicial exponents of the third-order equation are -2n,1,2n+2. At the elliptic origin n=5, and at each of the three half-periods n=1. Consequently an even coefficient has pole order at most 5 in x at infinity, and at most 1 in x-e at each root e of d. Every possible coefficient is therefore in the nine-dimensional span {x^k/d:0<=k<=8}. This is a global consequence of the differential equation, not an arbitrary ansatz.

Multiplying the third-order equation by d^3 gives a 14-by-9 polynomial matrix M(E) in this basis. The first eight rows and first eight columns at E=1 have determinant

    463525805393322292668499180388352000,

so M has rank at least 8 over Q(E). The displayed N is a nonzero null vector, so the kernel has dimension exactly one. Its x-coefficient polynomials have gcd 1 (in fact the x^8 coefficient is the nonzero constant 893025). Thus every solution polynomial in E is a polynomial-in-E multiple of this degree-5 solution. Hence m>=5, proving that 11 is the smallest positive odd commuting order over the full K.

## Right-division obstruction

Since q(L)=L, take

    Q=sum_{j=0}^4 (-f_j D+(Df_j)/2)L^{4-j},
    R=-f_5 D+(Df_5)/2,
    f_5=35721 x^2(5x^3-88)^2/(x^3-11).

This nonzero R has order 1<2. The exact differential-ring identity A=QL+R is verified. In particular normalization of the plane spectral curve does not furnish a differential quotient A/L.

## Specified group sum

Use z=y/2, so the target is z^2=d(x). Let V=EW. The specified points have z_i=-V d(x_i)/N_x(x_i). Put U=N/893025, and t=-d/N_x modulo U. The initial divisor is represented by (U,v), where v=Vt; the equality U | (-P t^2-d) is verified exactly.

Apply the standard divisor reduction identity explicitly:

    U_new=monic((-P t^2-d)/U),
    t_new=-t mod U_new.

The divisor of z-v shows that this replacement preserves the degree-zero divisor class of the original sum: the other intersections are reflected in the elliptic involution. The degrees are 8,6,4,2,1. At degree 1 the remaining point has X=-U(0), and y=2Vt= W(2Et). Thus the coordinates in cover.pkl, and hence in centralizer.json, are the required group sum, including the prescribed sign. This is stronger than merely checking that the coordinates satisfy an elliptic equation.

With B=E^6+902286E^3-836509234176, the computed coordinates are

    X = -(E^18 -52317738E^15 +137541930139845E^12
          -130688851922762918400E^9 +53454932630448304961617920E^6
          -8100189794317793342169727107072E^3
          +47783298913570122159712398471069696)
        / (324 E^2 (E^3-551232) B^2),

    Y = -(E^24 +108867132E^21 -850413582239265E^18
          +1845872425854496537344E^15 -1882424664672226560039813120E^12
          +1017497292619159818455595916197888E^9
          -282142935388202807657710071937304100864E^6
          +30772016361980893082560233592278583439523840E^3
          +365450704279711412131618611249798077188398907392)
        / (2916 E^3 (E^3-551232)^2 B^3).

The exact checks are -hY^2=4(X^3-11) and X'/Y=9(E^3-120582). The coprime numerator and denominator degrees of X are 18 and 17. Since each hyperelliptic/elliptic x-coordinate projection has degree 2, deg(alpha)=18.

## Complete ramification and geometric monodromy

The pullback of the nowhere-zero target differential is

    alpha*(dx/y)=9(E^3-120582)dE/W.

Let rho=E^3-120582. Its roots are simple and gcd(rho,h)=1, giving six distinct simple ramification points on the source. At the unique source infinity, dE/W has a zero of order 6, canceled exactly by the pole of order 6 of rho; the infinity ramification order is 0. The sum 6 agrees with Riemann-Hurwitz, 2g-2=6.

Modulo rho the coordinates simplify to

    X = -195908029 E /4747761216,
    Y = 2523287022071 /42507719813867616000.

The three energy roots therefore give three different target x coordinates, and each pair of opposite source W values gives opposite nonzero target y coordinates. Thus all six branch values are distinct, with exactly one simple ramification point each, and every local inertia permutation is a transposition.

Let G be geometric monodromy and let H be the normal subgroup generated by these inertia transpositions. H is the product of full symmetric groups on the connected components of its transposition graph. The corresponding orbit quotient is an unramified connected cover of the elliptic target, hence an isogeny. Its degree divides 18. If it were nontrivial, there would be an intermediate cyclic isogeny of prime degree l=2 or 3 through which alpha factors.

The following finite-field certificate rules out both possibilities. Smooth good reduction holds at p=229 (h is squarefree of degree 9; the two coordinate fractions preserve their degrees and coprimality). Both curves and the map extend over good reduction; an isogeny of prime degree 2 or 3 extends and reduces. A prime-degree factor over the algebraic closure is the dual of the quotient by a subgroup of the target l-torsion. All target 6-torsion is F_229-rational, so this quotient and dual isogeny are defined over F_229, and the kernel of the dual is also rational (it is the image of the full target l-torsion). The lift of alpha is defined over F_229: normalize it to send the rational source infinity to the isogeny origin, making the lift unique and hence Frobenius-invariant. Therefore all rational source images would lie in the image of this isogeny on F_229-points, an index-l proper subgroup, because the two isogenous finite elliptic groups have the same cardinality and the kernel has l rational points.

But the certified source images generate the whole target group. This contradiction excludes all nontrivial unramified factors. Hence H acts transitively, H=S_18, and G=S_18, of order

    18! = 6402373705728000.

This argument determines geometric monodromy; it does not substitute an arithmetic polynomial Galois group.

## Finite-field certificate

The prime is 229. The source pairs are (1,48) and (2,111). The values h(1),h(2) modulo 229 are 215 and 45; the W-squares are 14 and 184, respectively, so W^2+h=0. The image points in the original y coordinates are

    alpha(1,48)=(16,9),
    alpha(2,111)=(2,149).

All coordinate denominators are nonzero at these energies. Direct enumeration of z^2=x^3-11 over F_229 gives exactly 252 elliptic points, with exactly 36 killed by multiplication by 6. As 229 is prime to 6, this proves that all E[6] is rational. The first image generates a subgroup of size 42; adjoining the second gives size 252. The enumeration and exact group operations are in certificate.py.

The degrees modulo 229 are h:9; X numerator:18, denominator:17; Y numerator:24, denominator:27. The gcd tests for h versus h' and for both numerator-denominator pairs pass. Making denominators monic introduces only coefficient denominators prime to 229 (the displayed denominator leading constants are 324 and 2916). Thus all required arithmetic conditions hold.

## Deliverable

The only submitted data artifact is `/app/output/centralizer.json`, with the nine specified keys. Reproducibility files are outside the output directory. `operators.py` reports exact checks for monicity, skew-adjointness, the commutator, right division, and the full spectral square identity before writing the artifact.

Final local execution result: all five differential-operator checks passed, including the full order-22 square identity. Serialization and size checks passed; the artifact is 4615 bytes, and its largest integer has 169 bits.
