import sympy as s,pickle,json
with open('/app/core.pkl','rb') as f:x,E,d,u,F,P=pickle.load(f)
with open('/app/cover.pkl','rb') as f:X,Y,r=pickle.load(f)
h=s.cancel(P/E**2);rho=E**3-120582
print('gcd h,hprime:',s.gcd(h,s.diff(h,E)))
print('gcd h,rho:',s.gcd(h,rho))
for label,f in [('X',X),('Y',Y)]:
 n,den=s.fraction(f); reduced=s.rem(n,rho,E)*s.invert(s.rem(den,rho,E),rho,E)
 print(label,'on ramification:',s.factor(s.rem(reduced,rho,E)))
 print(label,'degrees:',s.degree(n,E),s.degree(den,E),'gcd:',s.gcd(n,den))
N=s.cancel(d*F)
print('E coefficient gcd of N:',s.gcd_list(s.Poly(N,x).all_coeffs()))
print('F(E=0):',s.factor(F.subs(E,0)))
basis=[x**k/d for k in range(9)]
ps=[s.Poly(s.cancel(d**3*(4*d*s.diff(f,x,3)+18*x*x*s.diff(f,x,2)+(12*x-4*u+4*E)*s.diff(f,x)-2*s.diff(u,x)*f)),x) for f in basis]
M=s.Matrix([[p.nth(k) for p in ps] for k in range(max(p.degree() for p in ps)+1)])
M0=M.subs(E,1);_,cols=M0.rref();_,rows=M0[:,cols].T.rref()
print('M shape',M.shape,'rank at E=1:',len(cols),'nonzero minor rows',rows,'cols',cols,'det',M0.extract(rows,cols).det())
# Finite-field certificate details independently enumerated by certificate.py.
p=229
for label,f in [('h',h),('X numerator',s.fraction(X)[0]),('X denominator',s.fraction(X)[1]),('Y numerator',s.fraction(Y)[0]),('Y denominator',s.fraction(Y)[1])]:
 print(label,'degree mod p',s.Poly(f,E,modulus=p).degree())
print('h mod p squarefree:',s.degree(s.gcd(s.Poly(h,E,modulus=p),s.Poly(s.diff(h,E),E,modulus=p)))==0)
print('h values source:',[int(h.subs(E,e))%p for e in [1,2]])
print('source W squared:',[48**2%p,111**2%p])
print('branch rho mod p',s.factor(rho,modulus=p))
