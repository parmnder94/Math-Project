import sympy as s,pickle,json,time,math
from functools import lru_cache
with open('/app/core.pkl','rb') as inp:x,E,d,u,F,P=pickle.load(inp)
Z=(s.S.Zero,s.S.Zero); ONE=(s.S.One,s.S.Zero)
def clean(a):return tuple(s.cancel(c) for c in a)
def add(a,b):return clean((a[0]+b[0],a[1]+b[1]))
def neg(a):return (-a[0],-a[1])
def mul(a,b):
 return clean((a[0]*b[0]+4*d*a[1]*b[1],a[0]*b[1]+a[1]*b[0]))
def scale(a,c):return clean((a[0]*c,a[1]*c))
@lru_cache(None)
def dif(a,k=1):
 if k==0:return a
 if k>1:return dif(dif(a,k-1))
 return clean((4*d*s.diff(a[1],x)+6*x*x*a[1],s.diff(a[0],x)))
def trim(a):
 while a and a[-1]==Z:a.pop()
 return a
def oadd(a,b):return trim([add(a[i] if i<len(a) else Z,b[i] if i<len(b) else Z) for i in range(max(len(a),len(b)))])
def oneg(a):return [neg(c) for c in a]
def omul(a,b):
 c=[Z]*(len(a)+len(b)-1)
 for i,ai in enumerate(a):
  if ai==Z:continue
  for j,bj in enumerate(b):
   if bj==Z:continue
   for k in range(i+1):
    val=scale(mul(ai,dif(bj,k)),s.binomial(i,k))
    c[i+j-k]=add(c[i+j-k],val)
 return trim(c)
def adj(a):
 out=[Z]*len(a)
 for i,c in enumerate(a):
  for k in range(i+1):out[i-k]=add(out[i-k],scale(dif(c,k),(-1)**i*s.binomial(i,k)))
 return trim(out)
def enc(f,var):
 a,b=s.fraction(s.cancel(f)); a=s.Poly(a,var);b=s.Poly(b,var)
 den=s.ilcm(*[int(c.q) for c in a.all_coeffs()+b.all_coeffs()])
 def coeffs(q):return [int(c*den) for c in q.all_coeffs()[::-1]] if not q.is_zero else []
 return {'num':coeffs(a),'den':coeffs(b)}
def encop(A):return [{'a':enc(a,x),'b':enc(b,x)} for a,b in A]
L=[(u,0),Z,(-s.S.One,0)]; powers=[[ONE]]
t0=time.time()
for i in range(1,12):
 powers.append(omul(powers[-1],L)); print('L power',i,'time',round(time.time()-t0,2),flush=True)
f=[s.cancel(s.Poly(s.expand(F*d),E).nth(5-j)/d) for j in range(6)]
A=[];Q=[]
for j in range(6):
 B=[scale(dif((f[j],0)),s.Rational(1,2)),(-f[j],0)]
 A=oadd(A,omul(B,powers[5-j]))
 if j<5:Q=oadd(Q,omul(B,powers[4-j]))
R=[scale(dif((f[5],0)),s.Rational(1,2)),(-f[5],0)]
print('A order',len(A)-1,'lc',A[-1],flush=True)
assert A[-1]==ONE
assert not oadd(A,adj(A)); print('skew check passed',flush=True)
assert not oadd(omul(A,L),oneg(omul(L,A)));print('commutator check passed',flush=True)
assert not oadd(A,oneg(oadd(omul(Q,L),R))); print('division check passed',flush=True)
# Independent full ring square verification
ASQ=omul(A,A);PL=[]
for (i,),c in s.Poly(P,E).terms():PL=oadd(PL,[scale(v,c) for v in powers[i]])
assert not oadd(ASQ,PL);print('square check passed',round(time.time()-t0,2),flush=True)
with open('/app/cover.pkl','rb') as inp:X,Y,r=pickle.load(inp)
h=s.cancel(P/E**2)
result={'operator':encop(A),'spectral_polynomial':enc(P,E),'square_factor':enc(E,E),'normalized_polynomial':enc(h,E),'genus':4,'quotient':encop(Q),'remainder':encop(R),'cover':{'x':enc(X,E),'y_multiplier':enc(Y,E),'degree':18,'pullback':enc(r,E),'ramification_polynomial':enc(E**3-120582,E),'infinity_ramification_order':0},'monodromy':json.load(open('/app/monodromy.json'))}
with open('/app/output/centralizer.json','w') as out:json.dump(result,out,separators=(',',':'))
with open('/app/operators.pkl','wb') as out:pickle.dump((A,Q,R),out)
print('Wrote centralizer.json',flush=True)
