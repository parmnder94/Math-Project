import sympy as s,json,math,time
x,E=s.symbols("x E");d=x**3-11
u=s.cancel(30*x+198*x/d)
F=s.sympify(open("/app/Fraw.txt").read(),locals={"E":E,"x":x})
P=s.sympify(open("/app/P.txt").read(),locals={"E":E});h=s.cancel(P/E**2)
fs=[s.cancel(s.expand(F).coeff(E,5-j)) for j in range(6)]
zero=(s.S.Zero,s.S.Zero);one=(s.S.One,s.S.Zero)
def norm(a):return tuple(s.cancel(z) for z in a)
def add(a,b):return norm((a[0]+b[0],a[1]+b[1]))
def neg(a):return (-a[0],-a[1])
def smul(a,c):return (a[0]*c,a[1]*c)
def mul(a,b):return norm((a[0]*b[0]+4*d*a[1]*b[1],a[0]*b[1]+a[1]*b[0]))
def deriv(a):return norm((4*d*s.diff(a[1],x)+6*x*x*a[1],s.diff(a[0],x)))
def trim(A):
 while A and A[-1]==zero:A.pop()
 return A
def opadd(A,B):
 return trim([add(A[i] if i<len(A) else zero,B[i] if i<len(B) else zero) for i in range(max(len(A),len(B)))])
def opneg(A):return [neg(z) for z in A]
def opmul(A,B):
 if not A or not B:return []
 C=[zero]*(len(A)+len(B)-1)
 db=[B]
 for k in range(1,len(A)):db.append([deriv(z) for z in db[-1]])
 for i,a in enumerate(A):
  if a==zero:continue
  for j in range(len(B)):
   for k in range(i+1):
    z=db[k][j]
    if z!=zero:C[i+j-k]=add(C[i+j-k],smul(mul(a,z),s.binomial(i,k)))
 return trim(C)
def adj(A):
 C=[zero]*len(A)
 for i,a in enumerate(A):
  for k in range(i+1):
   C[i-k]=add(C[i-k],smul(a,(-1)**i*s.binomial(i,k)))
   a=deriv(a)
 return trim(C)
L=[(u,0),zero,(-s.S.One,0)]
powers=[[one]]
for k in range(1,6):
 print("power",k,flush=True);powers.append(opmul(powers[-1],L))
Bs=[[(0,s.diff(f,x)/2),(-f,0)] for f in fs]
A=[];Q=[]
for j,B in enumerate(Bs):
 print("A term",j,flush=True);A=opadd(A,opmul(B,powers[5-j]))
 if j<5:Q=opadd(Q,opmul(B,powers[4-j]))
R=trim(Bs[5])
print("operators",len(A)-1,len(Q)-1,len(R)-1,flush=True)
assert A[-1]==one
print("division",flush=True);assert opadd(A,opneg(opadd(opmul(Q,L),R)))==[]
print("commutator",flush=True);assert opadd(opmul(A,L),opneg(opmul(L,A)))==[]
print("adjoint",flush=True);assert opadd(A,adj(A))==[]
print("encode",flush=True)
def rat(f,v):
 n,de=map(lambda a:s.Poly(a,v,domain=s.QQ),s.fraction(s.cancel(f)))
 z=s.ilcm(*[c.q for c in n.all_coeffs()+de.all_coeffs()])
 nn=[int(c*z) for c in reversed(n.all_coeffs())] if n else []
 dd=[int(c*z) for c in reversed(de.all_coeffs())]
 return {"num":nn,"den":dd}
def encop(A):return [{"a":rat(a,x),"b":rat(b,x)} for a,b in A]
X,Y,r=s.sympify(open("/app/cover.txt").read(),locals={"E":E})
cert=json.load(open("/app/certificate.json"))
obj={"operator":encop(A),"spectral_polynomial":rat(P,E),"square_factor":rat(E,E),"normalized_polynomial":rat(h,E),"genus":4,"quotient":encop(Q),"remainder":encop(R),"cover":{"x":rat(X,E),"y_multiplier":rat(Y,E),"degree":18,"pullback":rat(r,E),"ramification_polynomial":rat(E**3-120582,E),"infinity_ramification_order":0},"monodromy":{"group_order":math.factorial(18),"prime":cert["prime"],"source_points":cert["source_points"]}}
json.dump(obj,open("/app/output/centralizer.json","w"),separators=(",",":"))
print("DONE",flush=True)
