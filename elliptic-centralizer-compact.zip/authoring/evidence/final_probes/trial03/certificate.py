import sympy as s,json
E=s.symbols("E")
X,Y,r=s.sympify(open("/app/cover.txt").read(),locals={"E":E})
P=s.sympify(open("/app/P.txt").read(),locals={"E":E});h=s.cancel(P/E**2)
def canon(f):
 n,d=map(lambda z:s.Poly(z,E,domain=s.QQ),s.fraction(s.cancel(f)));c=d.LC()
 return n.mul_ground(1/c),d.monic()
ratios=[canon(X),canon(Y)]
def modpoly(poly,p):
 return s.Poly.from_list([int(c.p)*pow(int(c.q),-1,p)%p for c in poly.all_coeffs()],E,modulus=p)
def validate(p):
 hp=modpoly(s.Poly(h,E),p)
 if hp.degree()!=9 or s.gcd(hp,hp.diff()).degree():return False
 for n,d in ratios:
  try: np,dp=modpoly(n,p),modpoly(d,p)
  except ValueError:return False
  if np.degree()!=n.degree() or dp.degree()!=d.degree() or s.gcd(np,dp).degree():return False
 return True
def add(a,b,p):
 if a is None:return b
 if b is None:return a
 x,y=a;xx,yy=b
 if x==xx and (y+yy)%p==0:return None
 slope=((yy-y)*pow(xx-x,-1,p) if x!=xx else 3*x*x*pow(2*y,-1,p))%p
 xxx=(slope*slope-x-xx)%p
 return xxx,(slope*(x-xxx)-y)%p
def mul(n,a,p):
 b=None
 while n:
  if n&1:b=add(a,b,p)
  a=add(a,a,p);n//=2
 return b
def ev(poly,e,p):return int(poly.eval(e))%p
for p in list(s.primerange(5,5000)):
 if p%3!=1 or 66%p==0 or not validate(p):continue
 sq={}
 for t in range(p):sq.setdefault(t*t%p,[]).append(t)
 pts=[None]+[(a,b) for a in range(p) for b in sq.get((a*a*a-11)%p,[])]
 if len(pts)%36 or sum(mul(6,a,p) is None for a in pts)!=36:continue
 print("eligible",p,"#E",len(pts),flush=True)
 hp=modpoly(s.Poly(h,E),p)
 (xn,xd),(yn,yd)=[(modpoly(a,p),modpoly(b,p)) for a,b in ratios]
 H={None};sources=[];images=[]
 for e in range(p):
  ww=sq.get(-ev(hp,e,p)%p,[])
  if not ww or ev(xd,e,p)==0 or ev(yd,e,p)==0:continue
  w=ww[0];a=(ev(xn,e,p)*pow(ev(xd,e,p),-1,p)%p,w*ev(yn,e,p)*pow(2*ev(yd,e,p),-1,p)%p)
  if a in H:continue
  cyc=[];b=a
  while b not in H:cyc.append(b);b=add(b,a,p)
  H={add(old,new,p) for old in H for new in [None]+cyc}
  sources.append([e,w]);images.append(a)
  print("grow",sources[-1],a,len(H),flush=True)
  if len(H)==len(pts) or len(sources)==8:break
 if len(H)==len(pts):
  print("SUCCESS",p,len(pts),sources,images,flush=True)
  json.dump({"prime":p,"source_points":sources,"target_order":len(pts),"images_t":images},open("/app/certificate.json","w"));break
