import sympy as s,json
x,E=s.symbols("x E");d=x**3-11;u=30*x+198*x/d
cs=s.symbols("a:9");N=sum(cs[j]*x**j for j in range(9));F=N/d
expr=s.cancel(4*d*s.diff(F,x,3)+18*x*x*s.diff(F,x,2)+(12*x-4*u+4*E)*s.diff(F,x)-2*s.diff(u,x)*F)
pol=s.Poly(expr.as_numer_denom()[0],x)
M,_=s.linear_eq_to_matrix(pol.all_coeffs(),cs)
print("matrix",M.shape,flush=True)
ns=M.nullspace();print("kernel",len(ns),flush=True)
f=s.cancel(sum(ns[0][j]*x**j for j in range(9))/d)
f=s.cancel(f/s.LC(s.Poly(f,E))) if s.denom(f).has(E)==False else f
print("Fraw",s.factor(f),flush=True)
open("/app/Fraw.txt","w").write(str(f))
