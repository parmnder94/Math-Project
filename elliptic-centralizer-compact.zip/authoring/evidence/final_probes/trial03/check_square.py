import sympy as s,json,time,math
exec(open("/app/compute_ops.py").read().split('print("encode"')[0])
print("spectral square direct",flush=True)
pp=[[one]]
for k in range(1,12):
 pp.append(opmul(pp[-1],L));print("L power",k,flush=True)
PL=[]
for (j,),c in s.Poly(P,E).terms():PL=opadd(PL,[smul(a,c) for a in pp[j]])
AA=opmul(A,A)
assert opadd(AA,PL)==[]
print("DIRECT SPECTRAL IDENTITY PASSED",flush=True)
