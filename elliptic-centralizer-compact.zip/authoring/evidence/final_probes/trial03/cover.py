import sympy as s,time
x,E=s.symbols("x E");d=x**3-11
F=s.sympify(open("/app/Fraw.txt").read(),locals={"E":E,"x":x});N=s.cancel(d*F)
P=s.sympify(open("/app/P.txt").read(),locals={"E":E,"x":x});h=s.cancel(P/E**2)
R=s.QQ.frac_field(E)
u=s.Poly(N,x,domain=R).monic();dp=s.Poly(d,x,domain=R)
print("invert",flush=True);iv=s.invert(u.diff(),u)
b=((-E/s.Integer(893025))*dp*iv).rem(u)
print("initial b",b.degree(),flush=True)
for i in range(15):
 if u.degree()==1:break
 print("reduce",i,u.degree(),b.degree(),time.time(),flush=True)
 uu,rem=(dp+h*b*b).div(u)
 assert rem.is_zero
 uu=uu.monic();b=(-b).rem(uu);u=uu
 print("done",u.degree(),time.time(),flush=True)
X=s.cancel(-u.nth(0)/u.nth(1));Y=s.cancel(2*b.nth(0))
print("X",s.factor(X),flush=True);print("Y",s.factor(Y),flush=True)
assert s.cancel(-h*Y**2-4*(X**3-11))==0
r=s.cancel(s.diff(X,E)/Y)
print("r",s.factor(r),flush=True)
open("/app/cover.txt","w").write(str([X,Y,r]))
