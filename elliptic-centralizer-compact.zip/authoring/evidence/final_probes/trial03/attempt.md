# Independent attempt 03: reproducible solution

All reads, calculations, scripts, and output for this attempt were confined to the assigned container. The only task inputs used were /instruction.md and /app/data. No reference answer, hidden grader, other container, or other agent's solution was accessed.

## Result

The submitted artifact is /app/output/centralizer.json. The primitive differential symmetry has order 11, the normalized spectral curve has genus 4, the specified divisor-sum covering has degree 18, and its geometric monodromy is S_18 of order 6402373705728000.

## Stationary equation and primitive operator

Put d=x^3-11 and u=30x+198x/d. A squared eigenfunction F obeys

    D^3 F - 4(u-E) D F - 2(Du) F = 0.

For F rational in x this becomes

    4d F_xxx + 18x^2 F_xx + (12x-4u+4E) F_x - 2u_x F = 0.

The script /app/solve.py inserts F=N/d, deg_x N<=8, and computes the kernel over Q(E) of the resulting coefficient matrix (11 rows, 9 columns). Its kernel has dimension 1. Normalizing F to be monic of degree 5 in E gives

N =
 E^5(x^3-11)
 + E^4(15x^4-66x)
 + E^3(315x^5+693x^2)
 + E^2(6300x^6-467082x^3+6090777)
 + E(99225x^7-4147605x^4+42261912x)
 + 893025x^8-31434480x^5+276623424x^2.

Write F=sum_{j=0}^5 f_j E^(5-j), f_0=1. The operator is

    A=sum_{j=0}^5 (-f_j D + (Df_j)/2) L^(5-j).

Its leading coefficient is +1 because (-D)(-D^2)^5=D^11. All coefficients in the JSON are expanded on the left. /app/compute_ops.py implements the Ore product directly, with pairs (a,b) representing a+yb and with
D(a+yb)=4d b_x+6x^2 b+y a_x. It verifies the commutator, formal adjoint, monicity, and division identity exactly.

### Global minimality

This is not an ansatz-limited minimality argument. A commuting monic odd-order operator of order 2m+1 yields, after subtracting polynomial even terms or taking its skew-adjoint part, a nonzero polynomial-in-E squared eigenfunction of degree m with coefficients in K. This follows by right reduction modulo L-E and equating its commutator with L; its coefficient of D is the required F up to an irrelevant constant sign.

At a pole where u=n(n+1)z^(-2)+O(1), the indicial equation for the third-order stationary equation is

    (r-1)(r+2n)(r-2n-2)=0.

At the elliptic point at infinity n=5; at each of the other three half periods n=1. No solution in the elliptic function field can have poles at an ordinary point. Therefore every solution has pole order at most 10 at infinity and at most 2 at each nonzero half period. The involution (x,y)->(x,-y) preserves the equation. Its odd part cannot have any poles: a pole of an odd function at a fixed half period would have negative odd order, whereas the only allowable negative indicial exponent is even. A pole-free odd elliptic function is zero. Consequently every solution is rational in x and necessarily has the form N/d with deg_x N<=8.

The kernel computation above thus covers the full field K. Since the x^8 coefficient of our N is the nonzero constant 893025, any rational function c(E) for which c(E)N remains polynomial in E must itself be a polynomial. Thus no nonzero polynomial-in-E solution has degree below 5. This proves order 11 is the smallest positive odd commuting order over all of K.

## Spectral normalization and division obstruction

/app/compute.py evaluates the x-independent expression

    P=(E-u)F^2 + F(D^2F)/2 - (DF)^2/4

and obtains

    P=E^2 (E^3-551232)(E^6-553014E^3+816903549).

The usual reduction modulo L-E gives A^2=-P(E): on an eigenfunction A acts as -F D+(DF)/2, whose squared action is the scalar -P(E). Equivalently, commuting A with L and reducing A^2+P(L) modulo L-E gives zero identically in E, forcing the operator itself to vanish. The independent direct Ore-product check /app/check_square.py also computes A*A and P(L).

The square factor is q=E. The normalized polynomial is

    h=(E^3-551232)(E^6-553014E^3+816903549).

It has degree 9 and gcd(h,h')=1, hence genus 4.

The right quotient and remainder are

    Q=sum_{j=0}^4 (-f_j D+(Df_j)/2)L^(4-j),
    R=-f_5 D+(Df_5)/2.

In particular R is nonzero and has order 1, below ord q(L)=2. It certifies the differential-division obstruction: normalization of the spectral curve does not produce a differential operator A/L.

## The prescribed group sum

The cover was computed from the actual points in the instruction, not guessed from a curve equation. Use t=y/2 on the target, so t^2=d(x). Let U=N/893025 be monic, and calculate the inverse of U_x modulo U. The prescribed point divisor has Mumford representation

    (U, W B),  B = -E d U_x^(-1)/893025 mod U,

because V=EW and t_i=-Vd(x_i)/N_x(x_i).

The script /app/cover.py performs exact divisor reduction over Q(E):

    Unew = monic((d+h B^2)/U),
    Bnew = -B mod Unew.

At every step the division has zero remainder. Degrees of U successively are 8,6,4,2,1. This standard elliptic divisor reduction preserves the sum of the points. At the final step U=x-X and y=2WB, yielding Y=2B. This establishes exactly the required sum and its sign.

For compactness set
    a=551232,
    B0=E^6+902286E^3-836509234176,
    J=E^18-52317738E^15+137541930139845E^12
      -130688851922762918400E^9
      +53454932630448304961617920E^6
      -8100189794317793342169727107072E^3
      +47783298913570122159712398471069696,
    K0=E^24+108867132E^21-850413582239265E^18
      +1845872425854496537344E^15
      -1882424664672226560039813120E^12
      +1017497292619159818455595916197888E^9
      -282142935388202807657710071937304100864E^6
      +30772016361980893082560233592278583439523840E^3
      +365450704279711412131618611249798077188398907392.

Then

    X=-J/[324 E^2(E^3-a) B0^2],
    Y=-K0/[2916 E^3(E^3-a)^2 B0^3].

Exact simplification checks -h Y^2=4(X^3-11), and

    X'/Y = 9(E^3-120582).

The rational function X has degree 18 (numerator degree 18, denominator degree 17, coprime). Since the source and target x-projections both have degree 2, alpha has degree 18.

### Complete ramification

The differential dE/W has divisor 6 times the unique point at infinity. The multiplier r=9(E^3-120582) has pole order 6 there, so the map is unramified at infinity. Its zeros are the six points above the three roots of rho=E^3-120582. These roots do not meet h=0; each zero on the source is simple, giving ramification index 2. Thus rho is exactly the requested ramification polynomial and the infinity ramification order is 0. Total ramification 6 agrees with Riemann-Hurwitz for genus 4 over genus 1.

All six branch values are distinct. Modulo E^3-120582,

    X=-1371356203/(275616 E^2).

Thus the three critical E values give three distinct nonzero target x values. None is a target two-torsion point: reducing the numerator of X^3-11 gives the nonzero integer
    -5927655955445051709491137171.
For each of those target x values the two signs of W give two distinct y values.

## Geometric monodromy, including the arithmetic certificate

The cover is connected and degree 18. Its six inertia permutations are transpositions because the six branch values are distinct and each has exactly one simple ramification point. The normal subgroup generated by all inertia is generated by transpositions. Its orbits determine the maximal unramified intermediate cover of the elliptic target. If that intermediate has degree 1, the transposition subgroup is transitive and therefore the full symmetric group S_18.

It remains to exclude a nontrivial unramified isogeny factor. The map takes the rational point at infinity to the target identity. Its maximal unramified isogeny factor is therefore defined over Q: it is the factor induced by quotienting the source Jacobian by the connected component of the kernel of its map to the target. Its degree k divides 18. At a prime of good reduction not dividing 18 it reduces to an isogeny factor.

At p=229, exact enumeration and rational-function checks in /app/certificate.py and /app/certificate_details.py establish:
* h mod p = E^9-8E^6-58E^3+51, squarefree of degree 9.
* X numerator/denominator degrees stay 18/17 and gcd stays 1.
* Y numerator/denominator degrees stay 24/27 and gcd stays 1.
* After making rational-function denominators monic, all coefficient denominators are among 1,2,4,27,324,2916, hence invertible.
* The target E(F_229) has 252 points.
* E[6](F_229) has 36 points, so all of E[6] is rational.
* The submitted source points are (E,W)=(1,48),(2,111).
  For the first, h(1)=215 and 48^2=14; for the second h(2)=45 and 111^2=184, all mod 229. Thus both satisfy W^2+h(E)=0.
* Their target images in the original y coordinate are (16,9) and (2,149). In t=y/2 coordinates these are (16,119) and (2,189).
* Each target image has order 42, and the intersection of their cyclic subgroups has order 7. They therefore generate a group of order 42*42/7=252, the entire target group.

For an explicit torsion crosscheck, the nonidentity 2-torsion has x=46,202,210. The nonidentity 3-torsion, in (x,t) coordinates, is
(0,26),(0,203),(37,105),(37,124),(43,105),(43,124),(149,105),(149,124).

Suppose a nontrivial isogeny factor psi:E'->E of degree k|18 existed. Choose a prime ell=2 or 3 dividing k. The dual isogeny's kernel contains an order-ell subgroup of E[ell]; over F_229 this subgroup is rational pointwise. Factoring the dual through this subgroup and dualizing exhibits psi as factoring through a degree-ell isogeny phi:E''->E. The kernel of phi is the Cartier dual of the constant order-ell subgroup, namely mu_ell. Since 229 is 1 modulo 6, this kernel is rational. Isogenous elliptic curves over a finite field have equal point counts, so phi(E''(F_229)) has index ell in E(F_229). Every image of a rational source point would belong to that proper subgroup, contradicting the generating pair above. Hence there is no nontrivial unramified factor.

It follows that geometric monodromy is S_18, and its order is 18! = 6402373705728000. This argument determines geometric monodromy, rather than an arithmetic Galois group.

## Reproduction and errors corrected

Run, inside this container:
    python /app/solve.py
    python /app/compute.py
    python /app/cover.py
    python /app/certificate.py
    python /app/compute_ops.py
    python /app/certificate_details.py
    python /app/check_square.py
The final JSON is produced by compute_ops.py. The other scripts retain independently checkable intermediate expressions in Fraw.txt, P.txt, cover.txt, and certificate.json.

Two implementation errors were identified immediately and corrected before any output was used: an initial sympify read interpreted the symbol E as Euler's constant, so all subsequent parses explicitly provide locals={"E":E}; and one shell heredoc failed because a comment contained an apostrophe, so the cover script was rewritten through a safely quoted file-write command. No approximate arithmetic or floating-point fitting was used.

## Final checks completed

The direct Ore-product calculation finished successfully with DIRECT SPECTRAL IDENTITY PASSED. Exact monicity, commutator zero, skew-adjointness, and right division all passed. The submitted JSON is 4615 bytes, has exactly the required nine fields, and has operator-array lengths 12, 10, and 2. Direct parsing of the submitted spectral fields confirms P=q^2 h and gcd(h,hprime)=1.
