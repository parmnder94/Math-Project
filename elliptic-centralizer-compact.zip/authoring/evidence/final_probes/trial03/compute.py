import sympy as s,json
x,E=s.symbols("x E");d=x**3-11;u=30*x+198*x/d
F=s.sympify(open("/app/Fraw.txt").read(),locals={"E":E,"x":x});N=s.cancel(d*F)
DxF=s.diff(F,x)
P=s.cancel((E-u)*F**2+F*(4*d*s.diff(F,x,2)+6*x*x*DxF)/2-d*DxF**2)
print("P=",s.factor(P),flush=True)
open("/app/P.txt","w").write(str(P))
