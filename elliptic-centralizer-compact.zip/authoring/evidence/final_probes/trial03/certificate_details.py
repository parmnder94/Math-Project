exec(open("/app/certificate.py").read().split("for p in list")[0])
p=229
sq={}
for t in range(p):sq.setdefault(t*t%p,[]).append(t)
pts=[None]+[(a,b) for a in range(p) for b in sq.get((a*a*a-11)%p,[])]
tors=[a for a in pts if mul(6,a,p) is None]
def cyc(a):
 ret=[None];b=a
 while b is not None:ret.append(b);b=add(b,a,p)
 return ret
a=(16,119);b=(2,189);aa=set(cyc(a));bb=set(cyc(b))
print("#E",len(pts),"#E[6]",len(tors))
print("orders",len(aa),len(bb),"intersection",len(aa&bb))
print("2-torsion x", [a[0] for a in pts[1:] if a[1]==0])
print("3-torsion", [a for a in pts if mul(3,a,p) is None])
print("hmod",modpoly(s.Poly(h,E),p))
for nm,rat in zip(["X","Y"],ratios):
 n,d=rat;np,dp=modpoly(n,p),modpoly(d,p)
 print(nm,np.degree(),dp.degree(),"gcd",s.gcd(np,dp).as_expr())
 print("num_mod",np.as_expr());print("den_mod",dp.as_expr())
for e,w in [(1,48),(2,111)]:
 print("point",e,w,"h(e)",ev(modpoly(s.Poly(h,E),p),e,p),"w2",w*w%p)
print("canonical_coefficient_denominators",sorted(set(int(c.q) for rr in ratios for po in rr for c in po.all_coeffs())))
