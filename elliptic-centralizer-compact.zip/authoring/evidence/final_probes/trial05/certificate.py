import os
os.environ['SYMPY_GROUND_TYPES']='flint'
import sympy as s,pickle,json,math
x,E=s.symbols('x E')
F,P,g=pickle.load(open('/app/spectral.pkl','rb')); h=s.cancel(P/E**2)
X,Y,r=pickle.load(open('/app/cover.pkl','rb'))
exprs=[h,X,Y]
canon=[]
for z in exprs:
 n,d=s.fraction(s.cancel(z)); n=s.Poly(n,E,domain=s.QQ);d=s.Poly(d,E,domain=s.QQ); lc=d.LC()
 canon.append((s.Poly(n.as_expr()/lc,E),s.Poly(d.as_expr()/lc,E)))
def redpoly(poly,p):return s.Poly.from_list([int(a.p)*pow(int(a.q),-1,p)%p for a in poly.all_coeffs()],E, modulus=p)
def ev(poly,z,p):
 v=0
 for a in poly.all_coeffs():v=(v*z+int(a))%p
 return v
for p0 in s.primerange(5,5000):
 p=int(p0)
 if 66%p==0:continue
 if p%6!=1:continue
 try: reduced=[(redpoly(n,p),redpoly(d,p)) for n,d in canon]
 except ValueError:continue
 if any(n.degree()!=nn.degree() or d.degree()!=dd.degree() or s.gcd(nn,dd).degree()>0 for (n,d),(nn,dd) in zip(canon,reduced)):continue
 if s.gcd(reduced[0][0],reduced[0][0].diff()).degree()>0:continue
 sq={}
 for v in range(p):sq.setdefault(v*v%p,[]).append(v)
 points={None}
 for xx in range(p):
  for v in sq.get((xx**3-11)%p,[]):points.add((xx,v))
 def add(a,b):
  if a is None:return b
  if b is None:return a
  xx,v=a;zz,t=b
  if xx==zz and (v+t)%p==0:return None
  m=((t-v)*pow((zz-xx)%p,-1,p) if xx!=zz else 3*xx*xx*pow(2*v,-1,p))%p
  q=(m*m-xx-zz)%p
  return (q,(m*(xx-q)-v)%p)
 def mul(a,n):
  b=None
  while n:
   if n&1:b=add(a,b)
   n//=2;a=add(a,a)
  return b
 if sum(mul(a,6) is None for a in points)!=36:continue
 print('candidate',p,'#E',len(points),flush=True)
 H={None}; witness=[];images=[];orders=[]
 hn,hd=reduced[0];xn,xd=reduced[1];yn,yd=reduced[2]
 for e in range(p):
  dx=ev(xd,e,p);dy=ev(yd,e,p)
  if dx==0 or dy==0:continue
  he=ev(hn,e,p)*pow(ev(hd,e,p),-1,p)%p
  for w in sq.get(-he%p,[]):
   xx=ev(xn,e,p)*pow(dx,-1,p)%p
   yy=w*ev(yn,e,p)*pow(dy,-1,p)%p
   a=(xx,yy*pow(2,-1,p)%p)
   assert a in points
   if a in H:continue
   cyc=[None];b=a
   while b is not None:cyc.append(b);b=add(b,a)
   H={add(t,v) for t in H for v in cyc}
   witness.append([e,w]);images.append([xx,yy]);orders.append(len(cyc))
   print('add',witness[-1],images[-1],'order',orders[-1],'generated',len(H),flush=True)
   if len(H)==len(points):break
  if len(H)==len(points):break
 if len(H)==len(points) and len(witness)<=8:
  cert={'group_order':math.factorial(18),'prime':p,'source_points':witness}
  json.dump(cert,open('/app/certificate.json','w'),indent=2)
  json.dump({'target_order':len(points),'images':images,'orders':orders,'six_torsion_count':36},open('/app/certificate_check.json','w'),indent=2)
  print('SUCCESS',cert,flush=True)
  break
else:raise ValueError('No certificate')
