# Independent solution and reproducibility notes

The only task inputs used were `/app/instruction.md`, `/app/data/README.md`, and `/app/data/operator.json` in this container. No task-specific outside material was consulted. Python, SymPy, and the general-purpose `python-flint` arithmetic package were used. All the scripts and calculations described here are local to this container.

The submission is `/app/output/centralizer.json`.

## Differential equation and global minimality

Write `d=x^3-11` and `u=30*x+198*x/d`. For an even elliptic function `F(E,x)`, the equation

    D^3 F - 4(u-E) D F - 2(Du) F = 0

is equivalent to

    T(F) = 4d F_xxx + 18x^2 F_xx + (12x-4u+4E) F_x - 2u_x F = 0.

The monic polynomial solution of least energy degree is

    F = (E^5-397782 E^2)
      + (15 E^4-3056130 E) x
      + (315 E^3-21611205) x^2
      + 6300 E^2 x^3 + 99225 E x^4 + 893025 x^5
      + [1715175 E^2 + (99 E^4+8644482 E)x
         + (4158 E^3+38900169)x^2]/d.

This is not merely a solution within an arbitrary denominator ansatz. The potential has local strengths `l(l+1)` with `l=5` at the elliptic origin and `l=1` at each of the three nonzero two-torsion points. A meromorphic solution of the third-order equation has local indicial exponents

    -2l, 1, 2l+2.

It cannot have a pole away from the potential poles. Inversion on the elliptic curve preserves the solution space. An odd solution under inversion cannot have any of the allowable even-order poles at these four fixed points, so it is holomorphic everywhere and consequently zero. Therefore every elliptic solution is even, and must lie in the nine-dimensional space with basis

    1, x, x^2, x^3, x^4, x^5, 1/d, x/d, x^2/d.

The coefficient matrix of `d^3 T` on this basis has rank eight over Q(E). A concrete witness is the minor in rows 0 through 7 and columns 0 through 7 (rows are increasing powers of x, starting at zero). Its value at E=0 is

    20191613463336379810368912419192832000.

The displayed F lies in the kernel, proving both rank and uniqueness up to a rational scalar in E. Its coefficient of x^5 in the above basis is the nonzero constant 893025, so any polynomial-in-E solution is a polynomial-in-E multiple of F. In particular none has energy degree below five.

For completeness, any odd commuting operator of order 2m+1 has right remainder `b1(E) D+b0(E)` modulo `L-E`, with `b1` of energy degree m and nonzero leading coefficient. Reducing the commutator forces

    b0 = -(D b1)/2 + c(E),
    D^3 b1 - 4(u-E) D b1 - 2(Du)b1 = 0.

Thus the preceding global function-field analysis implies m>=5. It applies to every operator in K[D], without restricting its coefficients beforehand.

If `F=sum(f_i E^i,i=0..5)`, define

    A = -sum((f_i D - (D f_i)/2) L^i, i=0..5).

Its leading coefficient is +1 and its order is 11. The script `operators.py` expands this expression in left coefficients and verifies exactly

    [A,L]=0,   A*=-A.

## Spectral identity and division obstruction

The x-independent polynomial

    P = (E-u)F^2 + F(D^2 F)/2 - (D F)^2/4
      = E^2 (E^3-551232)(E^6-553014 E^3+816903549)

is monic. The full differential-operator calculation in `operators.py` verifies `A^2+P(L)=0`, without substituting numerical x values.

Consequently

    q = E,
    h = (E^3-551232)(E^6-553014 E^3+816903549),
    genus = 4.

The polynomial h is squarefree and does not vanish at E=0. For the right division by q(L)=L, the quotient and remainder used in the artifact are

    Q = -sum((f_i D - (D f_i)/2) L^(i-1), i=1..5),
    R = -f_0 D + (D f_0)/2,
    f_0 = 35721*x^2*(5*x^3-88)^2/(x^3-11).

In particular R is nonzero. The normalization does not produce an order-nine differential symmetry by dividing A by L. The exact expanded identity `A=Q L+R` is checked in `operators.py`.

## Prescribed group sum

Put `N=d F` and `V=E W`. I computed the required group sum on the target in coordinates `(x,t=y/2)`, where `t^2=d`, using elliptic divisor reduction. At each root of N, the prescribed point has

    t = -V d/N_x.

Start with

    a = monic(N),
    b = -d * inverse(N_x mod a) mod a,

so the divisor consists of `a=0, t=V b`. Since `V^2=-P`, the reduction step is

    a_new = monic((d+P b^2)/a),
    b_new = -b mod a_new.

Every division is exact. The successive degrees of a are `8,6,4,2,1`. This reduction preserves the divisor class `sum P_i - 8 O`, so its final point is exactly the group sum required in the task, including its sign. If the final a is `x-X`, then `Y=2 E b` and the point is `(X,W Y)`.

The complete rational functions produced by this calculation are in the artifact and in `cover.pkl`; `cover.py` reconstructs them from F. The cover satisfies, exactly,

    -h(E) Y(E)^2 = 4(X(E)^3-11),
    X'(E)/Y(E) = 9(E^3-120582).

The reduced X has numerator degree 18 and denominator degree 17. Comparing the two degree-two coordinate projections proves that the elliptic cover has degree 18.

## Complete ramification

For a degree-nine squarefree hyperelliptic polynomial, `dE/W` has divisor `6 infinity`. Thus

    alpha*(dx/y) = 9(E^3-120582) dE/W

has finite zero divisor exactly that of the monic polynomial

    rho = E^3-120582,

and order zero at infinity. The three roots of rho are simple and avoid the branch points of the hyperelliptic coordinate. In fact,

    h mod rho = 22103805403968750.

There are six simple ramification points, each of index two. Their target branch values are distinct: at a root e of rho,

    X(e)/e = -195908029/4747761216,
    Y(e) = 2523287022071/42507719813867616000.

Both constants are nonzero. The three energies have distinct nonzero x images and, for each energy, the two signs of W give distinct nonzero target y values. No ramification is omitted at poles of the displayed coordinate functions, or at infinity.

## Geometric monodromy

The geometric monodromy is S_18, of order

    6402373705728000.

Here is why this is geometric, rather than an arithmetic Galois group calculation. The six distinct simple branch values give transposition inertia. Let N be the normal subgroup generated by those inertia transpositions. Its orbits give an unramified intermediate cover of the elliptic target. Each orbit carries the full symmetric group generated by the connected transposition graph. Therefore, once nontrivial unramified intermediate covers are excluded, N, and hence the full monodromy, is S_18.

Any such intermediate unramified cover has degree dividing 18. The unique rational point at infinity on the source maps to the elliptic origin, so the canonical maximal unramified intermediate cover descends, with its chosen origin, to an isogeny over Q. At a common good prime away from 6 it reduces to an isogeny over the residue field through which the reduced cover factors.

At p=229 the source and target have good reduction, the rational map retains degree, and every point of target E[6] is rational. The target has 252 rational points. The submitted source points and their images are

    (e,w)=(1,48)  -> (x,y)=(16,9),
    (e,w)=(2,111) -> (x,y)=(2,149).

Both images have order 42, and together they generate all 252 points. Enumeration also verifies that precisely 36 target rational points are killed by six, proving full rational six-torsion.

A nontrivial isogeny of degree dividing 18 into this target cannot be surjective on rational points. Indeed, choose a prime ell in {2,3} dividing its degree, and an order-ell subgroup of the kernel of its dual. This subgroup lies in the rational target E[ell], and quotienting by it gives an ell-isogeny whose dual is the last factor into the target. Since the ell-th roots of unity are rational, this last factor has a rational kernel of order ell. Isogenous curves over the finite field have equal point counts, so its image has index ell. This contradicts the generation by the two displayed source images. Hence there is no nontrivial unramified intermediate cover, and the geometric monodromy is S_18.

## Exact checks and reproduction

Run, in order, from inside this container:

    python /app/solve.py
    python /app/cover.py
    python /app/operators.py
    python /app/minimality.py
    python /app/certificate.py
    python /app/assemble.py
    python /app/verify_artifact.py

`solve.py` constructs the third-order kernel and spectral polynomial. `operators.py` checks the full ring identities, formal adjoint, and right division. `minimality.py` checks the rank minor and kernel vector. `cover.py` performs the exact group-sum reduction and checks the elliptic equation. `certificate.py` searches primes and enumerates the finite group; its result is independently rechecked by `verify_artifact.py` using the serialized artifact. That final script also rechecks the right remainder of A modulo L-E, the spectral factorization, cover degree and differential, and ramification. Serialization limits are checked by `assemble.py`.

The artifact is 14057 bytes, and its largest integer has 169 bits. These are local exact checks, not an official evaluation result.
