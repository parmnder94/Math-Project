import os
os.environ['SYMPY_GROUND_TYPES']='flint'
import sympy as s,pickle,json
x,E=s.symbols('x E');d=x**3-11
F,P,g=pickle.load(open('/app/spectral.pkl','rb')); A,Q,R=pickle.load(open('/app/operators.pkl','rb')); X,Y,r=pickle.load(open('/app/cover.pkl','rb'))
h=s.cancel(P/E**2)
def rf(z,t):
 n,d=s.fraction(s.cancel(z)); n=s.Poly(n,t,domain=s.QQ);d=s.Poly(d,t,domain=s.QQ)
 c=s.ilcm(*[v.q for v in n.all_coeffs()+d.all_coeffs()])
 def arr(p):
  if p.is_zero:return []
  return [int(c*p.nth(i)) for i in range(p.degree()+1)]
 return {'num':arr(n),'den':arr(d)}
def op(a):return [{'a':rf(z[0],x),'b':rf(z[1],x)} for z in a]
out={'operator':op(A),'spectral_polynomial':rf(P,E),'square_factor':rf(E,E),'normalized_polynomial':rf(h,E),'genus':4,'quotient':op(Q),'remainder':op(R),'cover':{'x':rf(X,E),'y_multiplier':rf(Y,E),'degree':18,'pullback':rf(r,E),'ramification_polynomial':rf(E**3-120582,E),'infinity_ramification_order':0},'monodromy':json.load(open('/app/certificate.json'))}
text=json.dumps(out,indent=2)+'\n'
assert len(text.encode())<=2097152
for a in (out['operator'],out['quotient'],out['remainder']):assert len(a)<=33
allints=[]
def walk(z):
 if isinstance(z,dict):
  if set(z)=={'num','den'}:assert len(z['num'])<=129 and 1<=len(z['den'])<=129 and any(z['den'])
  for v in z.values():walk(v)
 elif isinstance(z,list):
  for v in z:walk(v)
 else:assert type(z)==int;allints.append(z)
walk(out);assert all(abs(z)<2**2048 for z in allints)
os.makedirs('/app/output',exist_ok=True)
open('/app/output/centralizer.json','w').write(text)
print('artifact bytes',len(text.encode()),'max integer bits',max(abs(z).bit_length() for z in allints))
