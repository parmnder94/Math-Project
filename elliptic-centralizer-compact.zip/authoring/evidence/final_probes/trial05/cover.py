import os
os.environ['SYMPY_GROUND_TYPES']='flint'
import sympy as s, pickle, time
x,E=s.symbols('x E'); d=x**3-11
F,P,g=pickle.load(open('/app/spectral.pkl','rb'))
K=s.QQ.frac_field(E)
N=s.Poly(s.cancel(d*F),x,domain=K)
f=s.Poly(d,x,domain=K)
print('start inverse',time.time(),flush=True)
a=N.monic(); B= -(f*N.diff().invert(a)).rem(a)
print('inverse done',time.time(),flush=True)
stages=[]
while a.degree()>1:
 print('reduce',a.degree(),B.degree(),time.time(),flush=True)
 aa,rr=(f+s.Poly(P,x,domain=K)*B*B).div(a)
 assert rr.is_zero
 aa=aa.monic(); B=(-B).rem(aa); a=aa
 stages.append((a,B))
 with open('/app/stages.pkl','wb') as z:pickle.dump(stages,z)
print('final',time.time(),flush=True)
X=s.factor(-a.nth(0)/a.nth(1)); Y=s.factor(2*E*B.nth(0)); h=s.cancel(P/E**2)
r=s.factor(s.diff(X,E)/Y)
print('X',X,flush=True);print('Y',Y,flush=True);print('r',r,flush=True)
assert s.cancel(-h*Y**2-4*(X**3-11))==0
with open('/app/cover.pkl','wb') as z:pickle.dump((X,Y,r),z)
