import os
os.environ['SYMPY_GROUND_TYPES']='flint'
import sympy as s,pickle,time,json
x,E=s.symbols('x E'); d=x**3-11; u=30*x+198*x/d
F,P,g=pickle.load(open('/app/spectral.pkl','rb'))
zero=(s.S(0),s.S(0)); one=(s.S(1),s.S(0))
def ca(z):return s.cancel(z)
def add(a,b):return tuple(ca(v+w) for v,w in zip(a,b))
def neg(a):return (-a[0],-a[1])
def scale(a,z):return (ca(a[0]*z),ca(a[1]*z))
def mul(a,b):return (ca(a[0]*b[0]+4*d*a[1]*b[1]),ca(a[0]*b[1]+a[1]*b[0]))
def deriv(a):return (ca(4*d*s.diff(a[1],x)+6*x*x*a[1]),ca(s.diff(a[0],x)))
def trim(a):
 while a and a[-1]==zero:a.pop()
 return a
def opadd(a,b):return trim([add(a[i] if i<len(a) else zero,b[i] if i<len(b) else zero) for i in range(max(len(a),len(b)))])
def opneg(a):return [neg(z) for z in a]
def opscale(a,z):return trim([scale(t,z) for t in a])
def opmul(a,b):
 if not a or not b:return []
 out=[zero]*(len(a)+len(b)-1)
 derivs=[b]
 for k in range(1,len(a)):derivs.append([deriv(z) for z in derivs[-1]])
 for i,ai in enumerate(a):
  if ai==zero:continue
  for j in range(len(b)):
   for k in range(i+1):
    if derivs[k][j]!=zero:out[i+j-k]=add(out[i+j-k],scale(mul(ai,derivs[k][j]),s.binomial(i,k)))
 return trim(out)
def adjoint(a):
 out=[]
 for i,c in enumerate(a):
  term=[zero]*(i+1);cur=c
  for k in range(i+1):
   term[i-k]=scale(cur,(-1)**i*s.binomial(i,k));cur=deriv(cur)
  out=opadd(out,term)
 return out
L=[(u,s.S(0)),zero,(-s.S(1),s.S(0))]
powers=[[one]]
for k in range(1,12):
 powers.append(opmul(powers[-1],L))
 print('Lpower',k,flush=True)
A=[];Q=[]
for i in range(g+1):
 fi=s.Poly(F,E).nth(i);B=[scale(deriv((fi,s.S(0))),s.Rational(1,2)),(-fi,s.S(0))]
 A=opadd(A,opmul(B,powers[i]))
 if i:Q=opadd(Q,opmul(B,powers[i-1]))
 else:R=B
print('Aorder',len(A)-1,flush=True)
assert A[-1]==one
assert not opadd(opmul(A,L),opneg(opmul(L,A)))
print('commutes',flush=True)
assert not opadd(A,adjoint(A))
print('skew',flush=True)
assert not opadd(A,opneg(opadd(opmul(Q,L),R)))
print('division',flush=True)
Pl=[]
for i in range(s.degree(P,E)+1):Pl=opadd(Pl,opscale(powers[i],s.Poly(P,E).nth(i)))
assert not opadd(opmul(A,A),Pl)
print('spectral operator identity',flush=True)
with open('/app/operators.pkl','wb') as f:pickle.dump((A,Q,R),f)
print('R=',R,flush=True)
