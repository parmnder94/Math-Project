import os
os.environ['SYMPY_GROUND_TYPES']='flint'
import sympy as s,pickle,json
x,E=s.symbols('x E');d=x**3-11;u=30*x+198*x/d
F,P,g=pickle.load(open('/app/spectral.pkl','rb'))
basis=[x**i for i in range(6)]+[x**i/d for i in range(3)]
ps=[s.Poly(s.cancel(d**3*(4*d*s.diff(f,x,3)+18*x*x*s.diff(f,x,2)+(12*x-4*u+4*E)*s.diff(f,x)-2*s.diff(u,x)*f)),x) for f in basis]
mat=s.Matrix([[t.nth(i) for t in ps] for i in range(max(t.degree() for t in ps)+1)])
p0=mat.subs(E,0); cols=list(p0.rref()[1]); rows=list(p0[:,cols].T.rref()[1]);det=p0.extract(rows,cols).det()
assert len(cols)==8 and det!=0
fp,fr=s.div(s.cancel(F*d),d,x)
v=[s.expand(fp).coeff(x,i) for i in range(6)]+[s.expand(fr).coeff(x,i) for i in range(3)]
assert all(s.expand(z)==0 for z in mat*s.Matrix(v))
print('basis coefficients:',v)
print('minor at E=0:',rows,cols,det)
json.dump({'rows':rows,'columns':cols,'determinant':int(det),'basis_coefficients':[str(a) for a in v]},open('/app/minimality_check.json','w'),indent=2)
