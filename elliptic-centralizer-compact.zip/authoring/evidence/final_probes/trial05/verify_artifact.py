import os
os.environ['SYMPY_GROUND_TYPES']='flint'
import sympy as s,pickle,json,math
x,E=s.symbols('x E');d=x**3-11;u=30*x+198*x/d
out=json.load(open('/app/output/centralizer.json'))
assert set(out)=={'operator','spectral_polynomial','square_factor','normalized_polynomial','genus','quotient','remainder','cover','monodromy'}
def rf(z,t):return s.cancel(sum(s.Integer(a)*t**i for i,a in enumerate(z['num']))/sum(s.Integer(a)*t**i for i,a in enumerate(z['den'])))
def op(a):return [(rf(z['a'],x),rf(z['b'],x)) for z in a]
F,P,g=pickle.load(open('/app/spectral.pkl','rb')); A,Q,R=pickle.load(open('/app/operators.pkl','rb')); X,Y,r=pickle.load(open('/app/cover.pkl','rb'))
assert all(len(op(out[k]))==len(want) and all(s.cancel(v-w)==0 for a,b in zip(op(out[k]),want) for v,w in zip(a,b)) for k,want in zip(('operator','quotient','remainder'),(A,Q,R)))
assert rf(out['spectral_polynomial'],E)==s.expand(P)
h=rf(out['normalized_polynomial'],E);q=rf(out['square_factor'],E)
assert s.expand(q*q*h-P)==0 and s.gcd(h,s.diff(h,E))==1 and q==E and out['genus']==4
C=out['cover']; assert set(C)=={'x','y_multiplier','degree','pullback','ramification_polynomial','infinity_ramification_order'}
assert all(s.cancel(rf(C[k],E)-v)==0 for k,v in [('x',X),('y_multiplier',Y),('pullback',r)])
assert s.cancel(-h*Y**2-4*(X**3-11))==0
assert s.cancel(s.diff(X,E)/Y-r)==0
rho=rf(C['ramification_polynomial'],E); assert rho==E**3-120582
assert s.gcd(rho,h)==1 and s.gcd(rho,s.diff(rho,E))==1
assert C['infinity_ramification_order']==6-2*s.degree(r,E)==0
xn,xd=s.fraction(X);assert s.gcd(xn,xd)==1 and max(s.degree(xn,E),s.degree(xd,E))==C['degree']==18
# Check the energy remainder of the submitted A directly.
def ca(z):return s.cancel(z)
z=(s.S(0),s.S(0));one=(s.S(1),s.S(0))
def add(a,b):return tuple(ca(v+w) for v,w in zip(a,b))
def mul(a,b):return (ca(a[0]*b[0]+4*d*a[1]*b[1]),ca(a[0]*b[1]+a[1]*b[0]))
def deriv(a):return (ca(4*d*s.diff(a[1],x)+6*x*x*a[1]),ca(s.diff(a[0],x)))
constant=z;linear=z;a=one;b=z
for c in A:
 constant=add(constant,mul(c,a));linear=add(linear,mul(c,b))
 a,b=add(deriv(a),mul(b,(u-E,s.S(0)))),add(a,deriv(b))
assert s.cancel(linear[0]+F)==0 and linear[1]==0
assert constant==(s.S(0),ca(s.diff(F,x)/2))
# Recheck the submitted finite-field witnesses without invoking search.
M=out['monodromy'];assert set(M)=={'group_order','prime','source_points'}
p=M['prime']; assert s.isprime(p) and 5<=p<5000 and 66%p and M['group_order']==math.factorial(18)
def modq(z):z=s.Rational(z);return int(z.p)*pow(int(z.q),-1,p)%p
def ev(poly,e):
 v=0
 for a in s.Poly(poly,E).all_coeffs():v=(v*e+modq(a))%p
 return v
def evalrf(f,e):
 n,d=s.fraction(s.cancel(f));dv=ev(d,e);assert dv;return ev(n,e)*pow(dv,-1,p)%p
for f in (h,X,Y):
 n,den=s.fraction(s.cancel(f));n=s.Poly(n,E,domain=s.QQ);den=s.Poly(den,E,domain=s.QQ);lc=den.LC()
 n=s.Poly(n.as_expr()/lc,E);den=s.Poly(den.as_expr()/lc,E)
 nm=s.Poly.from_list([modq(v) for v in n.all_coeffs()],E,modulus=p);dm=s.Poly.from_list([modq(v) for v in den.all_coeffs()],E,modulus=p)
 assert nm.degree()==n.degree() and dm.degree()==den.degree() and s.gcd(nm,dm).degree()==0
 if f==h:assert s.gcd(nm,nm.diff()).degree()==0
sq={}
for v in range(p):sq.setdefault(v*v%p,[]).append(v)
target={None}
for xx in range(p):
 for v in sq.get((xx**3-11)%p,[]):target.add((xx,v))
def addp(a,b):
 if a is None:return b
 if b is None:return a
 xx,v=a;zz,t=b
 if xx==zz and (v+t)%p==0:return None
 m=((t-v)*pow((zz-xx)%p,-1,p) if xx!=zz else 3*xx*xx*pow(2*v,-1,p))%p
 q=(m*m-xx-zz)%p;return q,(m*(xx-q)-v)%p
def mulp(a,n):
 b=None
 for _ in range(n):b=addp(a,b)
 return b
assert sum(mulp(a,6) is None for a in target)==36
H={None}
for e,w in M['source_points']:
 assert 0<=e<p and 0<=w<p and (w*w+evalrf(h,e))%p==0
 a=(evalrf(X,e),w*evalrf(Y,e)*pow(2,-1,p)%p);assert a in target
 cyc=[None];b=a
 while b is not None:cyc.append(b);b=addp(b,a)
 H={addp(v,t) for v in H for t in cyc}
assert H==target and len(H)==252
print('PASS: serialized artifact, spectral factorization, energy remainder, cover equation and differential, degree, full ramification, and arithmetic certificate.')
