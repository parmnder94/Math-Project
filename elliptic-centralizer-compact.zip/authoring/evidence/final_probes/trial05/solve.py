import sympy as s, json, time, pickle
x,E=s.symbols('x E'); d=x**3-11; u=30*x+198*x/d
basis=[x**i for i in range(6)]+[x**i/d for i in range(3)]
M=[]
for f in basis:
 t=s.cancel(d**3*(4*d*s.diff(f,x,3)+18*x*x*s.diff(f,x,2)+(12*x-4*u+4*E)*s.diff(f,x)-2*s.diff(u,x)*f))
 M.append(s.Poly(t,x))
n=max(t.degree() for t in M)
mat=s.Matrix([[t.nth(i) for t in M] for i in range(n+1)])
print('matrix',mat.shape,flush=True)
v=mat.nullspace()[0]; v=[s.factor(z) for z in v]; print(v,flush=True)
F=s.cancel(sum(a*b for a,b in zip(v,basis))); den=s.lcm([z.as_numer_denom()[1] for z in v]); F=s.cancel(F*den)
F=s.Poly(F,E); g=F.degree(); F=s.cancel(F.as_expr()/F.LC()); print('g',g,'F',s.collect(F,E),flush=True)
P=s.factor((u-E)*F**2- s.Rational(1,2)*F*(4*d*s.diff(F,x,2)+6*x*x*s.diff(F,x))+d*s.diff(F,x)**2)
print('P_expr',P,flush=True)
# This identity yields W^2=P_expr; monic spectral polynomial is negative P_expr for monic F.
P=-P
print('P',s.factor(P),flush=True)
with open('/app/spectral.pkl','wb') as f:pickle.dump((F,P,g),f)
