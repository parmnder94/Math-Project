import json,math,os,sympy as s,runpy
E,x=s.symbols('E x'); path='/app/output/centralizer.json'
raw=open(path).read(); obj=json.loads(raw)
assert len(raw.encode())<=2097152
assert set(obj)=={'operator','spectral_polynomial','square_factor','normalized_polynomial','genus','quotient','remainder','cover','monodromy'}
def rf(o,var):
 assert set(o)=={'num','den'} and 0<len(o['den'])<=129 and len(o['num'])<=129
 for c in o['num']+o['den']:assert type(c) is int and abs(c)<2**2048
 n=sum(c*var**i for i,c in enumerate(o['num']));d=sum(c*var**i for i,c in enumerate(o['den']));assert d!=0
 return s.cancel(n/d)
ops={}
for key in ['operator','quotient','remainder']:
 assert len(obj[key])<=33
 vals=[]
 for el in obj[key]:
  assert set(el)=={'a','b'}
  vals.append((rf(el['a'],x),rf(el['b'],x)))
 ops[key]=vals
P,q,h=[rf(obj[k],E) for k in ['spectral_polynomial','square_factor','normalized_polynomial']]
assert s.cancel(P-q*q*h)==0 and q==E
assert all(s.Poly(f,E).LC()==1 for f in (P,q,h))
assert s.gcd(h,s.diff(h,E))==1 and obj['genus']==4
cover=obj['cover'];assert set(cover)=={'x','y_multiplier','degree','pullback','ramification_polynomial','infinity_ramification_order'}
X,Y,r,rho=[rf(cover[k],E) for k in ['x','y_multiplier','pullback','ramification_polynomial']]
assert s.cancel(-h*Y**2-4*(X**3-11))==0
assert s.cancel(s.diff(X,E)-r*Y)==0 and r==9*(E**3-120582)
assert rho==E**3-120582 and s.gcd(rho,h)==1
assert cover['degree']==18 and cover['infinity_ramification_order']==0
assert max(s.degree(t,E) for t in s.fraction(X))==18
ctx=runpy.run_path('/app/operators.py')
for key,name in [('operator','A'),('quotient','Q'),('remainder','R')]:
 decoded=[(ctx['K'].from_expr(a),ctx['K'].from_expr(b)) for a,b in ops[key]]
 assert decoded==ctx[name]
print('JSON operators match the exact checked operators')
mono=obj['monodromy'];assert set(mono)=={'group_order','prime','source_points'}
assert mono['group_order']==math.factorial(18)
p=mono['prime'];assert type(p)is int and 5<=p<5000 and 66%p and s.isprime(p)
assert s.Poly(h,E,modulus=p).degree()==9 and s.Poly(h,E,modulus=p).gcd(s.Poly(s.diff(h,E),E,modulus=p)).degree()==0
for f in [h,X,Y]:
 n,d=s.fraction(f); n=s.Poly(n,E,domain=s.QQ);d=s.Poly(d,E,domain=s.QQ); lc=d.LC();n=n.mul_ground(1/lc);d=d.monic()
 for c in n.all_coeffs()+d.all_coeffs():assert int(c.q)%p!=0
 def modpoly(poly):return s.Poly.from_list([int(c.p)*pow(int(c.q),-1,p)%p for c in poly.all_coeffs()],E,modulus=p)
 nm,dm=modpoly(n),modpoly(d)
 assert nm.degree()==n.degree() and dm.degree()==d.degree() and nm.gcd(dm).degree()==0

def add(P,Q):
 if P is None:return Q
 if Q is None:return P
 a,b=P;c,d=Q
 if a==c:
  if (b+d)%p==0:return None
  t=3*a*a*pow(2*b,-1,p)%p
 else:t=(d-b)*pow(c-a,-1,p)%p
 xx=(t*t-a-c)%p
 return xx,(t*(a-xx)-b)%p

def multiply(n,P):
 R=None
 while n:
  if n&1:R=add(R,P)
  P=add(P,P);n//=2
 return R
sq={}
for z in range(p):sq.setdefault(z*z%p,[]).append(z)
pts=[None]+[(a,b) for a in range(p) for b in sq.get((a**3-11)%p,[])]
assert len([P for P in pts if multiply(6,P)is None])==36

def ev(f,e):
 n,d=s.fraction(f)
 def ep(t):
  val=0
  for c in s.Poly(t,E).all_coeffs():val=(val*e+int(c.p)*pow(int(c.q),-1,p))%p
  return val
 nv,dv=ep(n),ep(d);assert dv
 return nv*pow(dv,-1,p)%p
sub={None};actual=[]
assert 1<=len(mono['source_points'])<=8
for pair in mono['source_points']:
 assert len(pair)==2 and all(type(z)is int and 0<=z<p for z in pair)
 e,w=pair;assert(w*w+ev(h,e))%p==0
 full=(ev(X,e),w*ev(Y,e)%p)
 assert(full[1]**2-4*(full[0]**3-11))%p==0
 actual.append(full)
 P=(full[0],full[1]*pow(2,-1,p)%p)
 cyclic=[None];v=P
 while v is not None:cyclic.append(v);v=add(v,P)
 sub={add(a,b) for a in sub for b in cyclic}
assert len(sub)==len(pts)
print('Prime',p,'target order',len(pts),'six-torsion 36','images',actual,'generated order',len(sub))
print('All local checks passed; artifact bytes',len(raw.encode()))
