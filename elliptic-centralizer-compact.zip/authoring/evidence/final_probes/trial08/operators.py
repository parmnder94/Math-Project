import sympy as s,pickle,json,time
from math import comb
sx,E=s.symbols('x E'); F,N,P=pickle.load(open('/app/intermediate.pkl','rb'))
K,x=s.polys.fields.field('x',s.QQ); z=K.zero; one=K.one; d=x**3-11; u=30*x+198*x/d
Z=(z,z); I=(one,z)
def add(a,b):return(a[0]+b[0],a[1]+b[1])
def neg(a):return(-a[0],-a[1])
def scale(a,c):return(a[0]*c,a[1]*c)
def mul(a,b):return(a[0]*b[0]+4*d*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def diff(a):return(4*d*a[1].diff(x)+6*x*x*a[1],a[0].diff(x))
def trim(a):
 while a and a[-1]==Z:a.pop()
 return a
def opadd(a,b):return trim([add(a[i] if i<len(a) else Z,b[i] if i<len(b) else Z) for i in range(max(len(a),len(b)))])
def opneg(a):return [neg(c) for c in a]
def compose(a,b):
 if not a or not b:return []
 r=[Z]*(len(a)+len(b)-1)
 for j,bj in enumerate(b):
  ders=[bj]
  for k in range(1,len(a)):ders.append(diff(ders[-1]))
  for i,ai in enumerate(a):
   if ai==Z:continue
   for k in range(i+1):
    r[i+j-k]=add(r[i+j-k],scale(mul(ai,ders[k]),comb(i,k)))
 return trim(r)
def adj(a):
 r=[Z]*len(a)
 for i,c in enumerate(a):
  for k in range(i+1):
   r[i-k]=add(r[i-k],scale(c,(-1)**i*comb(i,k)));c=diff(c)
 return trim(r)
L=[(u,z),Z,(-one,z)]; powers=[[I]]
for i in range(1,12):powers.append(compose(powers[-1],L))
fs=[K.from_expr(s.cancel(s.Poly(N,E).nth(5-j)/(sx**3-11))) for j in range(6)]
Ts=[[(z,f.diff(x)/2),(-f,z)] for f in fs]
A=[];Q=[]
for j in range(6):A=opadd(A,compose(Ts[j],powers[5-j]))
for j in range(5):Q=opadd(Q,compose(Ts[j],powers[4-j]))
R=Ts[-1]
print('orders',len(A)-1,len(Q)-1,len(R)-1,flush=True)
assert A[-1]==I
assert not opadd(compose(A,L),opneg(compose(L,A)));print('commutator verified',flush=True)
assert not opadd(A,adj(A));print('skew adjoint verified',flush=True)
assert not opadd(opadd(compose(Q,L),R),opneg(A));print('division verified',flush=True)
PL=[]
for i in range(12):
 c=s.Poly(P,E).nth(i)
 if c:PL=opadd(PL,[scale(a,K(c)) for a in powers[i]])
assert not opadd(compose(A,A),PL);print('spectral identity verified',flush=True)
def rf_expr(f,var):
 num,den=s.fraction(s.cancel(f));pn=s.Poly(num,var);pd=s.Poly(den,var)
 mult=s.ilcm(*[c.q for c in pn.all_coeffs()+pd.all_coeffs()])
 def enc(p):return [int(mult*p.nth(i)) for i in range(p.degree()+1)] if not p.is_zero else []
 return {'num':enc(pn),'den':enc(pd)}
def rf(f):return rf_expr(f.as_expr(),sx)
def op(a):return[{'a':rf(c[0]),'b':rf(c[1])} for c in a]
X,Y,r=pickle.load(open('/app/cover.pkl','rb'))
res={'operator':op(A),'spectral_polynomial':rf_expr(P,E),'square_factor':rf_expr(E,E),'normalized_polynomial':rf_expr(P/E**2,E),'genus':4,'quotient':op(Q),'remainder':op(R),'cover':{'x':rf_expr(X,E),'y_multiplier':rf_expr(Y,E),'degree':18,'pullback':rf_expr(r,E),'ramification_polynomial':rf_expr(E**3-120582,E),'infinity_ramification_order':0}}
json.dump(res,open('/app/partial.json','w'),indent=2)
print('saved partial',flush=True)
