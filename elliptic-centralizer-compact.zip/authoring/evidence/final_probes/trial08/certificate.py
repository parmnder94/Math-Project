import sympy as s,pickle,json,math
E=s.symbols('E'); F,N,P=pickle.load(open('/app/intermediate.pkl','rb')); h=s.Poly(P/E**2,E)
X,Y,r=pickle.load(open('/app/cover.pkl','rb'))
fracs=[tuple(s.Poly(t,E) for t in s.fraction(s.cancel(f))) for f in (X,Y)]
def add(P,Q,p):
 if P is None:return Q
 if Q is None:return P
 x,y=P; xx,yy=Q
 if x==xx:
  if (y+yy)%p==0:return None
  m=3*x*x*pow(2*y,-1,p)%p
 else:m=(yy-y)*pow(xx-x,-1,p)%p
 xxx=(m*m-x-xx)%p
 return xxx,(m*(x-xxx)-y)%p

def mul(n,P,p):
 R=None
 while n:
  if n&1:R=add(R,P,p)
  P=add(P,P,p);n//=2
 return R

def evalpoly(f,e,p):
 out=0
 for c in f.all_coeffs():out=(out*e+int(c))%p
 return out

def good(p):
 if s.Poly(h,E,modulus=p).gcd(s.Poly(h.diff(),E,modulus=p)).degree():return False
 for n,d in fracs:
  if int(n.LC())%p==0 or int(d.LC())%p==0:return False
  if s.Poly(n,E,modulus=p).gcd(s.Poly(d,E,modulus=p)).degree():return False
 return True

def pointorder(P,p,n):
 for q in s.factorint(n):
  while n%q==0 and mul(n//q,P,p) is None:n//=q
 return n

for p in list(s.primerange(5,5000)):
 if 66%p==0 or p%3!=1 or not good(p):continue
 squares={}
 for w in range(p):squares.setdefault(w*w%p,[]).append(w)
 target=[None]+[(x,y) for x in range(p) for y in squares.get((x*x*x-11)%p,[])]
 if len(target)%36:continue
 torsion=[pt for pt in target if mul(6,pt,p) is None]
 if len(torsion)!=36:continue
 print('eligible prime',p,'target size',len(target),flush=True)
 sub={None}; chosen=[]; images=[]
 for e in range(p):
  ws=squares.get(-evalpoly(h,e,p)%p,[])
  if not ws:continue
  nX,dX=fracs[0];nY,dY=fracs[1]
  xd=evalpoly(dX,e,p);yd=evalpoly(dY,e,p)
  if not xd or not yd:continue
  w=ws[0];im=(evalpoly(nX,e,p)*pow(xd,-1,p)%p,w*evalpoly(nY,e,p)*pow(2*yd,-1,p)%p)
  assert (im[1]**2-im[0]**3+11)%p==0
  if im in sub:continue
  chosen.append([e,w]);images.append(im)
  cyc=[None];v=im
  while v is not None:cyc.append(v);v=add(v,im,p)
  sub={add(a,b,p) for a in sub for b in cyc}
  print(' point',e,w,'image (half-y)',im,'order',len(cyc),'generated',len(sub),flush=True)
  if len(sub)==len(target):break
  if len(chosen)==8:break
 if len(sub)==len(target):
  res=json.load(open('/app/partial.json'))
  res['monodromy']={'group_order':math.factorial(18),'prime':p,'source_points':chosen}
  json.dump(res,open('/app/output/centralizer.json','w'),indent=2)
  json.dump({'prime':p,'target_order':len(target),'torsion_order':len(torsion),'images_half_y':images,'generated_order':len(sub),'points':chosen},open('/app/certificate_details.json','w'),indent=2)
  print('saved final',flush=True)
  break
else:raise RuntimeError('No certificate found')
