import sympy as s
import pickle,time
x,E=s.symbols('x E'); d=x**3-11; u=30*x+198*x/d
n=8
basis=[x**i/d for i in range(n+1)]
def dd(f):return 4*d*s.diff(f,x,2)+6*x*x*s.diff(f,x)
def ode(f):return s.diff(dd(f),x)-4*(u-E)*s.diff(f,x)-2*s.diff(u,x)*f
cols=[s.Poly(s.cancel(ode(f)*d**3),x) for f in basis]
M=s.Matrix([[p.nth(k) for p in cols] for k in range(max(p.degree() for p in cols)+1)])
print('Matrix',M.shape,flush=True)
t=time.time(); ker=M.nullspace(); print('kernel',len(ker),'time',time.time()-t,flush=True)
assert len(ker)==1
v=ker[0]; den=s.lcm([s.denom(s.cancel(a)) for a in v]); N=s.expand(sum(s.cancel(den*a)*x**i for i,a in enumerate(v)))
F=s.cancel(N/d); lc=s.Poly(N,E).LC(); print('leading',s.factor(lc),flush=True)
F=s.cancel(F/(lc/d)); N=s.cancel(d*F)
print('F=',s.collect(s.expand(N),E),' / d',flush=True)
P=s.cancel(F**2*(E-u)+F*dd(F)/2-d*s.diff(F,x)**2)
print('P=',s.factor(P),flush=True)
with open('/app/intermediate.pkl','wb') as out:pickle.dump((F,N,P),out)
