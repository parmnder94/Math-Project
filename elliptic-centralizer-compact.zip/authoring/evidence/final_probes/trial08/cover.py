import sympy as s,pickle,time
x,E=s.symbols('x E'); d=x**3-11
F,N,P=pickle.load(open('/app/intermediate.pkl','rb'))
K=s.QQ.frac_field(E)
def poly(f):return s.Poly(f,x,domain=K)
a=poly(N).monic()
t=time.time(); inv=s.invert(a.diff(),a); print('inverse',time.time()-t,flush=True)
# Nx = leading(N)*a_x, initial b = -V*d/Nx
B=(-poly(d)*inv).mul_ground(1/s.Poly(N,x).LC()).rem(a)
print('B done',time.time()-t,flush=True)
while a.degree()>1:
 t0=time.time()
 num=poly(d)+B*B*P
 anew,rem=s.div(num,a);assert rem.is_zero
 anew=anew.monic(); B=(-B).rem(anew)
 a=anew
 print('reduction',a.degree(),'seconds',time.time()-t0,flush=True)
X=s.cancel(-a.nth(0)); Y=s.cancel(2*E*B.nth(0)) # y=2VB=2EW B
print('X=',s.factor(X),flush=True)
print('Y=',s.factor(Y),flush=True)
print('curve check',s.cancel(-P/E**2*Y**2-4*(X**3-11)),flush=True)
r=s.cancel(s.diff(X,E)/Y)
print('pullback',s.factor(r),flush=True)
pickle.dump((X,Y,r),open('/app/cover.pkl','wb'))
