import sympy as s
from sympy.integrals.rationaltools import ratint
import pickle,time
x,E=s.symbols("x E")
d=x**3-11;u=30*x+198*x/d
p=[s.Integer(1)];rps=[]
for j in range(1,10):
 t=time.time();v=p[-1]
 rp=s.cancel(u*s.diff(v,x)+s.diff(u,x)*v/2-d*s.diff(v,x,3)-s.Rational(9,2)*x*x*s.diff(v,x,2)-3*x*s.diff(v,x))
 rps.append(rp)
 cs=s.symbols("c1:"+str(j))
 check=s.cancel(rp+sum(cs[k-1]*rps[-1-k] for k in range(1,j)))
 so=s.solve(s.Poly(s.fraction(check)[0],x).all_coeffs(),cs)
 print(j,"solution",so,"time",time.time()-t,flush=True)
 if so:
  g=j-1;constants=[1]+[so[c] for c in cs]
  f=[s.cancel(sum(constants[k]*p[z-k] for k in range(z+1))) for z in range(g+1)]
  F=s.cancel(sum(f[k]*E**(g-k) for k in range(g+1)))
  P=s.cancel(F**2*(E-u)+F*(4*d*s.diff(F,x,2)+6*x*x*s.diff(F,x))/2-d*s.diff(F,x)**2)
  print("g",g,"F",s.factor(F),"P",s.factor(P),flush=True)
  with open("/app/precalc.pkl","wb") as out:pickle.dump((x,E,u,d,g,f,F,P),out)
  break
 p.append(s.cancel(ratint(rp,x)))
 print("integral done",j,time.time()-t,flush=True)
