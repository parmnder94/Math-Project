import sympy as s,pickle,math,json
with open('/app/precalc.pkl','rb') as inp:x,E,u,d,g,fs,F,P=pickle.load(inp)
with open('/app/cover.pkl','rb') as inp:X,Y,r=pickle.load(inp)
h=s.cancel(P/E**2)
def integer_pair(v):
 n,d=s.fraction(s.cancel(v));return [s.Poly(z,E) for z in (n,d)]
xn,xd=integer_pair(X);yn,yd=integer_pair(Y);hp=s.Poly(h,E)
def coeff_mod(poly,p):return [int(z.p)*pow(int(z.q),-1,p)%p for z in reversed(poly.all_coeffs())]
def ev(c,e,p):
 v=0
 for a in reversed(c):v=(v*e+a)%p
 return v
def add(a,b,p):
 if a is None:return b
 if b is None:return a
 x,y=a;z,w=b
 if x==z and (y+w)%p==0:return None
 m=((w-y)*pow(z-x,-1,p) if x!=z else 3*x*x*pow(2*y,-1,p))%p
 q=(m*m-x-z)%p
 return (q,(m*(x-q)-y)%p)
def mul(a,n,p):
 out=None
 while n:
  if n&1:out=add(out,a,p)
  a=add(a,a,p);n>>=1
 return out
for p in list(s.primerange(5,5000)):
 if 66%p==0 or p%3!=1:continue
 polys=[hp,xn,xd,yn,yd]
 try:c=[coeff_mod(z,p) for z in polys]
 except ValueError:continue
 if any(cs[-1]==0 for cs in c):continue
 if s.gcd(s.Poly(h,E,modulus=p),s.Poly(s.diff(h,E),E,modulus=p)).degree()!=0:continue
 if s.gcd(s.Poly(xn,E,modulus=p),s.Poly(xd,E,modulus=p)).degree()!=0:continue
 if s.gcd(s.Poly(yn,E,modulus=p),s.Poly(yd,E,modulus=p)).degree()!=0:continue
 roots={}
 for v in range(p):roots.setdefault(v*v%p,[]).append(v)
 target=[None]+[(z,v) for z in range(p) for v in roots.get((z**3-11)%p,[])]
 if sum(mul(a,6,p) is None for a in target)!=36:continue
 print('good torsion prime',p,'target size',len(target),flush=True)
 subgroup={None};witness=[];images=[]
 for e in range(p):
  xdv=ev(c[2],e,p);ydv=ev(c[4],e,p)
  if not xdv or not ydv:continue
  for w in roots.get(-ev(c[0],e,p)%p,[]):
   z=ev(c[1],e,p)*pow(xdv,-1,p)%p
   v=w*ev(c[3],e,p)*pow(2*ydv,-1,p)%p
   a=(z,v)
   assert (v*v-z**3+11)%p==0
   if a in subgroup:continue
   old=set(subgroup);nxt=a
   while nxt not in old:
    subgroup.update(add(b,nxt,p) for b in old)
    nxt=add(nxt,a,p)
   witness.append([e,w]);images.append([z,2*v%p])
   print('added',witness[-1],'image',images[-1],'subgroup size',len(subgroup),flush=True)
   if len(subgroup)==len(target):break
  if len(subgroup)==len(target):break
 if len(subgroup)==len(target) and len(witness)<=8:
  cert={'group_order':math.factorial(18),'prime':int(p),'source_points':witness}
  json.dump(cert,open('/app/certificate.json','w'))
  with open('/app/attempt.md','a') as out:out.write('\nFinite-field certificate: p='+str(p)+', target order '+str(len(target))+', 36 points killed by 6. Source witnesses '+str(witness)+' map to '+str(images)+'. Exact subgroup closure has order '+str(len(subgroup))+'. Reproduce with `/app/certificate.py`.\n')
  break
else:raise RuntimeError('No certificate found')
