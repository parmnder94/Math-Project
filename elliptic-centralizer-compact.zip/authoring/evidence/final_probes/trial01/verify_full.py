import time,pickle,sympy as s,json
exec(open('/app/build_operator.py').read().split('L=[k(u)')[0])
with open('/app/operators.pkl','rb') as inp:A,Q,R=pickle.load(inp)
L=[k(u),Z,k(-1)];t=time.time()
assert add(A,neg(add(mul(Q,L),R)))==[]
print('right division independently checked',time.time()-t,flush=True)
PL=[]
for coeff in s.Poly(P,E).all_coeffs():PL=add(mul(PL,L),[k(coeff)])
print('P(L) built',time.time()-t,flush=True)
identity=add(mul(A,A),PL)
assert identity==[],identity
print('FULL OPERATOR SQUARE VERIFIED',time.time()-t,flush=True)
with open('/app/attempt.md','a') as out:out.write('\nFinal verification `/app/verify_full.py` explicitly composed A with itself and evaluated P(L) by Ore-Horner arithmetic; A^2+P(L) is the zero operator. It also independently rechecked A=QL+R.\n')
