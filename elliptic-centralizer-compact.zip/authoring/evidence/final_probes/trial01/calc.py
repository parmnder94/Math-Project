import sympy as s
import pickle,time
x,E=s.symbols("x E")
d=x**3-11; u=30*x+198*x/d
f=[s.Integer(1)]
cs=[]
for j in range(1,10):
 t=time.time(); p=f[-1]
 rp=s.cancel(u*s.diff(p,x)+s.diff(u,x)*p/2-d*s.diff(p,x,3)-s.Rational(9,2)*x**2*s.diff(p,x,2)-3*x*s.diff(p,x))
 v=s.integrate(rp,x)
 print(j,"int",time.time()-t,flush=True)
 c=s.Symbol("c"+str(j)); cs.append(c); f.append(s.cancel(v+c))
 num=s.Poly(s.fraction(rp)[0],x)
 so=s.solve(num.all_coeffs(),cs[:-1])
 print("solution",so,flush=True)
 if so:
  g=j-1; f=[s.cancel(q.subs(so)) for q in f[:-1]]
  F=sum(f[k]*E**(g-k) for k in range(g+1))
  FF=s.cancel(F); DF2=4*d*s.diff(F,x,2)+6*x*x*s.diff(F,x)
  P=s.cancel(F**2*(E-u)+F*DF2/2-d*s.diff(F,x)**2)
  print("g",g,"F",s.factor(FF),"P",s.factor(P),flush=True)
  with open("/app/precalc.pkl","wb") as out:pickle.dump((x,E,u,d,g,f,FF,P),out)
  break
