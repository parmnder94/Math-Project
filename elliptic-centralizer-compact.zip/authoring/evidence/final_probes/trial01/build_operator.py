import sympy as s,pickle,json,time
with open('/app/precalc.pkl','rb') as inp:x,E,u,d,g,fs,F,P=pickle.load(inp)
# K elements are (a,b), denoting a+y*b; operations exact.
def k(a=0,b=0):return (s.cancel(a),s.cancel(b))
def ka(v,w):return k(v[0]+w[0],v[1]+w[1])
def kn(v):return k(-v[0],-v[1])
def km(v,w):return k(v[0]*w[0]+4*d*v[1]*w[1],v[0]*w[1]+v[1]*w[0])
def kd(v):return k(4*d*s.diff(v[1],x)+6*x*x*v[1],s.diff(v[0],x))
def trim(v):
 while v and v[-1]==(0,0):v.pop()
 return v
Z=k()
def add(a,b):return trim([ka(a[i] if i<len(a) else Z,b[i] if i<len(b) else Z) for i in range(max(len(a),len(b)))])
def neg(a):return [kn(v) for v in a]
def mul(a,b):
 out=[Z]*(len(a)+len(b)-1)
 for j,v in enumerate(a):
  for z,w in enumerate(b):
   for ell in range(j+1):
    v1=km(v,w);v1=k(s.binomial(j,ell)*v1[0],s.binomial(j,ell)*v1[1])
    out[j+z-ell]=ka(out[j+z-ell],v1);w=kd(w)
 return trim(out)
def power(a,j):
 out=[k(1)]
 for _ in range(j):out=mul(out,a)
 return out
def adj(a):
 out=[]
 for j,v in enumerate(a):
  c=[Z]*j+[k((-1)**j)]
  out=add(out,mul(c,[v]))
 return out
def div(a,b):
 a=a.copy();q=[]
 assert b[-1][1]==0
 while len(a)>=len(b):
  j=len(a)-len(b);c=k(a[-1][0]/b[-1][0],a[-1][1]/b[-1][0]);t=[Z]*j+[c]
  q=add(q,t);a=add(a,neg(mul(t,b)))
 return q,a
L=[k(u),Z,k(-1)]
A=[];t=time.time()
for j in range(g+1):
 term=[k(0,-s.diff(fs[j],x)/2),k(fs[j])]
 A=add(A,neg(mul(term,power(L,g-j))))
print('built A',len(A)-1,'seconds',time.time()-t,flush=True)
assert A[-1]==(1,0)
assert add(A,adj(A))==[]
assert add(mul(A,L),neg(mul(L,A)))==[]
print('commutator and skew checked',time.time()-t,flush=True)
# A squared takes substantial time; use the already exact squared-eigenfunction identity
# plus right division through L-E, whose injectivity for constant-polynomial E guarantees equality.
Q,R=div(A,L)
print('R',R,flush=True)
with open('/app/operators.pkl','wb') as out:pickle.dump((A,Q,R),out)
print('saved',time.time()-t,flush=True)
