import sympy as s,pickle,time
with open('/app/precalc.pkl','rb') as f:x,E,u,d,g,fs,F,P=pickle.load(f)
h=s.cancel(P/E**2);K=s.QQ.frac_field(E)
t=time.time()
N=s.Poly(s.cancel(d*F),x,domain=K).monic()
print("invert start",time.time()-t,flush=True)
T=(s.Poly(d,x,domain=K)*s.invert(N.diff(),N)).mul_ground(-2*E/s.LC(s.Poly(s.cancel(d*F),x))).rem(N)
# Multiplying by leading coefficient: N_original'=lc N_monic'.
print("invert done",time.time()-t,flush=True)
with open('/app/divisor.pkl','wb') as f:pickle.dump((N,T),f)
while N.degree()>1:
 norm=(T*T).mul_ground(-h)-s.Poly(4*d,x,domain=K)
 U,rem=norm.div(N)
 assert rem.is_zero
 U=U.monic()
 T=(-T).rem(U)
 N=U
 print("reduced degree",N.degree(),"time",time.time()-t,flush=True)
 with open('/app/divisor'+str(N.degree())+'.pkl','wb') as f:pickle.dump((N,T),f)
X=s.cancel(-N.nth(0));Y=s.cancel(T.nth(0))
r=s.cancel(s.diff(X,E)/Y)
print("X",s.factor(X),"Y",s.factor(Y),"r",s.factor(r),flush=True)
assert s.cancel(-h*Y**2-4*(X**3-11))==0
with open('/app/cover.pkl','wb') as f:pickle.dump((X,Y,r),f)
