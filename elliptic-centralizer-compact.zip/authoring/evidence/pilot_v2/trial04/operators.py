import sympy as s,pickle,json,math,time
from sympy.polys.domains import QQ
x,E=s.symbols("x E");K=QQ.frac_field(x);xx=K.gens[0]
d=K.from_sympy(x**3-11);u=K.from_sympy(30*x+198*x/(x**3-11));z=K.zero;o=K.one
zero=(z,z);one=(o,z)
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[0],-a[1])
def mul(a,b):return (a[0]*b[0]+4*d*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,c):return (a[0]*c,a[1]*c)
def der(a):return (4*d*a[1].diff(xx)+6*K.from_sympy(x*x)*a[1],a[0].diff(xx))
def trim(a):
 while a and a[-1]==zero:a.pop()
 return a

def oa(a,b):return trim([add(a[i] if i<len(a) else zero,b[i] if i<len(b) else zero) for i in range(max(len(a),len(b)))])
def on(a):return [neg(c) for c in a]
def om(a,b):
 if not a or not b:return []
 out=[zero]*(len(a)+len(b)-1)
 for j,c in enumerate(b):
  ds=[c]
  for i in range(1,len(a)):ds.append(der(ds[-1]))
  for i,a_i in enumerate(a):
   if a_i==zero:continue
   for k in range(i+1):out[i+j-k]=add(out[i+j-k],scale(mul(a_i,ds[k]),math.comb(i,k)))
 return trim(out)
def adj(a):
 out=[zero]*len(a)
 for j,c in enumerate(a):
  for k in range(j+1):
   out[j-k]=add(out[j-k],scale(c,(-1)**j*math.comb(j,k)))
   c=der(c)
 return trim(out)
def ep(poly,L):
 out=[]
 for c in s.Poly(poly,E).all_coeffs():out=oa(om(out,L),[(K.from_sympy(c),z)])
 return out

def rf(v,var):
 v=s.cancel(v);num,den=s.fraction(v); np=s.Poly(num,var);dp=s.Poly(den,var);lcm=s.ilcm(*[a.q for a in np.all_coeffs()+dp.all_coeffs()]);
 return {"num":[int(a*lcm) for a in reversed(np.all_coeffs())] if num!=0 else [],"den":[int(a*lcm) for a in reversed(dp.all_coeffs())]}
def openc(a):return [{"a":rf(K.to_sympy(c[0]),x),"b":rf(K.to_sympy(c[1]),x)} for c in a]

F,P,q,h=pickle.load(open("/app/stage2.pkl","rb"));X,Y,r=pickle.load(open("/app/cover.pkl","rb"))
L=[(u,z),zero,(-o,z)]
fs=s.Poly(F,E).all_coeffs(); A=[]
for f in fs:
 f=K.from_sympy(f);A=oa(om(A,L),[(z,f.diff(xx)/2),(-f,z)])
 print("A order",len(A)-1,time.time(),flush=True)
print("check commute",oa(om(A,L),on(om(L,A)))==[],flush=True)
print("check adjoint",oa(A,adj(A))==[],flush=True)
print("square start",time.time(),flush=True)
assert oa(om(A,A),ep(P,L))==[]
print("square checked",time.time(),flush=True)
# Right division q(L)=L. Leading coefficient -1.
R=A[:];Q=[zero]*(len(A)-2)
while len(R)>=3:
 k=len(R)-3;c=neg(R[-1]);Q[k]=add(Q[k],c)
 R=oa(R,on(om([zero]*k+[c],L)))
assert oa(oa(om(Q,L),R),on(A))==[]
print("R",[(K.to_sympy(a),K.to_sympy(b)) for a,b in R],flush=True)
rho=s.Poly(s.fraction(s.cancel(r))[0],E).monic().as_expr()
res={"operator":openc(A),"spectral_polynomial":rf(P,E),"square_factor":rf(q,E),"normalized_polynomial":rf(h,E),"genus":4,"quotient":openc(Q),"remainder":openc(R),"cover":{"x":rf(X,E),"y_multiplier":rf(Y,E),"degree":18,"pullback":rf(r,E),"ramification_polynomial":rf(rho,E),"infinity_ramification_order":0}}
json.dump(res,open("/app/output/centralizer.json","w"),separators=(",",":"))
pickle.dump([[(K.to_sympy(a),K.to_sympy(b)) for a,b in T] for T in (A,Q,R)],open("/app/ops.pkl","wb"))
print("written",flush=True)
