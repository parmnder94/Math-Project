# Independent exact solution

All computations were performed inside this container, from `/instruction.md` and
`/app/data`. No external task, solution, verifier, other container, or other
solver was consulted. The submitted artifact is `/app/output/centralizer.json`.

## Squared eigenfunction and spectral polynomial

Write `d=x^3-11`, `u=30x+198x/d`. For a rational function depending on x,
`D^2 f=4d f_xx+6x^2 f_x` and
`D^3 f=y(4d f_xxx+18x^2 f_xx+12x f_x)`.
The squared-eigenfunction equation is

    D^3 F - 4(u-E) D F - 2(Du) F = 0.

I solved this linear homogeneous equation over Q(E) on the basis

    1,x,x^2,x^3,x^4,x^5,1/d,x/d,x^2/d.

The matrix has 14 rows and 9 columns and its nullspace is one dimensional.
The primitive solution, monic as a polynomial in E, is F=N/d, where

    N = E^5(x^3-11)
      + E^4(15x^4-66x)
      + E^3(315x^5+693x^2)
      + E^2(6300x^6-467082x^3+6090777)
      + E(99225x^7-4147605x^4+42261912x)
      + 893025x^8-31434480x^5+276623424x^2.

Let F=sum_{j=0}^5 f_j E^(5-j), so f_0=1. Construct

    A = sum_{j=0}^5 (-f_j D + (D f_j)/2) L^(5-j).

Its leading term is D^11, and its remainder modulo L-E is
`-F D+(D F)/2`, as prescribed. Exact noncommutative arithmetic verifies
`[A,L]=0`, `A*=-A`, and `A^2+P(L)=0`, with

    P = (E-u)F^2 + F D^2(F)/2 - (D F)^2/4
      = E^2 (E^3-551232)(E^6-553014E^3+816903549).

Consequently

    q=E,
    h=(E^3-551232)(E^6-553014E^3+816903549).

The degree-nine polynomial h is squarefree, giving normalized genus 4.

## Why this order is globally minimal in K

This is not just minimal within an arbitrary ansatz. The elliptic curve has four
fixed points for its negation involution. At infinity, choose a local Abelian
coordinate z, so x~z^-2. The potential has leading term 30/z^2, corresponding
to l=5. At each finite fixed point x=a, a^3=11, one has
`x-a=3a^2 z^2+O(z^4)` and u~2/z^2, corresponding to l=1.
There are no other poles of u.

For a local solution of the third-order equation at a potential pole, the
indicial polynomial is

    (nu+2l)(nu-1)(nu-2l-2).

Thus a meromorphic solution can have poles of order at most 10 at infinity,
at most 2 at the finite fixed points, and none elsewhere (the third derivative
would otherwise have an uncancelled leading pole). Decompose any solution
under (x,y)->(x,-y). The equation preserves this decomposition. An odd part
can only have odd Laurent pole orders at a fixed point, whereas the only
negative indicial root is even. Hence the odd part has no poles at all and
must be zero. Every meromorphic solution is therefore rational in x and lies
in the displayed nine-dimensional space.

For any commuting differential operator of odd order 2m+1, reduction on
solutions of (L-E)psi=0 gives a nonzero D coefficient polynomial in E of degree
m satisfying this third-order equation. A possible scalar remainder only adds
a polynomial in L and does not affect that coefficient. The computed
one-dimensional nullspace implies that coefficient equals c(E)F. The
coefficients of N as a polynomial in x have no common nonconstant E factor;
in particular the x^8 coefficient is the nonzero constant 893025. Thus c(E)
must be a polynomial whenever c(E)F is polynomial in E over K. Its E degree
cannot be less than 5. Therefore every odd centralizer has order at least 11.
The displayed A attains this bound over the full field K.

## Differential division and obstruction

Since q(L)=L, the quotient is

    Q=sum_{j=0}^4 (-f_j D+(D f_j)/2)L^(4-j),

and the remainder is

    R= -f_5 D+(D f_5)/2,
    f_5=35721 x^2(5x^3-88)^2/(x^3-11).

This R is nonzero and has order 1. The serialized Q and R were also obtained
by ordinary exact right division and checked against A=QL+R. In particular,
the square factor E of the spectral polynomial does not divide A as a
differential operator on the right.

## Exact group sum, including its sign

Work over Q(E,W), with W^2=-h. Set U_8=N/893025 and interpolate the y
coordinates of the specified points as W T_8(x), where

    T_8 = (-2 E d / 893025) * inverse(U_8', modulo U_8) mod U_8.

This is exactly `-2Vd/N_x`, since V=EW. No sign is chosen independently.
Starting with U_8,T_8, repeat the following exact elliptic divisor reduction:

    U_new = monic((-h T^2-4(x^3-11))/U),
    T_new = -T mod U_new.

Every division is exact. The degrees successively are 8,6,4,2,1. To justify
the group sum, the function y-WT has zeros at the current points and the
residual intersection points. Its only pole is at infinity. The sum of all
zeros is the identity, so negating the residual points preserves the sum of
the original divisor. The minus sign in T_new implements this negation.
Thus the final pair U_1=x-X,T_1=Y gives exactly the group sum in the task,
not just an unrelated elliptic map.

The final expressions are as follows. Put

    B=E^6+902286E^3-836509234176,

    H=E^18-52317738E^15+137541930139845E^12
      -130688851922762918400E^9+53454932630448304961617920E^6
      -8100189794317793342169727107072E^3
      +47783298913570122159712398471069696,

    J=E^24+108867132E^21-850413582239265E^18
      +1845872425854496537344E^15-1882424664672226560039813120E^12
      +1017497292619159818455595916197888E^9
      -282142935388202807657710071937304100864E^6
      +30772016361980893082560233592278583439523840E^3
      +365450704279711412131618611249798077188398907392.

Then

    X=-H/(324 E^2 (E^3-551232) B^2),
    Y=-J/(2916 E^3 (E^3-551232)^2 B^3).

Exact arithmetic gives `-h Y^2=4(X^3-11)` and

    X'/Y = 9(E^3-120582).

The numerator and denominator of X are coprime, with degrees 18 and 17.
The degree of X on the spectral curve is 36; since x on the target elliptic
curve has degree two, the covering has degree 18.

## Complete ramification

The elliptic differential dx/y is nowhere zero. Its pullback is

    9(E^3-120582) dE/W.

On the genus-four degree-nine hyperelliptic curve, dE/W has no finite zeros
or poles and has a zero of order 6 at the unique point at infinity. The cubic
factor has a pole of order 6 there, so the pullback has order zero at infinity.
Its cubic roots are simple and are not hyperelliptic branch points; indeed

    h mod (E^3-120582) = 22103805403968750 != 0.

Each root therefore gives two simple ramification points. The complete
ramification divisor is the finite zero divisor of `rho=E^3-120582`, with
infinity coefficient zero. Its total degree is 6, agreeing with Riemann--Hurwitz.

## Reproduction and exact checks

Python/SymPy scripts in this container:

* `/app/solve.py`: builds the third-order equation matrix and obtains F.
* `/app/stage2.py`: evaluates and factors the correct spectral invariant.
* `/app/cover.py`: interpolates and reduces the exact divisor; writes all
  intermediate pairs as `/app/coverstep6.pkl`, `coverstep4.pkl`,
  `coverstep2.pkl`, `coverstep1.pkl`.
* `/app/operators.py`: exact pair arithmetic for a(x)+yb(x), operator
  multiplication and adjoints, identities, right division, JSON serialization.
* `/app/check_output.py`: independent checks on the serialized artifact.

Reproduce with `python /app/solve.py`, `python /app/stage2.py`,
`python /app/cover.py`, `python /app/operators.py`, then
`python /app/check_output.py`. Arithmetic is rational throughout.

Errors encountered and corrected: the first version of the invariant in
solve.py had the derivative-term signs reversed, leaving spurious x
dependence. The corrected invariant is isolated in stage2.py and used by all
subsequent work. Initial cover code used Python division on a SymPy Poly,
which lost its univariate polynomial domain; this was corrected to
`mul_ground`. The field derivative needs its field generator, not the SymPy
Symbol; operators.py uses `xx=K.gens[0]`. Pickling raw rational-domain elements
raised an internal SymPy exception after the JSON had been written; the
pickle now stores ordinary SymPy expressions. The final run completed all
assertions and wrote the artifact successfully. One shell heredoc used while
writing this log initially had conflicting quotation marks; the retry used
standard input to docker exec and succeeded.

The serialized-check harness initially compared identical SymPy Polys with
different coefficient domains after unpickling (QQ[E] versus QQ(E)); the
check now coerces every stored Poly back to QQ(E) before equality tests.
