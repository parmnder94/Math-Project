import sympy as s,pickle,time
from sympy.polys.domains import QQ
x,E=s.symbols("x E");d=x**3-11
F,P,q,h=pickle.load(open("/app/stage2.pkl","rb"))
K=QQ.frac_field(E)
U=s.Poly(s.cancel(d*F),x,domain=K).monic()
print("inverse start",flush=True)
t=(s.Poly(-2*E*d,x,domain=K)*s.invert(U.diff(),U)).mul_ground(1/s.Poly(s.cancel(d*F),x,domain=K).LC()).rem(U)
print("inverse done",time.time(),"length",len(str(t)),flush=True)
pickle.dump((U,t),open("/app/coverstart.pkl","wb"))
while U.degree()>1:
 numer=t*t*s.Poly(-h,x,domain=K)-s.Poly(4*d,x,domain=K)
 print("numer done",time.time(),flush=True)
 Un,rem=s.div(numer,U);assert rem.is_zero
 Un=Un.monic()
 print("division done newdeg",Un.degree(),time.time(),flush=True)
 tn=-s.rem(t,Un)
 U,t=Un,tn
 print("reduction done",time.time(),"lengths",len(str(U)),len(str(t)),flush=True)
 pickle.dump((U,t),open("/app/coverstep%d.pkl"%U.degree(),"wb"))
X=s.cancel(-U.nth(0)/U.nth(1));Y=s.cancel(t.nth(0))
print("X",s.factor(X),flush=True);print("Y",s.factor(Y),flush=True)
print("curve check",s.cancel(-h*Y**2-4*(X**3-11)),flush=True)
r=s.cancel(s.diff(X,E)/Y);print("r",s.factor(r),flush=True)
pickle.dump((X,Y,r),open("/app/cover.pkl","wb"))
