import json,os,sympy as s,pickle
# Load only the arithmetic definitions, not the generation/checking main program.
exec(open('/app/operators.py').read().split('F,P,q,h=pickle.load')[0])
p='/app/output/centralizer.json'
obj=json.load(open(p))
assert set(obj)=={'operator','spectral_polynomial','square_factor','normalized_polynomial','genus','quotient','remainder','cover'}
assert os.stat(p).st_size<=2097152

def check_rf(v):
 assert set(v)=={'num','den'}
 for ar in v.values():
  assert len(ar)<=129
  assert all(type(c) is int and abs(c)<2**2048 for c in ar)
 assert any(v['den'])

def dec(v,t):
 check_rf(v)
 return s.cancel(sum(c*t**i for i,c in enumerate(v['num']))/sum(c*t**i for i,c in enumerate(v['den'])))

def decop(op):
 assert len(op)<=33
 for c in op:assert set(c)=={'a','b'}
 return trim([(K.from_sympy(dec(c['a'],x)),K.from_sympy(dec(c['b'],x))) for c in op])

A=decop(obj['operator']);Q=decop(obj['quotient']);R=decop(obj['remainder'])
L=[(u,z),zero,(-o,z)]
P=dec(obj['spectral_polynomial'],E);q=dec(obj['square_factor'],E);h=dec(obj['normalized_polynomial'],E)
assert len(A)==12 and A[-1]==one
assert oa(om(A,L),on(om(L,A)))==[]
assert oa(A,adj(A))==[]
assert oa(om(A,A),ep(P,L))==[]
assert s.cancel(P-q*q*h)==0 and s.gcd(h,s.diff(h,E))==1
assert q==E and s.degree(h,E)==9 and obj['genus']==4
assert oa(oa(om(Q,ep(q,L)),R),on(A))==[] and len(R)==2
f5=K.from_sympy(35721*x*x*(5*x**3-88)**2/(x**3-11))
assert R==[(z,f5.diff(xx)/2),(-f5,z)]
cov=obj['cover'];assert set(cov)=={'x','y_multiplier','degree','pullback','ramification_polynomial','infinity_ramification_order'}
X=dec(cov['x'],E);Y=dec(cov['y_multiplier'],E);r=dec(cov['pullback'],E);rho=dec(cov['ramification_polynomial'],E)
assert s.cancel(-h*Y**2-4*(X**3-11))==0
assert s.cancel(s.diff(X,E)-r*Y)==0
assert r==9*(E**3-120582) and rho==E**3-120582
assert s.gcd(h,rho)==1 and s.gcd(rho,s.diff(rho,E))==1
xn,xd=s.fraction(X)
assert max(s.degree(xn,E),s.degree(xd,E))==cov['degree']==18
assert cov['infinity_ramification_order']==0
# Recheck the saved exact divisor-reduction chain and its final coordinates.
B=QQ.frac_field(E)
U,T=[s.Poly(p.as_expr(),x,domain=B) for p in pickle.load(open('/app/coverstart.pkl','rb'))]
F,_,_,_=pickle.load(open('/app/stage2.pkl','rb'))
N=s.Poly(s.cancel((x**3-11)*F),x,domain=B)
assert U==N.monic()
assert (T*N.diff()+s.Poly(2*E*(x**3-11),x,domain=B)).rem(U).is_zero
for degree in (6,4,2,1):
 Un,Tn=[s.Poly(p.as_expr(),x,domain=B) for p in pickle.load(open('/app/coverstep%d.pkl'%degree,'rb'))]
 quotient,rem=(T*T*s.Poly(-h,x,domain=B)-s.Poly(4*(x**3-11),x,domain=B)).div(U)
 assert rem.is_zero and quotient.monic()==Un and -T.rem(Un)==Tn
 U,T=Un,Tn
assert s.cancel(U.nth(0)+X)==0 and s.cancel(T.nth(0)-Y)==0
print('All serialized identities, divisor reductions, signs, normalization, ramification and size checks passed.')
print('Artifact bytes:',os.stat(p).st_size)
