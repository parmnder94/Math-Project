import sympy as s,pickle
x,E=s.symbols("x E");d=x**3-11;u=30*x+198*x/d
F,_=pickle.load(open("/app/stage1.pkl","rb"))
P=s.cancel((2*F*(4*d*s.diff(F,x,2)+6*x*x*s.diff(F,x))-s.diff(F,x)**2*4*d)/4+(E-u)*F**2)
print("P",s.factor(P),flush=True)
fs=s.factor_list(P)[1];q=s.prod(f**(k//2) for f,k in fs);h=s.cancel(P/q**2)
print("q",q,"h",s.factor(h),flush=True)
pickle.dump((F,P,q,h),open("/app/stage2.pkl","wb"))
