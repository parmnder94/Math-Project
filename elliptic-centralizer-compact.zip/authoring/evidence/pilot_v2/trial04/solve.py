import sympy as s, pickle
x,E=s.symbols("x E")
d=x**3-11
u=30*x+198*x/d
basis=[x**i for i in range(6)]+[x**i/d for i in range(3)]
def ode(f):
 return s.cancel(4*d*s.diff(f,x,3)+18*x*x*s.diff(f,x,2)+(12*x-4*u+4*E)*s.diff(f,x)-2*s.diff(u,x)*f)
polys=[s.Poly(s.cancel(ode(f)*d**3),x) for f in basis]
M=s.Matrix([[p.nth(i) for p in polys] for i in range(max(p.degree() for p in polys)+1)])
print("matrix",M.shape,flush=True)
n=M.nullspace()
print("nullity",len(n),flush=True)
v=n[0]; den=s.lcm([s.denom(s.cancel(c)) for c in v]); v=[s.cancel(c*den) for c in v]; g=s.gcd_list(v);v=[s.cancel(c/g) for c in v]
F=s.cancel(sum(a*b for a,b in zip(v,basis)))
fpol=s.Poly(F,E); F=s.cancel(F/fpol.LC());print("F=",s.factor(F),flush=True)
P=s.cancel((s.diff(F,x)**2*4*d-2*F*(4*d*s.diff(F,x,2)+6*x*x*s.diff(F,x)))/4+(E-u)*F**2)
print("P=",s.factor(P),flush=True)
pickle.dump((F,P),open("/app/stage1.pkl","wb"))
