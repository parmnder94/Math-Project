import sympy as s,pickle,time
from sympy.external.gmpy import GROUND_TYPES
print('GROUND_TYPES',GROUND_TYPES,flush=True)
x,E=s.symbols('x E'); z,t=s.symbols('z t'); d=x**3-11
g,F,P,fs,sol=pickle.load(open('/app/spectral.pkl','rb'))
N=s.Poly(s.cancel(d*F),E,x)
n=sum(c*s.Rational(1,11)**((8-i-j)//3)*z**j*t**((8-i-j)//3) for (i,j),c in N.terms())
p=(1-50112*t)*(1-50274*t+6751269*t*t)
print('n',n,flush=True); print('p',p,flush=True)
K=s.QQ.frac_field(t)
u=s.Poly(n,z,domain=K).monic()
v=-s.invert(u.diff(),u)*s.Poly(z**3-t,z,domain=K)/s.Rational(893025)
v=s.Poly(v,z,domain=K).rem(u)
# u=n/893025. Derivative n = 893025 u' -> v=-(z³-t)/n'.
start=time.time()
print('initial v, secs',time.time()-start,flush=True)
print('verification', (v*v*s.Poly(p,z,domain=K)+s.Poly(z**3-t,z,domain=K)).rem(u).is_zero,flush=True)
for k in range(10):
 print('step',k,'u degree',u.degree(),'v degree',v.degree(),'secs',time.time()-start,flush=True)
 pickle.dump((u,v,n,p),open('/app/cover_step'+str(k)+'.pkl','wb'))
 if u.degree()==1:break
 numerator=-s.Poly(p,z,domain=K)*v*v-s.Poly(z**3-t,z,domain=K)
 unew,rem=s.div(numerator,u)
 assert rem.is_zero
 unew=unew.monic()
 vnew=(-v).rem(unew)
 u,v=unew,vnew
Xhat=-u.nth(0)
Khat=v.nth(0)
print('Xhat',s.factor(Xhat),flush=True)
print('Khat',s.factor(Khat),flush=True)
# z=X/E, Ystandard=V/E^4 Khat; original y=2Ystandard=2W/E^3 Khat.
X=s.factor(E*Xhat.subs(t,11/E**3))
Y=s.factor(2/E**3*Khat.subs(t,11/E**3))
print('X',X,flush=True);print('Y',Y,flush=True)
pickle.dump((X,Y,Xhat,Khat),open('/app/cover.pkl','wb'))
