import sympy as s
x,E=s.symbols('x E'); d=x**3-11; u=30*x+198*x/d
f=[s.Integer(1)]
for n in range(1,8):
 p=f[-1]
 derivative=s.cancel(u*s.diff(p,x)+s.diff(u,x)*p/2-(4*d*s.diff(p,x,3)+18*x*x*s.diff(p,x,2)+12*x*s.diff(p,x))/4)
 print('n',n,'derivative length',len(str(derivative)),flush=True)
 # Integrate rational expression, require no transcendentals.
 pn=s.integrate(derivative,x,risch=True)
 pn=s.cancel(pn)
 print('primitive',n,s.factor(pn),flush=True)
 if pn.has(s.log,s.Integral): raise Exception('integration failed')
 f.append(pn)
 s.polys.polytools.cancel
 # stationarity sum constant combination derivative
 cs=s.symbols('c1:'+str(n))
 eq=s.together(s.diff(f[n],x)+sum(cs[i-1]*s.diff(f[n-i],x) for i in range(1,n)))
 sol=s.solve(s.Poly(s.fraction(eq)[0],x).all_coeffs(),cs)
 print('stationarity',n,sol,flush=True)
 if sol:
  g=n-1
  F=sum((f[j]+sum(sol.get(cs[i-1],0)*f[j-i] for i in range(1,j+1)))*E**(g-j) for j in range(g+1))
  F=s.cancel(F)
  print('F=',s.factor(F),flush=True)
  P=s.cancel((E-u)*F**2+F*(4*d*s.diff(F,x,2)+6*x*x*s.diff(F,x))/2-d*s.diff(F,x)**2)
  print('P=',s.factor(P),flush=True)
  import pickle
  with open('/app/spectral.pkl','wb') as out:pickle.dump((g,F,P,f,sol),out)
  break
