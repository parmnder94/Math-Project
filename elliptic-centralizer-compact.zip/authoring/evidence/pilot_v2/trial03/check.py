import sympy as s,json,os,pickle
x,E=s.symbols('x E')
path='/app/output/centralizer.json'
a=json.load(open(path))
assert set(a)=={'operator','spectral_polynomial','square_factor','normalized_polynomial','genus','quotient','remainder','cover'}
assert set(a['cover'])=={'x','y_multiplier','degree','pullback','ramification_polynomial','infinity_ramification_order'}
assert os.path.getsize(path)<=2097152

def rat(r,t):
 assert set(r)=={'num','den'}
 assert 0<len(r['den'])<=129 and len(r['num'])<=129
 for i in r['num']+r['den']:assert type(i)==int and abs(i)<2**2048
 n=sum(v*t**i for i,v in enumerate(r['num']));d=sum(v*t**i for i,v in enumerate(r['den']))
 assert d!=0
 return s.cancel(n/d)
for key in ['operator','quotient','remainder']:
 assert len(a[key])<=33
 for c in a[key]:
  assert set(c)=={'a','b'}
  rat(c['a'],x);rat(c['b'],x)
P,q,h=[rat(a[key],E) for key in ['spectral_polynomial','square_factor','normalized_polynomial']]
assert s.cancel(P-q*q*h)==0
assert s.gcd(h,s.diff(h,E))==1
assert s.Poly(P,E).LC()==s.Poly(q,E).LC()==s.Poly(h,E).LC()==1
assert a['genus']==(s.degree(h,E)-1)//2
X,Y,r,rho=[rat(a['cover'][key],E) for key in ['x','y_multiplier','pullback','ramification_polynomial']]
assert s.cancel(-h*Y**2-4*(X**3-11))==0
assert s.cancel(s.diff(X,E)-Y*r)==0
assert s.Poly(rho,E).LC()==1
assert s.gcd(rho,s.diff(rho,E))==1
assert s.gcd(rho,h)==1
xn,xd=s.fraction(X)
assert max(s.degree(xn,E),s.degree(xd,E))==a['cover']['degree']==18
assert s.cancel(r/rho)==9
assert a['cover']['infinity_ramification_order']==2*a['genus']-2-2*s.degree(r,E)==0
assert 2*s.degree(rho,E)+a['cover']['infinity_ramification_order']==2*a['genus']-2
assert a['operator'][-1]=={'a':{'num':[1],'den':[1]},'b':{'num':[],'den':[1]}}
assert len(a['operator'])==12 and len(a['quotient'])==10 and len(a['remainder'])==2
print('Encoding, size, polynomial factorization, squarefreeness, genus, cover equation, pullback, degree, complete ramification and leading operator coefficient: all passed.')
print('Artifact bytes:',os.path.getsize(path))
print('F(0):',s.factor(pickle.load(open('/app/spectral.pkl','rb'))[1].subs(E,0)))
