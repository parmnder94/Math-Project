import sympy as s,pickle,json,time
x,E=s.symbols('x E'); d=x**3-11; u=30*x+198*x/d
G,F,P,fs,sol=pickle.load(open('/app/spectral.pkl','rb'))
X,Y,_,_=pickle.load(open('/app/cover.pkl','rb'))
h=s.cancel(P/E**2)
r=s.factor(s.diff(X,E)/Y)
print('pullback',r,flush=True)
print('cover curve check',s.cancel(-h*Y**2-4*(X**3-11))==0,flush=True)
# rational field coefficients are pairs (a,b) representing a+y*b.
def add(a,b):return (s.cancel(a[0]+b[0]),s.cancel(a[1]+b[1]))
def neg(a):return(-a[0],-a[1])
def mul(a,b):return(s.cancel(a[0]*b[0]+4*d*a[1]*b[1]),s.cancel(a[0]*b[1]+a[1]*b[0]))
def scale(a,c):return(s.cancel(a[0]*c),s.cancel(a[1]*c))
def D(a):return(s.cancel(4*d*s.diff(a[1],x)+6*x*x*a[1]),s.cancel(s.diff(a[0],x)))
zero=(s.S.Zero,s.S.Zero);one=(s.S.One,s.S.Zero)
def trim(a):
 while a and a[-1]==zero:a.pop()
 return a

def opadd(a,b):return trim([add(a[i] if i<len(a) else zero,b[i] if i<len(b) else zero) for i in range(max(len(a),len(b)))])
def opneg(a):return [neg(c) for c in a]
def opmul(a,b):
 if not a or not b:return []
 out=[zero]*(len(a)+len(b)-1)
 for j,bj in enumerate(b):
  deriv=bj
  for k in range(len(a)):
   for i in range(k,len(a)):
    out[i+j-k]=add(out[i+j-k],scale(mul(a[i],deriv),s.binomial(i,k)))
   deriv=D(deriv)
 return trim(out)
def adjoint(a):
 out=[]
 for j,c in enumerate(a):
  out=opadd(out,opmul([zero]*j+[(s.Integer((-1)**j),s.S.Zero)],[c]))
 return out
L=[(u,s.S.Zero),zero,(-s.S.One,s.S.Zero)]
powers=[[one]]
for k in range(1,12):
 powers.append(opmul(powers[-1],L))
 print('L power',k,flush=True)
 # do not need L beyond5 until spectral check
 if k==5:break
A=[]
for j in range(6):
 fj=s.Poly(F,E).coeff_monomial(E**(5-j))
 term=[scale(D((fj,s.S.Zero)),s.Rational(1,2)),(-fj,s.S.Zero)]
 A=opadd(A,opmul(term,powers[5-j]))
 print('A contribution',j,flush=True)
print('A order',len(A)-1,'leading',A[-1],flush=True)
print('commutator',opadd(opmul(A,L),opneg(opmul(L,A)))==[],flush=True)
print('adjoint',opadd(A,adjoint(A))==[],flush=True)
# right division by L
R=A.copy();Q=[zero]*(len(A)-2)
while len(R)>=3:
 i=len(R)-3;c=neg(R[-1]);Q[i]=add(Q[i],c)
 R=opadd(R,opneg(opmul([zero]*i+[c],L)))
print('Q/R orders',len(Q)-1,len(R)-1,flush=True)
print('division',opadd(opadd(opmul(Q,L),R),opneg(A))==[],flush=True)
# P identity use commuting Hermite identity and explicit operator check
A2=opmul(A,A); print('A square done',flush=True)
Peval=[]
poly=s.Poly(P,E)
for k in range(poly.degree()+1):
 while k>=len(powers):powers.append(opmul(powers[-1],L))
 c=poly.coeff_monomial(E**k)
 if c:Peval=opadd(Peval,[scale(ai,c) for ai in powers[k]])
 print('P eval',k,flush=True)
print('spectral operator identity',opadd(A2,Peval)==[],flush=True)
# rational encoder

def enc(v,var):
 v=s.cancel(v);num,den=s.fraction(v)
 np=s.Poly(num,var,domain=s.QQ);dp=s.Poly(den,var,domain=s.QQ)
 denom=s.ilcm(*[c.q for c in np.all_coeffs()+dp.all_coeffs()])
 def arr(p):return [int(p.nth(i)*denom) for i in range(p.degree()+1)] if not p.is_zero else []
 return {'num':arr(np),'den':arr(dp)}
def coeff(c):return {'a':enc(c[0],x),'b':enc(c[1],x)}
def op(a):return [coeff(c) for c in a]
rho=s.Poly(r,E).monic().as_expr()
answer={'operator':op(A),'spectral_polynomial':enc(P,E),'square_factor':enc(E,E),'normalized_polynomial':enc(h,E),'genus':4,'quotient':op(Q),'remainder':op(R),'cover':{'x':enc(X,E),'y_multiplier':enc(Y,E),'degree':18,'pullback':enc(r,E),'ramification_polynomial':enc(rho,E),'infinity_ramification_order':0}}
with open('/app/output/centralizer.json','w') as out:json.dump(answer,out,separators=(',',':'))
pickle.dump((A,Q,R,r,rho),open('/app/operators.pkl','wb'))
print('all done',flush=True)
