# Independent exact solution

Only `/instruction.md`, `/app/data/README.md`, and `/app/data/operator.json` were read as task inputs. All calculations and scripts are in this container. The final artifact is `/app/output/centralizer.json`.

## Reproduction

The scripts, in order, are:

1. `python /app/derive.py`: derive the stationary recursion and spectral polynomial; writes `/app/spectral.pkl`.
2. `python /app/cover.py`: compute the specified group sum by polynomial divisor reduction; writes `/app/cover.pkl` and intermediate `/app/cover_step0.pkl` through `/app/cover_step4.pkl`.
3. `python /app/build.py`: expand and check the differential operators, compute/check the covering differential and equation, and serialize the answer; writes `/app/operators.pkl` and the final JSON.

SymPy is used for exact rational arithmetic. I installed `python-flint` to accelerate its polynomial arithmetic. The first pip attempt met a container certificate-chain error; explicitly trusting the public PyPI download hosts allowed installing the package. No mathematical solution or task-specific hint was obtained online. An initial version of `cover.py` accidentally turned a `Poly` into an expression by scalar division; wrapping the result back into `Poly` fixed that ordinary API error.

## Stationary recursion, operator, and global minimality

Put `d=x^3-11` and `u=30*x+198*x/d`. Starting with `f_0=1`, the rational recursion is

`d_x f_(j+1) = u*d_x f_j + (d_x u)*f_j/2 - (4*d*d_x^3 f_j + 18*x^2*d_x^2 f_j + 12*x*d_x f_j)/4`.

Here integration constants were set to zero. The resulting primitives are

- `f_1 = 3*x*(5*x^3-22)/d`,
- `f_2 = 63*x^2*(5*x^3+11)/d`,
- `f_3 = 1575*(4*x^6-44*x^3+1089)/d`,
- `f_4 = 33075*x*(3*x^6+55*x^3+484)/d`,
- `f_5 = 99225*x^2*(9*x^6+946*x^3+5566)/d`,
- `f_6 = 397782*f_3`.

Thus the stationary polynomial is

`F = E^5 + f_1*E^4 + f_2*E^3 + (f_3-397782)*E^2 + (f_4-397782*f_1)*E + (f_5-397782*f_2)`.

Write its coefficients as `F=sum(g_j E^(5-j),j=0..5)`. The submitted monic order-11 operator is

`A = -sum((g_j*D - D(g_j)/2)*L^(5-j),j=0..5)`.

This formula also fixes the sign in the task: the right remainder modulo `L-E` is `-F*D + D(F)/2`.

Minimality is over the entire field, not a rational ansatz. The constants of the differential function field are Q. Any commuting odd-order operator has a nonzero skew-adjoint part of the same odd order; its leading coefficient is constant. Comparing powers of D in its commutator with L gives precisely the above recursion with arbitrary integration constants. For any order `2*m+1<11`, closure would require a constant linear combination of `d_x f_1,...,d_x f_(m+1)` whose coefficient on the last term is nonzero to vanish. At the elliptic point at infinity these functions have distinct pole orders, because

`f_1~15*x`, `f_2~315*x^2`, `f_3~6300*x^3`, `f_4~99225*x^4`, `f_5~893025*x^5`.

Their derivatives therefore have distinct pole orders as well. Such a relation is impossible, establishing global minimality.

The exact first-integral identity is

`P = (E-u)*F^2 + F*D^2(F)/2 - D(F)^2/4`

`  = E^2*(E^3-551232)*(E^6-553014*E^3+816903549)`.

Consequently `q=E` and `h=(E^3-551232)*(E^6-553014*E^3+816903549)`. This degree-9 polynomial is squarefree, so the normalization has genus 4. The operator division is ordinary right division by `q(L)=L`, performed in the noncommutative ring by cancelling its highest coefficient at every step. Its remainder is `D(F(0))/2-F(0)*D`, nonzero, and its quotient has order 9. In particular the square factor does not yield an order-9 commuting differential operator by naive division.

## The specified group sum

The cover calculation derives the actual sum of the points in the instruction. It does not search for an arbitrary elliptic subcover.

Set `z=x/E`, `t=11/E^3`, and `p=P/E^11=(1-50112*t)*(1-50274*t+6751269*t^2)`. Then `N=d*F=E^8*n(z,t)`, with `n` printed by `cover.py`. On the rescaled elliptic curve write `eta^2=z^3-t`. Introduce a formal scalar `c` with `c^2=-p`. The given points have `eta=c*k(z)` with

`k = -(z^3-t)/(partial_z n) modulo n`.

This follows directly from `y=-2*V*d/N_x` after putting `eta=y/(2*E^(3/2))` and `c=V/E^(11/2)`; the square-root notation is only a scaling device and disappears from the result. The code performs all arithmetic over Q(t) and only uses `c^2=-p`.

The starting monic polynomial is `U=n/893025`. Its derivative must be multiplied by 893025 to recover `partial_z n`; the code includes that factor. The congruence `-p*k^2 = z^3-t modulo U` is checked exactly.

At each step let

`U_new = monic((-p*k^2-(z^3-t))/U)`, `k_new = -k modulo U_new`.

The divisor of `eta-c*k` shows that the new points before reflection sum to minus the old points; the reflection in `k_new` preserves the sum. Thus this is an exact group-law computation of the required divisor. The degree sequence is `8,6,4,2,1`. All polynomial divisions have zero remainder. At the last step `U=z-Xhat(t)` and `k=Khat(t)`. Converting back gives

`X(E)=E*Xhat(11/E^3)`, `Y(E)=2*Khat(11/E^3)/E^3`,

so the required coordinates are `(X,W*Y)` with precisely the prescribed sign. The complete rational expressions are in the JSON and in `/app/cover.pkl`; `cover.py` prints them factored.

The reduced rational function X has numerator degree 18 and denominator degree 17, with no common factor. Since the E-coordinate and the elliptic x-coordinate both have degree 2, this proves that the covering has degree 18.

## Ramification and checks

Exact simplification gives

`-h*Y^2 = 4*(X^3-11)` and `r=X'/Y=9*(E^3-120582)`.

Thus the finite ramification polynomial is `rho=E^3-120582`. It is squarefree and coprime to h; each of its three roots has two preimages on the spectral curve, each with ramification order 1. At the unique point above infinity, `dE/W` has order `2*g-2=6` and r has pole order 6, so the infinity ramification order is zero. The complete ramification degree is 6, in agreement with Riemann-Hurwitz for a genus-4 curve covering a genus-1 curve.

`build.py` independently expands operators with the full Ore multiplication law and checks exact zero for `[A,L]`, `A+A*`, `A-Q*L-R`, and `A^2+P(L)`. It also verifies the elliptic covering equation and the exact pullback formula. Additional serialization and squarefreeness checks are in `/app/check.py`.
