import sympy as s, json, math, pickle, time
from pathlib import Path
from functools import lru_cache
x,E=s.symbols('x E'); k=s.QQ.frac_field(x); xx=k.gens[0]; dz=xx**3-11
zero=(k.zero,k.zero); one=(k.one,k.zero)
def cf(a=0,b=0): return (k.from_sympy(s.sympify(a)),k.from_sympy(s.sympify(b)))
def ca(a,b): return (a[0]+b[0],a[1]+b[1])
def cn(a): return (-a[0],-a[1])
def cm(a,b): return (a[0]*b[0]+4*dz*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def cs(a,n): return (a[0]*n,a[1]*n)
@lru_cache(None)
def deriv(a): return (4*dz*a[1].diff(xx)+6*xx**2*a[1],a[0].diff(xx))
@lru_cache(None)
def dj(a,n): return a if n==0 else deriv(dj(a,n-1))
def trim(a):
    while a and a[-1]==zero: a.pop()
    return a
def oa(a,b):
    c=list(a)+[zero]*max(0,len(b)-len(a))
    for i,z in enumerate(b): c[i]=ca(c[i],z)
    return trim(c)
def on(a): return [cn(z) for z in a]
def om(a,b):
    if not a or not b:return []
    c=[zero]*(len(a)+len(b)-1)
    for i,z in enumerate(a):
        if z==zero:continue
        for j,w in enumerate(b):
            if w==zero:continue
            for t in range(i+1):
                c[i+j-t]=ca(c[i+j-t],cs(cm(z,dj(w,t)),math.comb(i,t)))
    return trim(c)
def adj(a):
    c=[zero]*len(a)
    for i,z in enumerate(a):
        for t in range(i+1):c[i-t]=ca(c[i-t],cs(dj(z,t),(-1)**i*math.comb(i,t)))
    return trim(c)
def divide(a,b):
    r=a.copy(); q=[zero]*max(0,len(a)-len(b)+1)
    lead=b[-1]; inv=(lead[0]/(lead[0]**2-4*dz*lead[1]**2),-lead[1]/(lead[0]**2-4*dz*lead[1]**2))
    while len(r)>=len(b):
        j=len(r)-len(b); z=cm(r[-1],inv); q[j]=ca(q[j],z)
        r=oa(r,on(om([zero]*j+[z],b)))
    return trim(q),r

t=time.time()
def log(*args): print(round(time.time()-t,2),*args,flush=True)
d=x**3-11; u=30*x+198*x/d
N=-11*E**2*(E**3-553707)-66*E*(E**3-640332)*x+693*(E**3+399168)*x*x+E**2*(E**3-467082)*x**3+15*E*(E**3-276507)*x**4+315*(E**3-99792)*x**5+6300*E**2*x**6+99225*E*x**7+893025*x**8
F=N/d; Fs=s.Poly(F,E)
P=E**2*(E**3-551232)*(E**6-553014*E**3+816903549); h=s.cancel(P/E**2)
assert s.cancel(4*d*s.diff(F,x,3)+18*x*x*s.diff(F,x,2)+(12*x-4*u+4*E)*s.diff(F,x)-2*s.diff(u,x)*F)==0
assert s.cancel((E-u)*F**2+F*(4*d*s.diff(F,x,2)+6*x*x*s.diff(F,x))/2-d*s.diff(F,x)**2-P)==0
assert s.gcd(h,s.diff(h,E))==1
L=[cf(u),zero,cf(-1)]
powers=[[one]]
for j in range(1,12):powers.append(om(powers[-1],L))
log('L powers')
A=[]
for j in range(6):
    f=cf(Fs.nth(j))
    A=oa(A,om([cs(deriv(f),s.Rational(1,2)),cn(f)],powers[j]))
assert len(A)==12 and A[-1]==one
log('A constructed',len(A)-1)
assert oa(om(A,L),on(om(L,A)))==[]
log('commutator zero')
assert oa(adj(A),A)==[]
log('skew adjoint')
PL=[]
for j in range(12): PL=oa(PL,[cs(z,s.Poly(P,E).nth(j)) for z in powers[j]])
assert oa(om(A,A),PL)==[]
log('A square + P(L) zero')
Q,R=divide(A,L)
assert len(R)<3 and oa(om(Q,L),R)==A
log('division',len(Q)-1,len(R)-1)
print('R=',[(k.to_sympy(a),k.to_sympy(b)) for a,b in R],flush=True)
# Independent reduction of A modulo L-E over the field Q(E,x) is
# immediate from construction: -(F D - DF/2).
with open('/app/cover_result.pkl','rb') as f: X,Ym,r,stages=pickle.load(f)
assert s.cancel(-h*Ym**2-4*(X**3-11))==0
assert s.cancel(s.diff(X,E)-r*Ym)==0
rho=E**3-120582
assert s.gcd(h,rho)==1
# x(alpha) has rational-map degree 18. Since both vertical projections
# are double covers, alpha also has degree 18.
Xnum,Xden=s.fraction(s.cancel(X)); coverdeg=max(s.degree(Xnum,E),s.degree(Xden,E)); assert coverdeg==18
assert s.degree(h,E)==9 and s.degree(r,E)==3

def rf(f,var):
    n,den=s.fraction(s.cancel(f)); np=s.Poly(n,var,domain=s.QQ); dp=s.Poly(den,var,domain=s.QQ)
    lc=s.ilcm(*[int(z.q) for z in np.all_coeffs()+dp.all_coeffs()])
    def coeffs(p):
        return [int(p.nth(i)*lc) for i in range(p.degree()+1)] if not p.is_zero else []
    return {'num':coeffs(np),'den':coeffs(dp)}
def fieldjson(z): return {'a':rf(k.to_sympy(z[0]),x),'b':rf(k.to_sympy(z[1]),x)}
out={'operator':[fieldjson(z) for z in A], 'spectral_polynomial':rf(P,E), 'square_factor':rf(E,E),'normalized_polynomial':rf(h,E),'genus':4,'quotient':[fieldjson(z) for z in Q],'remainder':[fieldjson(z) for z in R], 'cover':{'x':rf(X,E),'y_multiplier':rf(Ym,E),'degree':18,'pullback':rf(r,E),'ramification_polynomial':rf(rho,E),'infinity_ramification_order':0}}
Path('/app/output').mkdir(exist_ok=True)
Path('/app/output/centralizer.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
with open('/app/operator_result.pkl','wb') as f:pickle.dump(([[tuple(k.to_sympy(v) for v in z) for z in op] for op in (A,Q,R)],F,P,h),f)
log('wrote submission',Path('/app/output/centralizer.json').stat().st_size,'bytes')
