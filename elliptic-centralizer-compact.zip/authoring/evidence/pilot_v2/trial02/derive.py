import sympy as s
from pathlib import Path
x,E=s.symbols('x E'); d=x**3-11; u=30*x+198*x/d
cs=s.symbols('c0:9'); N=sum(cs[i]*x**i for i in range(9)); F=N/d
expr=s.cancel(4*d*s.diff(F,x,3)+18*x*x*s.diff(F,x,2)+(12*x-4*u+4*E)*s.diff(F,x)-2*s.diff(u,x)*F)
M,z=s.linear_eq_to_matrix(s.Poly(expr.as_numer_denom()[0],x).all_coeffs(),cs)
ns=M.nullspace(); assert len(ns)==1
N=s.cancel(893025*sum(ns[0][i]*x**i for i in range(9))); F=s.cancel(N/d)
assert s.Poly(F,E).degree()==5 and s.Poly(F,E).LC()==1
assert s.Poly(N,x).nth(8)==893025
assert s.gcd_list(s.Poly(N,x).all_coeffs())==1
print('Even ansatz matrix dimensions:',M.shape)
print('Kernel dimension:',len(ns),'energy degree:',s.degree(F,E))
print('N=',s.factor(N))
Path('/app/derived_F.txt').write_text(str(F)+'\n')
