import sympy as s, time, pickle
from pathlib import Path
x,E=s.symbols('x E'); d=x**3-11
N=-11*E**2*(E**3-553707)-66*E*(E**3-640332)*x+693*(E**3+399168)*x*x+E**2*(E**3-467082)*x**3+15*E*(E**3-276507)*x**4+315*(E**3-99792)*x**5+6300*E**2*x**6+99225*E*x**7+893025*x**8
P=E**2*(E**3-551232)*(E**6-553014*E**3+816903549)
K=s.QQ.frac_field(E)
t=time.time()
def log(*args): print(round(time.time()-t,2),*args,flush=True)
u=s.Poly(N,x,domain=K).monic(); dp=s.Poly(d,x,domain=K)
log('inverting derivative')
b=s.rem(-dp*s.invert(s.Poly(s.diff(N,x),x,domain=K),u),u)
log('initial b', b.degree())
stages=[(u,b)]
while u.degree()>1:
    log('degree',u.degree(),'compute quotient')
    nu,rem=(dp+b*b*P).div(u)
    assert rem.is_zero
    log('quotient',nu.degree(),'monic')
    nu=nu.monic()
    nb=(-b).rem(nu)
    u,b=nu,nb
    log('reduced',u.degree(),'bdeg',b.degree())
    stages.append((u,b))
X=s.factor(-u.nth(0)); Ym=s.factor(2*E*b.nth(0))
log('X',X); log('Y',Ym)
r=s.factor(s.diff(X,E)/Ym)
log('r',r)
assert s.cancel(-P/E**2*Ym**2-4*(X**3-11))==0
log('curve identity verified')
with open('/app/cover_result.pkl','wb') as f: pickle.dump((X,Ym,r,stages),f)
Path('/app/cover_result.txt').write_text('X='+str(X)+'\nY='+str(Ym)+'\nr='+str(r)+'\n')
