# Independent solution attempt

Work is confined to kepler-v2-02. Input read: /instruction.md and /app/data/README.md.

## Squared eigenfunction
Let d=x^3-11 and u=30x+198x/d. For F rational in x the squared-eigenfunction equation is
4d F_xxx+18x^2 F_xx+(12x-4u+4E)F_x-2u_x F=0.
At the four potential poles the local coefficients are 5*6 and 1*2 respectively. Local indicial exponents for the third-order equation are -2n,1,2n+2. Consequently any elliptic rational solution can have poles at most order 10 at infinity and order 2 at the three finite half-period points, and no poles elsewhere. The even part has form N(x)/d with degree N<=8; the odd part is y times a rational function and must be considered in the global minimality argument below.
Solving the even ansatz over Q(E) gives a one-dimensional kernel. Scaling it to be monic in E produces F of degree 5.

The constant-in-x first integral P=(E-u)F^2+(1/2)F D^2 F-(1/4)(DF)^2 factors as
P=E^2*(E^3-551232)*(E^6-553014*E^3+816903549).
Hence q=E, h=(E^3-551232)*(E^6-553014*E^3+816903549), and genus=4.

## Working calculations and errors
An initial docker exec invocation omitted -i, so its heredoc did not reach Python and produced no result. Retried with -i; subsequent algebra was exact SymPy.

## Global minimality over the full field
Every formally skew odd commuting operator B of order 2m+1 has a right remainder modulo L-E of the form a(E,x,y)D-(1/2)D(a), where a is a polynomial in E of degree m with nonzero constant leading coefficient, and a satisfies the squared-eigenfunction equation. This follows by equating the two coefficients in the commutator with L modulo L-E (the scalar integration term is excluded by skew-adjointness). The same conclusion about the D coefficient follows without using the scalar remainder.

At an ordinary point a rational solution of that third-order equation cannot have a pole. At a potential pole with coefficient n(n+1)/t^2 the indicial polynomial is (r-1)(r+2n)(r-2n-2), so its only negative exponent is -2n. The potential has n=5 at the origin of the elliptic group and n=1 at each of its three nonzero two-torsion points. Splitting a into even and odd parts under (x,y)->(x,-y), both separately satisfy the equation. An odd elliptic function has an odd local Laurent expansion around every two-torsion point, so it cannot have the permitted even negative exponent. It is consequently holomorphic everywhere and zero. Every solution therefore lies in the even ansatz N/d with deg_x N<=8.

The kernel over Q(E) of this ansatz is one-dimensional and its primitive generator F has E-degree 5. The coefficient of x^8 in dF is the nonzero constant 893025, so a rational multiplier c(E) producing a polynomial in E must itself be polynomial. Thus m>=5. The constructed A has order 11 and is globally minimal. For an arbitrary odd commuting operator, its skew part (B-B*)/2 retains its odd leading term and commutes with L, so the result also excludes all lower odd orders without a skew assumption.

## Covering by the specified group sum
Use elliptic coordinate z=y/2, for which z^2=d. Let u=N/893025 be monic in x. At each root of N, the given point has z=-V*d/N_x. In Q(E)[x]/(u), compute b=-d*(N_x)^(-1), so the points have z=V*b. With V^2=-P, the polynomial d+P*b^2 is divisible by u. The elliptic divisor reduction step is
  u_new=monic((d+P*b^2)/u), b_new=(-b) mod u_new.
The graph z=V*b has principal intersection divisor, and reflection changes the sign of the group sum. Thus this reduction preserves the elliptic group sum, including its sign. Four steps reduce degrees 8->6->4->2->1. The final u=x-X and z=V*b give alpha=(X, W*Y) with Y=2E*b. All divisions are exact over Q(E). This is a function-field proof that the map is the required sum, rather than merely a map satisfying an elliptic equation. See /app/cover.py and its saved /app/cover_result.pkl.

The exact resulting fractions are in /app/cover_result.txt and the submitted JSON. The identity -h*Y^2=4*(X^3-11) holds, and X'/Y=9*(E^3-120582). The reduced numerator and denominator of X have degrees 18 and 17, hence the covering has degree 18 (both curve projections to their respective x coordinates have degree two).

## Complete ramification
The normalized polynomial h is squarefree of degree 9, so genus=4 and the unique infinity has ord_infinity(dE/W)=6. At finite branch points, dE/W is a nonzero regular differential; it is also nonzero regular at all other finite points. Thus finite ramification is precisely the zero divisor of E^3-120582. This polynomial is coprime to h and squarefree, giving six distinct geometric points, each of order one. At infinity the factor E^3 has pole order six, canceling the order six of dE/W. Infinity ramification order is zero. The total 6 equals 2g-2, independently agreeing with Riemann-Hurwitz for a map to an elliptic curve.

## Exact operator construction and checks
Write F=sum_j f_j E^j. Construct A=-sum_j (f_j D-(1/2)D(f_j))*L^j. The minus sign makes A monic of order 11 and its D coefficient modulo L-E equals -F. /app/solve.py implements exact coefficient-field arithmetic as pairs (a,b) representing a+y*b, exact differential-operator multiplication, formal adjoint, and right division. It verifies [A,L]=0, A*=-A, A^2+P(L)=0, A=Q*L+R, and ord R=1. In particular q=E does not divide A on the right. The remainder is also the j=0 summand, which is nonzero because f_0=35721*x**2*(5*x**3 - 88)**2/(x**3 - 11).

The operator script initially failed only when trying to pickle internal SymPy domain elements after it had already written the valid JSON; it was changed to pickle ordinary symbolic expressions and rerun.

## Reproduction
Commands inside this container:
  PYTHONPATH=/app/pydeps python /app/cover.py
  PYTHONPATH=/app/pydeps python /app/solve.py
The optional python-flint accelerator is installed solely under /app/pydeps. Initial pip download failed on this container's certificate chain; retry with PyPI and files.pythonhosted.org marked trusted succeeded. All mathematical computation is exact rational arithmetic.

Final artifact validated for exact key sets, integer-only fraction coefficients, nonzero denominators, and all size/degree/bit-length limits.

The primitive squared eigenfunction can be rederived from scratch with `PYTHONPATH=/app/pydeps python /app/derive.py`. It confirms the 11-by-9 ansatz matrix has a one-dimensional kernel and the normalized primitive solution has degree 5 in E.
