"""Exact, independent verifier for the elliptic centralizer task.

This module reads inert JSON only.  It uses FLINT rational polynomials, not the
reference implementation or its symbolic algebra package.  MIN_ORDER is the
independently proved minimum in authoring/evidence/minimality_proof.md; acceptance of
the actual operator, curve, factorization and division uses exact identities.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

from flint import fmpq, fmpq_poly

MIN_ORDER = 11
MAX_BYTES = 2 * 1024 * 1024
MAX_RAW_POLY = 129
MAX_INT_BITS = 2048
MAX_OPERATOR = 33


class VerificationError(ValueError):
    """A submitted artifact violates the published mathematical contract."""


def require(condition, message):
    if not condition:
        raise VerificationError(message)


class RF:
    """Canonical element of Q(x), represented by FLINT rational polynomials."""

    __slots__ = ("n", "d", "_derivative")

    def __init__(self, n=0, d=1):
        n = n if isinstance(n, fmpq_poly) else fmpq_poly(n if isinstance(n, list) else [n])
        d = d if isinstance(d, fmpq_poly) else fmpq_poly(d if isinstance(d, list) else [d])
        if not d:
            raise ZeroDivisionError("zero rational-function denominator")
        if not n:
            self.n, self.d = fmpq_poly([]), fmpq_poly([1])
        else:
            g = n.gcd(d)
            n, rn = divmod(n, g)
            d, rd = divmod(d, g)
            if rn or rd:
                raise ArithmeticError("nonexact polynomial gcd division")
            leading = d.leading_coefficient()
            self.n, self.d = n / leading, d / leading
        self._derivative = None

    def __bool__(self):
        return bool(self.n)

    def __eq__(self, other):
        other = as_rf(other)
        return self.n == other.n and self.d == other.d

    def __neg__(self):
        return RF(-self.n, self.d)

    def __add__(self, other):
        other = as_rf(other)
        if not self:
            return other
        if not other:
            return self
        if self.d == other.d:
            return RF(self.n + other.n, self.d)
        return RF(self.n * other.d + other.n * self.d, self.d * other.d)

    __radd__ = __add__

    def __sub__(self, other):
        return self + (-as_rf(other))

    def __rsub__(self, other):
        return as_rf(other) - self

    def __mul__(self, other):
        other = as_rf(other)
        if not self or not other:
            return ZERO_RF
        return RF(self.n * other.n, self.d * other.d)

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = as_rf(other)
        if not other:
            raise ZeroDivisionError("zero rational function")
        return RF(self.n * other.d, self.d * other.n)

    def derivative(self):
        if self._derivative is None:
            self._derivative = RF(self.n.derivative() * self.d - self.n * self.d.derivative(), self.d * self.d)
        return self._derivative

    def polynomial(self, where):
        require(self.d.degree() == 0, f"{where} must reduce to a polynomial")
        return self.n / self.d[0]


def as_rf(value):
    return value if isinstance(value, RF) else RF(value)


ZERO_RF = RF(0)
ONE_RF = RF(1)
S = RF([-44, 0, 0, 4])
HALF_S_PRIME = RF([0, 0, 6])


class K:
    """Canonical a(x)+y b(x), with y^2=4(x^3-11)."""

    __slots__ = ("a", "b", "_derivative")

    def __init__(self, a=0, b=0):
        self.a, self.b = as_rf(a), as_rf(b)
        self._derivative = None

    def __bool__(self):
        return bool(self.a) or bool(self.b)

    def __eq__(self, other):
        other = as_k(other)
        return self.a == other.a and self.b == other.b

    def __neg__(self):
        return K(-self.a, -self.b)

    def __add__(self, other):
        other = as_k(other)
        return K(self.a + other.a, self.b + other.b)

    __radd__ = __add__

    def __sub__(self, other):
        return self + (-as_k(other))

    def __rsub__(self, other):
        return as_k(other) - self

    def __mul__(self, other):
        other = as_k(other)
        return K(self.a * other.a + S * self.b * other.b,
                 self.a * other.b + self.b * other.a)

    __rmul__ = __mul__

    def derivative(self):
        if self._derivative is None:
            self._derivative = K(HALF_S_PRIME * self.b + S * self.b.derivative(), self.a.derivative())
        return self._derivative


def as_k(value):
    return value if isinstance(value, K) else K(value)


ZERO = K()
ONE = K(1)
U = K(RF([0, -132, 0, 0, 30], [-11, 0, 0, 1]))
L = [U, ZERO, K(-1)]


def trim(operator):
    operator = list(operator)
    while operator and not operator[-1]:
        operator.pop()
    return operator


def add(left, right):
    result = [ZERO] * max(len(left), len(right))
    for i, value in enumerate(left):
        result[i] = result[i] + value
    for i, value in enumerate(right):
        result[i] = result[i] + value
    return trim(result)


def scale(operator, scalar):
    return trim([value * scalar for value in operator])


def derivatives(value, count):
    result = [value]
    for _ in range(count):
        result.append(result[-1].derivative())
    return result


def compose(left, right):
    """Product in K[D], coefficients on the left; empty list is zero."""
    if not left or not right:
        return []
    result = [ZERO] * (len(left) + len(right) - 1)
    right_derivatives = [derivatives(value, len(left) - 1) for value in right]
    for i, a in enumerate(left):
        if not a:
            continue
        for j, jet in enumerate(right_derivatives):
            for k in range(i + 1):
                if jet[k]:
                    result[i + j - k] = result[i + j - k] + a * jet[k] * math.comb(i, k)
    return trim(result)


def adjoint(operator):
    result = [ZERO] * len(operator)
    for i, value in enumerate(operator):
        for k, dk in enumerate(derivatives(value, i)):
            result[i - k] = result[i - k] + dk * ((-1 if i % 2 else 1) * math.comb(i, k))
    return trim(result)


def evaluate_polynomial(polynomial, operator=L):
    result = []
    for coefficient in reversed(polynomial.coeffs()):
        result = add(compose(result, operator), [K(coefficient)])
    return trim(result)


def check_commutator(operator):
    """Descending exact coefficients of [A,-D^2+u]; reject early."""
    n = len(operator) - 1
    ujet = derivatives(U, n)
    for power in range(n + 1, -1, -1):
        coefficient = ZERO
        if 0 <= power - 1 <= n:
            coefficient += 2 * operator[power - 1].derivative()
        if power <= n:
            coefficient += operator[power].derivative().derivative()
        for j in range(power + 1, n + 1):
            coefficient += operator[j] * ujet[j - power] * math.comb(j, j - power)
        require(not coefficient, f"operator does not commute with L: nonzero D^{power} coefficient")


def exact_keys(value, expected, where):
    require(type(value) is dict, f"{where} must be a JSON object")
    require(set(value) == set(expected), f"{where} must have exactly the keys {', '.join(expected)}")


def parse_integer(value, where):
    require(type(value) is int, f"{where} must be a JSON integer, not a boolean or float")
    require(value.bit_length() <= MAX_INT_BITS, f"{where} exceeds the {MAX_INT_BITS}-bit integer limit")
    return value


def parse_integer_polynomial(value, where):
    require(type(value) is list, f"{where} must be a coefficient array")
    require(len(value) <= MAX_RAW_POLY, f"{where} exceeds {MAX_RAW_POLY} raw coefficients")
    return fmpq_poly([parse_integer(v, f"{where}[{i}]") for i, v in enumerate(value)])


def parse_rf(value, where):
    exact_keys(value, ("num", "den"), where)
    n = parse_integer_polynomial(value["num"], where + ".num")
    d = parse_integer_polynomial(value["den"], where + ".den")
    require(bool(d), f"{where}.den represents the zero polynomial")
    return RF(n, d)


def parse_coefficient(value, where):
    exact_keys(value, ("a", "b"), where)
    return K(parse_rf(value["a"], where + ".a"), parse_rf(value["b"], where + ".b"))


def parse_operator(value, where):
    require(type(value) is list, f"{where} must be an array of differential coefficients")
    require(len(value) <= MAX_OPERATOR, f"{where} exceeds {MAX_OPERATOR} raw coefficients")
    return trim([parse_coefficient(v, f"{where}[{i}]") for i, v in enumerate(value)])


def right_divide(operator, divisor):
    """Right division by L, whose leading coefficient is -1."""
    quotient, remainder = [], list(operator)
    while len(remainder) >= len(divisor):
        term = [ZERO] * (len(remainder) - len(divisor)) + [-remainder[-1]]
        quotient = add(quotient, term)
        remainder = add(remainder, scale(compose(term, divisor), -1))
    return quotient, remainder


def xp_trim(value):
    value = list(value)
    while value and not value[-1]:
        value.pop()
    return value


def xp_add(left, right):
    result = [ZERO_RF] * max(len(left), len(right))
    for i, value in enumerate(left):
        result[i] = result[i] + value
    for i, value in enumerate(right):
        result[i] = result[i] + value
    return xp_trim(result)


def xp_scale(value, scalar):
    return xp_trim([v * scalar for v in value])


def xp_mul(left, right):
    """Polynomials in x whose coefficients are rational functions in E."""
    if not left or not right:
        return []
    result = [ZERO_RF] * (len(left) + len(right) - 1)
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            result[i + j] = result[i + j] + a * b
    return xp_trim(result)


def xp_divmod(value, divisor):
    quotient, remainder = [], list(value)
    while len(remainder) >= len(divisor):
        term = [ZERO_RF] * (len(remainder) - len(divisor)) + [remainder[-1] / divisor[-1]]
        quotient = xp_add(quotient, term)
        remainder = xp_add(remainder, xp_scale(xp_mul(term, divisor), -1))
    return quotient, remainder


def xp_evaluate(polynomial, value):
    result = ZERO_RF
    for coefficient in reversed(polynomial):
        result = result * value + coefficient
    return result


def squared_eigenfunction_numerator(operator):
    """Derive N=(x^3-11)F from the submitted A, without golden coefficients."""
    d = RF([-11, 0, 0, 1])
    coefficients, current = [], list(operator)
    while current:
        current, remainder = right_divide(current, L)
        require(len(remainder) == 2, "squared-eigenfunction decomposition has invalid remainder order")
        fj = -remainder[1]
        require(not fj.b, "squared-eigenfunction coefficient must be rational in x")
        require(remainder[0] == fj.derivative() * fmpq(1, 2),
                "squared-eigenfunction decomposition has invalid scalar coefficient")
        coefficients.append((d * fj.a).polynomial("(x^3-11) times squared-eigenfunction coefficient"))
    N = [ZERO_RF] * max(p.degree() + 1 for p in coefficients)
    for energy_power, polynomial in enumerate(coefficients):
        for x_power, coefficient in enumerate(polynomial.coeffs()):
            N[x_power] = N[x_power] + RF([0] * energy_power + [coefficient])
    return xp_trim(N)


def check_cover(value, operator, P, q, h, genus):
    exact_keys(value, ("x", "y_multiplier", "degree", "pullback", "ramification_polynomial",
                       "infinity_ramification_order"), "cover")
    X = parse_rf(value["x"], "cover.x")
    multiplier = parse_rf(value["y_multiplier"], "cover.y_multiplier")
    degree = parse_integer(value["degree"], "cover.degree")
    pullback = parse_rf(value["pullback"], "cover.pullback")
    ramification = parse_rf(value["ramification_polynomial"], "cover.ramification_polynomial")
    infinity_order = parse_integer(value["infinity_ramification_order"], "cover.infinity_ramification_order")
    require(degree > 0, "cover.degree must be positive")
    require(infinity_order >= 0, "cover.infinity_ramification_order must be nonnegative")
    actual_degree = max(X.n.degree(), X.d.degree())
    require(actual_degree > 0 and degree == actual_degree, "incorrect covering degree")
    require(bool(multiplier), "cover.y_multiplier must be nonzero")
    require(-RF(h) * multiplier * multiplier == 4 * (X * X * X - 11),
            "cover does not satisfy the target elliptic-curve equation")

    N = squared_eigenfunction_numerator(operator)
    require(len(N) == 9, "squared-eigenfunction numerator must have x-degree eight")
    Nx = [N[i] * i for i in range(1, len(N))]
    d = [RF(-11), ZERO_RF, ZERO_RF, ONE_RF]
    # A coprime specialization, with full degree preserved, certifies the
    # corresponding generic coprimalities over Q(E). No root approximations.
    specialize = lambda coefficient: sum(coefficient.n.coeffs(), fmpq(0)) / sum(coefficient.d.coeffs(), fmpq(0))
    specialized = fmpq_poly([specialize(coefficient) for coefficient in N])
    require(specialized.degree() == 8, "generic-divisor specialization loses degree")
    require(specialized.gcd(specialized.derivative()).degree() == 0,
            "generic-divisor squarefreeness certificate failed")
    require(specialized.gcd(fmpq_poly([-11, 0, 0, 1])).degree() == 0,
            "generic divisor meets a potential pole identically")
    selected_curve = xp_add(xp_scale(xp_mul(d, xp_mul(Nx, Nx)), 4),
                            xp_scale(xp_mul(d, d), 4 * RF(P)))
    require(not xp_divmod(selected_curve, N)[1],
            "selected divisor does not lie on the target elliptic curve")

    witness_path = Path(__file__).with_name("cover_witness.json")
    witness = json.loads(witness_path.read_text())
    a = [parse_rf(v, f"sealed a[{i}]") for i, v in enumerate(witness["a"])]
    b = [parse_rf(v, f"sealed b[{i}]") for i, v in enumerate(witness["b"])]
    require(len(a) <= 5 and len(b) == 4 and bool(b[-1]), "invalid interpolation witness pole order")
    congruence = xp_add(xp_mul(Nx, a), xp_scale(xp_mul(d, b), -2))
    require(not xp_divmod(congruence, N)[1], "interpolation witness does not vanish on the selected divisor")
    norm = xp_add(xp_scale(xp_mul(a, a), -RF(P)), xp_scale(xp_mul(d, xp_mul(b, b)), -4))
    require(len(norm) == 10 and bool(norm[-1]), "invalid interpolation norm degree")
    factor = norm[-1] / N[-1]
    expected_norm = xp_scale(xp_mul(N, [-X, ONE_RF]), factor)
    require(not xp_add(norm, xp_scale(expected_norm, -1)),
            "cover.x is not the Abel-sum x-coordinate (interpolation norm identity fails)")
    aX, bX = xp_evaluate(a, X), xp_evaluate(b, X)
    require(bool(bX), "interpolation sign certificate has zero denominator")
    require(multiplier * bX == RF(q) * aX,
            "cover.y_multiplier has the wrong Abel-sum sign or value")
    require(pullback == X.derivative() / multiplier, "incorrect pullback differential")
    pullback_polynomial = pullback.polynomial("cover.pullback")
    require(bool(pullback_polynomial) and pullback_polynomial.degree() <= genus - 1,
            "pullback is not a nonzero holomorphic differential")
    ramification_polynomial = ramification.polynomial("cover.ramification_polynomial")
    monic_pullback = pullback_polynomial / pullback_polynomial.leading_coefficient()
    require(ramification_polynomial == monic_pullback, "incorrect finite ramification polynomial")
    require(infinity_order == 2 * genus - 2 - 2 * pullback_polynomial.degree(),
            "incorrect ramification order at infinity")
    return {"cover_degree": degree, "pullback_degree": pullback_polynomial.degree(),
            "infinity_ramification_order": infinity_order}


def verify_object(obj):
    """Verify an already decoded JSON object; return compact exact metrics."""
    exact_keys(obj, ("operator", "spectral_polynomial", "square_factor", "normalized_polynomial",
                     "genus", "quotient", "remainder", "cover"), "submission")
    A = parse_operator(obj["operator"], "operator")
    Q = parse_operator(obj["quotient"], "quotient")
    R = parse_operator(obj["remainder"], "remainder")
    P = parse_rf(obj["spectral_polynomial"], "spectral_polynomial").polynomial("spectral_polynomial")
    q = parse_rf(obj["square_factor"], "square_factor").polynomial("square_factor")
    h = parse_rf(obj["normalized_polynomial"], "normalized_polynomial").polynomial("normalized_polynomial")
    genus = parse_integer(obj["genus"], "genus")
    require(genus >= 0, "genus must be nonnegative")
    require(len(A) - 1 == MIN_ORDER, f"minimum nonzero odd operator order is {MIN_ORDER}")
    require(A[-1] == ONE, "operator must be monic")
    require(P.degree() == MIN_ORDER, f"spectral_polynomial must have degree {MIN_ORDER}")
    for name, polynomial in (("spectral_polynomial", P), ("square_factor", q), ("normalized_polynomial", h)):
        require(bool(polynomial) and polynomial.leading_coefficient() == 1, f"{name} must be monic and nonzero")
    require(q * q * h == P, "spectral factorization P = q^2 h is false")
    require(h.gcd(h.derivative()).degree() == 0, "normalized_polynomial is not squarefree")
    require(genus == (h.degree() - 1) // 2, "incorrect genus of the normalized double cover")
    require(bool(R), "right-division remainder must be nonzero for this instance")
    require(len(R) - 1 < 2 * q.degree(), "right-division remainder order is too large")
    require(len(Q) - 1 == MIN_ORDER - 2 * q.degree(), "right-division quotient has incorrect order")
    check_commutator(A)
    require(not add(adjoint(A), A), "operator is not formally skew-adjoint")
    require(not add(compose(A, A), evaluate_polynomial(P)), "spectral identity A^2 + P(L) = 0 is false")
    require(not add(add(compose(Q, evaluate_polynomial(q)), R), scale(A, -1)),
            "right-division identity A = Q q(L) + R is false")
    metrics = {"order": len(A) - 1, "spectral_degree": P.degree(), "square_factor_degree": q.degree(),
               "normalized_degree": h.degree(), "genus": genus, "remainder_order": len(R) - 1}
    metrics.update(check_cover(obj["cover"], A, P, q, h, genus))
    return metrics


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON object key: {key}")
        result[key] = value
    return result


def reject_constant(value):
    raise VerificationError(f"nonfinite JSON number is forbidden: {value}")


def json_integer(text):
    # Bound before int conversion, including Python builds without a digit cap.
    require(len(text.lstrip("-")) <= 617, f"JSON integer exceeds {MAX_INT_BITS} bits")
    return parse_integer(int(text), "JSON integer")


def verify_path(path):
    path = Path(path)
    require(path.is_file(), f"missing submission artifact: {path}")
    require(path.stat().st_size <= MAX_BYTES, f"submission exceeds {MAX_BYTES} bytes")
    try:
        with path.open("rb") as stream:
            raw = stream.read(MAX_BYTES + 1)
        require(len(raw) <= MAX_BYTES, f"submission exceeds {MAX_BYTES} bytes")
        obj = json.loads(raw.decode("utf-8"), object_pairs_hook=no_duplicates,
                         parse_constant=reject_constant, parse_int=json_integer)
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as exc:
        raise VerificationError(f"invalid UTF-8 JSON: {exc}") from exc
    return verify_object(obj)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("path", nargs="?", default="/app/output/centralizer.json")
    args = parser.parse_args()
    try:
        print(json.dumps({"accepted": True, "metrics": verify_path(args.path)}, sort_keys=True))
    except (VerificationError, OSError) as exc:
        print(json.dumps({"accepted": False, "error": str(exc)}, sort_keys=True))
        raise SystemExit(1)
