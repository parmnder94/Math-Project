import sympy as s,pickle,time,json,math
with open("/app/spectral.pkl","rb") as f:x,E,d,u,F,P,q,h=pickle.load(f)
Z=(s.S(0),s.S(0));ONE=(s.S(1),s.S(0))
def k(a=0,b=0):return (s.cancel(a),s.cancel(b))
def add(v,w):return k(v[0]+w[0],v[1]+w[1])
def neg(v):return (-v[0],-v[1])
def mul(v,w):return k(v[0]*w[0]+4*d*v[1]*w[1],v[0]*w[1]+v[1]*w[0])
def scale(v,c):return k(c*v[0],c*v[1])
def D(v):return k(4*d*s.diff(v[1],x)+6*x*x*v[1],s.diff(v[0],x))
def trim(a):
 while a and a[-1]==Z:a.pop()
 return a
def oa(a,b):
 n=max(len(a),len(b));return trim([add(a[i] if i<len(a) else Z,b[i] if i<len(b) else Z) for i in range(n)])
def om(a,b):
 if not a or not b:return []
 r=[Z]*(len(a)+len(b)-1)
 for j,c in enumerate(b):
  ds=[c]
  for n in range(len(a)-1):ds.append(D(ds[-1]))
  for i,ai in enumerate(a):
   if ai==Z:continue
   for z in range(i+1):
    if ds[z]!=Z:r[i+j-z]=add(r[i+j-z],scale(mul(ai,ds[z]),math.comb(i,z)))
 return trim(r)
def os(a,c):return trim([scale(v,c) for v in a])
def opow(a,n):
 r=[ONE]
 for i in range(n):r=om(r,a)
 return r
def ev(poly,l):
 r=[]
 for c in s.Poly(poly,E).all_coeffs():r=oa(om(r,l),[k(c)])
 return r
def adj(a):
 r=[]
 for j,c in enumerate(a):
  r=oa(r,om([Z]*j+[k((-1)**j)],[c]))
 return r
def div(a,b):
 r=a[:];q=[]
 while len(r)>=len(b):
  n=len(r)-len(b)
  assert b[-1][1]==0
  term=[Z]*n+[scale(r[-1],1/b[-1][0])]
  q=oa(q,term)
  r=oa(r,os(om(term,b),-1))
 return q,r
L=[k(u),Z,k(-1)]
fcoef=[s.cancel(s.expand(F).coeff(E,5-j)) for j in range(6)]
assert s.cancel(sum(fcoef[j]*E**(5-j) for j in range(6))-F)==0
A=[]
for j,fj in enumerate(fcoef):
 A=oa(A,os(om([scale(D(k(fj)),-s.Rational(1,2)),k(fj)],opow(L,5-j)),-1))
print("A built",len(A)-1,time.time(),flush=True)
assert A[-1]==ONE
assert oa(adj(A),A)==[]
print("adjoint checked",time.time(),flush=True)
assert oa(om(A,L),os(om(L,A),-1))==[]
print("commutator checked",time.time(),flush=True)
Q,R=div(A,ev(q,L))
assert oa(om(Q,ev(q,L)),R)==A
print("division checked",len(Q)-1,len(R)-1,"R",R,flush=True)
rem=div(A,[k(u-E),Z,k(-1)])[1]
assert rem[1]==k(-F)
assert rem[0]==scale(D(k(F)),s.Rational(1,2))
print("spectral remainder checked",time.time(),flush=True)
assert oa(om(A,A),ev(P,L))==[]
print("spectral operator identity checked",time.time(),flush=True)
with open("/app/operators.pkl","wb") as f:pickle.dump((A,Q,R),f)
