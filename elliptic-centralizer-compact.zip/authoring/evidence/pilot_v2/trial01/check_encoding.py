import sympy as s,pickle,json
with open("/app/output/centralizer.json") as f:o=json.load(f)
with open("/app/spectral.pkl","rb") as f:x,E,d,u,F,P,q,h=pickle.load(f)
with open("/app/operators.pkl","rb") as f:A,Q,R=pickle.load(f)
with open("/app/cover.pkl","rb") as f:X,Y,r=pickle.load(f)
def rf(v,z):
 assert set(v)=={"num","den"}
 return s.cancel(sum(s.Integer(c)*z**i for i,c in enumerate(v["num"]))/sum(s.Integer(c)*z**i for i,c in enumerate(v["den"])))
def decop(v):
 for c in v:assert set(c)=={"a","b"}
 return [(rf(c["a"],x),rf(c["b"],x)) for c in v]
assert set(o)=={"operator","spectral_polynomial","square_factor","normalized_polynomial","genus","quotient","remainder","cover"}
assert set(o["cover"])=={"x","y_multiplier","degree","pullback","ramification_polynomial","infinity_ramification_order"}
for name,a in (("operator",A),("quotient",Q),("remainder",R)):
 b=decop(o[name]);assert len(a)==len(b)
 for v,w in zip(a,b):assert all(s.cancel(vi-wi)==0 for vi,wi in zip(v,w))
for name,a in (("spectral_polynomial",P),("square_factor",q),("normalized_polynomial",h)):
 assert s.cancel(rf(o[name],E)-a)==0
for name,a in (("x",X),("y_multiplier",Y),("pullback",r),("ramification_polynomial",E**3-120582)):
 assert s.cancel(rf(o["cover"][name],E)-a)==0
assert (o["genus"],o["cover"]["degree"],o["cover"]["infinity_ramification_order"])==(4,18,0)
print("Decoded artifact matches all exactly verified mathematical objects.")
