import sympy as s,pickle,json,os
with open("/app/spectral.pkl","rb") as f:x,E,d,u,F,P,q,h=pickle.load(f)
with open("/app/operators.pkl","rb") as f:A,Q,R=pickle.load(f)
with open("/app/cover.pkl","rb") as f:X,Y,r=pickle.load(f)
def rat(a,z):
 n,den=s.fraction(s.cancel(a))
 np,dp=s.Poly(n,z,domain=s.QQ),s.Poly(den,z,domain=s.QQ)
 scale=s.ilcm(*[c.q for c in np.all_coeffs()+dp.all_coeffs()])
 enc=lambda p:[int(c*scale) for c in reversed(p.all_coeffs())] if not p.is_zero else []
 return {"num":enc(np),"den":enc(dp)}
def elem(v):return {"a":rat(v[0],x),"b":rat(v[1],x)}
assert s.degree(h,E)==9 and s.gcd(h,s.diff(h,E))==1
assert s.cancel(r-9*(E**3-120582))==0
rho=E**3-120582
assert s.gcd(rho,h)==1 and s.gcd(rho,s.diff(rho,E))==1
xn,xd=s.fraction(s.cancel(X))
assert max(s.degree(xn,E),s.degree(xd,E))==18
result={"operator":[elem(v) for v in A],"spectral_polynomial":rat(P,E),"square_factor":rat(q,E),"normalized_polynomial":rat(h,E),"genus":4,"quotient":[elem(v) for v in Q],"remainder":[elem(v) for v in R],"cover":{"x":rat(X,E),"y_multiplier":rat(Y,E),"degree":18,"pullback":rat(r,E),"ramification_polynomial":rat(rho,E),"infinity_ramification_order":0}}
os.makedirs("/app/output",exist_ok=True)
path="/app/output/centralizer.json"
with open(path,"w") as f:json.dump(result,f,separators=(",",":"))
assert os.path.getsize(path)<2097152
for key in ("operator","quotient","remainder"):assert len(result[key])<=33
for key in ("spectral_polynomial","square_factor","normalized_polynomial"):
 for coeff in result[key].values():assert len(coeff)<=129
for key in ("x","y_multiplier","pullback","ramification_polynomial"):
 for coeff in result["cover"][key].values():assert len(coeff)<=129
for key in ("operator","quotient","remainder"):
 for v in result[key]:
  for vv in v.values():
   for coeff in vv.values():assert len(coeff)<=129

def checkints(o):
 if isinstance(o,dict):
  for v in o.values():checkints(v)
 elif isinstance(o,list):
  for v in o:checkints(v)
 else:assert type(o) is int and abs(o)<2**2048
checkints(result)
print("Wrote",path,"bytes",os.path.getsize(path))
print("R factors",[(s.factor(v[0]),s.factor(v[1])) for v in R])
