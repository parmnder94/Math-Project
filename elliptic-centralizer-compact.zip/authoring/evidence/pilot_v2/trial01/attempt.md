# Independent exact solution

The required artifact is `/app/output/centralizer.json` (4,525 bytes). All calculations used the public instructions, the public operator, and exact SymPy rational arithmetic inside this container. No reference solution or hidden verifier was used.

## Reproduction

Run, in order:

```sh
python /app/solve.py
python /app/spectral.py
python /app/cover.py
python /app/operators.py
python /app/submit.py
python /app/check_encoding.py
```

The scripts write intermediate pickle files in `/app`, including the four successive group-sum reductions `/app/cover-stage-0.pkl` through `/app/cover-stage-3.pkl`. The longest step is the direct differential-operator square check in `operators.py`.

## Stationary equation, operator, and global minimality

Write `d=x^3-11` and `u=30x+198x/d`. The polynomial in the energy which determines the answer is `F=N/d`, where

```
N = E^5*x^3 - 11*E^5
  + 15*E^4*x^4 - 66*E^4*x
  + 315*E^3*x^5 + 693*E^3*x^2
  + 6300*E^2*x^6 - 467082*E^2*x^3 + 6090777*E^2
  + 99225*E*x^7 - 4147605*E*x^4 + 42261912*E*x
  + 893025*x^8 - 31434480*x^5 + 276623424*x^2.
```

In particular F is monic of degree 5 in E. It satisfies exactly

```
4d F_xxx + 18x^2 F_xx + (12x-4u+4E) F_x - 2u_x F = 0,
```

which is `D^3 F - 4(u-E) D F - 2(Du) F = 0` after dividing by y.

Set `F=sum_{j=0}^5 f_j E^(5-j)`. The submitted operator is

```
A = -sum_{j=0}^5 (f_j D - (D f_j)/2) L^(5-j).
```

It is monic of order 11. `operators.py` implements the exact left-coefficient multiplication rule, and verifies `A*=-A`, `[A,L]=0`, and the right remainder `A mod (L-E) = -F D + (D F)/2`.

The rational ansatz used to find F is complete, not an assumed restriction for minimality. On the elliptic curve the potential has a pole with coefficient 5*6 at infinity, and poles with coefficient 1*2 at the three nontrivial points of order two. In a local parameter t with D=d/dt, the indicial exponents of the stationary third-order equation at a pole with coefficient l(l+1) are `-2l,1,2l+2`. A rational solution therefore has pole order at most 10 at infinity and at most 2 at each of the three other poles. It cannot have a pole at any regular point, since its third derivative would have an unmatched leading pole.

The potential is even under the elliptic involution. The odd part of any rational stationary solution satisfies the same equation. At each of the four possible poles its Laurent exponents are odd, whereas the only negative indicial exponent is even. Thus this odd part has no poles anywhere, is constant, and by oddness is zero. Every rational solution is consequently a function of x in the complete space

```
span(1,x,x^2,x^3,x^4,x^5,1/d,x/d,x^2/d).
```

The symbolic linear system for `N=sum_{i=0}^8 c_i x^i` in `solve.py` has a one-dimensional kernel over Q(E), namely `N/893025` times the free coefficient c8. All c_i are polynomial in E if a stationary solution is polynomial in E. Since the coefficient of x^8 in the displayed N is the nonzero constant 893025, any polynomial-in-E stationary solution is a polynomial-in-E multiple of F. It has degree at least 5.

For any commuting odd operator of order 2m+1, its right remainder modulo L-E has a nonzero D coefficient which is polynomial of degree m in E and satisfies this stationary equation. This follows directly by using commutation on the two-dimensional solution space of L-E: if the remainder is aD+b, the D coefficient of its compatibility equation gives b=-(Da)/2+c(E), and the constant coefficient gives the stationary equation for a. The leading term of a is the nonzero leading coefficient of the operator times (-E)^m. Therefore m>=5. This proves global minimality over the full K, including operators outside a denominator ansatz.

## Spectral identity and differential division

Exact rational simplification gives

```
P = (E-u)F^2 + F D^2(F)/2 - (D F)^2/4
  = E^2 (E^3-551232)(E^6-553014 E^3+816903549).
q = E.
h = E^9 - 1104246 E^6 + 305655916797 E^3 - 450303377122368.
```

The direct noncommutative calculation in `operators.py` verifies `A^2+P(L)=0`. The gcd of h and its derivative is 1, so q^2 is the greatest square divisor and the normalized curve has genus 4.

The submitted quotient and remainder are calculated by exact right division by q(L)=L and checked by reconstruction. The remainder has order one and is nonzero:

```
R = y*35721*x*(5*x^3-88)*(25*x^6-352*x^3+1936)/(2*d^2)
    - 35721*x^2*(5*x^3-88)^2/d * D.
```

The quotient has order 9. This nonzero R is the differential-division obstruction at the double spectral factor E^2.

## Specified elliptic group sum

The computation uses the actual points in the question, with their required sign. Let `N0=N/893025`, which is monic in x, and form

```
t0 = (-2 E d / 893025) * (N0_x)^(-1) mod N0.
```

Then the original points satisfy `y=W t0(x)`, because `V=E W` and `N_x=893025 N0_x`. At every step the pair `(M,t)` represents a divisor of points on `y=W t(x)`. Set

```
Mnew = monic((-h*t^2 - 4d)/M),
tnew = -t mod Mnew.
```

The division is exact; every remainder is asserted to be zero. The zeros of `y-Wt` consist of the old points and the residual points. Its pole divisor is supported at the elliptic identity, so their total group sum is zero. Negating the residual ordinates therefore preserves the specified group sum. The successive degrees are

```
8 -> 6 -> 4 -> 2 -> 1.
```

The final pair gives `X=-M(0)` and the constant multiplier `Y=t`, so this construction proves that the map is the specified group sum, rather than just a map into the elliptic curve.

The exact resulting functions, also stored in the JSON, are

```
X = -(E^18 - 52317738 E^15 + 137541930139845 E^12
      - 130688851922762918400 E^9 + 53454932630448304961617920 E^6
      - 8100189794317793342169727107072 E^3
      + 47783298913570122159712398471069696)
    / (324 E^2 (E^3-551232) (E^6+902286 E^3-836509234176)^2).

Y = -(E^24 + 108867132 E^21 - 850413582239265 E^18
      + 1845872425854496537344 E^15 - 1882424664672226560039813120 E^12
      + 1017497292619159818455595916197888 E^9
      - 282142935388202807657710071937304100864 E^6
      + 30772016361980893082560233592278583439523840 E^3
      + 365450704279711412131618611249798077188398907392)
    / (2916 E^3 (E^3-551232)^2 (E^6+902286 E^3-836509234176)^3).
```

Exact checks give `-h Y^2 = 4(X^3-11)` and

```
X_E/Y = 9(E^3-120582).
```

The reduced X has numerator degree 18 and denominator degree 17, hence degree 18 as a rational map of E-lines. Both hyperelliptic/elliptic x-coordinate projections have degree two, so the covering degree is 18.

The differential dE/W is regular and nonzero at every finite point of the normalized curve, and has a zero of order 6 at its unique infinity. The pullback multiplier r is `9(E^3-120582)`. Its three simple roots are disjoint from the roots of h (both gcd checks pass), and thus give six simple ramification points. At infinity, r has pole order 6, canceling the zero of dE/W. The complete ramification data are therefore

```
rho = E^3-120582,
infinity_ramification_order = 0.
```

The degree of this ramification divisor is 6, also consistent with Riemann-Hurwitz for a genus-4 curve mapping to a genus-1 curve.

## Errors encountered and corrected

1. SymPy division of a Poly by a scalar returned an expression; the cover script was corrected to put the scalar inside the polynomial before multiplication.
2. Structural equality tests for two identically equal but differently factored expressions failed twice. Those checks were replaced with exact rational simplification of the difference. No mathematical identity failed after simplification.
3. One orchestration JavaScript call had a missing parenthesis and did not execute. It was corrected immediately.

All final exact operator, curve, group-reduction, genus, ramification, and encoding checks pass.
