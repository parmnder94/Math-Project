import sympy as s
import pickle
x,E=s.symbols("x E")
d=x**3-11
u=30*x+198*x/d
coeff=s.symbols("c:9")
N=sum(c*x**i for i,c in enumerate(coeff))
F=N/d
ode=s.cancel(4*d*s.diff(F,x,3)+18*x*x*s.diff(F,x,2)+(12*x-4*u+4*E)*s.diff(F,x)-2*s.diff(u,x)*F)
eqs=s.Poly(s.fraction(ode)[0],x).all_coeffs()
print("linear system",len(eqs), flush=True)
sol=s.linsolve(eqs,coeff)
print(sol,flush=True)
Fs=s.cancel(F.subs(dict(zip(coeff,list(sol)[0]))))
print("F initial",s.factor(Fs),flush=True)
open("/app/prelim.txt","w").write(str(Fs))
with open("/app/prelim.pkl","wb") as f:pickle.dump((x,E,d,u,Fs),f)
