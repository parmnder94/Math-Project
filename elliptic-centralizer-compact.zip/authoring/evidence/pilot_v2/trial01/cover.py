import sympy as s,pickle,time
from sympy.polys.domains import QQ
with open("/app/spectral.pkl","rb") as f:x,E,d,u,F,P,q,h=pickle.load(f)
K=QQ.frac_field(E)
poly=lambda f:s.Poly(f,x,domain=K)
N=poly(s.cancel(F*d)).monic()
print("inverse",time.time(),flush=True)
t=poly(-2*E*d/s.Integer(893025))*s.invert(N.diff(),N)
t=t.rem(N)
print("inverse done; start degrees",N.degree(),t.degree(),time.time(),flush=True)
with open("/app/cover-initial.pkl","wb") as f:pickle.dump((N,t,h),f)
curve=poly(4*d)
for it in range(8):
    z=poly(-h)*t*t-curve
    nn,rem=z.div(N)
    assert rem.is_zero
    nn=nn.monic()
    tt=(-t).rem(nn)
    N,t=nn,tt
    print("reduction",it,N.degree(),t.degree(),time.time(),flush=True)
    with open("/app/cover-stage-"+str(it)+".pkl","wb") as f:pickle.dump((N,t,h),f)
    if N.degree()==1:break
X=s.factor(-N.nth(0)/N.nth(1))
Y=s.factor(t.nth(0))
print("X",X,flush=True)
print("Y",Y,flush=True)
assert s.cancel(-h*Y**2-4*(X**3-11))==0
r=s.factor(s.diff(X,E)/Y)
print("r",r,flush=True)
with open("/app/cover.pkl","wb") as f:pickle.dump((X,Y,r),f)
