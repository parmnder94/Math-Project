# Actual mathematical validation

The unchanged mathematical contract was solved in all eight completed local blind trials: **8/8 successes**. The requested 0/8–1/8 success target was not achieved. The two earlier mathematical versions each had four successes in four trials. These are local collaborative trials, not an official controlled model evaluation; the exact inherited model revision and effort settings were unavailable.

The recorded reference and independent outputs pass all defining identities. The two implementations use different differential and divisor algorithms. The validation script runs 68 controls with the intended outcomes: 11 accepts and 57 rejects, plus six arithmetic smoke assertions. The alternate valid certificate at prime 727 is accepted, demonstrating that no particular saved prime or generating points are required.

Previously executed separate offline Docker checks accepted repeated reference solutions and the independent solution, and rejected empty outputs. Successful mathematical verification took approximately 0.2 seconds. Ten actual wrapper fault checks also produced their intended outcomes, including process kill 137, missing/malformed/inconsistent/empty reports, and a passing report paired with a failed process.

The presentation cleanup changes instruction headings and the task identifier, and removes unrelated bundle history. It does not change the input, mathematical requirements, reference solution, or mathematical verifier. The structural and mathematical validations are rerun for this edition; their machine-readable records are retained alongside this file.
