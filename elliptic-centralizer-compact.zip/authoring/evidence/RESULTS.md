# Actual validation and difficulty results

Compact-edition reproduction note: these retained results describe the original validated task. Docker builds now fetch the omitted wheels automatically; `python3 authoring/fetch_dependencies.py` prepares local Python tools. Exact URLs and hashes are preserved. The mathematical code and submitted trial artifacts are unchanged.

**The requested difficulty target was not achieved. All eight final local blind attempts solved the task: 8/8.** The package is mathematically tested and functional, but it is an author-review draft and cannot be represented as fully compliant with the requested 0/8–1/8 band or as having passed the official project gates.

## Local blind attempts

| Version | Mathematical scope | Completed attempts | Successful submissions |
|---|---|---:|---:|
| Pilot 1 | Primitive centralizer, spectral normalization, differential division | 4 | 4 |
| Pilot 2 | Above plus the prescribed elliptic Abel covering and ramification | 4 | 4 |
| Final 3 | Above plus geometric monodromy and a finite-field saturation certificate | 8 | 8 |

Each final attempt started with a fresh conversation context and a separate Docker container containing only the public instruction/data and installed public tools. The solver had a 14400-second budget and finished voluntarily; no short artificial deadline was imposed. Every submitted artifact was graded by the unchanged final verifier after completion. All eight pass all nine deliverables. Instruction SHA-256 is `0f13cf5656bf06ad04013ab952defcbb929d74961bbf0566830bfce5e9343daa` for all eight trials.

`final_probes/summary.json` contains exact scores, hashes, and timing definitions; each trial directory contains its actual artifact, proof notes, and scripts. The pilot artifacts and historical verifiers are preserved separately. Trial 2 used a theory subagent; this is disclosed, not hidden as a single-model benchmark. All probes inherited the session model and effort; their exact revision/settings were unavailable. Tool-access restrictions were instructions to the solvers, not a hostile-access security boundary. Complete platform trajectories and a controlled official model harness were unavailable. These results are actual local collaborative probes, not an official frontier-agent calibration.

The seven-of-eight and eight-of-eight observations exceed both the user's stricter target and the PDF's explicit 0–6/8 band for this local test population. No earlier successes were relabeled as failures, and no infrastructure failure was counted as a mathematical failure.

## Exact correctness and robustness

`validation_results.json` records **68 controls, all with the intended outcome: 11 accepts and 57 rejects**, plus six arithmetic smoke assertions. This count includes repeated reference acceptance, the independent implementation, equivalent rational encodings, a different valid prime, and a fraction whose written denominator vanishes at a certificate point but whose canceled rational function is regular. The latter confirms that the published canonical-function convention is honored. Malformed JSON, algebraically wrong operators, forged curves, wrong orientation, a curve-valid doubled map, bad primes, false points, deficient subgroups, and wrong monodromy orders are rejected for their intended reasons. The slowest local control in the recorded run was under 0.2 seconds.

The independent solver uses a global pole-bounded differential pencil and successive elliptic divisor reductions. The reference uses canonical differential-polynomial recurrences and an elliptic interpolation construction. Neither solver imports the verifier or a saved answer. Their normalized output agrees exactly. Full minimality, covering, ramification, and monodromy arguments accompany machine-readable certificates.

The finite-field certificate is not tied to one saved witness. The reference finds p=229 and two source points; an independent certificate at p=727 with three source points is also accepted and checked by a separate group implementation.

## Actual container runs

`docker-final/` records offline image builds and **two reference runs scoring 1, one independent run scoring 1, and two empty-output runs scoring 0**. Every run produced CTRF, an explicit binary reward, and the expected process status. Successful verification took about **0.19–0.21 seconds**. Only the declared JSON artifact crossed into the separate verifier; its Docker network mode was inspected as `none`.

After pinning the already-tested base-image digest, `docker-pinned/` records another successful image audit, reference run, independent run, and empty-output rejection. All three expected results were reproduced. The public agent networking policy remains `public`; disabling networking additionally for these authoring runs proves the reference has no download dependency.

The final wrapper was additionally hardened so a successful process exit cannot receive reward 1 without a valid, nonempty, entirely passing CTRF report. `wrapper_faults/` records **10/10 actual Docker cases with the intended outcomes**, including normal reference acceptance, normal empty-output rejection, process kill 137, missing/malformed/inconsistent/empty/skipped reports, and a passing report paired with nonzero process status. The mathematical verifier and all eight blind scores are unchanged. Original nonzero pytest status is preserved, and failures have binary reward 0 and a valid failure report.

The wheels and every runtime dependency are pinned and SHA-256 checked against the corresponding PyPI release metadata. The exact Linux x86_64 wheels are shipped. `authoring/setup.sh` successfully recreated the local tools from those wheels without package-index access. The ZIP has a per-file manifest; the separately delivered release-validation report records final archive integrity and fresh-extraction checks.

## Unmet or unavailable gates

- The difficulty target is **failed in local testing**, not pending or assumed passed.
- The actual Harbor oracle attempt ran the solver but errored before grading because the host lacks CONFIG_NFT_FIB_INET, required by Harbor 0.24.0's network-isolation helper. `harbor/` retains the exception, logs, job record, and exact failed kernel probe. There is no successful Harbor oracle/nop grade.
- The actual quality-check command produced no report before a 60-second local infrastructure-probe timeout during environment setup. Provider API credentials were absent. It returned no quality verdict; this was not a task-solver timeout or difficulty failure.
- The submitting expert must personally write/finalize the instruction under the PDF's explicit authorship rule. The supplied author identity was reused as authorized, without inventing expertise in this field.
- Official model calibration, AI screening, global similarity, the unpublished 35-item rubric, and human acceptance have not passed here.

## Difficulty interpretation

The task requires substantive reasoning: global minimality over an entire elliptic function field, a distinction between spectral normalization and differential divisibility, an oriented eight-point Abel sum, complete ramification, and exclusion of every geometric isogeny factor before concluding S18 monodromy. Small exact inputs and subsecond verification keep difficulty out of computational scale. Nevertheless, the local agents consistently recognized and implemented the needed constructions. The empirical evidence does not support calling this an exceptionally low-success task. Further difficulty work must address that design limitation without adding arbitrary workload or compromising the verifier.
