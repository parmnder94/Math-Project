#!/usr/bin/env python3
"""Build a reproducible contents-only ZIP and its complete per-file manifest."""
import argparse
import hashlib
import json
import stat
import zipfile
from pathlib import Path


def build(root, output):
    files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts
                 and '.pytest_cache' not in p.parts and p.suffix!='.pyc')
    if (root/'authoring/compact.json').exists():
        files=[p for p in files if p.relative_to(root).parts[:2] not in [('environment','wheels'),('tests','wheels')]]
    assert not any(p.is_symlink() for p in root.rglob('*'))
    manifest=root/'authoring/MANIFEST.sha256'
    files=[p for p in files if p!=manifest]
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in files))
    files.append(manifest)
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in sorted(files):
            name=p.relative_to(root).as_posix()
            info=zipfile.ZipInfo(name,date_time=(2026,10,9,0,0,0))
            info.create_system=3
            permissions=0o755 if p.stat().st_mode & stat.S_IXUSR else 0o644
            info.external_attr=(stat.S_IFREG | permissions)<<16
            info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,p.read_bytes(),compresslevel=9)
    result={'archive':str(output),'bytes':output.stat().st_size,'files':len(files),
            'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}
    output.with_suffix('.sha256').write_text(result['sha256']+'  '+output.name+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    build(args.root,args.output)
