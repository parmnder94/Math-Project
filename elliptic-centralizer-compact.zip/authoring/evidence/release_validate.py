#!/usr/bin/env python3
"""Validate a real ZIP from a fresh extraction, keeping new logs outside it."""
import argparse
import hashlib
import json
import os
import stat
import subprocess
import sys
import time
import zipfile
from pathlib import Path,PurePosixPath


def verify_manifest(root):
    manifest=root/'authoring/MANIFEST.sha256'
    expected={}
    for line in manifest.read_text().splitlines():
        digest,name=line.split('  ',1)
        assert name not in expected
        expected[name]=digest
    actual={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file() and p!=manifest}
    if (root/'authoring/compact.json').exists():
        for entry in json.loads((root/'authoring/dependencies.json').read_text()):
            name=entry['path']
            if name not in expected and name in actual:
                assert actual.pop(name)==entry['sha256'], 'restored dependency hash mismatch'
    assert expected==actual, 'manifest mismatch'
    return len(expected)


def validate(archive,root,evidence):
    assert not root.exists(), 'fresh extraction directory must not already exist'
    root.mkdir(parents=True)
    evidence.mkdir(parents=True,exist_ok=True)
    report={'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
            'archive_bytes':archive.stat().st_size,'checks':[],'status':'running'}
    def run(name,command):
        started=time.perf_counter()
        environment=dict(os.environ);environment['PYTHONDONTWRITEBYTECODE']='1'
        with (evidence/(name+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=environment)
        entry={'name':name,'exit_status':result.returncode,'seconds':time.perf_counter()-started,'command':command}
        report['checks'].append(entry)
        print(json.dumps(entry),flush=True)
        assert result.returncode==0, name
    try:
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            names=z.namelist()
            assert len(names)==len(set(names))
            for info in z.infolist():
                relative=PurePosixPath(info.filename)
                assert not relative.is_absolute() and '..' not in relative.parts
                assert stat.S_IFMT(info.external_attr>>16)==stat.S_IFREG
                destination=root.joinpath(*relative.parts)
                destination.parent.mkdir(parents=True,exist_ok=True)
                destination.write_bytes(z.read(info))
                destination.chmod((info.external_attr>>16)&0o777)
        report['manifest_files_checked_before']=verify_manifest(root)
        py=sys.executable
        run('static',[py,'-B','authoring/evidence/static_validate.py','--output',str(evidence/'static_results.json')])
        run('reference',[py,'-B','solution/solve.py','--data','environment/data/operator.json','--output',str(evidence/'reference.json')])
        run('independent',[py,'-B','authoring/evidence/independent.py','--data','environment/data/operator.json','--output',str(evidence/'independent.json'),'--certificate',str(evidence/'minimality.json')])
        for flavor in ['reference','independent']:
            run('grade_'+flavor,[py,'-B','tests/check_submission.py',str(evidence/(flavor+'.json'))])
        run('controls',[py,'-B','authoring/evidence/validate.py','--output',str(evidence/'validation_results.json')])
        run('containers',[py,'-B','authoring/evidence/container_validate.py','--evidence',str(evidence/'docker'),'--repetitions','1'])
        report['manifest_files_checked_after']=verify_manifest(root)
        report['all_extracted_files_unchanged']=True
        report['controls']=json.loads((evidence/'validation_results.json').read_text())['cases']
        report['docker_records']=json.loads((evidence/'docker/summary.json').read_text())['records']
        report['final_local_blind_successes']=json.loads((root/'authoring/evidence/calibration_summary.json').read_text())['final_successes']
        report['difficulty_target_met']=False
        report['status']='passed technical release validation; difficulty target not met'
    except BaseException as exc:
        report['status']='failed';report['error']=repr(exc)
        raise
    finally:
        (evidence/'release_validation.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--archive',type=Path,required=True)
    parser.add_argument('--extract-to',type=Path,required=True)
    parser.add_argument('--evidence',type=Path,required=True)
    args=parser.parse_args()
    validate(args.archive.resolve(),args.extract_to.resolve(),args.evidence.resolve())
