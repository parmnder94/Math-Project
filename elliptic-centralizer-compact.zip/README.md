# Elliptic centralizer

Audit an exact elliptic differential operator: recover its minimum odd commuting symmetry, normalize its spectral curve, reconstruct the specified elliptic divisor-sum map, and certify its ramification and geometric monodromy. The complete mathematical contract is in `instruction.md` and `environment/data/README.md`.

## Difficulty

The input is synthetic and exact. `authoring/generate.py` uses seed 20261009 to select the curve scale 11, with fixed elliptic pole strengths (5,1,1,1). No observations or numerical tolerances are involved.

The reasoning joins global minimality over the full elliptic function field, singular spectral normalization, noncommutative right division, an oriented eight-point Abel sum, and geometric monodromy. Normalization does not imply differential divisibility. An incidental elliptic quotient does not determine the prescribed Abel map, and simple ramification alone does not establish the monodromy group.

The mathematical contract was solved in all eight completed local blind trials. The requested 0/8–1/8 difficulty target was not achieved. Those trials preceded the presentation cleanup; their mathematical requirements are unchanged. The twelve-hour expert estimate is an estimate rather than a measured human result.

## Reference solution

`solution/solve.py` derives canonical differential-polynomial densities, finds their first stationary relation, constructs the commuting operator, factors the spectral polynomial, and performs right division. An elliptic interpolation construction recovers the required map with its orientation. Exact finite-field group generation provides the monodromy certificate.

`authoring/evidence/independent.py` instead uses global pole bounds and a rational differential pencil, followed by successive elliptic divisor reductions. Its finite-group calculation uses separate short-Weierstrass arithmetic. It imports neither the reference solver nor the verifier.

The minimum odd order is 11, while the normalized spectral genus is 4. The prescribed map has degree 18 and geometric monodromy S18. Complete arguments and exact certificates are in `authoring/evidence/minimality_proof.md`, `cover_proof.md`, and `monodromy_proof.md`.

## Verification

`tests/check_submission.py` checks exact defining identities with FLINT rational arithmetic. It verifies global minimum order, commutation, adjoint, spectral identity, maximal square factor, genus, right division, the specified Abel sum, complete ramification, and the finite-field monodromy certificate. Equivalent rational encodings and different valid certificate primes are accepted. It reads bounded inert JSON and never runs submitted code.

`tests/test.sh` starts with reward 0. Reward 1 requires a successful pytest process and a valid, nonempty, entirely passing CTRF report. Missing or malformed reports fail closed; nonzero pytest status is preserved. The verifier runs in a separate offline container and installs nothing at runtime.

`authoring/evidence/validate.py` reproduces 68 mathematical, malformed-input, and adversarial controls, including acceptance of removable factors at certificate points. Recorded outcomes and mathematical-contract calibration are in `authoring/evidence/RESULTS.md`.

## Setup and reproduction

The compact ZIP omits dependency wheels. Docker builds obtain exact wheel URLs with SHA-256-checked `ADD` instructions, then install only those local files with hash enforcement and no package-index access. A modern Docker BuildKit supporting `ADD --checksum` is required. Initial image preparation needs internet access; verifier execution remains offline. The tested platform is Linux x86_64 with Python 3.12.

For local tools:

```sh
bash authoring/setup.sh /tmp/elliptic-centralizer-tools
/tmp/elliptic-centralizer-tools/bin/python -B authoring/evidence/static_validate.py
/tmp/elliptic-centralizer-tools/bin/python -B authoring/evidence/validate.py
```

For separate-container reference, independent, and empty-output checks:

```sh
/tmp/elliptic-centralizer-tools/bin/python -B authoring/evidence/container_validate.py
```

The pinned Dockerfiles, requirements, dependency hashes, complete input, reference implementation, and sealed verifier are included. All task-specific mathematical information is contained in the bundle. The authoring directory is not copied into the solver image.
