# Elliptic centralizer, spectral covering, and monodromy

**Compact download:** the nine dependency wheels are omitted from the ZIP. Docker/Harbor builds download their exact recorded URLs automatically using Docker's SHA-256-checked ADD instruction. A modern Docker BuildKit supporting `ADD --checksum` is required. Initial image builds therefore need internet access; package installation uses only those downloaded wheels, and verifier execution remains offline.

For local Python setup, `bash authoring/setup.sh /tmp/elliptic-centralizer-tools` restores the same hash-checked wheels automatically. You may also run `python3 authoring/fetch_dependencies.py` to prepare the local authoring tools. Mathematical files, proofs, and all recorded trial results are unchanged.

**Measured status: all eight final local blind attempts solved the task (8/8). The requested 0/8–1/8 difficulty target was not achieved. This is a tested author-review draft, not a submission-ready claim of full project compliance.**

This task audits an exact symbolic calculation in the research theory of integrable differential equations. The solver receives one rational elliptic Schrödinger operator. It must recover the smallest odd differential symmetry, distinguish its singular spectral curve from its smooth normalization, reconstruct a specific elliptic covering from the joint eigenfunction divisor, and determine its geometric monodromy with an exact arithmetic certificate.

The mathematics, data, solution strategy, and verifier are fundamentally different from the supplied wind-estimation reference. The original reference's folder layout and Harbor interfaces are retained.

## Difficulty

The input is **synthetic and exact**, not measured data. `authoring/provenance/generate.py`, seed **20261009**, selects the nonsingular curve scale 11. The fixed elliptic pole strengths are (5,1,1,1). This is an honest construction from classical integrable-systems mathematics, not a claim that its underlying theorems are new. All task-specific outputs are computed afresh.

A researcher developing or auditing an integrable-systems computer-algebra package would need these certificates to trust an elliptic reduction of a spectral problem. A differential symmetry is an operation that can be applied before or after the original differential operator without changing the result. Its order measures how many derivatives it uses. A spectral curve packages the simultaneous eigenvalues. Its normalization separates branches that meet at singular points. Those operations occur in different mathematical categories: simplifying the curve need not simplify the differential operator.

The interacting obstacles are:

1. **Global minimality.** Finding a commuting operator in one convenient ansatz is insufficient. The lowest odd order is 11 over the entire elliptic function field. A proof must rule out coefficients with an unanticipated denominator or an odd part involving y.
2. **A genuine singularity.** The spectral polynomial has a double energy factor. The normalized curve has genus 4, but the primitive differential generator still has order 11. Dividing by the apparent common spectral factor gives a nonzero differential remainder. An order-9 answer based only on the normalized genus is false.
3. **The required elliptic reduction.** The covering is a group sum of eight algebraically varying points with a specified sheet choice. Choosing an arbitrary elliptic quotient is wrong. In particular, the visible symmetry of the normalized equation supplies an incidental degree-3 elliptic quotient; the required divisor sum instead gives a degree-18 covering of the original elliptic curve.
4. **Orientation and global geometry.** Negating the covering's y-coordinate still satisfies the target curve equation, but changes the prescribed group sum. Ramification must be measured on the normalized curve, including the point at infinity and the distinction between its energy projection and the elliptic covering.
5. **Geometric monodromy.** Simple ramification alone does not establish the full symmetric group. The branch values must be distinct, and every possible unramified elliptic factor over the algebraic closure must be excluded. The certificate joins a canonical Jacobian quotient, reduction of isogenies, rational torsion, and generation of an entire finite elliptic group.

The expert-time estimate is 12 focused hours, including derivation, implementation, and checking. It is an estimate, not a measured human trial. Correct implementations run in seconds; the verifier uses exact arithmetic and takes a fraction of a second. The intended difficulty is recognizing and joining these structures, not search volume, withheld conventions, numerical precision, or expensive computation.

The final local result is **8/8 successes**, so the requested **0/8–1/8 target was not achieved**. This also exceeds the attached PDF’s explicit 0–6/8 band for this local test population. The first design, without the elliptic-covering requirement, was solved by all four local blind pilot agents. The second design, including the covering but without monodromy, was also solved by all four. These outcomes are preserved in `authoring/evidence/pilot_v1/` and `pilot_v2/`; neither is counted as a final-task failure. Actual final calibration is recorded in `authoring/evidence/RESULTS.md`. Local collaborative probes are not the platform's controlled model evaluation.

## Reference solution

`solution/solve.py` implements two algebraic constructions without reading tests, sealed witnesses, or golden outputs.

First it generates canonical differential-polynomial densities from the formal squared-eigenfunction identity. It searches for the first constant linear relation making the third-order squared-eigenfunction equation stationary. The first relation has energy degree 5. Expanding that polynomial in the noncommutative differential-operator ring yields the monic skew-adjoint order-11 generator. A conserved polynomial expression gives the spectral curve:

```
P(E) = E^2 (E^3 - 551232) (E^6 - 553014 E^3 + 816903549).
```

Thus q(E)=E and the squarefree normalized polynomial has degree 9, giving genus 4. Exact right Euclidean division by L gives a nonzero first-order remainder.

For the geometric layer, let N=(x^3-11)F be the numerator of the squared eigenfunction. The reference constructs a function on the base elliptic curve that vanishes at all eight selected points. It has one additional zero and a pole of order nine at infinity. The elliptic group law says that this ninth zero is the negative of the required sum. A small polynomial interpolation problem and an exact norm identity recover both coordinates, including their sign. Differentiating the resulting map gives

```
alpha*(dx/y) = 9 (E^3 - 120582) dE/W.
```

The map has degree 18. Its six simple ramification points lie over E^3=120582. These energies are not branch points of the energy projection; the point at infinity is unramified.

Finally, the reference searches small good primes and source points, computing the finite elliptic group exactly. At p=229, the images of (1,48) and (2,111) generate all 252 target points, and all 36 points of target 6-torsion are rational. This excludes any isogeny factor of degree divisible by 2 or 3. Distinct simple branch values then give primitive monodromy containing a transposition, hence S18, of order 6402373705728000. The proof explains why the certificate excludes geometric factors, not merely rational cyclic ones. The verifier also accepts an independently checked certificate at p=727.

The independent solver, `authoring/evidence/independent.py`, follows different routes at both stages:

- It derives a complete nine-dimensional space of meromorphic squared eigenfunctions from local pole exponents and elliptic parity, then computes the kernel of a rational differential pencil. An exact rank minor and a primitive polynomial kernel prove the global minimum order.
- It reduces the degree-eight elliptic divisor through successive complementary intersections, with degrees 8, 6, 4, 2, and 1. This is group-law divisor reduction, not the reference's interpolation construction.
- Its finite-field implementation uses the short Weierstrass coordinates y/2; the reference uses the original y coordinates. The prime, torsion, source membership, and generation claims are recomputed exactly.

It imports neither the reference solver nor the verifier. It independently checks the exact operator identities and the covering equation. Both routes agree after rational simplification. Complete proofs and machine-readable certificates are in `authoring/evidence/minimality_proof.md`, `minimality_certificate.json`, `cover_proof.md`, `monodromy_proof.md`, and `cover_independent_comparison.json`.

## Verification

The source of truth is the mathematical input and exact identities, together with the independently proved minimum-order theorem. The verifier does **not** compare an operator or covering to a reference-output file. The seeded generator contains no computed answer. Reference output is not copied into the solver environment.

`tests/check_submission.py` uses FLINT rational polynomials and its own quadratic-field/Ore arithmetic, while the reference uses SymPy. It reads inert JSON, never executable submissions. Checks are:

1. Bounded file size, exact key/type/shape rules, bounded integer sizes, nonzero denominators, no duplicate keys, and no floating-point values.
2. Monicity and minimum order 11; exact commutation and formal skew-adjointness; the exact spectral identity A^2+P(L)=0.
3. P=q^2h with all polynomials monic and h squarefree; correct geometric genus; exact right division with the required remainder order.
4. Reconstruction of N from the **submitted** valid operator; exact generic-divisor and curve-membership checks.
5. A sealed interpolation proof object is checked against that N. Its vanishing congruence, pole order, and norm identity establish the submitted x-coordinate as the specified group sum. A separate evaluation identity fixes the y-coordinate's sign. The witness is not trusted as an answer and contains no golden coordinate comparison.
6. The target elliptic equation, covering degree, exact differential pullback, and complete finite/infinite ramification divisor.
7. Six distinct simple branch values and pointedness at infinity; a valid small good prime, full rational target 6-torsion, exact source points whose images generate the entire target group, and the resulting monodromy order. The verifier computes these properties and does not compare the prime or source points with saved answers.

Equivalent fractions, common polynomial factors, negative denominator scaling, and trailing zero coefficients are accepted within the published limits. The verifier rejects a curve-valid but incorrectly oriented map and a curve-valid doubled map. This matters: checking only the elliptic equation would accept either wrong answer.

The separate verifier image is offline. `tests/test.sh` initializes reward 0 and grants reward 1 only when pytest exits successfully and supplies a valid, nonempty, entirely passing CTRF report. It preserves nonzero pytest status and supplies a failure report if the original report is missing, malformed, or inconsistent. Ten actual Docker fault tests check these failure paths, including a killed pytest process and a process that falsely exits successfully without a report. It installs nothing at runtime.

## Ablation ladder

`authoring/evidence/validate.py` records each actual outcome and diagnostic. Controls include:

- Empty output: rejected.
- The normalized order-9 quotient used as the primitive operator: rejected for wrong minimum order.
- A+1: still commutes, but is rejected for failing skew-adjointness.
- A coherently forged factorization: rejected by the spectral identity.
- Leaving the square factor in h: rejected by squarefreeness.
- A valid left-division pair: rejected by the specified right-division identity.
- Negating only the map's y-coordinate: rejected by the Abel-sum orientation identity.
- Doubling the elliptic map and updating its curve/degree/pullback data: rejected by the divisor-sum norm identity.
- Wrong map degree, pullback, finite ramification, or infinity multiplicity: rejected by the corresponding geometric check.
- A composite or bad prime, false source point, insufficient target torsion, subgroup that is too small, or wrong monodromy order: rejected by an exact arithmetic or geometric check. A different valid prime and different generating points pass.
- Duplicate keys, booleans, floats, malformed rational encodings, missing/extra fields, and oversized inputs: rejected by strict bounded parsing and field checks. Later fields are parsed when their mathematical layer is reached.

These controls establish verifier behavior. They are not agent-success measurements.

## Reproduction and environment

The agent image needs Python and SymPy. The verifier needs Python, FLINT, pytest 8.4.1, and pytest-json-ctrf 0.3.5. All wheels and transitive dependencies are pinned, with SHA-256 hashes checked against the exact releases' HTTPS PyPI metadata. This compact edition downloads the recorded wheel artifacts during setup instead of shipping them inside the ZIP. Requirements files enforce those hashes during installation. Both images install exclusively from local, hash-verified wheels without package-index access; the validation builds additionally disabled networking for RUN steps. The Docker engine fetches the pinned base image and checksum-verified remote ADD sources during initial image preparation; this is not a completely network-free first build. The FLINT wheel targets the validated Linux x86_64 platform. The agent's runtime network remains public; the verifier remains offline.

Both Dockerfiles pin the Python base image to the exact digest used in validation. Local validation additionally disabled solver networking to establish that the oracle and independent constructions need no downloads; this does not change the public-network policy for actual agents.

On a machine with Docker and Harbor, and network access for initial image preparation, run from the task root:

```sh
harbor run -p . -a oracle -e docker
harbor run -p . -a nop -e docker
harbor check . -m anthropic/claude-opus-4-8
```

This cloud host mounts its home directory read-only. `authoring/evidence/harbor_local.py` redirects only Harbor 0.24.0's hardcoded cache locations to a writable directory; it does not alter task loading, agent execution, artifact transfer, or grading. Local records distinguish that adapter from the standard command above.

The actual Harbor run reached oracle execution but failed before grading: this host lacks the kernel feature CONFIG_NFT_FIB_INET required by Harbor's network-isolation helper. This is an infrastructure failure, not an oracle failure or a graded Harbor trial. Separate Docker validation uses `--network none` for the verifier and transfers only the declared JSON artifact. Its actual reward, exit-status, and CTRF records are retained under `authoring/evidence/docker-final/`; they are explicitly not presented as Harbor passes. The quality-check command was also attempted but produced no report before a 60-second infrastructure-probe timeout; provider API credentials were absent. No quality verdict was obtained.

For direct exact checks, `bash authoring/setup.sh /tmp/elliptic-centralizer-tools` first restores the exact wheels if absent, then creates a virtual environment from them without package-index access during installation. Use its Python to run the reference and independent scripts with `--data environment/data/operator.json --output <path>`, followed by the verifier on that output. `authoring/evidence/validate.py` reruns the retained acceptance/rejection controls. Generated JSON outputs in authoring are evidence only and are never copied into the agent image. This setup downloads missing wheels first and then installs the mathematical tools offline; the separately tested external Harbor CLI version is 0.24.0.

## Submission status and authorship

The user instructed reuse of the reference ZIP's author details. Name, email, organization, profile, conflict disclosure, and professional-experience text are preserved without inventing additional credentials. That supplied experience concerns wind-farm optimization; the submitting author must assess its relevance to this different mathematical field.

The attached guidelines require the submitting expert to write the final instruction personally. This assistant-generated instruction is therefore an **author-review draft**. It cannot honestly be certified as meeting that authorship rule. The expert must write/finalize their own instruction while preserving the tested mathematical contract. Platform AI screening, global similarity, the unpublished 35-criterion rubric, official difficulty probes, and human acceptance cannot be certified by local tests.
