# Elliptic centralizer

Audit an exact elliptic differential operator: recover its minimum odd commuting symmetry, normalize its spectral curve, reconstruct the specified elliptic divisor-sum map, and certify its ramification and geometric monodromy. The complete mathematical contract is in `instruction.md`; `environment/data/README.md` describes the input.

## Difficulty

A researcher studying exact wave equations, or a developer checking symbolic mathematics software, would do this work to establish which transformations preserve an equation and how its solutions are connected. The synthetic input requires several linked proofs: that no smaller commuting operator exists, that removing repeated factors from a curve does not imply division of differential operators, and that the prescribed sum of elliptic points gives the correct map and sign. Local calculations must then support a global conclusion about how the map permutes its fibers. Finding formulas is insufficient: each step must agree with the others, and a finite-field certificate must justify the group calculation. The numbers are small enough for exact arithmetic; the challenge is choosing and connecting the right mathematical arguments.

## Reference solution

`solution/solve.py` derives canonical differential-polynomial densities, finds their first stationary relation, constructs the commuting operator, factors the spectral polynomial, and performs right division. An elliptic interpolation construction recovers the required map with its orientation. Exact finite-field group generation provides the monodromy certificate.

`authoring/evidence/independent.py` instead uses global pole bounds and a rational differential pencil, followed by successive elliptic divisor reductions. Its finite-group calculation uses separate short-Weierstrass arithmetic. It imports neither the reference solver nor the verifier.

The minimum odd order is 11, while the normalized spectral genus is 4. The prescribed map has degree 18 and geometric monodromy S18. Complete arguments and exact certificates are in `authoring/evidence/minimality_proof.md`, `cover_proof.md`, and `monodromy_proof.md`.

## Verification

`tests/check_submission.py` checks exact defining identities with FLINT rational arithmetic. It verifies global minimum order, commutation, adjoint, spectral identity, maximal square factor, genus, right division, the specified Abel sum, complete ramification, and the finite-field monodromy certificate. Equivalent rational encodings and different valid certificate primes are accepted. It reads bounded inert JSON and never runs submitted code.

`tests/test.sh` starts with reward 0. Reward 1 requires a successful pytest process and a valid, nonempty, entirely passing CTRF report. Missing or malformed reports fail closed; nonzero pytest status is preserved. The verifier runs in a separate offline container and installs nothing at runtime.

`authoring/evidence/validate.py` reproduces 68 mathematical, malformed-input, and adversarial controls, including acceptance of removable factors at certificate points. Recorded outcomes and mathematical-contract calibration are in `authoring/evidence/RESULTS.md`.

## Setup and reproduction

The compact ZIP omits dependency wheels. Docker builds obtain exact wheel URLs with SHA-256-checked `ADD` instructions, then install only those local files with hash enforcement and no package-index access. A modern Docker BuildKit supporting `ADD --checksum` is required. Initial image preparation needs internet access; verifier execution remains offline. The tested platform is Linux x86_64 with Python 3.12.

For local tools:

```sh
bash authoring/setup.sh /tmp/elliptic-centralizer-tools
/tmp/elliptic-centralizer-tools/bin/python -B authoring/evidence/static_validate.py
/tmp/elliptic-centralizer-tools/bin/python -B authoring/evidence/validate.py
```

For separate-container reference, independent, and empty-output checks:

```sh
/tmp/elliptic-centralizer-tools/bin/python -B authoring/evidence/container_validate.py
```

The pinned Dockerfiles, requirements, dependency hashes, complete input, reference implementation, and sealed verifier are included. All task-specific mathematical information is contained in the bundle. The authoring directory is not copied into the solver image.
