#!/bin/bash
# Fail closed, preserve pytest's status, and emit a report even on crashes.
set -uo pipefail
mkdir -p /logs/verifier
printf '0\n' > /logs/verifier/reward.txt
rm -f /logs/verifier/ctrf.json /logs/verifier/metrics.json /logs/verifier/wrapper_status.json
status=0
pytest --ctrf /logs/verifier/ctrf.json /tests/test_submission.py -rA || status=$?
report_status=0
python - "$status" <<'PY' || report_status=$?
import json
import math
import sys
import time
from pathlib import Path

logs = Path("/logs/verifier")
pytest_status = int(sys.argv[1])
valid = False
reason = ""
summary = {}

def distinct_keys(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError("duplicate report key")
        obj[key] = value
    return obj

def reject_constant(value):
    raise ValueError("nonfinite report number: " + value)

def finite_number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0

try:
    report = json.loads((logs / "ctrf.json").read_text(),
                        object_pairs_hook=distinct_keys, parse_constant=reject_constant)
    result = report["results"]
    if not isinstance(result["tool"]["name"], str) or not result["tool"]["name"]:
        raise ValueError("missing report tool name")
    summary, tests = result["summary"], result["tests"]
    statuses = ("passed", "failed", "skipped", "pending", "other")
    if any(type(summary[key]) is not int or summary[key] < 0 for key in ("tests", *statuses)):
        raise ValueError("report counts must be nonnegative integers")
    if summary["tests"] < 1 or not isinstance(tests, list) or len(tests) != summary["tests"]:
        raise ValueError("report must contain the declared nonempty test list")
    if not all(finite_number(summary[key]) for key in ("start", "stop")) or summary["stop"] < summary["start"]:
        raise ValueError("invalid report timestamps")
    counts = dict.fromkeys(statuses, 0)
    for test in tests:
        if not isinstance(test["name"], str) or not test["name"] or test["status"] not in counts:
            raise ValueError("invalid report test name or status")
        if not finite_number(test["duration"]):
            raise ValueError("invalid report test duration")
        counts[test["status"]] += 1
    if any(counts[key] != summary[key] for key in statuses):
        raise ValueError("report summary does not match individual tests")
    valid = True
except Exception as exc:
    reason = "pytest did not produce a valid nonempty CTRF report: " + str(exc)

accepted = valid and pytest_status == 0 and summary["passed"] == summary["tests"]
if not accepted and not reason:
    reason = (f"pytest exited with status {pytest_status}" if pytest_status else
              "pytest reported tests that were not all passed")
fallback = not accepted and (not valid or summary.get("failed", 0) == 0)
if fallback:
    now = time.time()
    report = {"results": {"tool": {"name": "pytest-wrapper"},
        "summary": {"tests": 1, "passed": 0, "failed": 1, "pending": 0,
                    "skipped": 0, "other": 0, "start": now, "stop": now},
        "tests": [{"name": "verifier completed with a valid all-passed report", "status": "failed",
                   "duration": 0, "message": reason}]}}
    (logs / "ctrf.json").write_text(json.dumps(report) + "\n")
(logs / "wrapper_status.json").write_text(json.dumps({"pytest_exit_status": pytest_status,
    "original_report_valid": valid, "fallback_report_written": fallback,
    "accepted": accepted, "reason": reason}, indent=2) + "\n")
(logs / "reward.txt").write_text("1\n" if accepted else "0\n")
raise SystemExit(0 if accepted else 1)
PY
if [ "$status" -ne 0 ]; then
    exit "$status"
fi
exit "$report_status"
