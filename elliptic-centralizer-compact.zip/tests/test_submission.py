"""The graded artifact is inert JSON and all mathematical checks are exact."""
import json
from pathlib import Path

from check_submission import verify_path


def test_exact_centralizer_certificate():
    metrics = verify_path("/app/output/centralizer.json")
    logdir = Path("/logs/verifier")
    logdir.mkdir(parents=True, exist_ok=True)
    (logdir / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
