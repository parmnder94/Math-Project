# Elliptic operator data and exact encoding

This is a synthetic, exact mathematical instance for an audit of a commuting differential-operator algebra. It contains no measurements or numerical approximations. The task asks for mathematical certificates, not a fitted model.

`/app/data/operator.json` records the field and potential. In general its integer fields mean

\[
y^2=4(x^3-b),\quad D(x)=y,\quad D(y)=6x^2,\quad
u(x)=c x+\frac{p x}{x^3-b},\quad L=-D^2+u(x).
\]

For this instance, `curve_b = 11`, `coefficient_x = 30`, and `pole_coefficient = 198`. There are no hidden parameter values. `D` is a derivation, so it obeys the product and quotient rules. In particular, for rational functions in (x),

\[
D(a(x)+y b(x))=4(x^3-11)b'(x)+6x^2 b(x)+y a'(x).
\]

Operator composition is noncommutative: coefficients are on the left and (Dc=cD+D(c)). Identities are identities in the field and operator ring, including across removable singularities; evaluation at a finite set of points is not the specification. No analytic branch of (y), contour, boundary condition, or numerical tolerance is involved.

## JSON representation

The only output is `/app/output/centralizer.json`, a UTF-8 JSON object with exactly the keys `operator`, `spectral_polynomial`, `square_factor`, `normalized_polynomial`, `genus`, `quotient`, `remainder`, `cover`, and `monodromy`.

A rational function is an object with exactly two keys:

```json
{"num": [2, 0, 3], "den": [5, 1]}
```

This denotes ((2+3t^2)/(5+t)). The variable is (x) in an operator coefficient and (E) in the three energy polynomials. All array entries must be JSON integers, not floats, strings, or booleans. The denominator must not be the zero polynomial. An empty numerator denotes zero. An empty denominator is invalid. Trailing zeros, negative denominators, nonprimitive coefficients, and common polynomial factors are allowed. For example `[2, 2]/[2, 2]` and `[1]/[1]` represent the same rational function. The three energy-polynomial fields must reduce to polynomials; their written denominators need not be constant.

An element of (K) has exactly the keys `a` and `b`:

```json
{"a": {"num": [1, 2], "den": [1]}, "b": {"num": [3], "den": [1]}}
```

This denotes (1+2x+3y). Every element of (K) has a unique form (a(x)+yb(x)) after rational simplification; the submitted fractions need not already be simplified.

An operator is an array of these field elements in increasing order of the power of (D). For example, `[c0, c1, c2]` denotes (c_0+c_1D+c_2D^2). Trailing zero field elements are allowed and do not change the order. The zero operator may be an empty array or an array of zero elements. These conventions apply to `operator`, `quotient`, and `remainder`.

`genus` is a nonnegative JSON integer. The `cover` object has exactly the keys `x`, `y_multiplier`, `degree`, `pullback`, `ramification_polynomial`, and `infinity_ramification_order`. The four rational-function fields use the same `{num,den}` encoding, with variable E. The degree is a positive JSON integer; the infinity ramification order is a nonnegative JSON integer. The ramification polynomial must reduce to a monic polynomial. Polynomial monicity is tested after simplification. Repeated JSON object keys, extra keys, nonfinite constants, and malformed values are rejected.

For ramification, a zero of the polynomial in E is interpreted on the normalized spectral curve. In particular, a root at a branch point of its E-coordinate projection has twice its polynomial multiplicity in the zero divisor. Ramification order means the local index minus one. The task asks for the ramification of the specified elliptic covering, not of the E-coordinate projection.

The `monodromy` object has exactly the keys `group_order`, `prime`, and `source_points`. The first two are JSON integers. The third is a nonempty array of at most eight arrays, each containing exactly two JSON integers giving the energy and normalized spectral coordinate W modulo the chosen prime. Repeated points are allowed; the generated subgroup is what matters. The conditions in the instruction concern canonical rational functions, so unreduced input fractions do not change their meaning. Finite-field membership and generation are exact, without a probabilistic primality or point-count test.

## Resource limits on the artifact

- At most 2 MiB (2,097,152 bytes), including whitespace.
- At most 33 field elements per operator array.
- At most 129 integers per numerator or denominator array before simplification.
- Every integer has absolute value less than (2^{2048}).

These are serialization limits, not suggested degrees or orders. An exact solution fits well inside them. Within the limits, mathematically equivalent representations receive the same result.

## Spectral normalization convention

The requested factorization is P = q^2 h, with q and h monic and h squarefree over the rational numbers. The polynomial q need not be squarefree. An irreducible factor with multiplicity m in P has multiplicity floor(m/2) in q, and multiplicity m mod 2 in h. The normalized curve's genus is geometric, not the arithmetic genus of the possibly singular plane model. The right-division equation is A = Q q(L) + R, with the divisor on the right.
