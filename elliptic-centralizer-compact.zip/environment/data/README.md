# Operator input

`operator.json` contains a synthetic exact instance, without measurements or numerical tolerances. Its integer fields specify

$$
y^2=4(x^3-b),\qquad D(x)=y,\qquad D(y)=6x^2,\qquad
L=-D^2+cx+\frac{px}{x^3-b}.
$$

Here `curve_b` gives $b=11$, `coefficient_x` gives $c=30$, and `pole_coefficient` gives $p=198$. The derivation obeys the product and quotient rules. There are no hidden parameters or analytic boundary conditions.

The complete task and the sole output format for `/app/output/centralizer.json` are specified in `instruction.md`.
