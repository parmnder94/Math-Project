Audit the elliptic differential centralizer described below.

**Task.**

An exact spectral calculation for an elliptic Schrödinger operator is being audited. Recover its primitive odd differential symmetry, normalize its spectral curve, reconstruct the elliptic covering determined by its joint eigenfunction divisor, and determine the geometric monodromy of that covering. Include the differential-division obstruction, complete ramification, and the arithmetic certificate specified below.

Work in the differential field
\[
K=\mathbb Q(x,y),\qquad y^2=4(x^3-11),\qquad D(x)=y,\quad D(y)=6x^2,
\]
and the operator ring \(K[D]\), with coefficients written on the left and multiplication defined by \(Dc=cD+D(c)\). The operator is
\[
L=-D^2+30x+\frac{198x}{x^3-11}.
\]
The inputs and the output encoding are also specified in `/app/data/README.md` and `/app/data/operator.json`.

**Files to submit.**

Write `/app/output/centralizer.json` as one JSON object containing exactly these nine fields:

1. `operator`: a monic, nonzero, formally skew-adjoint operator \(A\in K[D]\) of the **smallest positive odd order** among all nonzero odd-order operators commuting with \(L\). Require \([A,L]=0\).
2. `spectral_polynomial`: the monic polynomial \(P\in\mathbb Q[E]\) satisfying \(A^2+P(L)=0\).
3. `square_factor`: the monic polynomial \(q\in\mathbb Q[E]\) such that \(q^2\) is the greatest monic square divisor of \(P\).
4. `normalized_polynomial`: the monic squarefree polynomial \(h\in\mathbb Q[E]\) with \(P=q^2h\). Thus \(V^2+P(E)=0\) has normalization \(W^2+h(E)=0\), with \(V=q(E)W\).
5. `genus`: the geometric genus of the smooth projective normalization over \(\overline{\mathbb Q}\).
6. `quotient` and 7. `remainder`: the unique right-division pair \(Q,R\in K[D]\) satisfying \(A=Qq(L)+R\) and \(\operatorname{ord}R<2\deg q\). If \(q=1\), use \(Q=A\) and \(R=0\). The zero operator has order \(-\infty\).
8. `cover`: the elliptic covering and ramification data defined below.
9. `monodromy`: the geometric monodromy order and finite-field certificate defined below.

Here \(E\) is a constant indeterminate. Monic refers to the coefficient of the highest power. The formal adjoint fixes \(K\), sends \(D\) to \(-D\), and reverses multiplication: \((cD^j)^*=(-D)^jc\). It is algebraic, without complex conjugation. Formally skew-adjoint means \(A^*=-A\). Minimality is over the full field \(K\), not a chosen polynomial or denominator ansatz.

**Elliptic covering.**

Let \(\widetilde C\) be the smooth projective normalization of \(W^2+h(E)=0\), and put \(V=q(E)W\). Extend \(D\) by \(D(E)=D(W)=0\). Let \(-F(E,x,y)\) be the coefficient of \(D\) in the right remainder of \(A\) upon division by \(L-E\). For this instance \(F\in\mathbb Q(E,x)\), and
\[
d(x)=x^3-11,\qquad N(E,x)=d(x)F(E,x)
\]
is a polynomial in \(x\) with distinct roots away from \(d=0\) at a generic point of \(\widetilde C\).

For every root \(\xi_i\) of \(N(E,x)\), define a point on the original elliptic curve \(\mathcal E:y^2=4(x^3-11)\) by
\[
P_i=\left(\xi_i,\ -\frac{2Vd(\xi_i)}{\partial_xN(E,\xi_i)}\right).
\]
The required covering is
\[
\alpha:\widetilde C\longrightarrow\mathcal E,\qquad
\alpha(E,W)=\sum_i P_i,
\]
where the sum uses the elliptic curve group law with the point at infinity as identity. These definitions are generic function-field definitions; use the unique extension to the smooth projective curves at root collisions, poles, and infinity.

The `cover` object must have exactly these six keys:

- `x` and `y_multiplier`: rational functions \(X(E),Y(E)\in\mathbb Q(E)\) such that \(\alpha(E,W)=(X(E),W Y(E))\), with the sign fixed by the points \(P_i\) above.
- `degree`: the degree of \(\alpha\) as a morphism of curves over \(\overline{\mathbb Q}\).
- `pullback`: the rational function \(r(E)\) satisfying \(\alpha^*(dx/y)=r(E)\,dE/W\).
- `ramification_polynomial`: the monic polynomial \(\rho(E)\) whose finite zero divisor on \(\widetilde C\), with its actual multiplicities on that curve, equals the finite part of the ramification divisor of \(\alpha\).
- `infinity_ramification_order`: the ramification index minus one at the unique point of \(\widetilde C\) over \(E=\infty\). Thus the complete ramification divisor is the finite zero divisor of \(\rho(E)\) plus this integer times that point.

The required covering is the specified group sum. Merely mapping the spectral curve into an elliptic curve does not establish this requirement.

**Geometric monodromy certificate.**

The geometric monodromy is the image of the topological fundamental group of the complex elliptic target with its branch values removed, acting on a generic fiber of \(\alpha\). It is a permutation group up to relabeling. Report its order, not an arithmetic Galois group over \(\mathbb Q\).

The `monodromy` object must contain exactly `group_order`, `prime`, and `source_points`. The first is the positive integer order of the geometric monodromy group. Supply a prime \(5\le p<5000\), with \(p\nmid66\), and between one and eight pairs \([e,w]\) of integer residues in \([0,p-1]\). They must satisfy all of the following certificate conditions:

- The reduction of \(h\) has the same degree and is squarefree. After canceling rational functions over \(\mathbb Q\) and making each denominator monic, every rational coefficient denominator of \(h,X,Y\) is invertible modulo \(p\). Each numerator and denominator of \(X\) and \(Y\) retains its degree under reduction, and each pair remains coprime.
- Every point of \(\mathcal E[6]\), the kernel of multiplication by six on the reduced target elliptic curve, is rational over \(\mathbb F_p\).
- Every supplied pair is a point \(w^2+h(e)=0\) over \(\mathbb F_p\), both coordinate functions of \(\alpha(e,w)=(X(e),wY(e))\) are defined by their displayed rational functions there, and these images generate the entire finite group \(\mathcal E(\mathbb F_p)\).

The certificate is part of the required output. Any prime and points meeting these conditions are acceptable; no particular witness is prescribed.

**Encoding and evaluation.**

The exact JSON encoding, size limits, and treatment of equivalent fractions are in `/app/data/README.md`. Operator arrays run from the coefficient of \(D^0\) upward. Each coefficient is encoded as \(a(x)+yb(x)\); energy polynomials use the same rational-function encoding with variable \(E\). All arithmetic is exact over the rationals. No floating-point values are accepted.

A submission passes only if all nine fields satisfy these definitions, including global minimality, every differential-operator identity, the specified group sum, complete ramification, and the monodromy result and certificate. No particular construction method or unreduced representation is required.

You have 14400 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
