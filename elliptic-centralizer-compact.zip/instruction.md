Find the smallest positive odd-order differential operator commuting with
$$
L=-D^2+30x+\frac{198x}{x^3-11}
$$
over $K=\mathbb Q(x,y)$, where $y^2=4(x^3-11)$, $D(x)=y$, and $D(y)=6x^2$. In $K[D]$, coefficients are on the left and $Dc=cD+D(c)$. Normalize the resulting spectral curve, compute the elliptic map defined below, and determine its ramification and geometric monodromy. The exact input is also recorded in `/app/data/operator.json`.

Write `/app/output/centralizer.json` with exactly these nine fields:

- `operator`: a monic nonzero $A\in K[D]$ of minimum positive odd order among all nonzero odd-order operators commuting with $L$, with $[A,L]=0$ and $A^*=-A$. Minimality is over the full field $K$. The algebraic adjoint fixes $K$, sends $D$ to $-D$, and reverses products: $(cD^j)^*=(-D)^jc$.
- `spectral_polynomial`: monic $P\in\mathbb Q[E]$ satisfying $A^2+P(L)=0$, where $E$ is a constant indeterminate.
- `square_factor`: monic $q\in\mathbb Q[E]$ such that $q^2$ is the greatest monic square divisor of $P$; $q$ need not be squarefree.
- `normalized_polynomial`: monic squarefree $h\in\mathbb Q[E]$ with $P=q^2h$. Write $\widetilde C$ for the smooth projective normalization $W^2+h(E)=0$, with $V=q(E)W$.
- `genus`: the geometric genus of $\widetilde C$ over $\overline{\mathbb Q}$.
- `quotient` and `remainder`: the unique right-division pair $Q,R\in K[D]$ with $A=Qq(L)+R$ and $\operatorname{ord}R<2\deg q$. For $q=1$, use $Q=A$, $R=0$; the zero operator has order $-\infty$.
- `cover`: the six fields specified next.
- `monodromy`: the three fields specified below.

To define the covering, extend $D$ by $D(E)=D(W)=0$. Let $-F$ be the coefficient of $D$ in the right remainder of $A$ modulo $L-E$. For this instance, $F\in\mathbb Q(E,x)$ and $N(E,x)=(x^3-11)F$ is a polynomial in $x$, generically with distinct roots $\xi_i$ away from $x^3=11$. On $\mathcal E:y^2=4(x^3-11)$, set
$$
P_i=\left(\xi_i,-\frac{2V(\xi_i^3-11)}{\partial_xN(E,\xi_i)}\right),\qquad
\alpha(E,W)=\sum_iP_i.
$$
Use the elliptic group law with identity at infinity and the unique extension of this generic map to the smooth projective curves, including root collisions and poles. The `cover` object has exactly these keys:

- `x`, `y_multiplier`: $X,Y\in\mathbb Q(E)$ with $\alpha(E,W)=(X(E),WY(E))$, including the sign fixed by the $P_i$.
- `degree`: the degree of $\alpha$ over $\overline{\mathbb Q}$.
- `pullback`: $r\in\mathbb Q(E)$ with $\alpha^*(dx/y)=r(E)\,dE/W$.
- `ramification_polynomial`: monic $\rho\in\mathbb Q[E]$ whose finite zero divisor on $\widetilde C$ equals the finite ramification divisor of $\alpha$, with actual multiplicities on that curve. At a branch point of the $E$ projection, a polynomial root has twice its polynomial multiplicity in this divisor.
- `infinity_ramification_order`: the ramification index minus one at the unique point over $E=\infty$.

Geometric monodromy means the image of the complex target's topological fundamental group, with branch values removed, acting on a generic fiber of $\alpha$. The `monodromy` object has exactly `group_order`, `prime`, and `source_points`. Report the positive integer order of this permutation group. Supply a prime $5\le p<5000$, $p\nmid66$, and one to eight pairs $[e,w]$ of integer residues between $0$ and $p-1$ satisfying:

- After cancellation over $\mathbb Q$ and normalization to monic denominators, all coefficient denominators of $h,X,Y$ are invertible modulo $p$. The reduction of $h$ retains its degree and is squarefree. Each numerator and denominator of $X,Y$ retains its degree, and each pair remains coprime.
- All points of $\mathcal E[6]$, the kernel of multiplication by six on the reduced target, are rational over $\mathbb F_p$.
- Each pair satisfies $w^2+h(e)=0$. The canonical denominators of $X,Y$ are nonzero at $e$, and the images $(X(e),wY(e))$ together generate $\mathcal E(\mathbb F_p)$.

Any such prime and points are accepted; repeated points are allowed.

Use UTF-8 JSON and the following encoding throughout:

- A rational function is exactly `{"num": [...], "den": [...]}`, with integer coefficients in increasing powers of its variable: $x$ for operator coefficients and $E$ elsewhere. For example, `{"num": [2,0,3], "den": [5,1]}` means $(2+3t^2)/(5+t)$. The denominator must be nonzero; an empty numerator means zero. Fractions may have common factors, trailing zeros, negative denominators, or nonprimitive coefficients. Their meaning, including evaluation in the certificate, is determined after rational cancellation. Polynomial fields must reduce to polynomials; monicity is checked after simplification.
- A field element $a(x)+yb(x)$ is exactly `{"a": RF, "b": RF}`, where `RF` uses that rational-function encoding. An operator is an array of field elements for $D^0,D^1,\ldots$. Trailing zero coefficients are allowed; zero may be `[]` or an array of zero coefficients.
- `genus` and `infinity_ramification_order` are nonnegative integers; `degree` and `group_order` are positive integers. `source_points` is an array of pairs. All numeric entries must be JSON integers: floats, strings, booleans, and nonfinite constants are invalid. Extra or repeated object keys are invalid.
- The file may contain at most 2,097,152 bytes, including whitespace. Each operator array may have at most 33 coefficients; each numerator or denominator may have at most 129 integers before simplification. Every integer must have absolute value less than $2^{2048}$.

You have 14400 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
