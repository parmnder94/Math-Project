#!/usr/bin/env python3
"""Compile as an unprivileged user; independently replay only kernel declarations."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import subprocess
import tempfile
import time

COMPILER_UID = 65532
MAX_SOURCE = 2_097_152
MAX_OBJECT = 67_108_864
FORMAL = Path('/opt/formal')


def regular_bytes(path, limit, owner=None, directory_fd=None):
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
    fd = os.open(path, flags, dir_fd=directory_fd)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError('artifact must be a bounded regular file')
        if owner is not None and info.st_uid != owner:
            raise ValueError('unexpected artifact owner')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            data = stream.read(limit + 1)
        if len(data) > limit:
            raise ValueError('artifact exceeds size bound')
        return data
    finally:
        os.close(fd)


def compiler_processes():
    result = []
    for item in Path('/proc').iterdir():
        if not item.name.isdigit():
            continue
        try:
            lines = (item / 'status').read_text().splitlines()
            ids = next(line for line in lines if line.startswith('Uid:')).split()[1:]
            if str(COMPILER_UID) in ids:
                result.append(int(item.name))
        except (FileNotFoundError, ProcessLookupError):
            pass
    return result


def stop_compiler_processes():
    deadline = time.monotonic() + 5
    while True:
        for pid in compiler_processes():
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        while True:
            try:
                pid, _ = os.waitpid(-1, os.WNOHANG)
                if pid == 0:
                    break
            except ChildProcessError:
                break
        if not compiler_processes():
            return
        if time.monotonic() >= deadline:
            raise RuntimeError('compiler processes did not terminate')
        time.sleep(0.02)


def drop_privileges():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(38, 1, 0, 0, 0) != 0:  # PR_SET_NO_NEW_PRIVS
        raise OSError(ctypes.get_errno(), 'no-new-privileges failed')
    os.setgroups([])
    os.setgid(COMPILER_UID)
    os.setuid(COMPILER_UID)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_OBJECT, MAX_OBJECT))
    resource.setrlimit(resource.RLIMIT_NOFILE, (128, 128))
    resource.setrlimit(resource.RLIMIT_NPROC, (128, 128))


def verify(source_path='/app/output/Proof.lean'):
    started = time.monotonic()
    if os.geteuid() != 0:
        raise RuntimeError('run this verifier in its supplied root-owned container')
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), 'child-subreaper setup failed')
    if compiler_processes():
        raise RuntimeError('compiler user already has running processes')
    source = regular_bytes(source_path, MAX_SOURCE)
    source.decode('utf-8', errors='strict')
    lean_path = (FORMAL / 'lean-path.txt').read_text().strip()
    lean = FORMAL / 'lean/bin/lean'
    logs = Path('/logs/verifier')
    logs.mkdir(parents=True, exist_ok=True)
    logs.chmod(0o700)
    with tempfile.TemporaryDirectory(prefix='proof-check-', dir='/tmp') as parent:
        parent = Path(parent)
        parent.chmod(0o711)
        work = parent / 'compile'
        work.mkdir(mode=0o700)
        os.chown(work, COMPILER_UID, COMPILER_UID)
        submitted = work / 'Proof.lean'
        submitted.write_bytes(source)
        submitted.chmod(0o444)
        directory_fd = os.open(work, os.O_DIRECTORY | os.O_RDONLY | os.O_NOFOLLOW)
        environment = {
            'PATH': str(FORMAL / 'lean/bin') + ':/usr/local/bin:/usr/bin:/bin',
            'TMPDIR': str(work), 'LANG': 'C.UTF-8',
            'LEAN_PATH': lean_path,
        }
        try:
            with (logs / 'compile.log').open('wb') as log:
                try:
                    result = subprocess.run(
                        [str(lean), '-j1', '-o', 'Proof.olean', 'Proof.lean'],
                        cwd=work, env=environment, stdout=log, stderr=subprocess.STDOUT,
                        preexec_fn=drop_privileges, start_new_session=True, timeout=120,
                    )
                finally:
                    stop_compiler_processes()
            if result.returncode != 0:
                raise ValueError('Lean compilation failed; see compile.log')
            obj = regular_bytes('Proof.olean', MAX_OBJECT, COMPILER_UID, directory_fd)
        finally:
            os.close(directory_fd)
        sealed = parent / 'sealed'
        sealed.mkdir(mode=0o700)
        artifact = sealed / 'Proof.olean'
        artifact.write_bytes(obj)
        with (logs / 'kernel.log').open('wb') as log:
            result = subprocess.run(
                ['/tests/verify', str(artifact)], cwd=sealed,
                env={'PATH': environment['PATH'], 'LEAN_PATH': lean_path, 'LANG': 'C.UTF-8'},
                stdout=log, stderr=subprocess.STDOUT, timeout=45,
            )
        if result.returncode != 0:
            raise ValueError('independent kernel replay failed; see kernel.log')
    report = {'accepted': True, 'seconds': time.monotonic()-started,
              'source_sha256': hashlib.sha256(source).hexdigest(),
              'object_sha256': hashlib.sha256(obj).hexdigest(),
              'compiler_processes_after': compiler_processes()}
    (logs / 'metrics.json').write_text(json.dumps(report, indent=2)+'\n')
    return report


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
