from check_submission import verify


def test_submitted_formal_proof():
    assert verify()['accepted']
