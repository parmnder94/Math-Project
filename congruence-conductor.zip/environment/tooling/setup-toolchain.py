#!/usr/bin/env python3
"""Install digest-pinned Lean/mathlib sources; compile required imports without cache servers."""
import argparse, ctypes, ctypes.util, hashlib, json, os, pathlib, subprocess, sys, tarfile, tempfile, urllib.request
HERE=pathlib.Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--root',type=pathlib.Path,default=pathlib.Path('/workspace/formal-tools'))
ap.add_argument('--manifest',type=pathlib.Path,default=HERE/'setup-dependencies.json')
ap.add_argument('--downloads','--archives-dir',dest='downloads',type=pathlib.Path)
ap.add_argument('--offline',action='store_true')
ap.add_argument('--jobs',type=int,default=4)
ap.add_argument('--skip-build',action='store_true')
a=ap.parse_args();root=a.root.resolve();root.mkdir(parents=True,exist_ok=True)
downloads=(a.downloads or root/'downloads').resolve();downloads.mkdir(parents=True,exist_ok=True)
records=json.loads(a.manifest.read_text())
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def obtain(r):
 p=downloads/r.get('file',r['name'])
 if not p.exists() or digest(p)!=r['sha256']:
  if a.offline:raise RuntimeError('Missing or invalid pinned archive in offline mode: '+str(p))
  part=p.with_suffix(p.suffix+'.part')
  print('Downloading',r['url'],flush=True)
  with urllib.request.urlopen(r['url'],timeout=120) as src,part.open('wb') as dst:
   while b:=src.read(1024*1024):dst.write(b)
  if digest(part)!=r['sha256']:raise RuntimeError('SHA256 mismatch: '+r['url'])
  part.replace(p)
 if p.stat().st_size!=r['bytes']:raise RuntimeError('Length mismatch: '+r['url'])
 return p

def decompress_zstd(src,dst):
 lib=ctypes.CDLL(ctypes.util.find_library('zstd') or 'libzstd.so.1')
 class InBuffer(ctypes.Structure):
  _fields_=[('src',ctypes.c_void_p),('size',ctypes.c_size_t),('pos',ctypes.c_size_t)]
 class OutBuffer(ctypes.Structure):
  _fields_=[('dst',ctypes.c_void_p),('size',ctypes.c_size_t),('pos',ctypes.c_size_t)]
 lib.ZSTD_createDStream.restype=ctypes.c_void_p
 lib.ZSTD_initDStream.argtypes=[ctypes.c_void_p];lib.ZSTD_initDStream.restype=ctypes.c_size_t
 lib.ZSTD_decompressStream.argtypes=[ctypes.c_void_p,ctypes.POINTER(OutBuffer),ctypes.POINTER(InBuffer)];lib.ZSTD_decompressStream.restype=ctypes.c_size_t
 lib.ZSTD_isError.argtypes=[ctypes.c_size_t];lib.ZSTD_isError.restype=ctypes.c_uint
 lib.ZSTD_getErrorName.argtypes=[ctypes.c_size_t];lib.ZSTD_getErrorName.restype=ctypes.c_char_p
 lib.ZSTD_freeDStream.argtypes=[ctypes.c_void_p];lib.ZSTD_freeDStream.restype=ctypes.c_size_t
 stream=lib.ZSTD_createDStream()
 if not stream:raise MemoryError('ZSTD_createDStream')
 def checked(code):
  if lib.ZSTD_isError(code):raise RuntimeError(lib.ZSTD_getErrorName(code).decode())
  return code
 try:
  checked(lib.ZSTD_initDStream(stream));remaining=1
  with src.open('rb') as inp,dst.open('wb') as out:
   while chunk:=inp.read(1024*1024):
    ibuf=ctypes.create_string_buffer(chunk);iv=InBuffer(ctypes.cast(ibuf,ctypes.c_void_p),len(chunk),0)
    while iv.pos<iv.size:
     obuf=ctypes.create_string_buffer(1024*1024);ov=OutBuffer(ctypes.cast(obuf,ctypes.c_void_p),len(obuf),0)
     remaining=checked(lib.ZSTD_decompressStream(stream,ctypes.byref(ov),ctypes.byref(iv)))
     out.write(obuf.raw[:ov.pos])
   if remaining!=0:raise RuntimeError('Truncated zstd archive')
 finally:lib.ZSTD_freeDStream(stream)

def untar(src,dst):
 with tarfile.open(src,'r:*') as tf:
  for member in tf:
   parts=member.name.split('/',1)
   if len(parts)==1 or not parts[1]:continue
   member=member.replace(name=parts[1],deep=False)
   if member.islnk():member=member.replace(linkname=member.linkname.split('/',1)[1],deep=False)
   tf.extract(member,dst,filter='data')

def extract(r,dst,zstd=False):
 p=obtain(r);marker=dst/'.setup-source-sha256'
 if marker.exists():
  if marker.read_text().strip()!=r['sha256']:raise RuntimeError('Different source already installed: '+str(dst))
  return
 if dst.exists() and any(dst.iterdir()):raise RuntimeError('Refusing to overwrite an untracked nonempty tree: '+str(dst))
 dst.mkdir(parents=True,exist_ok=True)
 if zstd:
  with tempfile.TemporaryDirectory(prefix='zstd-',dir=root) as td:
   unpacked=pathlib.Path(td)/'lean.tar';decompress_zstd(p,unpacked);untar(unpacked,dst)
 else:untar(p,dst)
 marker.write_text(r['sha256']+'\n')

lean_root=root/'lean';project=root/'mathlib'
extract(records['lean'],lean_root,True)
extract(records['mathlib'],project)
for r in records['dependencies']:extract(r,project/'.lake/packages'/r['name'])
# Widget source has include_str references to upstream JS; never extract its prebuilt .oleans.
with tarfile.open(obtain(records['proofwidgets_assets']),'r:gz') as tf:
 for member in tf:
  name=member.name.removeprefix('./')
  if not name.startswith('js/'):continue
  member=member.replace(name=name,deep=False)
  tf.extract(member,project/'.lake/packages/proofwidgets/.lake/build',filter='data')
actual=json.loads((project/'lake-manifest.json').read_text())
expected={r['name']:r['commit'] for r in records['dependencies']}
assert {r['name']:r['rev'] for r in actual['packages']}==expected,'Mathlib dependency pin mismatch'
version=subprocess.check_output([str(lean_root/'bin/lean'),'--version'],text=True).strip()
assert 'version 4.19.0,' in version,version
print(version,flush=True)
(root/'installed-dependencies.json').write_text(json.dumps(records,indent=2)+'\n')
if not a.skip_build:
 subprocess.run([sys.executable,str(HERE/'setup-build.py'),'--project',str(project),'--lean',str(lean_root/'bin/lean'),'--out',str(root/'lib'),'--logs',str(root/'build-logs'),'--manifest',str(root/'build-manifest.json'),'--jobs',str(a.jobs)],check=True)
 env=os.environ.copy();env['LEAN_PATH']=str(root/'lib')
 sanity=root/'SetupSanity.lean'
 sanity.write_text('import Mathlib.Algebra.Quaternion\nimport Mathlib.Data.Int.GCD\nimport Mathlib.Data.ZMod.Basic\nimport Mathlib.Algebra.Ring.Subring.Basic\nimport Mathlib.Tactic.Ring\nimport Mathlib.Tactic.NormNum\nimport Mathlib.Tactic.Linarith\nimport Mathlib.Tactic.LinearCombination\nexample (x : ℤ) : (x + 1)^2 = x^2 + 2*x + 1 := by ring\n')
 subprocess.run([str(lean_root/'bin/lean'),str(sanity)],env=env,check=True)
 (root/'lean-path.txt').write_text(str(root/'lib')+'\n')
 print('Source-build sanity passed.',flush=True)
