import argparse, concurrent.futures as cf, json, os, pathlib, subprocess, time
ap=argparse.ArgumentParser()
ap.add_argument('--project',type=pathlib.Path,required=True)
ap.add_argument('--lean',required=True)
ap.add_argument('--out',type=pathlib.Path,required=True)
ap.add_argument('--logs',type=pathlib.Path,required=True)
ap.add_argument('--manifest',type=pathlib.Path,required=True)
ap.add_argument('--jobs',type=int,default=4)
a=ap.parse_args()
assert a.jobs > 0
base=a.project.resolve()
roots=[base,*list((base/'.lake/packages').iterdir())]
out=a.out.resolve(); out.mkdir(parents=True,exist_ok=True)
logs=a.logs.resolve(); logs.mkdir(parents=True,exist_ok=True)
lean=str(pathlib.Path(a.lean).resolve())
def imports(src):
 level=0; cleaned=[]; i=0
 while i<len(src):
  if src[i:i+2]=='/-':level+=1;i+=2;continue
  if level and src[i:i+2]=='-/':level-=1;i+=2;continue
  if src[i]=='\n' or not level:cleaned.append(src[i])
  i+=1
 result=[]
 for line in ''.join(cleaned).splitlines():
  line=line.split('--')[0].strip()
  if not line or line=='prelude':continue
  if line.startswith('import '):result.extend(line[7:].split())
  else:break
 return result
starts=['Mathlib.Algebra.Quaternion','Mathlib.Data.Int.GCD','Mathlib.Data.ZMod.Basic','Mathlib.Algebra.Ring.Subring.Basic','Mathlib.Tactic.Ring','Mathlib.Tactic.NormNum','Mathlib.Tactic.Linarith','Mathlib.Tactic.LinearCombination']
mods={}; stack=list(starts)
while stack:
 n=stack.pop()
 if n in mods:continue
 for root in roots:
  path=root/pathlib.Path(n.replace('.','/')+'.lean')
  if path.exists():
   deps=imports(path.read_text())
   mods[n]=(root,path,set(deps)); stack.extend(deps);break
 else:mods[n]=None
mods={k:v for k,v in mods.items() if v}
assert all(n in mods for n in starts), 'Missing requested source module'
for root,path,deps in mods.values():deps.intersection_update(mods)
print('BUILD_MODULES',len(mods),flush=True)
env=os.environ.copy();env['LEAN_PATH']=str(out)
def build(n):
 root,path,_=mods[n];dst=out/pathlib.Path(n.replace('.','/')+'.olean');dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():return n,0,0
 start=time.monotonic();p=subprocess.run([lean,'--root='+str(root),'-o',str(dst),str(path)],cwd=root,env=env,capture_output=True,text=True)
 (logs/(n+'.log')).write_text(p.stdout+p.stderr)
 return n,p.returncode,time.monotonic()-start
done=set();pending=set(mods);active={};started=time.monotonic()
with cf.ThreadPoolExecutor(max_workers=a.jobs) as pool:
 while pending or active:
  ready=sorted(n for n in pending if mods[n][2]<=done)
  for n in ready[:a.jobs-len(active)]:pending.remove(n);active[pool.submit(build,n)]=n
  if not active:raise RuntimeError('Cycle '+str(pending))
  finished,_=cf.wait(active,return_when=cf.FIRST_COMPLETED)
  for f in finished:
   active.pop(f);n,code,seconds=f.result()
   if code:
    print('FAILED',n,code,flush=True)
    print((logs/(n+'.log')).read_text()[-5000:],flush=True)
    raise SystemExit(1)
   done.add(n)
   if len(done)%25==0:print('DONE',len(done),'/',len(mods),'seconds',round(time.monotonic()-started),flush=True)
import hashlib
manifest={'lean':'4.19.0','required_modules':len(mods),'targets':starts,'modules':[]}
for name,(root,path,deps) in sorted(mods.items()):
 artifact=out/pathlib.Path(name.replace('.','/')+'.olean')
 manifest['modules'].append({'name':name,'source_root':str(root),'source_path':str(path.relative_to(root)),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'olean_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'dependencies':sorted(deps)})
a.manifest.write_text(json.dumps(manifest,indent=2)+'\n')
print('COMPLETE',len(done),'seconds',round(time.monotonic()-started),flush=True)
