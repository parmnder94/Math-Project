# Public formal specification

`Spec.lean` defines the ambient ring, congruence lattice, closure proposition, and conductor proposition. `QuotientSpec.lean` defines the additive subgroup and quotient proposition. `Task.lean` fixes their conjunction as `OrderTask.ExpectedType`.

These files define a synthetic parameterized algebraic family. Their complete source and pinned mathlib imports are available for inspection. The submission contract is in `instruction.md`; the artifact is `/app/output/Proof.lean`.
