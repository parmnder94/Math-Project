import Mathlib.Algebra.Quaternion
import Mathlib.Algebra.Ring.Subring.Basic
import Mathlib.Data.Int.GCD
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination

namespace Conductor

abbrev Quad (d : ℤ) := QuaternionAlgebra ℤ (-1) (-1) d

/-- The integral Eisenstein ring, with its basis `1, ζ` and `ζ² + ζ + 1 = 0`. -/
def eisensteinRing : Subring (Quad 0) where
  carrier := {x | x.imJ = 0 ∧ x.imK = 0}
  zero_mem' := ⟨rfl, rfl⟩
  one_mem' := ⟨rfl, rfl⟩
  add_mem' := by intro x y hx hy; simp_all
  neg_mem' := by intro x hx; simp_all
  mul_mem' := by intro x y hx hy; simp_all

abbrev Eisenstein := ↥eisensteinRing
abbrev Ambient (d : ℤ) := Eisenstein × ℤ × Quad d

def eisenstein (r s : ℤ) : Eisenstein := ⟨⟨r,s,0,0⟩, rfl, rfl⟩

/-- Coordinates in the order are `(x + y ζ, n, a + b ζ + (c + e ζ) j)`. -/
def point (d x y n a b c e : ℤ) : Ambient d :=
  (eisenstein x y, n, ⟨a,b,c,e⟩)

def InOrder (N h : ℤ) {d : ℤ} (v : Ambient d) : Prop :=
  3 ∣ v.2.1 - v.1.val.re - v.1.val.imI ∧
  N ∣ v.2.2.re - v.1.val.re ∧
  N ∣ v.2.2.imI - v.1.val.imI ∧
  h ∣ v.2.2.imJ ∧ h ∣ v.2.2.imK

def MultiplicativelyClosed (N h d : ℤ) : Prop :=
  ∀ v w : Ambient d, InOrder N h v → InOrder N h w → InOrder N h (v * w)

/-- The largest two-sided ideal of the ambient ring contained in the congruence lattice. -/
def InConductor (N h : ℤ) {d : ℤ} (v : Ambient d) : Prop :=
  ∀ l r : Ambient d, InOrder N h (l * v * r)

/-- A coefficientwise candidate for the exact conductor. -/
def ConductorCoordinates (N h : ℤ) {d : ℤ} (v : Ambient d) : Prop :=
  N ∣ v.1.val.re ∧ N ∣ v.1.val.imI ∧ 3 ∣ v.2.1 ∧
  N ∣ v.2.2.re ∧ N ∣ v.2.2.imI ∧
  h ∣ v.2.2.re ∧ h ∣ v.2.2.imI ∧
  h ∣ v.2.2.imJ ∧ h ∣ v.2.2.imK ∧
  N ∣ d * v.2.2.imJ ∧ N ∣ d * v.2.2.imK

def ClosureStatement : Prop :=
  ∀ N h d : ℤ, 0 < N → 0 < h → 3 ∣ N →
    (MultiplicativelyClosed N h d ↔ N ∣ d * h ^ 2)

def ConductorStatement : Prop :=
  ∀ N h d : ℤ, 0 < N → 0 < h → 3 ∣ N →
    ∀ v : Ambient d, InConductor N h v ↔ ConductorCoordinates N h v

end Conductor
