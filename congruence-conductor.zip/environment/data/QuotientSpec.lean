import Spec

namespace Conductor

/-- The additive group underlying the congruence lattice. -/
def orderGroup (N h d : ℤ) : AddSubgroup (Ambient d) where
  carrier := {v | InOrder N h v}
  zero_mem' := by
    change 3 ∣ (0 : ℤ) ∧ N ∣ (0 : ℤ) ∧ N ∣ (0 : ℤ) ∧ h ∣ (0 : ℤ) ∧ h ∣ (0 : ℤ)
    simp
  add_mem' := by
    intro v w hv hw
    rcases hv with ⟨hv₀, hv₁, hv₂, hv₃, hv₄⟩
    rcases hw with ⟨hw₀, hw₁, hw₂, hw₃, hw₄⟩
    refine ⟨?_, ?_, ?_, ?_, ?_⟩
    · convert dvd_add hv₀ hw₀ using 1
      simp
      ring
    · convert dvd_add hv₁ hw₁ using 1
      simp
      ring
    · convert dvd_add hv₂ hw₂ using 1
      simp
      ring
    · simpa using dvd_add hv₃ hw₃
    · simpa using dvd_add hv₄ hw₄
  neg_mem' := by
    intro v hv
    rcases hv with ⟨hv₀, hv₁, hv₂, hv₃, hv₄⟩
    refine ⟨?_, ?_, ?_, ?_, ?_⟩
    · convert dvd_neg.mpr hv₀ using 1
      simp
      ring
    · convert dvd_neg.mpr hv₁ using 1
      simp
      ring
    · convert dvd_neg.mpr hv₂ using 1
      simp
      ring
    · simpa using dvd_neg.mpr hv₃
    · simpa using dvd_neg.mpr hv₄

def scalarModulus (N h : ℤ) : ℕ := Int.lcm N h

def skewModulus (N h d : ℤ) : ℕ :=
  (N / (Int.gcd N (d * h) : ℤ)).natAbs

abbrev ResidueTarget (N h d : ℤ) :=
  (ZMod (scalarModulus N h) × ZMod (scalarModulus N h)) ×
  (ZMod (skewModulus N h d) × ZMod (skewModulus N h d))

/-- The prescribed quotient coordinates; integer division is exact on the order. -/
def residueCoordinates (N h d : ℤ) (v : orderGroup N h d) : ResidueTarget N h d :=
  ((↑v.val.2.2.re, ↑v.val.2.2.imI), (↑(v.val.2.2.imJ / h), ↑(v.val.2.2.imK / h)))

/-- A concrete first-isomorphism certificate for the additive conductor quotient. -/
def QuotientStatement : Prop :=
  ∀ N h d : ℤ, 0 < N → 0 < h → 3 ∣ N →
    ∃ f : orderGroup N h d →+ ResidueTarget N h d,
      (∀ v, f v = residueCoordinates N h d v) ∧
      Function.Surjective f ∧
      (∀ v, f v = 0 ↔ InConductor N h v.val)

end Conductor
