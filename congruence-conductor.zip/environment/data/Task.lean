import QuotientSpec

namespace OrderTask

/-- The complete parametric classification to be proved by the submitted theorem. -/
def ExpectedType : Prop :=
  Conductor.ClosureStatement ∧ Conductor.ConductorStatement ∧ Conductor.QuotientStatement

end OrderTask
