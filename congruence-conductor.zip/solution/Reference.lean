import Task
import Core
import QuotientProof

theorem OrderTask.solution : OrderTask.ExpectedType :=
  ⟨Conductor.closure_reference, Conductor.conductor_reference,
    Conductor.quotient_statement Conductor.conductor_reference⟩
