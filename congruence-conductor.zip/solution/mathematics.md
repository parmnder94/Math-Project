# Parametric conductor classification

Let $ O=\mathbb Z[\zeta] $, where $ \zeta^2+\zeta+1=0 $. Let $ Q_d $ be the free rank-four ring $ O\oplus O j $ with $ j^2=d $ and $ jz=\bar z j $. These definitions are valid for every integer $ d $, including zero; no division-algebra assumption is used. The ambient ring is $ M=O\times\mathbb Z\times Q_d $.

For positive integers $ N,h $ with $ 3\mid N $, the additive subgroup $ S $ consists of

$$
(x+y\zeta,n,a+b\zeta+(c+e\zeta)j)
$$

such that $ n\equiv x+y\pmod 3 $, $ a\equiv x\pmod N $, $ b\equiv y\pmod N $, and $ h\mid c,e $.

## Multiplication

Evaluation $ \zeta\mapsto1 $ defines a ring homomorphism $ O\to\mathbb F_3 $, since $ 1+1+1=0 $ there. Thus the first congruence is preserved by multiplication. The two scalar congruences are preserved except for the scalar contribution $ d(c+e\zeta)\overline{(c'+e'\zeta)} $. Since both skew coefficients belong to $ hO $, this contribution belongs to $ d h^2 O $. The skew product still belongs to $ hO $. Consequently $ N\mid d h^2 $ is sufficient for closure. It is necessary by squaring the element $ (0,0,hj) $, which belongs to $ S $ and has scalar quaternion coefficient $ d h^2 $ in its square. This proves the first theorem.

## Exact conductor

For any additive subgroup of $ M $, define its conductor to be the set of all $ v $ such that $ lvr $ belongs to the subgroup for every $ l,r\in M $. Associativity and distributivity make this the largest two-sided ideal of $ M $ contained in that subgroup. Its definition therefore remains meaningful before multiplication closure has been established.

Multiplication by the three central idempotents shows that a conductor element must satisfy $ N\mid x,y $, $ 3\mid n $, $ N\mid a,b $, and $ h\mid c,e $. On the quaternion coordinate, left multiplication by $ j $ changes the four coefficients to

$$
(d(c-e),-de,a-b,-b).
$$

Applying the same scalar and skew congruences gives $ h\mid a,b $ and $ N\mid dc,de $. These are all the necessary conditions.

They are sufficient as well. The conditions $ N\mid x,y $ and $ 3\mid n $ are preserved by multiplication in their respective factors. In the quaternion factor, multiplication by any element preserves the simultaneous conditions

$$
N\mid a,b,\qquad h\mid a,b,c,e,\qquad N\mid dc,de.
$$

This follows by expanding the four coefficients, on both the left and the right. Every term in either scalar coefficient contains an $ N $-divisible factor $ a,b,dc, $ or $ de $. Every term in a skew coefficient contains an $ h $-divisible factor; after multiplication by $ d $ it contains an $ N $-divisible factor. Hence these conditions hold for every $ lvr $. They imply membership in $ S $ because $ 3\mid N $. This proves the exact conductor description without assuming that $ S $ is multiplicatively closed.

## Additive quotient

Set

$$
A=\operatorname{lcm}(N,h),\qquad
q=\frac{N}{\gcd(N,dh)}.
$$

Both are positive. For an element of $ S $, division of $ c,e $ by $ h $ is exact. Define

$$
f:S\longrightarrow (\mathbb Z/A\mathbb Z)^2\times(\mathbb Z/q\mathbb Z)^2,
\qquad
f(v)=(a,b,c/h,e/h).
$$

This is an additive homomorphism. Given four residue classes, choose integer representatives $ a,b,r,s $ and take $ x=a,y=b,n=a+b,c=hr,e=hs $. This gives an element of $ S $ with the prescribed image, so $ f $ is surjective.

The scalar image vanishes exactly when both $ N $ and $ h $ divide $ a,b $. Together with the defining congruences of $ S $, this forces $ N\mid x,y $, and then $ 3\mid n $. For a skew coefficient $ c=hk $, Euclid's lemma gives

$$
q\mid k\quad\Longleftrightarrow\quad N\mid dhk
\quad\Longleftrightarrow\quad N\mid dc.
$$

The same statement holds for $ e $. Thus the kernel is precisely the conductor just proved. The additive first isomorphism theorem gives the claimed quotient. The formal contract requests the explicit surjective homomorphism and this exact kernel equality, which are a complete first-isomorphism certificate.

For the specialization $ N=18,h=3,d=2 $, one obtains $ A=18,q=3 $, so the quotient has invariant factors $ 3,3,18,18 $. The formal proof quantifies over the entire parameter family; this specialization is not used to establish it.
