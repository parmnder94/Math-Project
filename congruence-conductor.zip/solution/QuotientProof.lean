import QuotientSpec

namespace Conductor

theorem scalar_cast_zero_iff (N h a : ℤ) :
    (a : ZMod (scalarModulus N h)) = 0 ↔ N ∣ a ∧ h ∣ a := by
  rw [ZMod.intCast_zmod_eq_zero_iff_dvd]
  change (Int.lcm N h : ℤ) ∣ a ↔ _
  exact ⟨fun ha => ⟨dvd_trans Int.dvd_lcm_left ha,
    dvd_trans Int.dvd_lcm_right ha⟩, fun ha => Int.coe_lcm_dvd ha.1 ha.2⟩

theorem gcd_quotient_dvd_iff (N t k : ℤ) (hN : N ≠ 0) :
    N / (Int.gcd N t : ℤ) ∣ k ↔ N ∣ t * k := by
  let g : ℤ := Int.gcd N t
  have hg : g ≠ 0 := by
    change (Int.gcd N t : ℤ) ≠ 0
    exact_mod_cast (Int.gcd_pos_of_ne_zero_left t hN).ne'
  have hgN : g * (N / g) = N := Int.mul_ediv_cancel_of_dvd Int.gcd_dvd_left
  have hgt : g * (t / g) = t := Int.mul_ediv_cancel_of_dvd Int.gcd_dvd_right
  change N / g ∣ k ↔ _
  constructor
  · rintro ⟨r, rfl⟩
    refine ⟨(t / g) * r, ?_⟩
    calc
      t * (N / g * r) = (g * (t / g)) * (N / g * r) := by rw [hgt]
      _ = (g * (N / g)) * ((t / g) * r) := by ac_rfl
      _ = N * ((t / g) * r) := by rw [hgN]
  · intro hk
    have h₁ : N ∣ N * (Int.gcdA N t * k) := dvd_mul_right _ _
    have h₂ : N ∣ t * (Int.gcdB N t * k) := by
      convert dvd_mul_of_dvd_left hk (Int.gcdB N t) using 1
      ac_rfl
    have hgk : N ∣ g * k := by
      dsimp [g]
      rw [Int.gcd_eq_gcd_ab]
      convert Int.dvd_add h₁ h₂ using 1
      simp only [Int.add_mul, Int.mul_assoc]
    obtain ⟨r, hr⟩ := hgk
    refine ⟨r, Int.eq_of_mul_eq_mul_left hg ?_⟩
    calc
      g * k = N * r := hr
      _ = g * (N / g * r) := by rw [← mul_assoc, hgN]

theorem skew_cast_zero_iff (N h d c : ℤ) (hN : N ≠ 0) (hc : h ∣ c) :
    ((c / h : ℤ) : ZMod (skewModulus N h d)) = 0 ↔ N ∣ d * c := by
  rw [ZMod.intCast_zmod_eq_zero_iff_dvd]
  change ((N / (Int.gcd N (d * h) : ℤ)).natAbs : ℤ) ∣ c / h ↔ _
  rw [Int.natAbs_dvd, gcd_quotient_dvd_iff N (d * h) (c / h) hN]
  rw [mul_assoc, Int.mul_ediv_cancel_of_dvd hc]

def residueHom (N h d : ℤ) : orderGroup N h d →+ ResidueTarget N h d where
  toFun := residueCoordinates N h d
  map_zero' := by
    change (((↑(0 : ℤ), ↑(0 : ℤ)), (↑((0 : ℤ) / h), ↑((0 : ℤ) / h))) :
      ResidueTarget N h d) = 0
    simp
  map_add' := by
    intro v w
    refine Prod.ext (Prod.ext ?_ ?_) (Prod.ext ?_ ?_)
    · simp [residueCoordinates]
    · simp [residueCoordinates]
    · simp [residueCoordinates, Int.add_ediv_of_dvd_left v.property.2.2.2.1]
    · simp [residueCoordinates, Int.add_ediv_of_dvd_left v.property.2.2.2.2]

theorem residueHom_surjective (N h d : ℤ) (hh : h ≠ 0) :
    Function.Surjective (residueHom N h d) := by
  rintro ⟨⟨a, b⟩, ⟨c, e⟩⟩
  obtain ⟨a', ha⟩ := ZMod.intCast_surjective a
  obtain ⟨b', hb⟩ := ZMod.intCast_surjective b
  obtain ⟨c', hc⟩ := ZMod.intCast_surjective c
  obtain ⟨e', he⟩ := ZMod.intCast_surjective e
  have hv : InOrder N h (point d a' b' (a' + b') a' b' (h * c') (h * e')) := by
    simp [InOrder, point, eisenstein]
  refine ⟨⟨_, hv⟩, ?_⟩
  simp [residueHom, residueCoordinates, point, eisenstein,
    Int.mul_ediv_cancel_left _ hh, ha, hb, hc, he]

theorem residueHom_kernel_coordinates (N h d : ℤ) (hN : N ≠ 0) (h₃ : 3 ∣ N)
    (v : orderGroup N h d) :
    residueHom N h d v = 0 ↔ ConductorCoordinates N h v.val := by
  have hv := v.property
  change InOrder N h v.val at hv
  rcases hv with ⟨hnxy, hax, hby, hhc, hhe⟩
  change (((↑v.val.2.2.re, ↑v.val.2.2.imI),
    (↑(v.val.2.2.imJ / h), ↑(v.val.2.2.imK / h))) : ResidueTarget N h d) =
    ((0, 0), (0, 0)) ↔ _
  simp only [Prod.mk.injEq, scalar_cast_zero_iff,
    skew_cast_zero_iff N h d _ hN hhc,
    skew_cast_zero_iff N h d _ hN hhe]
  constructor
  · rintro ⟨⟨⟨hNa, hha⟩, ⟨hNb, hhb⟩⟩, hdc, hde⟩
    have hNx : N ∣ v.val.1.val.re := by
      convert dvd_sub hNa hax using 1
      ring
    have hNy : N ∣ v.val.1.val.imI := by
      convert dvd_sub hNb hby using 1
      ring
    have hn : 3 ∣ v.val.2.1 := by
      convert dvd_add (dvd_add hnxy (dvd_trans h₃ hNx)) (dvd_trans h₃ hNy) using 1
      ring
    exact ⟨hNx, hNy, hn, hNa, hNb, hha, hhb, hhc, hhe, hdc, hde⟩
  · rintro ⟨_, _, _, hNa, hNb, hha, hhb, _, _, hdc, hde⟩
    exact ⟨⟨⟨hNa, hha⟩, ⟨hNb, hhb⟩⟩, hdc, hde⟩

theorem quotient_statement (hc : ConductorStatement) : QuotientStatement := by
  intro N h d hN hh h₃
  refine ⟨residueHom N h d, fun _ => rfl,
    residueHom_surjective N h d hh.ne', ?_⟩
  intro v
  exact (residueHom_kernel_coordinates N h d hN.ne' h₃ v).trans
    (hc N h d hN hh h₃ v.val).symm

end Conductor
