#!/bin/bash
set -euo pipefail
mkdir -p /app/output
cp /solution/Proof.lean /app/output/Proof.lean
lean /app/output/Proof.lean
