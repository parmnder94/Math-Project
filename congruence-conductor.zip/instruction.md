Prove the formal classification in `/app/data/Task.lean`. Submit `/app/output/Proof.lean`, importing `Task` and declaring `theorem OrderTask.solution : OrderTask.ExpectedType`.

The specification uses $ O=\mathbb Z[\zeta] $ with $ \zeta^2+\zeta+1=0 $, conjugation $ \bar\zeta=-1-\zeta $, and the ring $ Q_d=O\oplus Oj $ with $ j^2=d $ and $ jz=\bar z j $. Its ambient ring is $ M_d=O\times\mathbb Z\times Q_d $, with componentwise multiplication between the three factors. An element has coordinates

$$
v=(x+y\zeta,\ n,\ a+b\zeta+(c+e\zeta)j).
$$

For positive integers $ N,h $ with $ 3\mid N $ and any integer $ d $, the additive subgroup $ S_{N,h,d} $ is defined by

$$
3\mid n-x-y,\qquad N\mid a-x,\qquad N\mid b-y,\qquad h\mid c,\qquad h\mid e.
$$

The proposition `OrderTask.ExpectedType` is the conjunction of these three statements, with all definitions and quantifiers fixed by the public Lean files:

- `Conductor.ClosureStatement`: $ S_{N,h,d} $ is closed under multiplication if and only if $ N\mid dh^2 $.
- `Conductor.ConductorStatement`: the largest two-sided ideal of $ M_d $ contained in $ S_{N,h,d} $ consists exactly of the elements satisfying $ N\mid x,y,a,b $, $ 3\mid n $, $ h\mid a,b,c,e $, and $ N\mid dc,de $. Membership in this ideal is defined by $ \ell v r\in S_{N,h,d} $ for every $ \ell,r\in M_d $.
- `Conductor.QuotientStatement`: put $ A=\operatorname{lcm}(N,h) $ and $ k=N/\gcd(N,dh) $, both positive. The map from $ S_{N,h,d} $ to $ (\mathbb Z/A\mathbb Z)^2\times(\mathbb Z/k\mathbb Z)^2 $ whose coordinates are $ a,b,c/h,e/h $ is an additive homomorphism, is surjective, and has precisely that conductor as its kernel. The exact statement specifies the residue map through `Conductor.residueCoordinates`.

All three statements quantify over the full parameter range, including $ d=0 $, negative $ d $, and parameters sharing common factors. The conductor and quotient statements concern the additive subgroup whether or not it is multiplicatively closed.

Use Lean 4.19.0 and the supplied mathlib version. The public definitions are in `/app/data/Spec.lean`, `/app/data/QuotientSpec.lean`, and `/app/data/Task.lean`; `Task` imports the pinned mathlib dependency subset listed in `Spec.lean`, including the available ring, arithmetic, and linear-combination tactics. The command `lean /app/output/Proof.lean` checks the submission in the supplied environment. Submit a single UTF-8 source file of at most 2,097,152 bytes; put any additional definitions and lemmas in that file. Its compiled module may contain at most 67,108,864 bytes. Compilation has a 120-second limit and independent kernel checking has a 45-second limit, within an overall verifier budget of 180 seconds and 4 GiB.

The verifier independently kernel-checks the submitted declarations against the unchanged public specification. The required declaration must be a theorem without additional assumptions or universe parameters. Proofs may use the standard foundations `propext`, `Quot.sound`, and `Classical.choice`. New axioms, unfinished proofs, and reliance on unsafe or native-only proof computation are invalid. The restrictions on axioms, unfinished proofs, and unsafe or native-only proof computation apply to all submitted safe declarations, including unused helpers. Imported dependencies must come from `Task` and its pinned library imports. Only the submitted source file is transferred to the verifier.

You have 14400 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
