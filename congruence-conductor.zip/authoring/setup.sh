#!/bin/bash
set -euo pipefail
bundle_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
setup_prefix="${1:-/tmp/conductor-tools}"
python3 "$bundle_root/environment/tooling/setup-toolchain.py" --root "$setup_prefix" --jobs 4
python3 -m venv "$setup_prefix/python"
"$setup_prefix/python/bin/python" -m pip install --require-hashes -r "$bundle_root/authoring/requirements.txt"
