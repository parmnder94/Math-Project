#!/usr/bin/env python3
"""Real separate offline solver/verifier containers; no simulated rewards."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def run(command, **kwargs):
    return subprocess.run(command,check=True,text=True,**kwargs)


def validate(root, evidence, build=True, toolchain_image=None):
    evidence.mkdir(parents=True,exist_ok=True)
    docker_config=evidence/'docker-config';docker_config.mkdir(exist_ok=True)
    build_environment=dict(os.environ,DOCKER_CONFIG=str(docker_config))
    images={};builds=[]
    for label,folder in [('agent','environment'),('verifier','tests')]:
        tag='task-conductor-'+label+':local'
        if build:
            command=['docker','build','--network','none','--progress','plain','--tag',tag]
            if toolchain_image:
                command += ['--build-arg','TOOLCHAIN_IMAGE='+toolchain_image]
            command += [str(root/folder)]
            started=time.monotonic()
            with (evidence/f'build_{label}.log').open('w') as log:
                run(command,env=build_environment,stdout=log,stderr=subprocess.STDOUT)
            builds.append({'flavor':label,'seconds':time.monotonic()-started,'command':command,'exit_status':0})
        images[label]=run(['docker','image','inspect','--format','{{.Id}}',tag],capture_output=True).stdout.strip()
    expected={f'/app/data/{p.name}':hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (root/'environment/data').iterdir() if p.is_file()}
    code=('import hashlib,json,pathlib,sys; expected=json.loads(sys.argv[1]); '
          'actual={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in expected}; '
          'assert actual==expected; '
          'assert not pathlib.Path("/solution").exists(); assert not pathlib.Path("/tests").exists(); '
          'print(json.dumps(actual))')
    audit=json.loads(run(['docker','run','--rm','--network','none',images['agent'],
                         'python','-c',code,json.dumps(expected)],capture_output=True).stdout)
    artifact=evidence/'Proof.lean'
    agent=f'conductor-solver-{time.time_ns()}'
    run(['docker','create','--name',agent,'--network','none','--cpus','2','--memory','4g',
         images['agent'],'bash','/solution/solve.sh'],capture_output=True)
    try:
        run(['docker','cp',str(root/'solution'),agent+':/solution'])
        run(['docker','cp',str(root/'instruction.md'),agent+':/app/instruction.md'])
        started=time.monotonic()
        with (evidence/'solver.log').open('w') as log:
            run(['docker','start','-a',agent],stdout=log,stderr=subprocess.STDOUT)
        solver_seconds=time.monotonic()-started
        run(['docker','cp',agent+':/app/output/Proof.lean',str(artifact)])
    finally:
        subprocess.run(['docker','rm','-f',agent],capture_output=True)
    assert artifact.read_bytes()==(root/'solution/Proof.lean').read_bytes()
    records=[]
    for label,expected_reward in [('reference',1),('nop',0)]:
        name=f'conductor-verifier-{label}-{time.time_ns()}'
        directory=evidence/label;directory.mkdir(exist_ok=True)
        run(['docker','create','--name',name,'--network','none','--cpus','2','--memory','4g',
             images['verifier'],'bash','/tests/test.sh'],capture_output=True)
        try:
            if expected_reward:
                run(['docker','cp',str(artifact),name+':/app/output/Proof.lean'])
            started=time.monotonic()
            with (directory/'container.log').open('w') as log:
                result=subprocess.run(['docker','start','-a',name],stdout=log,stderr=subprocess.STDOUT)
            seconds=time.monotonic()-started
            run(['docker','cp',name+':/logs/verifier/.',str(directory)])
            reward=int((directory/'reward.txt').read_text().strip())
            ctrf=json.loads((directory/'ctrf.json').read_text())['results']['summary']
            assert reward==expected_reward and (result.returncode==0)==bool(expected_reward)
            assert ctrf['tests']==1 and ctrf['passed']==expected_reward and ctrf['failed']==1-expected_reward
            records.append({'case':label,'reward':reward,'exit_status':result.returncode,
                            'seconds':seconds,'network':'none','cpus':2,'memory_mb':4096,'ctrf':ctrf})
        finally:
            subprocess.run(['docker','rm','-f',name],capture_output=True)
    report={'all_expected_outcomes':True,'runner':'separate Docker containers; not an official platform run',
            'images':images,'builds':builds,'reused_toolchain_image':toolchain_image,'public_image_file_hashes':audit,
            'solver_seconds':solver_seconds,'records':records}
    (evidence/'container_results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument('--evidence',type=Path,required=True)
    parser.add_argument('--no-build',action='store_true')
    parser.add_argument('--toolchain-image',help='Optional previously validated local toolchain image; default builds pinned sources.')
    args=parser.parse_args()
    validate(args.root.resolve(),args.evidence.resolve(),not args.no_build,args.toolchain_image)
