#!/usr/bin/env python3
"""Visible packaging/clarity checks; no claim to official quality approval."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import tomllib


def validate(root):
    checks = []
    def check(name, ok):
        assert ok, name
        checks.append(name)
    allowed = {'instruction.md','task.toml','README.md','environment','solution','tests','authoring'}
    check('allowed root entries', {p.name for p in root.iterdir()} <= allowed)
    required = ['instruction.md','task.toml','README.md','environment/Dockerfile',
                'solution/solve.sh','solution/Proof.lean','tests/test.sh','tests/Dockerfile',
                'tests/Verify.lean','tests/check_submission.py',
                'environment/data/Spec.lean','environment/data/QuotientSpec.lean','environment/data/Task.lean']
    check('required files exist', all((root/p).is_file() for p in required))
    task = tomllib.loads((root/'task.toml').read_text())
    m = task['metadata']
    check('schema 1.4', task['schema_version']=='1.4')
    check('namespaced slug', task['task']['name'].split('/')[0]==''.join(['after','query']) and
          re.fullmatch(r'[a-z0-9]+/[a-z0-9]+(?:-[a-z0-9]+){0,2}',task['task']['name']) is not None)
    check('formal mathematics taxonomy', (m['domain'],m['field'],m['category'],m['subcategory']) ==
          ('mathematical-sciences','formal-mathematics','Science','Formal Mathematics & Theorem Proving'))
    keys = ['author_name','author_email','author_organization','author_profile','conflicts_of_interest',
            'relevant_experience','subfield','tags','expert_time_estimate_hours','difficulty_explanation',
            'solution_explanation','verification_explanation']
    check('required metadata', all(m.get(k) for k in keys))
    check('consistent author identity', task['task']['authors']==[{'name':m['author_name'],'email':m['author_email']}])
    check('consistent tags', task['task']['keywords']==m['tags'])
    check('single formal proof artifact', task['artifacts']==['/app/output/Proof.lean'])
    check('separate offline verifier', task['verifier']['environment_mode']=='separate' and
          task['verifier']['environment']['network_mode']=='no-network')
    check('public agent network', task['environment']['network_mode']=='public')
    check('timeouts', 3600<=task['agent']['timeout_sec']<=28800 and 0<task['verifier']['timeout_sec']<=28800)
    e = task['environment']
    check('resources', e['cpus'] in [1,2,4,8,16] and e['memory_mb'] in [1024,2048,4096,8192,16384]
          and 0<e['storage_mb']<=40960 and e['gpus']==0)
    instruction = (root/'instruction.md').read_text()
    check('plain prose without headings', re.search(r'^\s{0,3}#{1,6}(?:\s|$)',instruction,re.M) is None)
    check('no decorative bold', '**' not in instruction)
    check('dollar math delimiters', not any(x in instruction for x in [r'\(',r'\)',r'\[',r'\]']))
    display = False
    lines = instruction.splitlines()
    for i,line in enumerate(lines):
        if line=='$$':
            if not display:
                check('blank line before display '+str(i), i>0 and lines[i-1]=='')
            else:
                check('blank line after display '+str(i), i+1<len(lines) and lines[i+1]=='')
            display = not display
        elif not display:
            pieces = line.split('$')
            check('balanced inline math line '+str(i), len(pieces)%2==1)
            for term in pieces[1::2]:
                check('inner math spaces line '+str(i), term.startswith(' ') and term.endswith(' ') and bool(term.strip()))
    check('balanced displays', not display)
    check('instruction no named rejected hints', not any(x in instruction for x in [
        'Subtract the two elliptic Frobenius traces','This identity certifies','Determine the full intersection, rather']))
    suffix=f"You have {int(task['agent']['timeout_sec'])} seconds to complete this task. Do not cheat by using online solutions or hints specific to this task."
    check('required final sentence', instruction.rstrip().endswith(suffix))
    readme=(root/'README.md').read_text()
    check('required README headings', all('\n## '+x+'\n' in readme for x in ['Difficulty','Reference solution','Verification']))
    difficulty=readme.split('## Difficulty\n',1)[1].split('\n## ',1)[0]
    check('no experimental rates in difficulty', re.search(r'\b\d+\s*/\s*\d+\b|pass rate|success rate',difficulty+' '+m['difficulty_explanation'],re.I) is None)
    check('practitioner and synthetic disclosure', all(x in m['difficulty_explanation'].lower() for x in ['proof engineers','synthetic']))
    for folder in ['environment','tests']:
        docker=(root/folder/'Dockerfile').read_text()
        check(folder+' pinned base', re.search(r'^FROM [^\n]+@sha256:[0-9a-f]{64}$',docker,re.M) is not None)
        check(folder+' has no platform override', 'FROM --platform' not in docker)
        check(folder+' creates output directory', 'mkdir -p /app/output' in docker)
    check('public copied files exclude answers', all('solution' not in x and '/tests' not in x for x in
          (root/'environment/Dockerfile').read_text().splitlines() if x.startswith('COPY ')))
    req=(root/'tests/requirements.txt').read_text()
    check('mandated pytest versions', 'pytest==8.4.1 ' in req and 'pytest-json-ctrf==0.3.5 ' in req)
    check('no runtime installation', re.search(r'\b(?:pip|uv|apt-get)\s+install\b',(root/'tests/test.sh').read_text()) is None)
    check('executable entrypoints', all((root/p).stat().st_mode&0o111 for p in ['tests/test.sh','solution/solve.sh']))
    check('copies of public specification match', all((root/'environment/data'/p).read_bytes()==(root/'tests/data'/p).read_bytes()
          for p in ['Spec.lean','QuotientSpec.lean','Task.lean']))
    check('copies of setup tooling match', all((root/'environment/tooling'/p).read_bytes()==(root/'tests/tooling'/p).read_bytes()
          for p in ['setup-toolchain.py','setup-build.py','setup-dependencies.json']))
    blocked=['after'+'query','kep'+'ler']
    hits=[]
    for p in root.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts:
            continue
        try: content=p.read_text()
        except UnicodeError: continue
        if p==root/'task.toml': content=content.replace(task['task']['name'],'')
        if any(x in content.lower() for x in blocked): hits.append(str(p.relative_to(root)))
    check('no blocked provenance terms beyond mandatory task namespace', not hits)
    return {'all_passed':True,'check_count':len(checks),'checks':checks,
            'scope':'Visible structural checks and local clarity checks; official quality, author eligibility, originality and difficulty gates remain unverified.',
            'file_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in required}}


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=validate(args.root)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'all_passed':True,'checks':result['check_count']}))
