#!/usr/bin/env python3
"""Recheck a fresh archive extraction against the exact formal specification."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import time
import zipfile


def check_manifest(root):
    manifest=root/'authoring/MANIFEST.sha256'
    expected={}
    for line in manifest.read_text().splitlines():
        digest,name=line.split('  ',1)
        assert name not in expected
        expected[name]=digest
    actual={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file() and p!=manifest}
    assert expected==actual, 'archive manifest mismatch'
    return len(expected)


def validate(args):
    root=args.extract_to.resolve();evidence=args.evidence.resolve()
    assert not root.exists(), 'fresh extraction directory required'
    root.mkdir(parents=True);evidence.mkdir(parents=True,exist_ok=True)
    report={'archive':args.archive.name,'bytes':args.archive.stat().st_size,
            'sha256':hashlib.sha256(args.archive.read_bytes()).hexdigest(),'checks':[]}
    with zipfile.ZipFile(args.archive) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist())==len(set(archive.namelist()))
        for item in archive.infolist():
            name=PurePosixPath(item.filename)
            assert not name.is_absolute() and '..' not in name.parts
            assert stat.S_IFMT(item.external_attr>>16)==stat.S_IFREG
            dest=root.joinpath(*name.parts);dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(archive.read(item));dest.chmod((item.external_attr>>16)&0o777)
    report['manifest_files_before']=check_manifest(root)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    public=evidence/'public';shutil.copytree(root/'environment/data',public)
    env['LEAN_PATH']=str(public)+':'+str(args.library.resolve())
    env['PATH']=str(args.lean_bin.resolve())+':'+env.get('PATH','')
    def run(name,command,cwd=root):
        start=time.monotonic()
        with (evidence/(name+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
        row={'name':name,'exit_status':result.returncode,'seconds':time.monotonic()-start}
        report['checks'].append(row);print(json.dumps(row),flush=True)
        assert result.returncode==0, name
    try:
        run('static',[sys.executable,'-B','authoring/evidence/static_validate.py','--output',str(evidence/'static_results.json')])
        lean=str(args.lean_bin.resolve()/'lean')
        for name in ['Spec','QuotientSpec','Task']:
            run('public_'+name,[lean,'--root='+str(public),'-o',str(public/(name+'.olean')),str(public/(name+'.lean'))])
        source=evidence/'Proof.lean';shutil.copy2(root/'solution/Proof.lean',source)
        run('reference',[lean,'--root='+str(evidence),'-o',str(evidence/'Proof.olean'),str(source)])
        checker=evidence/'Verify.lean';shutil.copy2(root/'tests/Verify.lean',checker)
        run('checker_compile',[lean,'--root='+str(evidence),'-c',str(evidence/'Verify.c'),str(checker)])
        run('checker_link',[str(args.lean_bin.resolve()/'leanc'),'-O3','-o',str(evidence/'verify'),str(evidence/'Verify.c')])
        run('kernel_replay',[str(evidence/'verify'),str(evidence/'Proof.olean')])
        run('independent_algebra',[sys.executable,'-B','authoring/evidence/independent_algebra.py','--output',str(evidence/'independent_algebra_results.json')])
        # Container images are built from this exact archive extraction.
        container_command=[sys.executable,'-B','authoring/evidence/container_validate.py','--evidence',str(evidence/'containers')]
        if args.toolchain_image:
            container_command += ['--toolchain-image',args.toolchain_image]
        run('containers',container_command)
        report['manifest_files_after']=check_manifest(root)
        report['extracted_sources_unchanged']=True
        report['status']='passed technical release validation'
    except BaseException as exc:
        report['status']='failed';report['error']=repr(exc)
        raise
    finally:
        (evidence/'release_validation.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--archive',type=Path,required=True)
    parser.add_argument('--extract-to',type=Path,required=True)
    parser.add_argument('--evidence',type=Path,required=True)
    parser.add_argument('--lean-bin',type=Path,required=True)
    parser.add_argument('--library',type=Path,required=True)
    parser.add_argument('--toolchain-image',help='Optional previously validated local toolchain image; default builds pinned sources.')
    validate(parser.parse_args())
