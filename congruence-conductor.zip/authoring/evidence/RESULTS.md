# Validation results

The delivered task requires a Lean proof of the full parameterized statement. These are actual local results, not official platform scores or model difficulty trials.

| Check | Observed result |
| --- | --- |
| Reference proof compilation | Passed; 12.81 seconds on the local pinned toolchain |
| Independent kernel replay | Passed; 30 declarations and 3,788 dependencies |
| Separate solver and verifier containers | Passed with network disabled, 2 CPUs and 4 GiB each |
| Reference reward | 1; verifier container completed in 19.30 seconds |
| Empty submission reward | 0; expected failing test and nonzero exit |
| Actual-container controls | All 8 matched their expected outcomes |
| Generic kernel controls | 9 valid variants accepted and 16 invalid variants rejected |
| Independent exact algebra controls | All 200 parameter cases passed |
| Visible structure and clarity checks | All 88 checks passed |

`containers/container_results.json` records image identifiers, commands, public-file hashes, timings and CTRF summaries. `container-controls/results.json` and its per-case directories contain the complete outcomes for the reference, equivalent proof assembly, unfinished proof, unused new axiom, weakened statement, denied permission attempts, detached-process cleanup and native-only proof computation. Invalid mathematical controls reached the checker and were rejected for their intended proof defects.

The permission probe ran as UID 65532 with no supplementary groups and no-new-privileges enabled. Attempts to change the trusted source, compiled specification, search path and reward, and to read the private verifier, were denied. Trusted-file hashes remained unchanged. No compiler-user process survived verification, including the deliberately detached child process.

`kernel-controls/` tests the same kernel-checker source against a small independent fixture, including forged theorem bodies, circular dependencies, altered constructors and recursors, malformed tables and valid alternative representations. These controls test checker behavior; they do not measure task difficulty. `independent_algebra.py` separately uses Eisenstein-pair arithmetic, full basis multiplication and Smith normal form. Its finite controls supplement the general Lean proof and are not a replacement for it.

## Build and release evidence

A clean Docker build downloaded the pinned Lean binary release and compiled all 1,335 required library modules from pinned sources. Its library-setup step took 1,699.3 seconds; `clean_source_build.log` records the complete build. No compiled-cache service was used.

Docker's VFS driver initially exhausted disk space by copying the large toolchain through successive layers. The final Dockerfiles put that tree into one final filesystem layer. For the final local image builds, the already validated tree was recovered from the earlier image and reused through `TOOLCHAIN_IMAGE`; `toolchain_reuse.json` records both image identifiers and hashes. Default builds still download pinned sources and compile the library modules independently. The first isolated verifier attempt exposed unreadable toolchain permissions; the final image fixes ownership and read/execute permissions and passed the reference and permission controls.

The release validator extracts the ZIP into a new directory, checks every manifest entry, recompiles the public specification and reference, builds and runs the independent kernel checker, reruns the exact algebra controls, and builds and tests the separate containers from the extracted source. The final archive hash and the results of this last extraction check are supplied alongside the ZIP in `congruence-conductor-validation.json`.

## Scope and difficulty limits

The scope repair is substantive: the artifact is a proof-assistant-checked theorem in formal mathematics. The instruction uses spaced inline mathematics, blank lines around displays, plain prose, and a fixed public proposition without a procedural solution recipe. The difficulty descriptions identify proof engineers and explain the synthetic setting without experimental pass rates.

No fresh solver calibration was run on this replacement. Claude Opus 5-5 was not available, and no claim that it is stumped or that a target success rate is met is supported. Earlier arithmetic-geometry task results do not measure this task. Official quality approval, private originality checks, author eligibility and the author's required final review remain unverified. The general reference proof and the tested verification behavior are established by the evidence above.

## Artifact-directory packaging correction

The verifier Dockerfile now contains the standalone command `RUN mkdir -p /app/output` in its final stage so the artifact-parent structural check can recognize it. The image rebuilt successfully. A proof was copied into `/app/output/Proof.lean` before the fresh offline container started, and verification returned reward 1 with one passing test in 17.42 seconds. `artifact-parent-fix/` contains the build log, upload result, CTRF and verifier logs. The mathematical specification, reference proof and verifier code are unchanged; the earlier general controls remain evidence for that unchanged code.
