#!/usr/bin/env python3
"""Independent exact basis checks; these finite controls are not a general proof."""
import argparse
import itertools
import json
import math
from pathlib import Path


def emul(z, w):
    r, s = z
    t, u = w
    return (r*t-s*u, r*u+s*t-s*u)


def eadd(z, w):
    return tuple(a+b for a,b in zip(z,w))


def econj(z):
    return (z[0]-z[1], -z[1])


def mul(v, w, d):
    scalar = emul(v[:2], w[:2])
    a, b, A, B = v[3:5], v[5:7], w[3:5], w[5:7]
    qscalar = eadd(emul(a,A), tuple(d*x for x in emul(b,econj(B))))
    qskew = eadd(emul(a,B), emul(b,econj(A)))
    return (*scalar, v[2]*w[2], *qscalar, *qskew)


def in_order(v, n, h):
    x,y,t,a,b,c,e = v
    return (t-x-y)%3 == 0 and (a-x)%n == 0 and (b-y)%n == 0 and c%h == 0 and e%h == 0


def check():
    from sympy import Matrix, ZZ
    from sympy.matrices.normalforms import smith_normal_form
    standard = [tuple(int(i==j) for i in range(7)) for j in range(7)]
    records = []
    for n,h,d in itertools.product([3,6,9,12,18], [1,2,3,4,7], [-6,-2,-1,0,1,2,3,6]):
        basis = [(1,0,1,1,0,0,0), (0,1,1,0,1,0,0), (0,0,3,0,0,0,0),
                 (0,0,0,n,0,0,0), (0,0,0,0,n,0,0), (0,0,0,0,0,h,0), (0,0,0,0,0,0,h)]
        closed = all(in_order(mul(v,w,d),n,h) for v in basis for w in basis)
        assert closed == (d*h*h%n == 0)
        a = math.lcm(n,h)
        k = n//math.gcd(n,d*h)
        b = h*k
        diagonal = [n,n,3,a,a,b,b]
        # This universal test on the integer basis is exact: the product is
        # bilinear in the two multipliers. It does not import reference code.
        samples = basis + standard + [tuple(t*(i+1) for i in range(7)) for t in range(-6,7)]
        for j in range(7):
            for t in range(-2,3):
                samples.append(tuple(t*diagonal[j] if i==j else 0 for i in range(7)))
        for v in samples:
            via_all_basis = all(in_order(mul(mul(l,v,d),r,d),n,h) for l in standard for r in standard)
            formula = all(v[i]%diagonal[i] == 0 for i in range(7))
            assert via_all_basis == formula, (n,h,d,v)
        order_matrix = Matrix.hstack(*(Matrix(v) for v in basis))
        conductor_matrix = Matrix.diag(*diagonal)
        coordinates = order_matrix.inv()*conductor_matrix
        assert all(x.q==1 for x in coordinates)
        snf = smith_normal_form(coordinates, domain=ZZ)
        factors = [abs(int(snf[i,i])) for i in range(7) if abs(snf[i,i])>1]
        expected = [x for x in [k,k,a,a] if x>1]
        assert factors == expected, (n,h,d,factors,expected)
        records.append({'N':n,'h':h,'d':d,'closed':closed,'scalar_modulus':a,
                        'skew_modulus':k,'invariant_factors':factors})
    return {'method':'independent Eisenstein-pair arithmetic, full basis multiplication, and Smith form',
            'scope':'finite exact controls only; the Lean theorem establishes the general statement',
            'parameter_cases':len(records),'all_passed':True,'records':records}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    result = check()
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='records'}))
