namespace OrderTask
def ExpectedType : Prop := ∀ n : Nat, n + 0 = n
end OrderTask
