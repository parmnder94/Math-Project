import Lean
open Lean

/-- Author-side negative controls create well-formed containers with forged
declarations. No code from this file is part of the trusted verifier. -/
def main (args : List String) : IO UInt32 := do
  if args.length != 3 then throw <| IO.userError "Forge input.olean output.olean case"
  let (mod, _) ← readModuleData args[0]!
  let variant := args[2]!
  let mut data := mod
  if variant == "kernel_false_body" then
    data := { data with constants := data.constants.map (fun ci =>
      if let .thmInfo t := ci then
        if t.name == `OrderTask.solution then .thmInfo { t with value := mkConst ``True.intro }
        else ci
      else ci) }
  else if variant == "circular_proof" then
    data := { data with constants := data.constants.map (fun ci =>
      if let .thmInfo t := ci then
        if t.name == `OrderTask.solution then .thmInfo { t with value := mkConst `OrderTask.solution }
        else ci
      else ci) }
  else if variant == "trusted_collision" then
    let ci : ConstantInfo := .thmInfo {
      name := `OrderTask.ExpectedType, levelParams := [], type := mkSort .zero,
      value := mkConst ``False }
    data := { data with
      constNames := data.constNames.push ci.name
      constants := data.constants.push ci }
  else if variant == "unchecked_unused_lemma" then
    let ci : ConstantInfo := .thmInfo {
      name := `unusedFalseProof, levelParams := [], type := mkConst ``False,
      value := mkConst ``True.intro }
    data := { data with
      constNames := data.constNames.push ci.name
      constants := data.constants.push ci }
  else if variant == "mismatched_name" then
    data := { data with constNames := data.constNames.set! 0 `Fake }
  else if variant == "mismatched_table_length" then
    data := { data with constNames := data.constNames.push `Fake }
  else if variant == "altered_constructor" then
    data := { data with constants := data.constants.map (fun ci =>
      if let .ctorInfo c := ci then .ctorInfo { c with numFields := c.numFields + 1 }
      else ci) }
  else if variant == "altered_recursor" then
    data := { data with constants := data.constants.map (fun ci =>
      if let .recInfo r := ci then .recInfo { r with numParams := r.numParams + 1 }
      else ci) }
  else if variant == "ignored_imports" then
    data := { data with imports := #[{ module := `ThisModuleDoesNotExist }] }
  else throw <| IO.userError s!"unknown variant {variant}"
  saveModuleData args[1]! `Proof data
  return 0
