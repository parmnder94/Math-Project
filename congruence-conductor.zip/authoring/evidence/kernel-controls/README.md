# Kernel replay controls

This directory tests the task's actual `Verify.lean` program against a small
independent fixture proposition, `forall n : Nat, n + 0 = n`. It does not claim
that the fixture measures the mathematical task's difficulty.

Run with pinned Lean 4.19.0:

```sh
python3 controls.py --lean-bin /path/to/lean-4.19.0-linux/bin
```

The script builds its own fixture modules and native checker/forge programs.
Its output is `control_results.json`. All 25 controls passed in the recorded
run: nine mathematically valid variants were accepted and sixteen invalid
variants were rejected. The native checker alone took approximately 0.1–0.5 s
per fixture across runs; this is not a timing claim for a full Mathlib task.

The controls cover valid direct, simplification, helper, inductive and opaque
proofs; a locally declared tactic macro; unused compiler-only unsafe/partial declarations; omitted and incorrect
target theorems; `sorry`; used and unused new axioms; native evaluation;
universe parameters; a forged theorem body; a self-referential proof; an unused
invalid theorem; collision with a trusted task declaration; mismatched names
and constant tables; altered constructor and recursor metadata; and a bogus
import list that is safely ignored.

`Forge.lean` intentionally writes well-formed object containers containing
forged declarations. It is author-side test code and is never part of the
trusted verifier binary.

## Acceptance boundary

`Verify.lean` imports only the fixed trusted `Task` module, with extension
initialization and plugins disabled. It reads the submitted object's constant
table without importing the object's modules or initializing its extensions.
It rejects every new axiom, every collision with a trusted name, and malformed
name tables. A preflight dependency walk follows declaration types and bodies
through both the new constants and pinned libraries. Only `propext`,
`Classical.choice`, and `Quot.sound` may occur as axioms; native reduction hooks
are rejected before the kernel can invoke their interpreter.

Lean 4.19's built-in `Environment.replay` reconstructs all safe declarations
and sends them to the kernel. It regenerates inductive declarations and
compares stored constructors and recursors with the regenerated objects.
Unsafe and partial compiler-only declarations are not installed in the
reconstructed environment. Ordinary inductives generate some such helpers,
so rejecting every helper would incorrectly reject valid proofs. No safe proof
may rely on an ignored declaration.

Finally, the checker constructs a new theorem whose exact type is the trusted
`OrderTask.ExpectedType` and whose body is `OrderTask.solution`. Kernel checking
of this new theorem establishes the expected type independently of source
notation, elaborator state or printed output.

The operating-system wrapper must compile source under a separate unprivileged
UID, terminate and reap all processes of that UID, then copy a bounded regular
object file into root-only storage before invoking the trusted checker. Search
paths, task objects, checker binary and library files must be immutable to the
compiler UID. The checker does not execute submitted tactic code or object-file
initializers. Security relies on the supplied OS/container isolation, pinned
Lean kernel and object-file decoder; these tests do not prove the absence of
native implementation vulnerabilities.
