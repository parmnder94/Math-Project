#!/usr/bin/env python3
"""Small reproducible acceptance controls against the trusted replay checker."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent

CASES = {
    'valid_rfl': (True, 'theorem OrderTask.solution : OrderTask.ExpectedType := by intro n; rfl'),
    'valid_simp': (True, 'theorem OrderTask.solution : OrderTask.ExpectedType := by intro n; simp'),
    'valid_helper': (True, 'theorem help (n : Nat) : n + 0 = n := rfl\ntheorem OrderTask.solution : OrderTask.ExpectedType := help'),
    'valid_inductive': (True, 'inductive Bits where | zero | one\ntheorem OrderTask.solution : OrderTask.ExpectedType := by intro n; cases Bits.zero <;> rfl'),
    'valid_opaque': (True, 'opaque auxiliary : True := True.intro\ntheorem OrderTask.solution : OrderTask.ExpectedType := by intro n; rfl'),
    'valid_local_tactic_macro': (True, 'syntax "tiny" : tactic\nmacro_rules\n  | `(tactic| tiny) => `(tactic| rfl)\ntheorem OrderTask.solution : OrderTask.ExpectedType := by intro n; tiny'),
    'sorry': (False, 'theorem OrderTask.solution : OrderTask.ExpectedType := by sorry'),
    'new_axiom_used': (False, 'axiom fake : OrderTask.ExpectedType\ntheorem OrderTask.solution : OrderTask.ExpectedType := fake'),
    'new_axiom_unused': (False, 'axiom fake : False\ntheorem OrderTask.solution : OrderTask.ExpectedType := by intro n; rfl'),
    'wrong_type': (False, 'theorem OrderTask.solution : True := True.intro'),
    'missing': (False, 'theorem unrelated : True := True.intro'),
    'definition_only': (False, 'def OrderTask.solution : OrderTask.ExpectedType := by intro n; rfl'),
    'unsafe_unused': (True, 'unsafe def auxiliary : Nat := 1\ntheorem OrderTask.solution : OrderTask.ExpectedType := by intro n; rfl'),
    'partial_unused': (True, 'partial def auxiliary (n : Nat) : Nat := auxiliary n\ntheorem OrderTask.solution : OrderTask.ExpectedType := by intro n; rfl'),
    'native_decide_unused': (False, 'theorem native : 2 + 2 = 4 := by native_decide\ntheorem OrderTask.solution : OrderTask.ExpectedType := by intro n; rfl'),
    'universe': (False, 'theorem OrderTask.solution.{u} : ∀ _ : Sort u, OrderTask.ExpectedType := by intros x n; rfl'),
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lean-bin', type=Path, help='Directory containing the pinned lean and leanc binaries')
    args = parser.parse_args()
    LEAN = args.lean_bin or Path(shutil.which('lean') or '/missing/lean').parent
    ENV = os.environ | {'PATH': str(LEAN) + ':' + os.environ['PATH'], 'LEAN_PATH': str(ROOT)}
    for module in ['Spec', 'Task', 'Verify', 'Forge']:
        command = [str(LEAN/'lean'), '-o', str(ROOT/f'{module}.olean')]
        if module in ['Verify', 'Forge']:
            command += ['-c', str(ROOT/f'{module}.c')]
        subprocess.run(command+[str(ROOT/f'{module}.lean')], cwd=ROOT, env=ENV, check=True)
        if module in ['Verify', 'Forge']:
            subprocess.run([str(LEAN/'leanc'), '-o', str(ROOT/module.lower()), str(ROOT/f'{module}.c')], cwd=ROOT, env=ENV, check=True)
    results = []
    for label, (expected, source) in CASES.items():
        path = ROOT / 'Controls' / label
        path.mkdir(parents=True, exist_ok=True)
        proof = path / 'Proof.lean'
        olean = path / 'Proof.olean'
        proof.write_text('import Task\n' + source + '\n')
        start = time.monotonic()
        compile_result = subprocess.run([str(LEAN/'lean'), '-o', str(olean), str(proof)], env=ENV, text=True, capture_output=True)
        if compile_result.returncode == 0:
            check = subprocess.run([str(ROOT/'verify'), str(olean)], env=ENV, text=True, capture_output=True)
            accepted = check.returncode == 0
            output = check.stdout + check.stderr
        else:
            accepted = False
            output = compile_result.stdout + compile_result.stderr
        results.append({'case':label, 'expected_accept':expected, 'compile_exit':compile_result.returncode, 'actual_accept':accepted, 'matched':expected == accepted, 'seconds':round(time.monotonic()-start, 4), 'output':output.strip()})
    for label in ['kernel_false_body', 'circular_proof', 'trusted_collision',
                  'unchecked_unused_lemma', 'mismatched_name', 'mismatched_table_length',
                  'altered_constructor', 'altered_recursor', 'ignored_imports']:
        expected = label == 'ignored_imports'
        original = ROOT/'Controls'/('valid_inductive' if label.startswith('altered_') else 'valid_rfl')/'Proof.olean'
        altered = ROOT/'Controls'/f'{label}.olean'
        subprocess.run([str(ROOT/'forge'), str(original), str(altered), label], env=ENV, check=True)
        start = time.monotonic()
        check = subprocess.run([str(ROOT/'verify'), str(altered)], env=ENV, text=True, capture_output=True)
        accepted = check.returncode == 0
        results.append({'case':label, 'expected_accept':expected, 'actual_accept':accepted, 'matched':expected==accepted,
                        'seconds':round(time.monotonic()-start, 4), 'output':(check.stdout+check.stderr).strip()})
    (ROOT/'control_results.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps({'passed':sum(r['matched'] for r in results), 'total':len(results), 'results':results}, indent=2))
    if not all(r['matched'] for r in results):
        raise SystemExit(1)

if __name__ == '__main__':
    main()
