import Lean.Replay
import Lean.Util.FoldConsts

open Lean

def standardAxioms : NameSet :=
  [``propext, ``Classical.choice, ``Quot.sound].foldl NameSet.insert {}

/-- Follow both types and bodies, including constants in the pinned library. -/
def checkAxioms (env : Environment) (newConstants : Std.HashMap Name ConstantInfo)
    (todo : List Name)
    (seen : NameSet := {}) : IO NameSet := do
  let mut pending := todo
  let mut visited := seen
  while !pending.isEmpty do
    let n := pending.head!
    pending := pending.tail!
    if !visited.contains n then
      if n == ``Lean.reduceBool || n == ``Lean.reduceNat then
        throw <| IO.userError s!"forbidden native reduction: {n}"
      let some ci := newConstants[n]? <|> env.find? n
        | throw <| IO.userError s!"unknown dependency: {n}"
      if ci.isUnsafe || ci.isPartial then
        throw <| IO.userError s!"unsafe or partial dependency: {n}"
      if let .axiomInfo _ := ci then
        unless standardAxioms.contains n do
          throw <| IO.userError s!"forbidden axiom: {n}"
      pending := ci.getUsedConstantsAsSet.toList ++ pending
      visited := visited.insert n
  return visited

def main (args : List String) : IO UInt32 := do
  try
    unless args.length == 1 do
      throw <| IO.userError "usage: verify /absolute/path/Proof.olean"
    initSearchPath (← findSysroot)
    -- Only a fixed, trusted import is resolved. In particular, nothing from
    -- the submitted module's import list or extension payload is initialized.
    let base ← importModules #[{ module := `Task }] {} 0 #[] false false
    let (mod, _) ← readModuleData args.head!
    unless mod.constNames.size == mod.constants.size do
      throw <| IO.userError "malformed constant table"
    let mut newConstants : Std.HashMap Name ConstantInfo := {}
    for n in mod.constNames, ci in mod.constants do
      unless n == ci.name do
        throw <| IO.userError "mismatched constant name"
      if base.contains n || newConstants.contains n then
        throw <| IO.userError s!"duplicate or trusted-name collision: {n}"
      -- Lean generates unsafe compiler-only helpers even for ordinary safe
      -- inductives. Replay deliberately never installs these; any safe proof
      -- depending on them consequently fails the independent kernel check.
      if let .axiomInfo _ := ci then
        throw <| IO.userError s!"new axiom: {n}"
      if let .quotInfo _ := ci then
        throw <| IO.userError s!"new quotient primitive: {n}"
      newConstants := newConstants.insert n ci
    unless newConstants.contains `OrderTask.solution do
      throw <| IO.userError "required theorem OrderTask.solution is absent"
    let checked := newConstants.toList.filter fun (_, ci) => !ci.isUnsafe && !ci.isPartial
    -- Audit first, before any replay can trigger Lean's native reduction hook.
    let deps ← checkAxioms base newConstants (checked.map Prod.fst)
    let env ← base.replay newConstants
    let some (.thmInfo answer) := env.find? `OrderTask.solution
      | throw <| IO.userError "OrderTask.solution must be a theorem"
    unless answer.levelParams.isEmpty do
      throw <| IO.userError "OrderTask.solution must have no universe parameters"
    -- This new declaration is built by the trusted checker, not the submitted
    -- frontend, so kernel type checking fixes the task's actual proposition.
    let finalDecl : Declaration := .thmDecl {
      name := `__TaskKernelCheckedAnswer
      levelParams := []
      type := mkConst `OrderTask.ExpectedType
      value := mkConst `OrderTask.solution
    }
    match env.addDeclCore 0 finalDecl none with
      | .ok _ => pure ()
      | .error e => throw <| IO.userError (← e.toMessageData {} |>.toString)
    IO.println s!"PASS: replayed {checked.length} declarations; checked {deps.size} dependencies"
    return (0 : UInt32)
  catch e =>
    IO.eprintln s!"REJECT: {e}"
    return (1 : UInt32)
