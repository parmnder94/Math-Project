import Task


namespace Conductor

lemma point_surjective {d : ℤ} (v : Ambient d) :
    ∃ x y n a b c e : ℤ, point d x y n a b c e = v := by
  rcases v with ⟨⟨⟨x,y,u,v⟩, huv⟩, n, ⟨a,b,c,e⟩⟩
  rcases huv with ⟨hu,hv⟩
  change u = 0 at hu
  change v = 0 at hv
  subst u
  subst v
  exact ⟨x,y,n,a,b,c,e,rfl⟩

@[simp] lemma inOrder_point (N h d x y n a b c e : ℤ) :
    InOrder N h (point d x y n a b c e) ↔
    3 ∣ n-x-y ∧ N ∣ a-x ∧ N ∣ b-y ∧ h ∣ c ∧ h ∣ e := Iff.rfl

@[simp] lemma coords_point (N h d x y n a b c e : ℤ) :
    ConductorCoordinates N h (point d x y n a b c e) ↔
    N∣x ∧ N∣y ∧ 3∣n ∧ N∣a ∧ N∣b ∧ h∣a ∧ h∣b ∧
      h∣c ∧ h∣e ∧ N∣d*c ∧ N∣d*e := Iff.rfl

lemma point_mul (d x y n a b c e X Y m A B C E : ℤ) :
    point d x y n a b c e * point d X Y m A B C E =
    point d (x*X-y*Y) (x*Y+y*X-y*Y) (n*m)
      (a*A-b*B+d*c*C-d*c*E+d*e*E)
      (a*B+b*A-b*B-d*c*E+d*e*C)
      (a*C-b*E+c*A-c*B+e*B)
      (a*E+b*C-b*E-c*B+e*A) := by
  apply Prod.ext
  · apply Subtype.ext
    ext <;> simp [point,eisenstein] <;> ring
  · apply Prod.ext
    · rfl
    · ext <;> simp [point,eisenstein] <;> ring

lemma point_one (d : ℤ) : point d 1 0 1 1 0 0 0 = 1 := rfl

syntax "divs" : tactic
macro_rules
  | `(tactic| divs) => `(tactic|
    first
    | assumption
    | exact dvd_zero _
    | apply dvd_add <;> divs
    | apply dvd_sub <;> divs
    | apply dvd_neg.mpr <;> divs
    | apply dvd_mul_of_dvd_left <;> divs
    | apply dvd_mul_of_dvd_right <;> divs)

theorem closure_reference : ClosureStatement := by
  intro N h d hN hh h3
  constructor
  · intro hclosed
    have hmem : InOrder N h (point d 0 0 0 0 0 h 0) := by simp
    have hsq := hclosed _ _ hmem hmem
    simpa [point_mul, point, eisenstein, pow_two, mul_assoc] using hsq.2.1
  · intro hd v w hv hw
    obtain ⟨x,y,n,a,b,c,e,rfl⟩ := point_surjective v
    obtain ⟨X,Y,m,A,B,C,E,rfl⟩ := point_surjective w
    rcases hv with ⟨⟨t,ht⟩,⟨u,hu⟩,⟨v,hv⟩,⟨p,hp⟩,⟨q,hq⟩⟩
    rcases hw with ⟨⟨T,hT⟩,⟨U,hU⟩,⟨V,hV⟩,⟨P,hP⟩,⟨Q,hQ⟩⟩
    change n-x-y=3*t at ht
    change a-x=N*u at hu
    change b-y=N*v at hv
    change c=h*p at hp
    change e=h*q at hq
    change m-X-Y=3*T at hT
    change A-X=N*U at hU
    change B-Y=N*V at hV
    change C=h*P at hP
    change E=h*Q at hQ
    have hn : n=x+y+3*t := by linarith
    have hm : m=X+Y+3*T := by linarith
    have ha : a=x+N*u := by linarith
    have hb : b=y+N*v := by linarith
    have hA : A=X+N*U := by linarith
    have hB : B=Y+N*V := by linarith
    rcases hd with ⟨k,hk⟩
    simp only [point_mul, inOrder_point]
    rw [hn,hm,ha,hb,hA,hB,hp,hq,hP,hQ]
    refine ⟨?_,?_,?_,?_,?_⟩
    · refine ⟨y*Y+t*X+t*Y+x*T+y*T+3*t*T,?_⟩
      ring
    · refine ⟨x*U+u*X+N*u*U-y*V-v*Y-N*v*V+k*(p*P-p*Q+q*Q),?_⟩
      linear_combination (p*P-p*Q+q*Q)*hk
    · refine ⟨x*V+u*Y+N*u*V+y*U+v*X+N*v*U-y*V-v*Y-N*v*V+k*(-p*Q+q*P),?_⟩
      linear_combination (-p*Q+q*P)*hk
    · refine ⟨(x+N*u)*P-(y+N*v)*Q+p*(X+N*U)-p*(Y+N*V)+q*(Y+N*V),?_⟩
      ring
    · refine ⟨(x+N*u)*Q+(y+N*v)*P-(y+N*v)*Q-p*(Y+N*V)+q*(X+N*U),?_⟩
      ring

lemma coordinates_mul_left {N h d : ℤ} {v : Ambient d}
    (hv : ConductorCoordinates N h v) (w : Ambient d) :
    ConductorCoordinates N h (w*v) := by
  obtain ⟨x,y,n,a,b,c,e,rfl⟩ := point_surjective v
  obtain ⟨X,Y,m,A,B,C,E,rfl⟩ := point_surjective w
  rcases hv with ⟨hx,hy,hn,ha,hb,hha,hhb,hc,he,hdc,hde⟩
  simp only [point_mul,coords_point]
  refine ⟨?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_⟩
  all_goals try divs
  · have : A*a-B*b+d*C*c-d*C*e+d*E*e =
      A*a-B*b+(d*c)*C-(d*e)*C+(d*e)*E := by ring
    rw [this]
    divs
  · have : A*b+B*a-B*b-d*C*e+d*E*c =
      A*b+B*a-B*b-(d*e)*C+(d*c)*E := by ring
    rw [this]
    divs
  · have : d*(A*c-B*e+C*a-C*b+E*b) =
      A*(d*c)-B*(d*e)+(d*C)*a-(d*C)*b+(d*E)*b := by ring
    rw [this]
    divs
  · have : d*(A*e+B*c-B*e-C*b+E*a) =
      A*(d*e)+B*(d*c)-B*(d*e)-(d*C)*b+(d*E)*a := by ring
    rw [this]
    divs

lemma coordinates_mul_right {N h d : ℤ} {v : Ambient d}
    (hv : ConductorCoordinates N h v) (w : Ambient d) :
    ConductorCoordinates N h (v*w) := by
  obtain ⟨x,y,n,a,b,c,e,rfl⟩ := point_surjective v
  obtain ⟨X,Y,m,A,B,C,E,rfl⟩ := point_surjective w
  rcases hv with ⟨hx,hy,hn,ha,hb,hha,hhb,hc,he,hdc,hde⟩
  simp only [point_mul,coords_point]
  refine ⟨?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_⟩
  all_goals try divs
  · have : d*(a*C-b*E+c*A-c*B+e*B) =
      (d*a)*C-(d*b)*E+(d*c)*A-(d*c)*B+(d*e)*B := by ring
    rw [this]
    divs
  · have : d*(a*E+b*C-b*E-c*B+e*A) =
      (d*a)*E+(d*b)*C-(d*b)*E-(d*c)*B+(d*e)*A := by ring
    rw [this]
    divs

lemma coordinates_in_order {N h d : ℤ} (h3 : 3∣N) {v : Ambient d}
    (hv : ConductorCoordinates N h v) : InOrder N h v := by
  obtain ⟨x,y,n,a,b,c,e,rfl⟩ := point_surjective v
  rcases hv with ⟨hx,hy,hn,ha,hb,hha,hhb,hc,he,hdc,hde⟩
  have hx3 : 3∣x := h3.trans hx
  have hy3 : 3∣y := h3.trans hy
  simp only [inOrder_point]
  exact ⟨dvd_sub (dvd_sub hn hx3) hy3,dvd_sub ha hx,dvd_sub hb hy,hc,he⟩

theorem conductor_reference : ConductorStatement := by
  intro N h d hN hh h3 v
  constructor
  · intro hv
    obtain ⟨x,y,n,a,b,c,e,rfl⟩ := point_surjective v
    have he := hv (point d 1 0 0 0 0 0 0) 1
    have hn := hv (point d 0 0 1 0 0 0 0) 1
    have hq := hv (point d 0 0 0 1 0 0 0) 1
    have hj := hv (point d 0 0 0 0 0 1 0) 1
    simp only [mul_one,point_mul,inOrder_point] at he hn hq hj
    simp only [zero_mul,mul_zero,one_mul,mul_one,sub_zero,zero_sub,
      add_zero,zero_add,neg_zero] at he hn hq hj
    have hx : N∣x := dvd_neg.mp he.2.1
    have hy : N∣y := dvd_neg.mp he.2.2.1
    have ha : h∣a := by
      have hs : h∣a-b := hj.2.2.2.1
      have hb : h∣b := dvd_neg.mp hj.2.2.2.2
      convert dvd_add hs hb using 1; ring
    have hb : h∣b := dvd_neg.mp hj.2.2.2.2
    have hde : N∣d*e := dvd_neg.mp hj.2.2.1
    have hdc : N∣d*c := by
      have ht := dvd_add hj.2.1 hde
      convert ht using 1; ring
    exact ⟨hx,hy,hn.1,hq.2.1,hq.2.2.1,ha,hb,
      hq.2.2.2.1,hq.2.2.2.2,hdc,hde⟩
  · intro hv l r
    exact coordinates_in_order h3
      (coordinates_mul_right (coordinates_mul_left hv l) r)

end Conductor


namespace Conductor

theorem scalar_cast_zero_iff (N h a : ℤ) :
    (a : ZMod (scalarModulus N h)) = 0 ↔ N ∣ a ∧ h ∣ a := by
  rw [ZMod.intCast_zmod_eq_zero_iff_dvd]
  change (Int.lcm N h : ℤ) ∣ a ↔ _
  exact ⟨fun ha => ⟨dvd_trans Int.dvd_lcm_left ha,
    dvd_trans Int.dvd_lcm_right ha⟩, fun ha => Int.coe_lcm_dvd ha.1 ha.2⟩

theorem gcd_quotient_dvd_iff (N t k : ℤ) (hN : N ≠ 0) :
    N / (Int.gcd N t : ℤ) ∣ k ↔ N ∣ t * k := by
  let g : ℤ := Int.gcd N t
  have hg : g ≠ 0 := by
    change (Int.gcd N t : ℤ) ≠ 0
    exact_mod_cast (Int.gcd_pos_of_ne_zero_left t hN).ne'
  have hgN : g * (N / g) = N := Int.mul_ediv_cancel_of_dvd Int.gcd_dvd_left
  have hgt : g * (t / g) = t := Int.mul_ediv_cancel_of_dvd Int.gcd_dvd_right
  change N / g ∣ k ↔ _
  constructor
  · rintro ⟨r, rfl⟩
    refine ⟨(t / g) * r, ?_⟩
    calc
      t * (N / g * r) = (g * (t / g)) * (N / g * r) := by rw [hgt]
      _ = (g * (N / g)) * ((t / g) * r) := by ac_rfl
      _ = N * ((t / g) * r) := by rw [hgN]
  · intro hk
    have h₁ : N ∣ N * (Int.gcdA N t * k) := dvd_mul_right _ _
    have h₂ : N ∣ t * (Int.gcdB N t * k) := by
      convert dvd_mul_of_dvd_left hk (Int.gcdB N t) using 1
      ac_rfl
    have hgk : N ∣ g * k := by
      dsimp [g]
      rw [Int.gcd_eq_gcd_ab]
      convert Int.dvd_add h₁ h₂ using 1
      simp only [Int.add_mul, Int.mul_assoc]
    obtain ⟨r, hr⟩ := hgk
    refine ⟨r, Int.eq_of_mul_eq_mul_left hg ?_⟩
    calc
      g * k = N * r := hr
      _ = g * (N / g * r) := by rw [← mul_assoc, hgN]

theorem skew_cast_zero_iff (N h d c : ℤ) (hN : N ≠ 0) (hc : h ∣ c) :
    ((c / h : ℤ) : ZMod (skewModulus N h d)) = 0 ↔ N ∣ d * c := by
  rw [ZMod.intCast_zmod_eq_zero_iff_dvd]
  change ((N / (Int.gcd N (d * h) : ℤ)).natAbs : ℤ) ∣ c / h ↔ _
  rw [Int.natAbs_dvd, gcd_quotient_dvd_iff N (d * h) (c / h) hN]
  rw [mul_assoc, Int.mul_ediv_cancel_of_dvd hc]

def residueHom (N h d : ℤ) : orderGroup N h d →+ ResidueTarget N h d where
  toFun := residueCoordinates N h d
  map_zero' := by
    change (((↑(0 : ℤ), ↑(0 : ℤ)), (↑((0 : ℤ) / h), ↑((0 : ℤ) / h))) :
      ResidueTarget N h d) = 0
    simp
  map_add' := by
    intro v w
    refine Prod.ext (Prod.ext ?_ ?_) (Prod.ext ?_ ?_)
    · simp [residueCoordinates]
    · simp [residueCoordinates]
    · simp [residueCoordinates, Int.add_ediv_of_dvd_left v.property.2.2.2.1]
    · simp [residueCoordinates, Int.add_ediv_of_dvd_left v.property.2.2.2.2]

theorem residueHom_surjective (N h d : ℤ) (hh : h ≠ 0) :
    Function.Surjective (residueHom N h d) := by
  rintro ⟨⟨a, b⟩, ⟨c, e⟩⟩
  obtain ⟨a', ha⟩ := ZMod.intCast_surjective a
  obtain ⟨b', hb⟩ := ZMod.intCast_surjective b
  obtain ⟨c', hc⟩ := ZMod.intCast_surjective c
  obtain ⟨e', he⟩ := ZMod.intCast_surjective e
  have hv : InOrder N h (point d a' b' (a' + b') a' b' (h * c') (h * e')) := by
    simp [InOrder, point, eisenstein]
  refine ⟨⟨_, hv⟩, ?_⟩
  simp [residueHom, residueCoordinates, point, eisenstein,
    Int.mul_ediv_cancel_left _ hh, ha, hb, hc, he]

theorem residueHom_kernel_coordinates (N h d : ℤ) (hN : N ≠ 0) (h₃ : 3 ∣ N)
    (v : orderGroup N h d) :
    residueHom N h d v = 0 ↔ ConductorCoordinates N h v.val := by
  have hv := v.property
  change InOrder N h v.val at hv
  rcases hv with ⟨hnxy, hax, hby, hhc, hhe⟩
  change (((↑v.val.2.2.re, ↑v.val.2.2.imI),
    (↑(v.val.2.2.imJ / h), ↑(v.val.2.2.imK / h))) : ResidueTarget N h d) =
    ((0, 0), (0, 0)) ↔ _
  simp only [Prod.mk.injEq, scalar_cast_zero_iff,
    skew_cast_zero_iff N h d _ hN hhc,
    skew_cast_zero_iff N h d _ hN hhe]
  constructor
  · rintro ⟨⟨⟨hNa, hha⟩, ⟨hNb, hhb⟩⟩, hdc, hde⟩
    have hNx : N ∣ v.val.1.val.re := by
      convert dvd_sub hNa hax using 1
      ring
    have hNy : N ∣ v.val.1.val.imI := by
      convert dvd_sub hNb hby using 1
      ring
    have hn : 3 ∣ v.val.2.1 := by
      convert dvd_add (dvd_add hnxy (dvd_trans h₃ hNx)) (dvd_trans h₃ hNy) using 1
      ring
    exact ⟨hNx, hNy, hn, hNa, hNb, hha, hhb, hhc, hhe, hdc, hde⟩
  · rintro ⟨_, _, _, hNa, hNb, hha, hhb, _, _, hdc, hde⟩
    exact ⟨⟨⟨hNa, hha⟩, ⟨hNb, hhb⟩⟩, hdc, hde⟩

theorem quotient_statement (hc : ConductorStatement) : QuotientStatement := by
  intro N h d hN hh h₃
  refine ⟨residueHom N h d, fun _ => rfl,
    residueHom_surjective N h d hh.ne', ?_⟩
  intro v
  exact (residueHom_kernel_coordinates N h d hN.ne' h₃ v).trans
    (hc N h d hN hh h₃ v.val).symm

end Conductor


theorem OrderTask.solution : OrderTask.ExpectedType :=
  ⟨Conductor.closure_reference, Conductor.conductor_reference,
    Conductor.quotient_statement Conductor.conductor_reference⟩

axiom anUnusedFalseAxiom : False
