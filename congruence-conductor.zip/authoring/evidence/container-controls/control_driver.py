
import hashlib,json,os,subprocess,sys
from pathlib import Path

def hashes():
    paths = ['/app/data/Spec.lean','/app/data/Spec.olean',
             '/app/data/QuotientSpec.lean','/app/data/QuotientSpec.olean',
             '/app/data/Task.lean','/app/data/Task.olean',
             '/opt/formal/lean-path.txt','/tests/verify',
             '/tests/check_submission.py','/tests/test.sh']
    return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}

def compiler_processes():
    found=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            lines=(p/'status').read_text().splitlines()
            uids=next(s for s in lines if s.startswith('Uid:')).split()[1:]
            if '65532' in uids: found.append(int(p.name))
        except (FileNotFoundError,ProcessLookupError): pass
    return found

Path('/app/output').mkdir(parents=True,exist_ok=True)
Path('/logs').mkdir(parents=True,exist_ok=True)
source=Path('/control_Proof.lean').read_text().replace('__BOUNDARY_PYTHON__',sys.executable)
Path('/app/output/Proof.lean').write_text(source)
report={'trusted_before':hashes(),'compiler_before':compiler_processes(),
        'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
        'python':sys.executable}
p=subprocess.run(['/bin/bash','/tests/test.sh'])
report.update(test_sh_exit=p.returncode,trusted_after=hashes(),
              compiler_after=compiler_processes())
Path('/logs/boundary_driver.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(p.returncode)
