#!/usr/bin/env python3
"""Exercise the actual verifier wrapper in eight fresh, isolated containers.

No reference proof is built into the verifier image. This author-side script
copies one source artifact per fresh container and records actual reward,
CTRF, process, permission and immutable-file evidence.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time
import uuid


DRIVER = r'''
import hashlib,json,os,subprocess,sys
from pathlib import Path

def hashes():
    paths = ['/app/data/Spec.lean','/app/data/Spec.olean',
             '/app/data/QuotientSpec.lean','/app/data/QuotientSpec.olean',
             '/app/data/Task.lean','/app/data/Task.olean',
             '/opt/formal/lean-path.txt','/tests/verify',
             '/tests/check_submission.py','/tests/test.sh']
    return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}

def compiler_processes():
    found=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            lines=(p/'status').read_text().splitlines()
            uids=next(s for s in lines if s.startswith('Uid:')).split()[1:]
            if '65532' in uids: found.append(int(p.name))
        except (FileNotFoundError,ProcessLookupError): pass
    return found

Path('/app/output').mkdir(parents=True,exist_ok=True)
Path('/logs').mkdir(parents=True,exist_ok=True)
source=Path('/control_Proof.lean').read_text().replace('__BOUNDARY_PYTHON__',sys.executable)
Path('/app/output/Proof.lean').write_text(source)
report={'trusted_before':hashes(),'compiler_before':compiler_processes(),
        'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
        'python':sys.executable}
p=subprocess.run(['/bin/bash','/tests/test.sh'])
report.update(test_sh_exit=p.returncode,trusted_after=hashes(),
              compiler_after=compiler_processes())
Path('/logs/boundary_driver.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(p.returncode)
'''

PERMISSION_PROBE = r'''
import json,os,sys
from pathlib import Path
attempts={
 'write_spec_source':('write','/app/data/Spec.lean'),
 'write_spec_object':('write','/app/data/Spec.olean'),
 'write_search_path':('write','/opt/formal/lean-path.txt'),
 'read_private_verifier':('read','/tests/check_submission.py'),
 'write_reward':('write','/logs/verifier/reward.txt'),
}
result={}
for label,(operation,path) in attempts.items():
 try:
  if operation=='write':
   with open(path,'ab') as stream: stream.write(b'FORBIDDEN_WRITE')
  else:
   with open(path,'rb') as stream: stream.read(1)
 except PermissionError:
  result[label]='denied'
 except Exception as exc:
  result[label]='unexpected-error:'+type(exc).__name__
 else:
  result[label]='UNEXPECTED_ACCESS'
status=Path('/proc/self/status').read_text().splitlines()
result['uid']=os.getuid();result['euid']=os.geteuid()
result['groups']=os.getgroups()
result['no_new_privs']=int(next(s for s in status if s.startswith('NoNewPrivs:')).split()[1])
print('BOUNDARY_PERMISSION '+json.dumps(result),flush=True)
sys.exit(0 if all(result[label]=='denied' for label in attempts) and
         result['uid']==65532 and result['euid']==65532 and
         result['groups']==[] and result['no_new_privs']==1 else 2)
'''

LINGERING_PROBE = r'''
import json,os,subprocess,sys
p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(90)'],
                   stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL,start_new_session=True)
print('BOUNDARY_LINGER '+json.dumps({'pid':p.pid,'uid':os.getuid()}),flush=True)
'''


def io_command(program):
    return '\nrun_cmd do\n' + (
        '  let result ← Lean.Elab.Command.liftIO <| IO.Process.output\n'
        '    { cmd := "__BOUNDARY_PYTHON__", args := #["-c", '+json.dumps(program)+'] }\n'
        '  Lean.Elab.Command.liftIO <| IO.print result.stdout\n'
        '  if result.exitCode != 0 then throwError "boundary probe failed"\n'
    )


def variants(reference):
    prefix, marker, _ = reference.rpartition('theorem OrderTask.solution')
    if not marker:
        raise ValueError('reference has no final OrderTask.solution theorem')
    alternate = prefix + '''theorem OrderTask.solution : OrderTask.ExpectedType := by
  constructor
  · exact Conductor.closure_reference
  constructor
  · exact Conductor.conductor_reference
  · apply Conductor.quotient_statement
    exact Conductor.conductor_reference
'''
    return [
        ('reference', True, reference),
        ('equivalent_assembly', True, alternate),
        ('sorry', False, 'import Task\ntheorem OrderTask.solution : OrderTask.ExpectedType := by sorry\n'),
        ('unused_new_axiom', False, reference+'\naxiom anUnusedFalseAxiom : False\n'),
        ('weakened_statement', False, 'import Task\ntheorem OrderTask.solution : True := True.intro\n'),
        ('permission_attempts', True, 'import Lean.Elab.Command\n'+reference+io_command(PERMISSION_PROBE)),
        ('lingering_process', True, 'import Lean.Elab.Command\n'+reference+io_command(LINGERING_PROBE)),
        ('native_trust', False, reference+'\ntheorem unusedNativeProof : 2 + 2 = 4 := by native_decide\n'),
    ]


def run(command, *, timeout=240, check=True):
    p = subprocess.run(command, text=True, capture_output=True, timeout=timeout)
    if check and p.returncode:
        raise RuntimeError(f'command failed: {command!r}\n{p.stdout}\n{p.stderr}')
    return p


def load(path):
    return json.loads(path.read_text())


def check_case(directory, expected, state):
    logs = directory/'logs'
    inner = logs/'verifier'
    reward = (inner/'reward.txt').read_text()
    wrapper = load(inner/'wrapper_status.json')
    summary = load(inner/'ctrf.json')['results']['summary']
    driver = load(logs/'boundary_driver.json')
    checks = {
        'reward': reward == ('1\n' if expected else '0\n'),
        'wrapper_acceptance': wrapper['accepted'] is expected,
        'pytest_exit': (wrapper['pytest_exit_status']==0) is expected,
        'container_exit': (state['ExitCode']==0) is expected,
        'test_sh_exit': (driver['test_sh_exit']==0) is expected,
        'ctrf': summary['tests']==1 and summary['passed']==int(expected)
                and summary['failed']==int(not expected)
                and all(summary[k]==0 for k in ['skipped','pending','other']),
        'no_compiler_processes_before': driver['compiler_before']==[],
        'no_compiler_processes_after': driver['compiler_after']==[],
        'trusted_files_unchanged': driver['trusted_before']==driver['trusted_after'],
    }
    compile_log=(inner/'compile.log').read_text(errors='replace')
    if directory.name=='permission_attempts':
        evidence=[json.loads(s.split('BOUNDARY_PERMISSION ',1)[1])
                  for s in compile_log.splitlines() if s.startswith('BOUNDARY_PERMISSION ')]
        checks['permission_probe_ran']=len(evidence)==1
        if evidence:
            probe=evidence[0]
            checks['all_permissions_denied']=all(probe[k]=='denied' for k in [
                'write_spec_source','write_spec_object','write_search_path',
                'read_private_verifier','write_reward'])
            checks['actual_privilege_drop']=(probe['uid']==65532 and probe['euid']==65532
                                            and probe['groups']==[] and probe['no_new_privs']==1)
    if directory.name=='lingering_process':
        evidence=[json.loads(s.split('BOUNDARY_LINGER ',1)[1])
                  for s in compile_log.splitlines() if s.startswith('BOUNDARY_LINGER ')]
        checks['lingering_child_spawned']=len(evidence)==1 and evidence[0]['pid']>0 and evidence[0]['uid']==65532
    return {'checks':checks,'matched':all(checks.values()),'reward':reward.strip(),
            'wrapper_status':wrapper,'ctrf_summary':summary,'container_state':state}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--image',required=True)
    parser.add_argument('--bundle',type=Path,required=True)
    parser.add_argument('--outputdir',type=Path,required=True)
    parser.add_argument('--only',help='Optional comma-separated case names')
    args=parser.parse_args()
    if args.outputdir.exists() and any(args.outputdir.iterdir()):
        parser.error('--outputdir must be empty; preserve earlier evidence in its existing directory')
    args.outputdir.mkdir(parents=True,exist_ok=True)
    image_info=json.loads(run(['docker','image','inspect',args.image]).stdout)[0]
    reference=(args.bundle/'solution/Proof.lean').read_text()
    driver_path=args.outputdir/'control_driver.py';driver_path.write_text(DRIVER)
    results=[]
    for name,expected,source in variants(reference):
        if args.only and name not in args.only.split(','): continue
        directory=args.outputdir/name;directory.mkdir(parents=True,exist_ok=True)
        proof=directory/'Proof.lean';proof.write_text(source)
        container='conductor-control-'+name.replace('_','-')+'-'+uuid.uuid4().hex[:10]
        create=['docker','create','--name',container,'--network','none','--cpus','2',
                '--memory','4g','--pids-limit','256','--entrypoint','python3',
                image_info['Id'],'/control_driver.py']
        start=time.monotonic();record={'case':name,'expected_accept':expected,
             'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'create_command':create}
        created=False
        try:
            run(create);created=True
            run(['docker','cp',str(driver_path),container+':/control_driver.py'])
            run(['docker','cp',str(proof),container+':/control_Proof.lean'])
            p=run(['docker','start','-a',container],check=False)
            (directory/'container.log').write_text(p.stdout+p.stderr)
            inspect=json.loads(run(['docker','inspect',container]).stdout)[0]
            run(['docker','cp',container+':/logs',str(directory/'logs')])
            run(['docker','cp',container+':/app/output/Proof.lean',str(directory/'submitted.lean')])
            record.update(check_case(directory,expected,inspect['State']))
            host=inspect['HostConfig']
            isolation={'network':inspect['NetworkSettings']['Networks'],
                       'mounts':inspect['Mounts'],'cpus':host['NanoCpus'],
                       'memory':host['Memory'],'pids_limit':host['PidsLimit']}
            record['isolation']=isolation
            isolation_ok=(host['NetworkMode']=='none' and inspect['Mounts']==[]
                          and host['NanoCpus']==2_000_000_000 and host['Memory']==4*1024**3)
            record['checks']['isolation']=isolation_ok
            record['matched']=record['matched'] and isolation_ok
        except Exception as exc:
            record.update(matched=False,infrastructure_error=str(exc))
        finally:
            if created: run(['docker','rm','-f',container],check=False)
        record['seconds']=round(time.monotonic()-start,3)
        (directory/'result.json').write_text(json.dumps(record,indent=2)+'\n')
        results.append(record)
        print(json.dumps({'case':name,'matched':record['matched'],'seconds':record['seconds']}),flush=True)
    report={'image':args.image,'image_id':image_info['Id'],
            'reference_source_sha256':hashlib.sha256(reference.encode()).hexdigest(),
            'passed':sum(r['matched'] for r in results),'total':len(results),'results':results}
    (args.outputdir/'results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'total':report['total']}))
    raise SystemExit(0 if report['total'] and report['passed']==report['total'] else 1)


if __name__=='__main__': main()
