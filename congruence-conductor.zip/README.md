# Congruence conductor classification

A formal-mathematics task: construct a Lean proof classifying a family of congruence lattices in a noncommutative integer ring. The deliverable is a proof of the fixed public theorem, independently checked by the Lean kernel.

## Difficulty

Proof engineers building trustworthy computer-algebra libraries need general theorems that justify their algorithms, including unusual parameter values. This synthetic task describes objects by seven integer coordinates and a multiplication rule whose order matters. The solver must prove a classification for every allowed parameter choice. Multiplication mixes the coordinates, so checking each congruence separately misses necessary conditions. The conductor is the largest collection of elements that stays inside the prescribed lattice after multiplication on either side by any element of the surrounding ring. Proving that one candidate works is only half the job: every larger candidate must be excluded. The final residue classification must account for exact division and common factors without assuming the parameters are coprime. Lean checks every inference and side condition, including zero and negative quaternion parameters. The challenge is connecting these arguments into a complete formal proof; it is not a large search or numerical computation.

## Reference solution

The reference expands products in the Eisenstein and quaternion coordinates to prove the exact closure condition. Special ambient coordinate elements force the necessary conductor conditions. The candidate conductor is stable under multiplication on both sides, proving sufficiency and maximality.

An additive residue map sends the two scalar coordinates to residues modulo the least common multiple, and the two divided skew coordinates to residues modulo an integer greatest-common-divisor quotient. Integer lifts prove surjectivity. Divisibility and greatest-common-divisor lemmas identify its kernel with the full conductor. These three results are combined into the required theorem.

The formal statements include zero and negative quaternion parameters and non-coprime lattice parameters. The conductor and quotient remain defined for the additive lattice even when the separate multiplication-closure condition fails.

## Verification

The submitted source is compiled as a dedicated unprivileged user in the offline verifier container. Public libraries and specification files are immutable to that user. All compiler-user processes are terminated before the compiled artifact is copied into a private directory.

A separate trusted executable reads the compiled declarations without loading submitted plugins or initialization extensions. It reconstructs them in a fresh environment containing the fixed public specification using Lean's kernel replay, then kernel-checks the required theorem against `OrderTask.ExpectedType`. It permits the standard foundational axioms and rejects added axioms, missing proofs, changed statements, and proof dependencies on unsafe computation. Compiler-generated unsafe helper definitions are not installed in the reconstructed environment.

Different valid proof terms, auxiliary lemmas, and ordinary tactic choices are accepted. The verifier does not compare the proof with the reference text. Exact independent algebra controls supplement the general formal proof; finite checks alone are not presented as a proof of the parameterized theorem. Actual validation results and remaining limitations are recorded in `authoring/evidence/RESULTS.md`.

## Setup and reproduction

The ZIP contains source, specifications, reference proofs, and validation scripts. Initial setup downloads the pinned Lean release and matching mathlib sources. The required library modules are built from those sources during initial image preparation; no external compiled-cache service is required. These large dependencies are omitted from the ZIP. Verification performs no downloads or package installation.

For a complete container reproduction, run:

```sh
python3 authoring/evidence/container_validate.py --evidence /tmp/conductor-validation
```

Initial image preparation builds 1,335 pinned library modules from source and can take tens of minutes. Subsequent builds reuse the Docker layers. Both Dockerfiles download the pinned Lean binary release and build the required library modules from source by default. An existing image containing the same validated `/opt/formal` tree can be reused with `--build-arg TOOLCHAIN_IMAGE=<image>`; the final stage copies that tree and compiles the public specifications and, for the verifier image, the checker. Each final image adds the complete toolchain in one filesystem layer to avoid repeated full-directory copies with Docker’s VFS storage driver. Proof checking uses the prebuilt libraries and does not repeat that setup work. The Docker build budget is one hour; the solver and verifier receive 2 CPUs and 4 GiB.

For local proof development and the independent algebra controls, `bash authoring/setup.sh /tmp/conductor-tools` prepares a pinned toolchain and Python environment. The supported release target is Linux x86_64, Python 3.12.

The author metadata is preserved from the supplied reference as requested. The author must review the formal-mathematics specialization and finalize the instruction in their own words before submission. Local checks do not establish author eligibility, private similarity results, official quality approval, or any frontier-model difficulty target.
