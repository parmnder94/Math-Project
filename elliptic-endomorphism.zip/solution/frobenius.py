#!/usr/bin/env python3
"""Independent exact arithmetic prototype for the residual-surface witness.

Uses only Python integers for point counting. SymPy handles tiny polynomial
GCDs and degree-four/six resultant identities, never point enumeration.
"""
import json
import math
import time
from functools import lru_cache
import sympy as s

T, X = s.symbols('T X')
H = (T**3-551232)*(T**6-553014*T**3+816903549)
B = T**3+1104246*T**2+305655916797*T+450303377122368

def configure(data):
    """Derive the three curves from the public input, clearing cached counts."""
    global H,B,SOURCE_COEFFICIENTS,TARGET_COEFFICIENTS,QUOTIENT_COEFFICIENTS
    hp=data['curve_h']
    H=s.cancel(sum(s.Integer(c)*T**i for i,c in enumerate(hp['num']))/
               sum(s.Integer(c)*T**i for i,c in enumerate(hp['den'])))
    q=data['target_B'];e=data['target_E']
    B=T**3+q['a2']*T*T+q['a4']*T+q['a6']
    SOURCE_COEFFICIENTS=[int(s.Poly(-H,T).nth(i)) for i in range(s.degree(H,T)+1)]
    TARGET_COEFFICIENTS=[e['a6'],e['a4'],e['a2'],1]
    QUOTIENT_COEFFICIENTS=[q['a6'],q['a4'],q['a2'],1]
    count.cache_clear();residual.cache_clear()


def good_prime(p):
    if type(p) is not int or not 5 < p < 100 or not s.isprime(p):
        return False
    return all(s.gcd(s.Poly(f,T,modulus=p),s.Poly(s.diff(f,T),T,modulus=p)).degree()==0
               for f in (H, B, sum(c*T**i for i,c in enumerate(TARGET_COEFFICIENTS))))


@lru_cache(maxsize=128)
def count(p, n):
    """Count the three smooth projective curves over F_p or F_(p^2)."""
    if n not in (1,2):
        raise ValueError('Only extension degrees one and two are used.')
    contribution = [0]*p
    contribution[0]=1
    for a in range(1,p):
        contribution[a] = 2 if pow(a,(p-1)//2,p)==1 else 0
    totals = [1,1,1]
    def eval1(coeffs,x):
        y=0
        for c in reversed(coeffs):y=(y*x+c)%p
        return y
    if n==1:
        for x in range(p):
            values = [eval1(cs,x) for cs in (SOURCE_COEFFICIENTS,TARGET_COEFFICIENTS,QUOTIENT_COEFFICIENTS)]
            for i,v in enumerate(values):
                totals[i] += contribution[v%p]
        return tuple(totals)

    nonsquare=next(d for d in range(2,p) if contribution[d]==0)
    def addc(a,c):
        return ((a[0]+c)%p,a[1])
    def mul(a,b):
        return ((a[0]*b[0]+nonsquare*a[1]*b[1])%p,
                (a[0]*b[1]+a[1]*b[0])%p)
    def scale(a,c):
        return (c*a[0]%p,c*a[1]%p)
    def plus(a,b):
        return ((a[0]+b[0])%p,(a[1]+b[1])%p)
    def eval2(coeffs,x):
        y=(0,0)
        for c in reversed(coeffs):y=addc(mul(y,x),c)
        return y
    for a in range(p):
        for b in range(p):
            x=(a,b)
            source,target,quotient=[eval2(cs,x) for cs in (SOURCE_COEFFICIENTS,TARGET_COEFFICIENTS,QUOTIENT_COEFFICIENTS)]
            for i,(v,w) in enumerate((source,target,quotient)):
                if v==w==0:
                    totals[i]+=1
                else:
                    # A nonzero element of F_(p^2) is square exactly when
                    # its norm to F_p is square.
                    totals[i]+=contribution[(v*v-nonsquare*w*w)%p]
    return tuple(totals)


@lru_cache(maxsize=128)
def residual(p):
    if not good_prime(p):
        raise ValueError('Invalid prime or bad reduction.')
    counts=[count(p,n) for n in (1,2)]
    traces=[]
    for n,(nc,n0,n1) in enumerate(counts,1):
        traces.append((p**n+1-nc)-(p**n+1-n0)-(p**n+1-n1))
    a,b=traces
    if (a*a-b)%2:
        raise ValueError('Invalid integral Newton coefficient.')
    f=s.Poly(T**4-a*T**3+((a*a-b)//2)*T**2-p*a*T+p*p,T)
    return f,counts


def geometric_prime(p):
    f,counts=residual(p)
    r=s.Poly(s.resultant(f.as_expr(),X-T**6,T),X)
    unit,factors=s.factor_list(r)
    if unit!=1 or len(factors)!=1 or factors[0][1]!=2:
        raise ValueError('Sixth-power Frobenius is not one repeated quadratic.')
    q=factors[0][0]
    if q.degree()!=2 or q.LC()!=1 or q.nth(0)!=p**6:
        raise ValueError('Incorrect elliptic Weil polynomial.')
    trace=-int(q.nth(1))
    discriminant=trace*trace-4*p**6
    if trace%p==0 or discriminant>=0:
        raise ValueError('Reduction is not an ordinary elliptic square.')
    return {'prime':p,'counts':counts,'residual':list(map(int,f.all_coeffs())),
            'sixth_power_quadratic':list(map(int,q.all_coeffs())),
            'discriminant':discriminant}


def descent_prime(p):
    f,counts=residual(p)
    unit,factors=s.factor_list(f)
    if unit!=1 or len(factors)!=2 or any(m!=1 or q.degree()!=2 for q,m in factors):
        raise ValueError('Frobenius is not a product of two distinct elliptic factors.')
    for q,m in factors:
        trace=-int(q.nth(1))
        disc=trace*trace-4*p
        if q.LC()!=1 or q.nth(0)!=p or trace%p==0 or disc>=0:
            raise ValueError('Factor is not ordinary elliptic.')
        if math.isqrt(-3*disc)**2 != -3*disc:
            raise ValueError('Factor does not have the Eisenstein CM field.')
    return {'prime':p,'counts':counts,'residual':list(map(int,f.all_coeffs()))}


def verify(witness):
    if set(witness)!={'geometric_primes','descent_prime'}:
        raise ValueError('Incorrect witness keys.')
    ps=witness['geometric_primes']
    if type(ps) is not list or len(ps)!=2:
        raise ValueError('Supply two geometric primes.')
    gs=[geometric_prime(p) for p in ps]
    product=gs[0]['discriminant']*gs[1]['discriminant']
    if math.isqrt(product)**2==product:
        raise ValueError('The two geometric CM fields coincide.')
    ds=descent_prime(witness['descent_prime'])
    return {'geometric':gs,'descent':ds}


def solve():
    descent=None
    geometric=[]
    for p in list(s.primerange(6,100)):
        if not good_prime(p):
            continue
        if descent is None:
            try:
                descent_prime(p)
                descent=p
            except ValueError:
                pass
        try:
            item=geometric_prime(p)
        except ValueError:
            continue
        if not geometric:
            geometric=[item]
        else:
            prod=geometric[0]['discriminant']*item['discriminant']
            if math.isqrt(prod)**2!=prod:
                geometric=[geometric[0],item]
        if len(geometric)==2 and descent is not None:
            result={'geometric_primes':[x['prime'] for x in geometric],
                    'descent_prime':descent}
            verify(result)
            return result
    raise ValueError('No complete certificate found in the allowed range.')


if __name__=='__main__':
    start=time.monotonic()
    witness=solve()
    print(json.dumps({'witness':witness,'details':verify(witness),'seconds':time.monotonic()-start},indent=2))
