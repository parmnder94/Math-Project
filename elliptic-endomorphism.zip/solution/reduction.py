"""Independent local arithmetic audit for the normalized genus-four curve.

This module imports neither the differential-operator solver nor its verifier.
All arithmetic below is exact; the only enumeration is over F_5 and F_7.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sympy as s

A, B, C, R = 551232, 553014, 816903549, 120582
e, z, u, pi = s.symbols('e z u pi')


def configure(data):
    """Read the curve and differential parameters from the public functions."""
    global A,B,C,R
    def rf(spec):
        return s.cancel(sum(s.Integer(c)*e**i for i,c in enumerate(spec['num']))/
                        sum(s.Integer(c)*e**i for i,c in enumerate(spec['den'])))
    h=rf(data['curve_h']);hp=s.Poly(h,e)
    assert all(i[0]%3==0 for i,c in hp.terms())
    cubic=sum(c*z**(i[0]//3) for i,c in hp.terms())
    fs=s.factor_list(cubic,z)[1]
    linear=[s.Poly(f,z) for f,m in fs if s.degree(f,z)==1]
    quadratic=[s.Poly(f,z) for f,m in fs if s.degree(f,z)==2]
    assert len(linear)==len(quadratic)==1
    A=int(-linear[0].nth(0)/linear[0].nth(1))
    B=int(-quadratic[0].nth(1)/quadratic[0].nth(2))
    C=int(quadratic[0].nth(0)/quadratic[0].nth(2))
    r=s.Poly(s.cancel(s.diff(rf(data['alpha_x']),e)/rf(data['alpha_y_multiplier'])),e)
    assert r.degree()==3 and r.nth(1)==r.nth(2)==0
    R=int(-r.nth(0)/r.nth(3))


def valuation(n, p):
    n = int(n)
    if not n:
        raise ValueError('valuation of zero')
    v = 0
    while n % p == 0:
        n //= p
        v += 1
    return v


def coefficients(expr, x, p):
    poly = s.Poly(s.expand(expr), x)
    return [int(poly.nth(i)) % p for i in range(poly.degree() + 1)]


def point_count(coeffs, p):
    """Smooth odd-degree y^2=f(x), including its unique infinity point."""
    assert len(coeffs) % 2 == 0
    return 1 + sum(
        sum((y*y - sum(c * pow(x, i, p) for i, c in enumerate(coeffs))) % p == 0
            for y in range(p))
        for x in range(p)
    )


def multiply(*polys):
    out = [1]
    for poly in polys:
        nxt = [0] * (len(out) + len(poly) - 1)
        for i, a in enumerate(out):
            for j, b in enumerate(poly):
                nxt[i+j] += a*b
        out = nxt
    return out


def derive():
    h = (e**3 - A) * (e**6 - B*e**3 + C)
    assert valuation(s.discriminant(h, e), 5) == 36
    assert valuation(s.discriminant(h, e), 7) == 15

    # At five, use z=(e^3-A)/25. The polynomial identity is exact,
    # independent of the three unramified choices of cube root a of A.
    tail5 = -z * (z*z + ((2*A-B)//25)*z + (A*A-B*A+C)//625)
    assert 2*A-B == 25*((2*A-B)//25)
    assert A*A-B*A+C == 625*((A*A-B*A+C)//625)
    tail5c = coefficients(tail5, z, 5)
    central5c = coefficients(A-e**3, e, 5)
    assert s.Poly(tail5, z, modulus=5).gcd(s.Poly(s.diff(tail5,z), z, modulus=5)).degree() == 0
    assert s.Poly(A-e**3,e,modulus=5).gcd(s.Poly(-3*e**2,e,modulus=5)).degree() == 0
    # A residue root is 3; the remaining two form one quadratic orbit.
    roots5 = [x for x in range(5) if pow(x, 3, 5) == A % 5]
    assert roots5 == [3]
    trace5central = 6-point_count(central5c, 5)
    trace5tail = 6-point_count(tail5c, 5)
    assert trace5central == trace5tail == 0
    # On a length-two orbit, F^2 is the elliptic Frobenius square.
    # t(F^2)=t(F)^2-2p; hence determinant(1-F T) is obtained by T->T^2.
    orbit2_factor = [1, 0, -(trace5tail**2-10), 0, 25]
    local5 = multiply([1,-trace5central,5], [1,-trace5tail,5], orbit2_factor)
    k5 = (A-R)//25
    assert A-R == 25*k5

    # At seven pi^2=7. Divide -h(pi*u) by pi^6 and reduce modulo pi.
    # The middle coefficient (B/pi^3) equals (B/49)*pi and vanishes.
    assert B % 49 == 0 and C % 343 == 0
    central7c = coefficients(A-e**3,e,7)
    tail7c = coefficients(A*(u**6+C//343),u,7)
    assert s.Poly(A*(u**6+C//343),u,modulus=7).gcd(s.Poly(s.diff(A*(u**6+C//343),u),u,modulus=7)).degree() == 0
    # The quotient by (u,v)->(-u,-v) has X=u^-2,Y=v/u^3.
    # Here v^2=3u^6+1, giving Y^2=X^3+3.
    invariant_quotient = [3,0,0,1]
    anti_invariant_quotient = [1,0,0,3]  # x=u^2,y=v
    trace7central = 8-point_count(central7c, 7)
    trace7invariant = 8-point_count(invariant_quotient, 7)
    trace7anti = 8-point_count(anti_invariant_quotient, 7)
    assert trace7central == trace7invariant
    assert pow(3, 3, 7) == 6  # +/-sqrt(3) are exchanged by Frobenius.
    local7 = multiply([1,1], [1,-trace7central,7], [1,-trace7invariant,7])
    assert R % 7 == 0 and R % 49 != 0

    return {
      '5': {
        'minimal_ramification_index': 1,
        'split_residue_degree': 2,
        'central_equation': central5c,
        'tail_equation': tail5c,
        'tail_count': 3,
        'component_frobenius_orbit_sizes': [1,1,2],
        'dual_graph_betti_number': 0,
        'node_thicknesses': [[1,1],[1,1],[1,1]],
        'tail_inertia_coordinate_signs': [1,1],
        'central_differential_valuation': [0,1],
        'tail_differential_valuation': [1,1],
        'central_differential_scalar': 4,
        'tail_differential_scalar_numerator': 3,
        'tail_differential_linear_factor': [k5 % 5,1],
        'node_differential_orders': [[0,-2],[0,-2],[0,-2]],
        'ramification_specializations': [[(-k5)%5,1],[(-k5)%5,4]],
        'elliptic_traces': [trace5central,trace5tail],
        'local_polynomial': local5,
        'inertia_fixed_dimension': 8,
        'monodromy_rank': 0,
        'artin_conductor': 0,
        'swan_conductor': 0,
      },
      '7': {
        'minimal_ramification_index': 2,
        'split_residue_degree': 2,
        'central_equation': central7c,
        'tail_equation': tail7c,
        'tail_count': 1,
        'component_frobenius_orbit_sizes': [1,1],
        'dual_graph_betti_number': 1,
        'node_thicknesses': [[1,2],[1,2]],
        'tail_inertia_coordinate_signs': [-1,-1],
        'node_frobenius_permutation': [1,0],
        'graph_frobenius_trace': -1,
        'central_differential_valuation': [0,1],
        'tail_differential_valuation': [0,1],
        'central_differential_scalar': 2,
        'tail_differential_scalar': (-9*(R//7))%7,
        'node_differential_orders': [[0,1],[0,1]],
        'annular_ramification_distance_from_central': [1,3],
        'annular_ramification_points_per_edge': 3,
        'invariant_quotient_equation': invariant_quotient,
        'anti_invariant_quotient_equation': anti_invariant_quotient,
        'elliptic_traces': [trace7central,trace7invariant,trace7anti],
        'local_polynomial': local7,
        'finite_inertia_negative_dimension': 2,
        'inertia_fixed_dimension': 5,
        'monodromy_rank': 1,
        'artin_conductor': 3,
        'swan_conductor': 0,
      },
    }


def check(candidate):
    """Recompute invariants from input curve and compare exact integer data.

    Coordinates, labels, orderings and reduced residue representatives must
    be stated in the task if this strict compact schema is used verbatim.
    Root integration may select only desired fields from this audit record.
    """
    return type(candidate) is dict and candidate == derive() and all_integers(candidate)


def all_integers(obj):
    if isinstance(obj, dict):
        return all(isinstance(k,str) and all_integers(v) for k,v in obj.items())
    if isinstance(obj, list):
        return all(all_integers(v) for v in obj)
    return type(obj) is int


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--check',type=Path)
    args=parser.parse_args()
    if args.check:
        ok=check(json.loads(args.check.read_text()))
        print(json.dumps({'accepted':ok}))
        raise SystemExit(0 if ok else 1)
    print(json.dumps(derive(),indent=2))
