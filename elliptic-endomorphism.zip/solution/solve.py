#!/usr/bin/env python3
"""Exact reference construction for the arithmetic Jacobian decomposition."""
import argparse
import json
import math
from pathlib import Path
import sympy as s
from gluing import solve_gluing, rf, E
import frobenius
from local_data import solve_local
from endomorphism_field import solve_field


def hilbert_ramification(a,b):
    """Ramification of the rational quaternion (a,b), a,b nonzero integers."""
    def unit(n,p):
        v=0
        while n%p==0:n//=p;v+=1
        return v,n
    def legendre(n,p):return 1 if pow(n%p,(p-1)//2,p)==1 else -1
    candidates=sorted(s.factorint(abs(2*a*b)))
    bad=[]
    for p in candidates:
        av,au=unit(a,p);bv,bu=unit(b,p)
        if p==2:
            exponent=((au-1)//2)*((bu-1)//2)+av*((bu*bu-1)//8)+bv*((au*au-1)//8)
            symbol=-1 if exponent%2 else 1
        else:
            symbol=((-1)**(av*bv*((p-1)//2)))*(legendre(au,p)**bv)*(legendre(bu,p)**av)
        if symbol==-1:bad.append(int(p))
    infinity=a<0 and b<0
    assert (len(bad)+int(infinity))%2==0
    return {'finite':bad,'infinity':infinity}


def j_invariant(a2,a4,a6):
    A=s.Rational(a4)-s.Rational(a2)**2/3
    B=2*s.Rational(a2)**3/27-s.Rational(a2)*a4/3+a6
    return s.cancel(1728*4*A**3/(4*A**3+27*B**2))


def factor(dimension,center=1,quaternion=None):
    return {'dimension':dimension,'multiplicity':1,
            'algebra':{'center_discriminant':center,'quaternion_ramification':quaternion}}


def solve(data):
    from inverse_map import solve as reconstruct
    b=-data['target_E']['a6']
    recovered=reconstruct({'curve_b':b,'coefficient_x':30,'pole_coefficient':18*b})
    assert s.cancel(rf(recovered['normalized_polynomial'])-rf(data['curve_h']))==0
    data=dict(data,alpha_x=recovered['cover']['x'],alpha_y_multiplier=recovered['cover']['y_multiplier'])
    output,coverfacts=solve_gluing(data)
    output['elliptic_map']={key:recovered['cover'][key] for key in ['x','y_multiplier','degree']}
    genus=(s.degree(rf(data['curve_h']),E)-1)//2
    assert genus==4
    target0,target1=data['target_E'],data['target_B']
    j0=j_invariant(**target0);j1=j_invariant(**target1)
    assert j0==0 and j1.q!=1
    # A signature-(1,1) Eisenstein action and an integral polarization of
    # degree product d give the rational Hodge quaternion (-3,d).
    pol=output['polarization_A'];d=math.prod(pol)
    quaternion=hilbert_ramification(-3,d)
    assert quaternion['finite'] and not quaternion['infinity']
    frobenius.configure(data)
    witness=frobenius.solve();details=frobenius.verify(witness)
    # Distinct ordinary geometric centers exclude a CM elliptic square.
    geometric=details['geometric']
    discr_product=geometric[0]['discriminant']*geometric[1]['discriminant']
    assert math.isqrt(discr_product)**2!=discr_product
    residual_dimension=int(genus-2)
    output['geometric_factors']=[factor(1,-3),factor(1),factor(residual_dimension,1,quaternion)]
    # The independently found descent prime gives K x K as reduction's
    # rational endomorphism algebra. Complex conjugation fixes a real
    # quadratic subfield of the division quaternion, forcing End_Q(A)=Q.
    assert details['descent']
    output['rational_factors']=[factor(1),factor(1),factor(residual_dimension)]
    output['reduction_witnesses']=[{'prime':g['prime'],
        'counts':[[g['counts'][0][i],g['counts'][1][i]] for i in range(3)]}
        for g in geometric]
    output['local_data']=solve_local(data)
    output['endomorphism_field']=solve_field(data)
    from integral_order import solve_integral
    output['integral_structure']=solve_integral(output['polarization_A'],output['intersection_order'])
    return output


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data',type=Path,default=Path('/app/data/jacobian.json'))
    ap.add_argument('--output',type=Path,default=Path('/app/output/decomposition.json'))
    args=ap.parse_args()
    result=solve(json.loads(args.data.read_text()))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(str(args.output))


if __name__=='__main__':main()
