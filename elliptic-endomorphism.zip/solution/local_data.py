"""Solve and check the local_data contract independently of the main solver."""
from __future__ import annotations
from fractions import Fraction
from itertools import permutations
import argparse
import json
from pathlib import Path
from reduction import derive, configure
from wild_three import solve_three


def solve_local(data=None):
    if data is not None: configure(data)
    facts = derive()
    out = [solve_three(data)]
    for p in (5,7):
        r=facts[str(p)]
        vertices=[{'genus':1,'vertical_order':r['central_differential_valuation']}]
        vertices += [
          {'genus':(len(r['tail_equation'])-2)//2,
           'vertical_order':r['tail_differential_valuation']}
          for _ in range(r['tail_count'])]
        ends=[[0,i] for i in range(1,4)] if p==5 else [[0,1],[0,1]]
        edges=[{'ends':end,'thickness':thick,'differential_orders':orders}
               for end,thick,orders in zip(ends,r['node_thicknesses'],r['node_differential_orders'])]
        assert sum(v['genus'] for v in vertices)+len(edges)-len(vertices)+1==4
        out.append({
          'prime':p, 'L_polynomial':r['local_polynomial'],
          'conductor':r['artin_conductor'], 'swan':r['swan_conductor'],
          'stable_extension_e':r['minimal_ramification_index'],
          'vertices':vertices, 'edges':edges,
        })
    return out


def integer(x):
    if type(x) is not int: raise ValueError('integer required')
    return x


def rational(x):
    if type(x) is not list or len(x)!=2: raise ValueError('rational pair required')
    return Fraction(integer(x[0]),integer(x[1]))


def canonical_graph(vertices,edges):
    if type(vertices) is not list or not 1<=len(vertices)<=8: raise ValueError('vertices')
    if type(edges) is not list or len(edges)>16: raise ValueError('edges')
    vs=[]
    for v in vertices:
        if type(v) is not dict or set(v)!={'genus','vertical_order'}: raise ValueError('vertex fields')
        g=integer(v['genus'])
        if g<0: raise ValueError('genus')
        vs.append((g,rational(v['vertical_order'])))
    es=[]
    for edge in edges:
        if type(edge) is not dict or set(edge)!={'ends','thickness','differential_orders'}: raise ValueError('edge fields')
        if type(edge['ends']) is not list or len(edge['ends'])!=2: raise ValueError('ends')
        a,b=map(integer,edge['ends'])
        if not (0<=a<len(vs) and 0<=b<len(vs)): raise ValueError('endpoint')
        thick=rational(edge['thickness'])
        if thick<=0: raise ValueError('thickness')
        if type(edge['differential_orders']) is not list or len(edge['differential_orders'])!=2: raise ValueError('node orders')
        c,d=map(integer,edge['differential_orders'])
        es.append((a,b,thick,c,d))
    # At most five vertices occur in the correct graph; reject a wrong
    # cardinality before reaching this helper in check_local.
    best=None
    for perm in permutations(range(len(vs))):
        nvs=tuple(vs[perm[i]] for i in range(len(vs)))
        inv={old:new for new,old in enumerate(perm)}
        nes=[]
        for a,b,t,c,d in es:
            forward=(inv[a],inv[b],t,c,d)
            backward=(inv[b],inv[a],t,d,c)
            nes.append(min(forward,backward))
        candidate=(nvs,tuple(sorted(nes)))
        if best is None or candidate<best: best=candidate
    return best


def check_local(data):
    try:
        if type(data) is not list or len(data)!=3: return False
        expected={r['prime']:r for r in solve_local()}
        seen=set()
        for r in data:
            if type(r) is not dict or set(r)!={'prime','L_polynomial','conductor','swan','stable_extension_e','vertices','edges'}:
                return False
            p=integer(r['prime'])
            if p not in expected or p in seen: return False
            seen.add(p)
            q=expected[p]
            for key in ('conductor','swan','stable_extension_e'):
                if integer(r[key])!=q[key]: return False
            coeffs=r['L_polynomial']
            if type(coeffs) is not list or not coeffs or len(coeffs)>129: return False
            coeffs=[integer(x) for x in coeffs]
            while len(coeffs)>1 and coeffs[-1]==0: coeffs.pop()
            if coeffs!=q['L_polynomial']: return False
            if type(r['vertices']) is not list or len(r['vertices'])!=len(q['vertices']): return False
            if type(r['edges']) is not list or len(r['edges'])!=len(q['edges']): return False
            if canonical_graph(r['vertices'],r['edges'])!=canonical_graph(q['vertices'],q['edges']): return False
        return True
    except (ValueError,TypeError,KeyError,ZeroDivisionError,OverflowError):
        return False


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--check',type=Path)
    args=parser.parse_args()
    if args.check:
        result=check_local(json.loads(args.check.read_text()))
        print(json.dumps({'accepted':result}))
        raise SystemExit(0 if result else 1)
    print(json.dumps(solve_local(),indent=2))
