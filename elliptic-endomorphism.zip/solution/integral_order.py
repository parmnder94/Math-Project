"""Integral order indices and conductor quotients from the proved gluing lattice.

See authoring/evidence/integral_order_proof.md for the geometric identification
of the lattice. This module computes its indices rather than assuming that
an isogeny decomposition splits the integral endomorphism ring.
"""
import sympy as s
from sympy.matrices.normalforms import smith_normal_form


def solve_integral(polarization, overlap):
    assert polarization[0] == 1 and overlap == 3
    d = polarization[1]
    # In D=K+K*j1, j1^2=d/9=2, the actual surface order is
    # O_K+3*O_K*j1. The product maximal order has integral coordinates
    # (a0_0,a0_1,n,a_0,a_1,b_0,b_1).
    assert d == 18
    G = s.Matrix([
        [1,0,0,0,0,0,0], [0,1,0,0,0,0,0],
        [1,1,overlap,0,0,0,0],
        [1,0,0,d,0,0,0], [0,1,0,0,d,0,0],
        [0,0,0,0,0,3,0], [0,0,0,0,0,0,3],
    ])
    # Multiplication by j1 on either side forces the j1 coefficient
    # of a conductor element into (d/2)O_K.
    C = s.diag(d,d,overlap,d,d,d//2,d//2)
    Gq = s.Matrix([[1,0,0],[1,overlap,0],[1,0,d]])
    Cq = s.diag(d,overlap,d)
    def quotient(g,c):
        inclusion = g.inv()*c
        assert all(x.q == 1 for x in inclusion)
        snf = smith_normal_form(inclusion,domain=s.ZZ)
        out = [abs(int(snf[i,i])) for i in range(snf.rows)]
        assert all(b % a == 0 for a,b in zip(out,out[1:]))
        return [x for x in out if x > 1]
    return {
        'geometric_index': abs(int(G.det())),
        'rational_index': abs(int(Gq.det())),
        'geometric_conductor_quotient': quotient(G,C),
        'rational_conductor_quotient': quotient(Gq,Cq),
    }
