"""Determine the endomorphism field by a proved finite Kummer classification.

The point counts are exact. The candidate space consists of all rational
Kummer classes allowed by the discriminant and conjugation invariance.
"""
from itertools import product
from math import prod
import sympy as s
from flint import fq_default_ctx


def add(a,b):return (a[0]+b[0],a[1]+b[1])
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def mul(a,b):
    # Coordinates in the basis 1,zeta with zeta^2+zeta+1=0.
    return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]-a[1]*b[1])


def exact_div(a,n):
    assert all(x%n==0 for x in a)
    return tuple(x//n for x in a)


def curve_coefficients(data):
    E=s.symbols('E');spec=data['curve_h']
    h=s.cancel(sum(s.Integer(c)*E**i for i,c in enumerate(spec['num']))/
               sum(s.Integer(c)*E**i for i,c in enumerate(spec['den'])))
    hp=s.Poly(h,E)
    assert all(mon[0]%3==0 for mon,c in hp.terms())
    hs=[int(hp.nth(3*i)) for i in range(hp.degree()//3+1)]
    assert data['target_E']['a2']==data['target_E']['a4']==0
    support=sorted(map(int,s.factorint(abs(int(s.discriminant(h,E))))))
    return hs,int(data['target_E']['a6']),support


def weighted_trace(p,n,hs,target_constant):
    field=fq_default_ctx(p,n,'a');q=p**n
    r=next(r for r in range(2,p) if (r*r+r+1)%p==0)
    inverse=field(pow(r,-1,p))
    affine=[[0,0],[0,0]];quotient_trace=0
    def solutions(f):return 1 if f.is_zero() else 2 if f.is_square() else 0
    for coefficients in product(range(p),repeat=n):
        z=field(list(coefficients));H=field(0)
        for c in reversed(hs):H=H*z+c
        source=-H;target=z+target_constant
        ns,nt=solutions(source),solutions(target)
        quotient_trace-=ns-1
        if z.is_zero():
            for k in (0,1):
                affine[0][k]+=ns;affine[1][k]+=nt
        else:
            cube_character=z**((q-1)//3)
            for k,desired in ((0,field.one()),(1,inverse)):
                if cube_character==desired:
                    affine[0][k]+=3*ns;affine[1][k]+=3*nt
    traces=[[q-x for x in row] for row in affine]
    def eigenspace(t):return exact_div((t[0]-t[1],-t[0]-2*t[1]),3)
    pry=eigenspace([traces[0][k]-quotient_trace for k in (0,1)])
    ell=eigenspace(traces[1])
    return sub(pry,ell),r


def character_table(data):
    hs,c,support=curve_coefficients(data);table=[]
    for p in s.primerange(7,100):
        p=int(p)
        if p%3!=1 or p in support:continue
        t1,r=weighted_trace(p,1,hs,c);t2,_=weighted_trace(p,2,hs,c)
        chi=exact_div(sub(mul(t1,t1),t2),2*p)
        power=(1,0)
        for _ in range(6):power=mul(power,chi)
        assert power==(1,0)
        residue=(chi[0]+chi[1]*r)%p;generator=(1+r)%p
        logs={pow(generator,j,p):j for j in range(6)}
        assert len(logs)==6 and residue in logs
        table.append({'prime':p,'zeta_residue':r,'A_trace_K':list(t1),
                      'A_trace_square_K':list(t2),'det_over_p':list(chi),
                      'residue':residue,'exponent':logs[residue]})
    return table,support


def solve_field(data,with_evidence=False):
    table,support=character_table(data)
    assert 3 in support
    basis=[-1]+support
    ranges=[range(2)]+[range(3) if p==3 else range(6) for p in support]
    constraints=[]
    for row in table:
        p=row['prime'];r=row['zeta_residue'];generator=(1+r)%p
        logs={pow(generator,j,p):j for j in range(6)}
        coefficients=[logs[pow(q%p,(p-1)//6,p)] for q in basis]
        constraints.append((coefficients,row['exponent']))
    survivors=[]
    for exponents in product(*ranges):
        if all(sum(a*b for a,b in zip(coeffs,exponents))%6==value
               for coeffs,value in constraints):
            survivors.append(exponents)
    assert len(survivors)==1
    exponents=survivors[0]
    radicand=prod(p**e for p,e in zip(basis,exponents))
    # Inverting the character keeps its kernel. Prefer the smaller of the
    # two rational representatives, each with prime exponents below six.
    inverse_exponents=[exponents[0]]+[(-e)%6 for e in exponents[1:]]
    inverse=prod(p**e for p,e in zip(basis,inverse_exponents))
    if abs(inverse)<abs(radicand):radicand=inverse
    order=1
    from math import gcd,lcm
    for row in table:order=lcm(order,6//gcd(6,row['exponent']))
    assert order==6
    answer={'radicand':[int(radicand),1],'degree':2*order}
    if with_evidence:
        return answer,{'support':support,'candidate_basis':basis,
                       'candidate_count':prod(len(r) for r in ranges),
                       'survivor_exponents':list(exponents),'table':table}
    return answer
