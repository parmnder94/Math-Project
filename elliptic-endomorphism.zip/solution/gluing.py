"""Construct the elliptic gluing by flex lines, norm, and a trace cubic."""
from itertools import product
from math import lcm
import sympy as s

E,z,t=s.symbols('E z t')


def rf(spec,variable=E):
    return s.cancel(sum(s.Integer(c)*variable**i for i,c in enumerate(spec['num']))/
                    sum(s.Integer(c)*variable**i for i,c in enumerate(spec['den'])))


def encode(q,variable=E):
    n,d=s.fraction(s.cancel(q));pn,pd=s.Poly(n,variable),s.Poly(d,variable)
    multiplier=s.ilcm(*[c.q for c in pn.all_coeffs()+pd.all_coeffs()])
    if not pn:return {'num':[],'den':[1]}
    return {'num':[int(multiplier*pn.nth(i)) for i in range(pn.degree()+1)],
            'den':[int(multiplier*pd.nth(i)) for i in range(pd.degree()+1)]}


def ratio(q):
    q=s.Rational(q);return [int(q.p),int(q.q)]


def scalar(a=0,b=0):return [ratio(a),ratio(b)]


def in_cube_variable(q):
    n,d=s.fraction(s.cancel(q))
    def convert(poly):
        pp=s.Poly(poly,E)
        assert all(mon[0]%3==0 for mon,c in pp.terms())
        return sum(c*z**(mon[0]//3) for mon,c in pp.terms())
    return s.cancel(convert(n)/convert(d))


def mul(v,w,h):
    return (s.cancel(v[0]*w[0]+11*h*v[1]*w[1]),
            s.cancel(v[0]*w[1]+v[1]*w[0]))


def saturated_type(n0,n1,intersection):
    # The common torsion point has order intersection on each elliptic side.
    k=intersection;mods=(n0,n0,n1,n1)
    hs=[(j*n0//k,0,j*n1//k,0) for j in range(k)]
    def canonical(v):
        return min(tuple((v[i]+h[i])%mods[i] for i in range(4)) for h in hs)
    zero=(0,0,0,0)
    orth=(v for v in product(*(range(n) for n in mods)) if (v[1]+v[3])%k==0)
    quotient={canonical(v) for v in orth}
    exponent=1
    for v in quotient:
        for j in range(1,lcm(n0,n1)+1):
            if canonical(tuple(j*v[i]%mods[i] for i in range(4)))==zero:
                exponent=lcm(exponent,j);break
        else:raise AssertionError('Missing finite order.')
    degree_product=n0*n1//k
    elementary=[degree_product//exponent,exponent]
    assert len(quotient)==degree_product**2 and elementary[1]%elementary[0]==0
    return elementary


def solve_gluing(data):
    h=in_cube_variable(rf(data['curve_h']))
    X=rf(data['alpha_x']);Y=rf(data['alpha_y_multiplier'])
    x=in_cube_variable(X/E);y=in_cube_variable(Y)
    assert s.cancel(-rf(data['curve_h'])*Y*Y/4-X**3+11)==0
    u=s.symbols('u');bcubic=-h.subs(z,-u);bp=s.Poly(bcubic,u)
    a2,a4,a6=[bp.nth(j) for j in (2,1,0)]
    phi3=3*u**4+4*a2*u**3+6*a4*u*u+12*a6*u+4*a2*a6-a4*a4
    answers=[]
    for fac,multiplicity in s.factor_list(phi3,u)[1]:
        fp=s.Poly(fac,u)
        if fp.degree()!=1:continue
        ux=-fp.nth(0)/fp.nth(1);ksquare=s.cancel(-bcubic.subs(u,ux)/11)
        kval=s.sqrt(ksquare)
        if not(kval.is_Rational and kval>0):continue
        slope=s.cancel(s.diff(bcubic,u).subs(u,ux)/(-22*kval))
        intercept=s.cancel(kval-slope*ux)
        A=-slope*z+intercept;B=z+ux
        assert s.expand(h-11*A*A-B**3)==0
        norm=-x/B
        for sign in (1,-1):
            r0=s.cancel((h*y/2-sign*11*A)/B**3)
            r1=s.cancel((1-sign*A*y/2)/B**3)
            cubic=s.fraction(s.together(4*z*z*t**3-3*z*norm*t-r0))[0]
            for fac,mult in s.factor_list(cubic,t)[1]:
                p=s.Poly(fac,t)
                if p.degree()!=1:continue
                a=s.cancel(-p.nth(0)/p.nth(1))
                b=s.cancel(r1/(z*(4*z*a*a-norm)))
                cube=mul(mul((a,b),(a,b),h),(a,b),h)
                if s.cancel(z*z*cube[0]-r0) or s.cancel(z*z*cube[1]-r1):continue
                f_a=E**2*a.subs(z,E**3);f_d=E**2*b.subs(z,E**3)
                answers.append({'point':[scalar(ux),scalar(0,sign*kval)],
                                'tangent':[scalar(0,sign*slope),scalar(0,sign*intercept)],
                                'function':[encode(f_a),encode(0),encode(0),encode(f_d)]})
    assert len(answers)==1
    # The automorphism sigma is cubic. Its fixed subgroup on B0 has order
    # Phi_3(1); the displayed nonzero flex class realizes the upper bound.
    intersection=int(s.cyclotomic_poly(3,t).subs(t,1))
    xn,xd=s.fraction(X)
    degree_alpha=max(s.degree(xn,E),s.degree(xd,E))
    degree_beta=3
    polarization=saturated_type(int(degree_alpha),degree_beta,intersection)
    return {'intersection_order':intersection,'gluing':answers[0],
            'polarization_S':polarization,'polarization_A':polarization[:]}, {'alpha_degree':int(degree_alpha),'beta_degree':degree_beta}
