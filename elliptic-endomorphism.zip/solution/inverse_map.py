#!/usr/bin/env python3
"""Reference route: differential-polynomial recursion, then Ore expansion.

This file is mounted only for the oracle run. It does not read verifier files,
the independent solver, or a table of answers.
"""
import argparse
import json
import time
from pathlib import Path

import sympy as s
from sympy.polys.matrices import DomainMatrix


x, E = s.symbols('x E')
ZERO = (s.S.Zero, s.S.Zero)
ONE = (s.S.One, s.S.Zero)


def cancel(value):
    return s.cancel(value)


class Algebra:
    def __init__(self, curve_b):
        self.S = 4 * (x**3 - curve_b)

    def add(self, left, right):
        return tuple(cancel(a+b) for a, b in zip(left, right))

    def neg(self, value):
        return (-value[0], -value[1])

    def mul(self, left, right):
        a, b = left
        c, d = right
        return (cancel(a*c+self.S*b*d), cancel(a*d+b*c))

    def deriv(self, value):
        a, b = value
        return (cancel(self.S*s.diff(b, x)+s.diff(self.S, x)*b/2),
                cancel(s.diff(a, x)))

    def d2(self, value):
        return cancel(self.S*s.diff(value, x, 2)+s.diff(self.S, x)*s.diff(value, x)/2)

    @staticmethod
    def trim(op):
        while op and op[-1] == ZERO:
            op.pop()
        return op

    def opadd(self, left, right):
        out = [ZERO] * max(len(left), len(right))
        for i in range(len(out)):
            out[i] = self.add(left[i] if i < len(left) else ZERO,
                              right[i] if i < len(right) else ZERO)
        return self.trim(out)

    def opmul(self, left, right):
        if not left or not right:
            return []
        out = [ZERO] * (len(left)+len(right)-1)
        for j, coeff in enumerate(right):
            derivatives = [coeff]
            for _ in range(len(left)-1):
                derivatives.append(self.deriv(derivatives[-1]))
            for i, a in enumerate(left):
                if a == ZERO:
                    continue
                for k in range(i+1):
                    term = self.mul(a, derivatives[k])
                    term = tuple(cancel(s.binomial(i, k)*c) for c in term)
                    out[i+j-k] = self.add(out[i+j-k], term)
        return self.trim(out)

    def opneg(self, op):
        return [self.neg(a) for a in op]

    def poly_operator(self, polynomial, op):
        out = []
        for coefficient in s.Poly(polynomial, E).all_coeffs():
            out = self.opadd(self.opmul(out, op), [(coefficient, s.S.Zero)])
        return out

    def right_divide(self, op, divisor):
        remainder = op[:]
        quotient = []
        # Here the leading coefficient is the nonzero rational (-1)^deg(q).
        assert divisor and divisor[-1][1] == 0 and not divisor[-1][0].has(x)
        leading = divisor[-1][0]
        while remainder and len(remainder) >= len(divisor):
            shift = len(remainder)-len(divisor)
            term = [ZERO]*shift + [tuple(cancel(v/leading) for v in remainder[-1])]
            quotient = self.opadd(quotient, term)
            remainder = self.opadd(remainder, self.opneg(self.opmul(term, divisor)))
        return quotient, remainder


def encode_rf(value, variable=x):
    numerator, denominator = s.fraction(cancel(value))
    pn, pd = s.Poly(numerator, variable), s.Poly(denominator, variable)
    coefficients = pn.all_coeffs()+pd.all_coeffs()
    scale = s.ilcm(*[int(c.q) for c in coefficients]) if len(coefficients)>1 else 1
    return {
        'num': [int(scale*c) for c in reversed(pn.all_coeffs())],
        'den': [int(scale*c) for c in reversed(pd.all_coeffs())],
    }


def encode_op(op):
    return [{'a': encode_rf(a), 'b': encode_rf(b)} for a, b in op]


def abel_cover(F, P, q, h, curve_b, geometric_genus):
    """Reference geometric route: interpolate the degree-nine Miller function.

    The independent solver instead reduces a degree-eight elliptic divisor by
    four successive chord intersections. No cover coordinates are hardcoded.
    """
    domain = s.QQ.poly_ring(E)
    d = x**3-curve_b
    S = 4*d
    N = s.Poly(cancel(d*F), x, domain=domain)
    n = N.degree()
    a_degree, b_degree = n//2, (n-1)//2
    columns = [(N.diff()*s.Poly(x**j, x, domain=domain)).rem(N)
               for j in range(a_degree+1)]
    columns += [s.Poly(-2*d*x**j, x, domain=domain).rem(N)
                for j in range(b_degree+1)]
    matrix = s.Matrix(n, len(columns), lambda i, j: columns[j].nth(i))
    kernel = DomainMatrix.from_Matrix(matrix).nullspace().to_Matrix()
    assert kernel.rows == 1
    vector = list(kernel[0, :])
    content = s.gcd_list(vector)
    vector = [cancel(value/content) for value in vector]
    a = s.Poly(sum(vector[j]*x**j for j in range(a_degree+1)), x, domain=domain)
    b = s.Poly(sum(vector[a_degree+1+j]*x**j for j in range(b_degree+1)), x, domain=domain)
    norm = -a*a*s.Poly(P, x, domain=domain)-b*b*s.Poly(S, x, domain=domain)
    linear, remainder = norm.div(N)
    assert remainder.is_zero and linear.degree() == 1
    X = cancel(-linear.nth(0)/linear.nth(1))
    aX = s.S.Zero
    bX = s.S.Zero
    for coefficient in a.all_coeffs():
        aX = cancel(aX*X+coefficient)
    for coefficient in b.all_coeffs():
        bX = cancel(bX*X+coefficient)
    Y_multiplier = cancel(q*aX/bX)
    assert cancel(-h*Y_multiplier**2-4*(X**3-curve_b)) == 0
    pullback = cancel(s.diff(X, E)/Y_multiplier)
    polynomial = s.Poly(pullback, E)
    numerator, denominator = s.fraction(X)
    return {
        'x': encode_rf(X, E),
        'y_multiplier': encode_rf(Y_multiplier, E),
        'degree': max(int(s.degree(numerator, E)), int(s.degree(denominator, E))),
        'pullback': encode_rf(pullback, E),
        'ramification_polynomial': encode_rf(polynomial.monic().as_expr(), E),
        'infinity_ramification_order': 2*geometric_genus-2-2*polynomial.degree(),
    }


def solve(data):
    algebra = Algebra(data['curve_b'])
    u = cancel(data['coefficient_x']*x + data['pole_coefficient']*x/(x**3-data['curve_b']))
    f = [s.S.One]
    constants = None
    # Canonical densities from the formal identity
    # 2 F D²F - (DF)² - 4u F² + 4E F² = 4E.
    for n in range(9):
        middle = sum(f[i]*f[n+1-i] for i in range(1, n+1))
        second = sum(f[i]*algebra.d2(f[n-i]) for i in range(n+1))
        first = algebra.S*sum(s.diff(f[i], x)*s.diff(f[n-i], x) for i in range(n+1))
        product = sum(f[i]*f[n-i] for i in range(n+1))
        f.append(cancel(-middle/2-second/4+first/8+u*product/2))
        unknowns = s.symbols(f'c1:{n+1}')
        relation = cancel(s.diff(f[n+1], x) + sum(
            unknowns[j-1]*s.diff(f[n+1-j], x) for j in range(1, n+1)))
        if not unknowns:
            if relation == 0:
                constants = []
                genus_arithmetic = n
                break
            continue
        equations = s.Poly(s.fraction(relation)[0], x).all_coeffs()
        solutions = s.linsolve(equations, unknowns)
        if solutions:
            constants = list(next(iter(solutions)))
            assert all(v.is_Rational for v in constants)
            genus_arithmetic = n
            break
    if constants is None:
        raise RuntimeError('Stationary relation was not found in the search range')

    g = genus_arithmetic
    coefficients = [cancel(f[j]+sum(constants[k-1]*f[j-k] for k in range(1, j+1)))
                    for j in range(g+1)]
    F = sum(coefficients[j]*E**(g-j) for j in range(g+1))
    invariant = (E-u)*F**2 + F*algebra.d2(F)/2-algebra.S*s.diff(F, x)**2/4
    # The stationary equation proves D(invariant)=0. Evaluation at an ordinary
    # point extracts its constant value without large multivariate expansion.
    P = s.Poly(s.expand(invariant.subs(x, 0)), E).as_expr()
    q = s.S.One
    h = s.S.One
    unit, factors = s.factor_list(P, E)
    assert unit == 1
    for factor, multiplicity in factors:
        q *= factor**(multiplicity//2)
        h *= factor**(multiplicity % 2)
    q, h = s.expand(q), s.expand(h)

    L = [(u, s.S.Zero), ZERO, (-s.S.One, s.S.Zero)]
    powers = [[ONE]]
    for _ in range(g):
        powers.append(algebra.opmul(powers[-1], L))
    A = []
    for j, coefficient in enumerate(coefficients):
        pair = [(s.S.Zero, -s.diff(coefficient, x)/2), (coefficient, s.S.Zero)]
        A = algebra.opadd(A, algebra.opmul(pair, powers[g-j]))
    if g % 2:
        A = algebra.opneg(A)
    assert A[-1] == ONE
    divisor = algebra.poly_operator(q, L)
    quotient, remainder = algebra.right_divide(A, divisor)
    geometric_genus = (int(s.degree(h, E))-1)//2
    cover = abel_cover(F, P, q, h, data['curve_b'], geometric_genus)
    result = {
        'operator': encode_op(A),
        'spectral_polynomial': encode_rf(P, E),
        'square_factor': encode_rf(q, E),
        'normalized_polynomial': encode_rf(h, E),
        'genus': geometric_genus,
        'quotient': encode_op(quotient),
        'remainder': encode_op(remainder),
        'cover': cover,
    }
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='/app/data/operator.json')
    parser.add_argument('--output', default='/app/output/centralizer.json')
    args = parser.parse_args()
    started = time.perf_counter()
    result = solve(json.loads(Path(args.data).read_text()))
    destination = Path(args.output)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'order': len(result['operator'])-1, 'genus': result['genus'],
                      'seconds': round(time.perf_counter()-started, 6)}))


if __name__ == '__main__':
    main()
