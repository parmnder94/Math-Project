#!/bin/bash
set -euo pipefail
cd /app
python /solution/solve.py --data /app/data/jacobian.json --output /app/output/decomposition.json
