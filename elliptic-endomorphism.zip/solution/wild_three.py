"""Exact arithmetic and independently derived wild local record at three."""
from fractions import Fraction
import json
import sympy as s


def v3(n):
    n=int(n)
    if not n: raise ValueError('zero')
    ans=0
    while n%3==0:n//=3;ans+=1
    return ans


def pair(q):
    q=Fraction(q)
    return [q.numerator,q.denominator]


def solve_three(data=None):
    a,b,c=20416,20482,1120581
    differential_order=2
    if data is not None:
        x=s.symbols('x')
        def rf(spec):
            return s.cancel(sum(s.Integer(v)*x**i for i,v in enumerate(spec['num']))/
                            sum(s.Integer(v)*x**i for i,v in enumerate(spec['den'])))
        scaled=s.Poly(s.expand(rf(data['curve_h']).subs(x,3*x)/3**9),x)
        factors=s.factor_list(scaled.as_expr(),x)[1]
        cubic=next(s.Poly(f,x) for f,m in factors if s.degree(f,x)==3)
        sextic=next(s.Poly(f,x) for f,m in factors if s.degree(f,x)==6)
        a=int(-cubic.nth(0));b=int(-sextic.nth(3));c=int(sextic.nth(0))
        differential=s.Poly(s.cancel(s.diff(rf(data['alpha_x']),x)/rf(data['alpha_y_multiplier'])),x)
        assert differential.degree()==3 and differential.nth(1)==differential.nth(2)==0
        differential_order=v3(differential.nth(3))
        normalized_root=-differential.nth(0)/differential.nth(3)/27
        assert normalized_root.q==1 and int(normalized_root)%3==2
    assert (a%9,b%9,(c//27)%9)==(4,7,4)
    assert v3(c)==3 and v3(b-a)==1
    assert ((c//27)*pow(b,-1,9))%9==7
    x=s.symbols('x')
    assert v3(s.discriminant(x**3-a,x))==3
    # Shifted cubic is Eisenstein, hence the polynomial discriminant
    # equals the local field discriminant.
    assert v3(1-a)==1
    assert (b*pow(a*a,-1,9))%9==1
    assert (7*pow(a*a,-1,9))%9==1
    # Cluster depths, differential heights and source node lengths are
    # derived rather than supplied as unrelated answer constants.
    top=Fraction(0);six=Fraction(1,3)
    unit=Fraction(1,2);small=Fraction(3,2)
    nu_top=Fraction(1)
    nu_six=1+6*six
    nu_unit=1+3*unit+3*six
    nu_small=1+3*small
    heights=[differential_order+top-nu_top/2,differential_order+six-nu_six/2,
             differential_order+small-nu_small/2,differential_order+unit-nu_unit/2,
             differential_order+unit-nu_unit/2]
    lengths=[(small-top)/2,six-top,six-top,(unit-six)/2,(unit-six)/2]
    stable_e=s.ilcm(*[q.denominator for q in lengths])
    vertices=[{'genus':g,'vertical_order':pair(h)}
              for g,h in zip([0,0,1,1,1],heights)]
    ends=[[0,2],[0,1],[0,1],[1,3],[1,4]]
    orders=[[-2,0],[-3,1],[-3,1],[-2,0],[-2,0]]
    edges=[{'ends':ab,'thickness':pair(length),'differential_orders':od}
           for ab,length,od in zip(ends,lengths,orders)]
    # Three elliptic tails carry the two nontrivial wild C3 characters.
    # The root permutation representation has conductor discr=3 and
    # tame part2, giving Swan1 per tail. Both graph pieces have tame
    # character-1; full inertia therefore has no invariant vector.
    swan_per_tail=v3(s.discriminant(x**3-a,x))-2
    swan=3*swan_per_tail
    return {'prime':3,'L_polynomial':[1],'conductor':8+swan,'swan':swan,
            'stable_extension_e':int(stable_e),'vertices':vertices,'edges':edges}


if __name__=='__main__':
    print(json.dumps(solve_three(),indent=2))
