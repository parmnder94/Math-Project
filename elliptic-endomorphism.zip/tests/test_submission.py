"""The graded artifact is inert JSON and all mathematical checks are exact."""
import json
from pathlib import Path

from check_submission import verify_path


def test_exact_decomposition_certificate():
    metrics = verify_path("/app/output/decomposition.json")
    logdir = Path("/logs/verifier")
    logdir.mkdir(parents=True, exist_ok=True)
    (logdir / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
