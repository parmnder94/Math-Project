Determine the arithmetic decomposition of the Jacobian $J$ of the smooth projective curve
$$
C:W^2=-h(E),\qquad h(E)=(E^3-551232)(E^6-553014E^3+816903549).
$$
Find a nonconstant morphism $\alpha:C\to B_0:v^2=x^3-11$ defined over $\mathbb Q$, sending infinity to the elliptic identity, of smallest possible degree among all such morphisms. Express it as $\alpha(E,W)=(X(E),WY(E)/2)$ with $X,Y\in\mathbb Q(E)$; either sign is permitted. The curve also has the pointed map
$$
\beta:C\to B_1:v^2=u^3+1104246u^2+305655916797u+450303377122368,
\quad(E,W)\mapsto(-E^3,W).
$$
The exact curve coefficients are recorded in `/app/data/jacobian.json`.
Both send the unique point at infinity to the elliptic identity. Let $S=\alpha^*B_0+\beta^*B_1\subset J$ and let $A$ be its connected orthogonal complement for the canonical principal polarization of $J$. All intersections, polarizations, and decompositions below are geometric unless a ground field is stated.

Write `/app/output/decomposition.json` with these fields:

- `elliptic_map`: an object with exactly `x`, `y_multiplier`, and `degree`, giving $X,Y$ and the minimum degree of $\alpha$.
- `intersection_order`: the order of the finite group $\alpha^*B_0\cap\beta^*B_1$.
- `gluing`: a constructive certificate as defined below, or `null` if the intersection is trivial.
- `polarization_S`, `polarization_A`: the ordered elementary divisors of the induced polarizations. For type $(d_1,\ldots,d_g)$, require positive $d_i\mid d_{i+1}$; its kernel is $\prod_i(\mathbb Z/d_i\mathbb Z)^2$.
- `geometric_factors`, `rational_factors`: the complete simple isogeny factors of $J$ over $\overline{\mathbb Q}$ and $\mathbb Q$, respectively, together with their endomorphism algebras. Use the encoding below; list each isogeny class once.
- `integral_structure`: the integral endomorphism-order invariants defined below.
- `endomorphism_field`: the smallest Galois extension $L/\mathbb Q$ over which every geometric endomorphism of $J$ is defined. Give exactly `radicand` and `degree`, representing $L=\mathbb Q(\zeta_3,\sqrt[6]{m})$ by a nonzero rational number $m$ and the degree $[L:\mathbb Q]$. Equivalent radicands are accepted.
- `reduction_witnesses`: two good primes and exact point counts meeting the certificate conditions below.
- `local_data`: the local invariants and unmarked stable graphs at $p=3$, $p=5$, and $p=7$, as specified below.

For the gluing certificate work over $k=\mathbb Q(s)$ with $s^2=-11$, and fix $T=(0,s)\in B_0(k)$. Supply `point`, a nonzero $U\in B_1(k)$ of order three, `tangent`, its affine tangent $v=mu+n$, and `function`, an element $f\in k(C)$ satisfying
$$
f^3=\frac{WY(E)/2-s}{W-(-mE^3+n)}.
$$
This identity certifies $\alpha^*(T-O)=\beta^*(U-O)$ in $J$. Determine the full intersection, rather than just the subgroup exhibited by this identity.

Each isogeny-factor record has `dimension`, `multiplicity`, and `algebra`. The dimension is that of one simple abelian variety and multiplicity is its exponent in the isogeny decomposition. The algebra describes the division algebra of that simple factor: use `center_discriminant` equal to $1$ for $\mathbb Q$, or the fundamental discriminant for a quadratic center, and `quaternion_ramification` equal to `null` for the center itself. For a quaternion algebra over $\mathbb Q$, use `{"finite": [...], "infinity": true_or_false}`, listing precisely its finite ramified primes. The full endomorphism algebra has a matrix algebra of size `multiplicity` over each reported division algebra. Factor order is immaterial.

For $F=\overline{\mathbb Q},\mathbb Q$, put $R_F=\operatorname{End}_F(J)$ and choose a maximal $\mathbb Z$-order $M_F\supset R_F$ in $R_F\otimes\mathbb Q$. Let $\mathfrak c_F$ be the largest two-sided ideal of $M_F$ contained in $R_F$. Determine $[M_F:R_F]$ and the nontrivial invariant factors of the additive finite group $R_F/\mathfrak c_F$. These quantities are independent of the containing maximal order for this curve. In `integral_structure`, use exactly `geometric_index`, `rational_index`, `geometric_conductor_quotient`, and `rational_conductor_quotient`; the indices are positive integers and the quotient fields are arrays of integers greater than one in divisibility order, with `[]` for a trivial group. Use the endomorphism rings of $J$ itself.

A reduction-witness record has `prime` and `counts`, where `counts` contains three pairs of integers, in the order $C,B_0,B_1$; each pair is the number of projective points over $\mathbb F_p$ and $\mathbb F_{p^2}$. Choose distinct primes $5<p<100$ of good reduction. Subtract the two elliptic Frobenius traces from those of $C$ to obtain the degree-four Frobenius polynomial of $A$. For each chosen prime, its four eigenvalues raised to the sixth power must be the two roots, each repeated twice, of an ordinary elliptic Weil polynomial over $\mathbb F_{p^6}$. The two resulting imaginary quadratic fields must differ.

Each `local_data` record has `prime`, `L_polynomial`, `conductor`, `swan`, `stable_extension_e`, `vertices`, and `edges`. Here $L_p(t)=\det(1-\mathrm{Frob}_p t\mid H^1_{\mathrm{et}}(C_{\overline{\mathbb Q}_p},\mathbb Q_\ell)^{I_p})$ for $\ell\ne p$, with the convention that at good reduction the trace is $p+1-\#C(\mathbb F_p)$. `conductor` is the Artin conductor exponent and `swan` its wild part. `stable_extension_e` is the least ramification index of an extension of the maximal unramified extension of $\mathbb Q_p$ over which the unmarked curve has stable reduction.

Give the geometric dual graph over the algebraic closure of the residue field. A vertex record has `genus` and `vertical_order`: the valuation, normalized by $v_p(p)=1$, of the rational differential
$$
\omega=\alpha^*(dx/(2v))=\frac{X'(E)}{Y(E)}\frac{dE}{W}
$$
at that component. An edge record has `ends`, two vertex indices starting at zero, `thickness`, and `differential_orders`, the orders at its two branches of the corresponding leading differentials. Thickness is $v_p(a)$ in a local equation $xy=a$. On each component divide $\omega$ by a constant of valuation `vertical_order` before reduction. Orders of the resulting nonzero meromorphic differential are independent of the choice of that constant. Loops and multiple edges are allowed; vertex labels and edge order are immaterial. Do not mark branch points or enlarge the stable extension to split ramification points.

Use UTF-8 JSON with exactly the stated keys. Rational numbers are `[numerator,denominator]` with integer entries and nonzero denominator. A scalar in $k$ is `[a,b]` representing $a+bs$, with both entries rational numbers. `point` is `[u,v]` and `tangent` is `[m,n]` in this scalar encoding. `function` is an array of four rational functions $[a,b,c,d]$ meaning $a(E)+sb(E)+W(c(E)+sd(E))$. Each rational function is exactly `{"num": [...], "den": [...]}`, with integer polynomial coefficients from constant term upward and nonzero denominator. Equivalent fractions and trailing zeros are allowed. `L_polynomial` is an integer coefficient array from constant term upward. All dimensions, multiplicities, counts, genera, conductors, map and field degrees, prime numbers, extension indices, intersection orders, and polarization entries are integers; vertical orders and thicknesses use rational-number encoding; differential orders are integers. Booleans are accepted only for `infinity`. Repeated or extra object keys are invalid.

The artifact may contain at most 2,097,152 bytes, 129 coefficients per numerator or denominator, eight factors per decomposition, eight vertices and sixteen edges per graph. Every integer must have absolute value less than $2^{2048}$.

You have 14400 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
