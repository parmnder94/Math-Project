# Exact curve data

`jacobian.json` records the monic polynomial $h$, the coefficients of the elliptic cubics, and the map $\beta$ specified in `instruction.md`. Polynomial arrays run from constant term upward. These synthetic algebraic data have no numerical tolerances and are reproducible from seed 20261009.

The complete task and the sole output format for `/app/output/decomposition.json` are specified in `instruction.md`.
