#!/usr/bin/env python3
"""Reconstruct the exact public input from a seeded elliptic construction.

This computes only the input curves/maps. It never calls the decomposition
solver or verifier and contains none of their arithmetic conclusions.
"""
import argparse,json,random,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'input_construction'))
from solve import solve
SEED=20261009

def generate(seed=SEED):
    b=random.Random(seed).choice([1,2,3,5,7,11,13])
    r=solve({'curve_b':b,'coefficient_x':30,'pole_coefficient':18*b})
    h=r['normalized_polynomial'];assert h['den']==[1]
    # -h(E), with u=-E^3, gives the cubic model for B.
    a2=-h['num'][6];a4=h['num'][3];a6=-h['num'][0]
    return {'curve_h':h,'target_E':{'a2':0,'a4':0,'a6':-b},'target_B':{'a2':a2,'a4':a4,'a6':a6},'beta_coordinate_convention':'beta(E,W)=(-E^3,W) on B'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.write_text(json.dumps(generate(),indent=2)+'\n')
