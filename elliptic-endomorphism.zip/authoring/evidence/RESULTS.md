# Executed validation and calibration

The reference and a structurally independent solver both pass. The independent route uses a different map construction, divisor interpolation, finite-field arithmetic, modular linear reconstruction of the field, and explicit finite residue groups for the integral orders. The exact map and primitivity premises were separately rechecked.

The final verifier has 74 executed controls: 13 accepted representations and 61 rejected mathematical or malformed controls, all with the intended outcome. Alternative map signs, certificate primes, field radicands and graph labels pass. Actual separate-container runs produced reference reward 1 twice, independent reward 1, and empty-output reward 0 twice. These are direct Docker runs, not official harness results. The verifier runs offline and reads only the declared inert JSON artifact. Mathematical verification of valid artifacts takes hundredths of a second on this host; full reference generation takes seconds.

An independent adversarial review found no counterexample. Its 45 additional artifact probes produced 10 valid acceptances and 35 expected rejections; all 146 graph relabelings were accepted. A complete 93,312-vector supported field-presentation sweep matched the expected four integer representatives. Twenty copied-wrapper controls failed closed as intended, and a fresh isolated verifier container accepted the reference. See `adversarial/report.md` for scripts, results and scope; this is not an exhaustive security or platform audit.

## Calibration results

| Contract | Probe mode | Completed | Passed |
|---|---|---:|---:|
| Previous centralizer task | Earlier local runs | 8 | 8 |
| First arithmetic pilot | Fresh local contexts | 2 | 2 |
| Arithmetic revision with reconstructed map, minimum field and wild reduction | Fresh local contexts | 6 | 6 |
| Final contract including integral endomorphism orders | Fresh local contexts | 3 | 2 |
| Final integral requirement added to each solver's own frozen arithmetic solution | Independent continuations | 5 | 5 |

The final evidence is therefore two successes in three fresh full-task attempts and five successes in five continuations. The combined descriptive count is seven in eight; it is not eight fresh runs. The requested zero-to-one-success ceiling was not achieved in these local probes. No unsuccessful attempt was created by a short time cutoff, unavailable dependency or execution failure.

The sole failed fresh artifact has the wrong geometric integral-order index and conductor quotient. Its antilinear Hermitian construction omitted a conjugation needed for the actual geometric endomorphism algebra. Correct algebra multiplication identities alone did not establish the required Hodge compatibility. The remaining submitted fields pass when only `integral_structure` is replaced by the correct result. That replacement is a post-completion diagnosis, not a solver success. Frozen artifacts, reasoning, hashes, verifier verdicts and the explicit ablation are in `calibration/`. An exact independent audit in `calibration/integral_disagreement/` reproduces both the erroneous calculation and the corrected geometric index.

The requested Claude model was not run. No endpoint or evaluation harness is available, and the user confirmed that they have none. Probes used fresh contexts of the available collaboration model, with task-specific source restrictions; the continuation group then retained only its own prior work. The probes shared a workspace and were not an official process-isolated evaluation. Exact backend model revision and effort were not exposed. Two transient infrastructure events were retried successfully and are recorded separately in `calibration_summary.json`.

## Remaining project gates

The package is an assistant-produced instruction draft. Human authorship, author eligibility, private similarity screening, official harness checks and platform quality gates have not been certified by these technical checks. Supplied author details are retained as requested, without inventing a different professional background. This package must not be described as having established the requested difficulty or as having defeated an untested external model.
