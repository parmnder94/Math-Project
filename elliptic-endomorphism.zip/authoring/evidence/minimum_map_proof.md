# Minimum degree of the reconstructed elliptic map

Write the elliptic target as v²=x³−11, with its differential dx/(2v). The proofs that use y²=4(x³−11) use the isomorphic coordinate y=2v. The public task supplies neither the map nor the differential-operator construction used to discover it.

The reference constructs one pointed rational map α from the input curve to this target. The independent construction uses a different differential pencil and successive elliptic divisor reductions. Exact arithmetic verifies the curve equation for both constructions. The numerator and denominator degrees of X(E) are 18 and 17 after cancellation. The hyperelliptic coordinate E has degree two and the elliptic coordinate x has degree two; therefore the curve map α has degree 18.

The proof in primitive_cover_proof.md establishes that the induced homomorphism α_*:J→B0 has connected kernel. Its proof uses exact ramification and finite-field generation at a good prime, rather than an assumption that a displayed map is primitive. Equivalently, its dual α*:B0→J is an embedding. The points used in that proof are expressed with y=2v and can be converted by dividing their second coordinate by two.

The independent gluing and endomorphism arguments show that J is geometrically isogenous to B0×B1×A, where B1 is non-CM and geometrically nonisogenous to B0, and A is a geometrically simple surface. Consequently Hom_Q(J,B0) has rank one over Z: its rational span is End_Q(B0)=Q. This conclusion does not assume minimum degree for α; only the existence and primitivity of the constructed map enter the gluing proof.

Since the homomorphism group is a free rank-one lattice, write α_*=nψ for a generator ψ. If |n|>1, dualizing gives α*=ψ*∘[n], whose kernel contains B0[n]. This contradicts injectivity. Thus α_* is itself a generator up to sign.

Every morphism γ:C→B0 taking infinity to O factors uniquely through the pointed Abel–Jacobi map and a rational homomorphism J→B0. Hence γ=[m]∘α for an integer m. A nonconstant map has m≠0, and its degree is 18m². The minimum is therefore 18, and the two rational pointed maps of minimum degree are α and −α.

No polynomial degree ansatz or imposed pole bound is used to exclude alternative maps. The verifier accepts any rational functions defining a pointed map of degree 18 to the required target, and thus accepts either sign and every equivalent rational encoding.
