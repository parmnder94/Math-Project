"""Exact verification of inert Jacobian-decomposition JSON.

Field identities, new point counts, and graph isomorphisms check constructive
outputs. Mathematical proofs establish the complete algebra classifications.
"""
from __future__ import annotations
import itertools
import json
import math
import time
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
from flint import fmpq, fmpq_poly, nmod_poly

MAX_BYTES=2097152
MAX_BITS=2048
MAX_COEFFICIENTS=129
class VerificationError(ValueError):
    pass

def require(condition,message):
    if not condition:
        raise VerificationError(message)

class RF:
    """Canonical element of Q(x), represented by FLINT rational polynomials."""

    __slots__ = ("n", "d", "_derivative")

    def __init__(self, n=0, d=1):
        n = n if isinstance(n, fmpq_poly) else fmpq_poly(n if isinstance(n, list) else [n])
        d = d if isinstance(d, fmpq_poly) else fmpq_poly(d if isinstance(d, list) else [d])
        if not d:
            raise ZeroDivisionError("zero rational-function denominator")
        if not n:
            self.n, self.d = fmpq_poly([]), fmpq_poly([1])
        else:
            g = n.gcd(d)
            n, rn = divmod(n, g)
            d, rd = divmod(d, g)
            if rn or rd:
                raise ArithmeticError("nonexact polynomial gcd division")
            leading = d.leading_coefficient()
            self.n, self.d = n / leading, d / leading
        self._derivative = None

    def __bool__(self):
        return bool(self.n)

    def __eq__(self, other):
        other = as_rf(other)
        return self.n == other.n and self.d == other.d

    def __neg__(self):
        return RF(-self.n, self.d)

    def __add__(self, other):
        other = as_rf(other)
        if not self:
            return other
        if not other:
            return self
        if self.d == other.d:
            return RF(self.n + other.n, self.d)
        return RF(self.n * other.d + other.n * self.d, self.d * other.d)

    __radd__ = __add__

    def __sub__(self, other):
        return self + (-as_rf(other))

    def __rsub__(self, other):
        return as_rf(other) - self

    def __mul__(self, other):
        other = as_rf(other)
        if not self or not other:
            return ZERO_RF
        return RF(self.n * other.n, self.d * other.d)

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = as_rf(other)
        if not other:
            raise ZeroDivisionError("zero rational function")
        return RF(self.n * other.d, self.d * other.n)

    def derivative(self):
        if self._derivative is None:
            self._derivative = RF(self.n.derivative() * self.d - self.n * self.d.derivative(), self.d * self.d)
        return self._derivative

    def polynomial(self, where):
        require(self.d.degree() == 0, f"{where} must reduce to a polynomial")
        return self.n / self.d[0]


def as_rf(value):
    return value if isinstance(value, RF) else RF(value)


ZERO_RF = RF(0)
ONE_RF = RF(1)
ZERO=ZERO_RF
ONE=ONE_RF
VARIABLE=RF([0,1])
H=RF([-450303377122368,0,0,305655916797,0,0,-1104246,0,0,1])


def keys(value,expected,where):
    require(type(value) is dict,where+' must be an object')
    require(set(value)==set(expected),where+' has incorrect keys')


def array(value,where,length=None,maximum=None):
    require(type(value) is list,where+' must be an array')
    if length is not None:require(len(value)==length,where+' has incorrect length')
    if maximum is not None:require(len(value)<=maximum,where+' is too long')
    return value


def integer(value,where,minimum=None):
    require(type(value) is int,where+' must be an integer')
    require(value.bit_length()<=MAX_BITS,where+' exceeds integer bound')
    if minimum is not None:require(value>=minimum,where+' is too small')
    return value


def rational(value,where):
    array(value,where,length=2)
    a=integer(value[0],where+' numerator');b=integer(value[1],where+' denominator')
    require(b!=0,where+' has zero denominator')
    return Fraction(a,b)


def polynomial(value,where,maximum=MAX_COEFFICIENTS):
    array(value,where,maximum=maximum)
    return fmpq_poly([integer(v,where) for v in value])


def rational_function(value,where):
    keys(value,('num','den'),where)
    n=polynomial(value['num'],where+'.num');d=polynomial(value['den'],where+'.den')
    require(bool(d),where+' has zero denominator')
    return RF(n,d)


class Field:
    """Q(E)[s,W], s^2=-11, W^2=-h, in the basis 1,s,W,sW."""
    __slots__=('c',)
    def __init__(self,coefficients=(0,0,0,0)):
        self.c=tuple(as_rf(c) for c in coefficients)
    def __bool__(self):return any(self.c)
    def __eq__(self,other):return self.c==field(other).c
    def __neg__(self):return Field([-c for c in self.c])
    def __add__(self,other):return Field([a+b for a,b in zip(self.c,field(other).c)])
    __radd__=__add__
    def __sub__(self,other):return self+-field(other)
    def __rsub__(self,other):return field(other)+-self
    def __mul__(self,other):
        other=field(other);out=[ZERO]*4
        for i,a in enumerate(self.c):
            if not a:continue
            for j,b in enumerate(other.c):
                if not b:continue
                term=a*b
                if i&j&1:term=term*(-11)
                if i&j&2:term=term*(-H)
                out[i^j]=out[i^j]+term
        return Field(out)
    __rmul__=__mul__
    def __pow__(self,n):
        result=field(1)
        for _ in range(n):result=result*self
        return result


def field(value):return value if isinstance(value,Field) else Field((value,0,0,0))


def scalar(value,where):
    array(value,where,length=2)
    aa=rational(value[0],where+'.a');bb=rational(value[1],where+'.b')
    return Field((fmpq(aa.numerator,aa.denominator),fmpq(bb.numerator,bb.denominator),0,0))


def verify_elliptic_map(value):
    keys(value,('x','y_multiplier','degree'),'elliptic_map')
    x=rational_function(value['x'],'elliptic_map.x')
    y=rational_function(value['y_multiplier'],'elliptic_map.y_multiplier')
    degree=integer(value['degree'],'elliptic_map.degree',1)
    require(bool(y),'elliptic map has zero ordinate multiplier')
    require(-H*y*y==4*(x*x*x-11),'elliptic map does not satisfy target equation')
    require(x.n.degree()>x.d.degree(),'elliptic map does not send source infinity to the identity')
    actual_degree=max(x.n.degree(),x.d.degree())
    # The independent Hom-lattice argument proves the minimum degree is 18.
    # Exact curve and pole identities admit every representation of either
    # pointed minimal map, without choosing a sign for its elliptic ordinate.
    require(degree==actual_degree==18,'elliptic map does not have minimal positive degree')
    return y


def verify_gluing(value,y):
    keys(value,('point','tangent','function'),'gluing')
    array(value['point'],'point',length=2);array(value['tangent'],'tangent',length=2)
    u,v=[scalar(a,'point') for a in value['point']]
    m,n=[scalar(a,'tangent') for a in value['tangent']]
    require(bool(v),'nonzero affine three-torsion cannot have zero ordinate')
    require(v*v==u**3+1104246*u*u+305655916797*u+450303377122368,'point is not on B1')
    require(v==m*u+n,'tangent does not pass through point')
    require(1104246-m*m==-3*u and 305655916797-2*m*n==3*u*u
            and 450303377122368-n*n==-(u**3),'line is not a flex tangent')
    array(value['function'],'function',length=4)
    f=Field([rational_function(a,'function') for a in value['function']])
    w=Field((0,0,1,0));s=Field((0,1,0,0))
    denominator=w-(m*field(-VARIABLE*VARIABLE*VARIABLE)+n)
    require(f**3*denominator==w*field(y/2)-s,'gluing cube identity fails')


def parse_factors(value,where):
    array(value,where,maximum=8);out=[]
    for item in value:
        keys(item,('dimension','multiplicity','algebra'),where)
        dim=integer(item['dimension'],where,1);mult=integer(item['multiplicity'],where,1)
        alg=item['algebra'];keys(alg,('center_discriminant','quaternion_ramification'),where+'.algebra')
        center=integer(alg['center_discriminant'],where+'.center_discriminant')
        ram=alg['quaternion_ramification']
        if ram is None:encoded=None
        else:
            keys(ram,('finite','infinity'),where+'.quaternion_ramification')
            array(ram['finite'],where+'.finite')
            finite=[integer(p,where+'.finite',2) for p in ram['finite']]
            require(len(set(finite))==len(finite),'a ramification place was repeated')
            require(type(ram['infinity']) is bool,'infinity must be Boolean')
            encoded=(tuple(sorted(finite)),ram['infinity'])
        out.append((dim,mult,center,encoded))
    return Counter(out)


def is_prime(p):return p>=2 and all(p%d for d in range(2,math.isqrt(p)+1))


def good_prime(p):
    if not is_prime(p):return False
    for coefficients in ([int(c) for c in H.n],[-11,0,0,1],
                         [450303377122368,305655916797,1104246,1]):
        f=nmod_poly(coefficients,p)
        if f.gcd(f.derivative()).degree()!=0:return False
    return True


@lru_cache(maxsize=32)
def point_counts(p,n):
    squares=[0]*p;squares[0]=1
    for x in range(1,p):squares[x]=2 if pow(x,(p-1)//2,p)==1 else 0
    total=[1,1,1]
    if n==1:
        for x in range(p):
            t=x*x*x%p
            vals=(-(t-551232)*(t*t-553014*t+816903549),t-11,
                  t+1104246*x*x+305655916797*x+450303377122368)
            for i,v in enumerate(vals):total[i]+=squares[v%p]
        return tuple(total)
    d=next(d for d in range(2,p) if squares[d]==0)
    def mul(x,y):return ((x[0]*y[0]+d*x[1]*y[1])%p,(x[0]*y[1]+x[1]*y[0])%p)
    def add(x,y):return ((x[0]+y[0])%p,(x[1]+y[1])%p)
    def const(x,c):return ((x[0]+c)%p,x[1])
    def scale(x,c):return (c*x[0]%p,c*x[1]%p)
    for a in range(p):
        for b in range(p):
            x=(a,b);x2=mul(x,x);t=mul(x2,x)
            h=mul(const(t,-551232),const(add(mul(t,t),scale(t,-553014)),816903549))
            vals=(scale(h,-1),const(t,-11),const(add(add(t,scale(x2,1104246)),scale(x,305655916797)),450303377122368))
            for i,(v,w) in enumerate(vals):
                total[i]+=1 if v==w==0 else squares[(v*v-d*w*w)%p]
    return tuple(total)


def residual_polynomial(p,counts):
    traces=[]
    for n,row in enumerate(counts,1):
        nc,n0,n1=row
        traces.append((p**n+1-nc)-(p**n+1-n0)-(p**n+1-n1))
    a,b=traces
    require((a*a-b)%2==0,'nonintegral Frobenius coefficient')
    return [1,-a,(a*a-b)//2,-p*a,p*p]


def power_sums(coefficients,limit):
    degree=len(coefficients)-1;out=[degree]
    for k in range(1,limit+1):
        if k<=degree:value=-k*coefficients[k]-sum(coefficients[j]*out[k-j] for j in range(1,k))
        else:value=-sum(coefficients[j]*out[k-j] for j in range(1,degree+1))
        out.append(value)
    return out


def verify_witnesses(value):
    array(value,'reduction_witnesses',length=2);primes=[];discriminants=[]
    for item in value:
        keys(item,('prime','counts'),'reduction witness')
        p=integer(item['prime'],'reduction prime')
        require(5<p<100 and good_prime(p),'reduction prime is outside bounds or bad')
        require(p not in primes,'reduction primes must differ');primes.append(p)
        array(item['counts'],'counts',length=3);submitted=[]
        for row in item['counts']:
            array(row,'counts row',length=2)
            submitted.append(tuple(integer(a,'point count',0) for a in row))
        counts=[point_counts(p,n) for n in (1,2)]
        require(submitted==list(zip(*counts)),'incorrect projective point counts')
        powers=power_sums(residual_polynomial(p,counts),24)
        require(powers[6]%2==0,'sixth-power trace is not twice an integer')
        trace=powers[6]//2;q=p**6
        require(powers[12]==2*(trace*trace-2*q)
                and powers[18]==2*(trace**3-3*q*trace)
                and powers[24]==2*(trace**4-4*q*trace*trace+2*q*q),
                'sixth powers do not give one repeated elliptic quadratic')
        disc=trace*trace-4*q
        require(disc<0 and trace%p!=0,'sixth-power quadratic is not ordinary elliptic')
        discriminants.append(disc)
    product=discriminants[0]*discriminants[1]
    require(math.isqrt(product)**2!=product,'the two quadratic fields coincide')
    # Descent lemma, proved independently: specialization at 13 places rational
    # endomorphisms in K x K; complex conjugation fixes a real quadratic field.
    require(residual_polynomial(13,[point_counts(13,n) for n in (1,2)])==[1,0,1,0,169],
            'internal descent certificate failed')
    return primes


LOCAL={
 3:{'L':[1],'conductor':11,'swan':3,'e':12,
    'vertices':[(0,Fraction(3,2)),(0,Fraction(5,6)),(1,Fraction(3,4)),(1,Fraction(3,4)),(1,Fraction(3,4))],
    'edges':[(0,2,Fraction(3,4),-2,0),(0,1,Fraction(1,3),-3,1),
             (0,1,Fraction(1,3),-3,1),(1,3,Fraction(1,12),-2,0),(1,4,Fraction(1,12),-2,0)]},
 5:{'L':[1,0,20,0,150,0,500,0,625],'conductor':0,'swan':0,'e':1,
    'vertices':[(1,Fraction(0)),(1,Fraction(1)),(1,Fraction(1)),(1,Fraction(1))],
    'edges':[(0,1,Fraction(1),0,-2),(0,2,Fraction(1),0,-2),(0,3,Fraction(1),0,-2)]},
 7:{'L':[1,11,49,109,119,49],'conductor':3,'swan':0,'e':2,
    'vertices':[(1,Fraction(0)),(2,Fraction(0))],
    'edges':[(0,1,Fraction(1,2),0,1),(0,1,Fraction(1,2),0,1)]},
}


def edge_key(edge):
    a,b,t,u,v=edge
    return min((a,b,t,u,v),(b,a,t,v,u))


def equivalent_graph(vertices,edges,expected):
    ev=expected['vertices'];ee=expected['edges']
    if len(vertices)!=len(ev) or len(edges)!=len(ee) or Counter(vertices)!=Counter(ev):return False
    target=Counter(edge_key(e) for e in ee);classes=[]
    for color in set(vertices):
        source=[i for i,v in enumerate(vertices) if v==color]
        destinations=[i for i,v in enumerate(ev) if v==color]
        classes.append((source,destinations))
    for choices in itertools.product(*(itertools.permutations(b) for a,b in classes)):
        mapping={}
        for (source,_),destination in zip(classes,choices):mapping.update(zip(source,destination))
        candidate=Counter(edge_key((mapping[a],mapping[b],t,u,v)) for a,b,t,u,v in edges)
        if candidate==target:return True
    return False


def verify_local(value):
    array(value,'local_data',length=3);seen=set()
    for item in value:
        keys(item,('prime','L_polynomial','conductor','swan','stable_extension_e','vertices','edges'),'local_data record')
        p=integer(item['prime'],'local prime')
        require(p in LOCAL and p not in seen,'local_data must contain primes 3, 5 and 7 once each');seen.add(p)
        expected=LOCAL[p]
        # No extra raw length bound is imposed on L_polynomial: the published
        # 129-coefficient bound applies to rational-function numerators/denominators.
        actual=polynomial(item['L_polynomial'],'L_polynomial',maximum=MAX_BYTES)
        require(actual==fmpq_poly(expected['L']),'incorrect local L polynomial')
        for key,target in [('conductor','conductor'),('swan','swan'),('stable_extension_e','e')]:
            require(integer(item[key],key,0)==expected[target],'incorrect '+key)
        array(item['vertices'],'vertices',maximum=8);vertices=[]
        for v in item['vertices']:
            keys(v,('genus','vertical_order'),'vertex')
            vertices.append((integer(v['genus'],'vertex genus',0),rational(v['vertical_order'],'vertical order')))
        array(item['edges'],'edges',maximum=16);edges=[]
        for edge in item['edges']:
            keys(edge,('ends','thickness','differential_orders'),'edge')
            array(edge['ends'],'edge ends',length=2);array(edge['differential_orders'],'differential orders',length=2)
            a,b=[integer(v,'vertex index',0) for v in edge['ends']]
            require(a<len(vertices) and b<len(vertices),'vertex index is out of bounds')
            thick=rational(edge['thickness'],'thickness');require(thick>0,'thickness must be positive')
            u,v=[integer(o,'differential order') for o in edge['differential_orders']]
            edges.append((a,b,thick,u,v))
        require(equivalent_graph(vertices,edges,expected),'incorrect weighted stable graph')


def integer_sixth_power(value):
    if value<0:return False
    if value in (0,1):return True
    low=0;high=1<<((value.bit_length()+5)//6)
    while low+1<high:
        middle=(low+high)//2
        if middle**6<value:low=middle
        else:high=middle
    return high**6==value


def rational_sixth_power(value):
    return value>0 and integer_sixth_power(value.numerator) and integer_sixth_power(value.denominator)


def eisenstein_sixth_power(value):
    # For r in Q*, r is a sixth power in Q(sqrt(-3)) exactly when it is
    # a positive rational sixth power, or -27 times such a power.
    return rational_sixth_power(value) or rational_sixth_power(value/Fraction(-27))


def verify_endomorphism_field(value):
    keys(value,('radicand','degree'),'endomorphism_field')
    m=rational(value['radicand'],'endomorphism_field.radicand')
    require(integer(value['degree'],'endomorphism_field.degree',1)==12,'incorrect endomorphism field degree')
    canonical=Fraction(-1203587)
    require(eisenstein_sixth_power(m/canonical) or eisenstein_sixth_power(m*canonical),
            'incorrect minimal field of definition of all endomorphisms')


def verify_object(obj):
    started=time.perf_counter()
    keys(obj,('elliptic_map','intersection_order','gluing','polarization_S','polarization_A','geometric_factors','rational_factors','endomorphism_field','reduction_witnesses','local_data'),'submission')
    require(integer(obj['intersection_order'],'intersection_order',1)==3,'incorrect full intersection order')
    for key in ('polarization_S','polarization_A'):
        array(obj[key],key,length=2)
        require([integer(a,key,1) for a in obj[key]]==[1,18],'incorrect induced polarization')
    expected_geo=Counter([(1,1,-3,None),(1,1,1,None),(2,1,1,((2,3),False))])
    expected_rat=Counter([(1,1,1,None),(1,1,1,None),(2,1,1,None)])
    require(parse_factors(obj['geometric_factors'],'geometric_factors')==expected_geo,'incorrect geometric factors or endomorphism algebras')
    require(parse_factors(obj['rational_factors'],'rational_factors')==expected_rat,'incorrect rational factors or endomorphism algebras')
    verify_endomorphism_field(obj['endomorphism_field'])
    y=verify_elliptic_map(obj['elliptic_map'])
    verify_gluing(obj['gluing'],y)
    primes=verify_witnesses(obj['reduction_witnesses'])
    verify_local(obj['local_data'])
    return {'exact_gluing_identity':True,'reduction_primes':primes,'endomorphism_field_degree':12,'weighted_graphs_verified':[3,5,7],
            'seconds':round(time.perf_counter()-started,6)}


def no_duplicates(pairs):
    result={}
    for key,value in pairs:
        require(key not in result,'repeated JSON key: '+key)
        result[key]=value
    return result


def reject_number(text):
    raise VerificationError('floating or nonfinite JSON number is forbidden')


def json_integer(text):
    require(len(text.lstrip('-'))<=617,'JSON integer exceeds integer bound')
    return integer(int(text),'JSON integer')


def verify_path(path):
    path=Path(path)
    require(path.is_file(),'missing submission artifact')
    require(path.stat().st_size<=MAX_BYTES,'submission exceeds byte limit')
    with path.open('rb') as stream:raw=stream.read(MAX_BYTES+1)
    require(len(raw)<=MAX_BYTES,'submission exceeds byte limit')
    try:
        obj=json.loads(raw.decode('utf-8'),object_pairs_hook=no_duplicates,
                       parse_int=json_integer,parse_float=reject_number,parse_constant=reject_number)
    except (UnicodeDecodeError,json.JSONDecodeError,RecursionError) as exc:
        raise VerificationError('invalid UTF-8 JSON') from exc
    return verify_object(obj)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('path',nargs='?',default='/app/output/decomposition.json')
    args=parser.parse_args()
    try:print(json.dumps({'accepted':True,'metrics':verify_path(args.path)},sort_keys=True))
    except (VerificationError,OSError) as exc:
        print(json.dumps({'accepted':False,'error':str(exc)},sort_keys=True))
        raise SystemExit(1)
