# Incremental integral endomorphism calculation

This calculation uses only my own frozen solution files and general mathematical facts. It does not replace the Jacobian by its isogenous product: the integral H_1 lattice of J is used throughout. No root or sibling artifacts were inspected.

The answer is

    [M:R] = 8748 = 2^2*3^7,
    [Mq:Rq] = 54 = 2*3^3,
    R/C  = (Z/3)^2 + (Z/18)^2,
    Rq/Cq = Z/18.

The requested four-key JSON is output/integral_structure.json. The matrices constituting a reproducible exact certificate are in integral_order_certificate.json, and integral_verify.py checks them independently of the construction script.

## 1. Rational algebra used

The frozen calculation gives

    End^0_Qbar(J) = K x Q x D,
    K=Q(zeta), zeta^2+zeta+1=0,
    D=(-3,2), discr(D)=6,
    End^0_Q(J)=Q x Q x Q.

The components correspond to B0, B1, and A in this order. The primitive elliptic map alpha has degree 18, and sigma:(E,W)->(zeta E,W) is an integral automorphism. Its action on B0 is multiplication by zeta, and its invariant factor is B1.

Write O=Z[zeta]. The maximal order in D ultimately used below has the presentation

    O_D = O + O j,
    j^2=2, j zeta=bar(zeta) j.

Its reduced discriminant is 6, so it is maximal. The certificate embeds this order in the actual rational endomorphisms of J, rather than merely choosing an abstract quaternion algebra.

## 2. Exact homology model of J

The nine finite branch points are on three radial arms. Their three positive radii correspond to the real numbers

    b < a < c,
    a=551232,
    b,c=(553014 +/- sqrt(302556870000))/2,

by E=t^(1/3), with b the minus sign. On arm i, let e_i be the lifted cycle from b^(1/3) to a^(1/3), f_i the one from a^(1/3) to c^(1/3), and g_i the one from c^(1/3) to infinity. Each cycle goes out on one sheet and returns on the other. On the positive arm the outward sheet has W=+i sqrt(h) for e and g, and W=+sqrt(-h) for f. The other arms are their sigma translates.

The three rays, including infinity, are an embedded branch tree. Its nine lifted edge cycles generate integral homology with the single relation

    g_0+g_1+g_2=e_0+e_1+e_2.

A basis is (e0,f0,g0,e1,f1,g1,e2,f2). The local branch orientations give

    e_i . f_i = 1,
    f_i . g_i = -1,
    g_i . g_(i+1) = 1

(indices on arms modulo three), with other unlisted pairings zero and skew symmetry understood. The last sign is also fixed without ambiguity by the positive degree identity alpha_* alpha^*=18. The resulting eight-dimensional alternating matrix J has determinant one. Sigma cyclically shifts the arms, with g2 eliminated by the displayed relation. Its integer matrix S satisfies S^3=1 and S^t J S=J. The matrices are included in the certificate.

### Alpha on integral homology

Let Omega be the positive real period of B0 and let delta=1+2zeta=sqrt(-3). In the target period basis (Omega,zeta Omega),

    alpha_*(e0) = -delta,
    alpha_*(f0) = 1,
    alpha_*(g0) = -3delta.

These identities can be established by real-circle degrees, without relying on numerical recognition. The source e and g circles map into the anti-real circle of B0; f maps into its real circle. The anti-real circle has primitive homology delta, since it is the primitive anti-invariant vector for complex conjugation on Z+Z zeta.

For the real map X, its positive poles are at t=a and at the unique positive root of

    D(t)=t^2+902286t-836509234176,

together with infinity. The positive root of D is strictly larger than c: D(c)<0 and D is strictly increasing for positive t. There are no cancellations. The e and f circles each have exactly one preimage of the elliptic identity, namely the point t=a, with local degree one. The g circle has three: its point at infinity and the two points over the positive root of D, all with local degree one. The pullback differential 9(t-120582)dE/W fixes the signs. On f it is positive real; on g it is negative imaginary and has no zero. At the unique identity preimage on e it has negative imaginary orientation. Hence the degrees are respectively -1,+1,-3 in the stated real and anti-real generators.

This also supplies an exact justification of the integer values first suggested by integral_periods.py. That numerical script is only a discovery cross-check.

Sigma-equivariance determines all remaining columns. Thus the exact alpha pushforward matrix is

    F = [ -1  1 -3  2  0  6 -1 -1 ]
        [ -2  0 -6  1  1  3  1 -1 ].

Let J0=[[0,1],[-1,0]]. The adjoint G=J^(-1)F^t J0 satisfies FG=18 I2. The three rational projectors are therefore

    P0=GF/18,
    P1=(1+S+S^2)/3,
    PA=1-P0-P1.

This step retains the finite gluings in H_1(J,Z). In particular the projectors are rational matrices, not assumed integral.

## 3. Recovering all rational quaternion operators on the lattice

On V_A=PA H_1(J,Q), the K-antilinear Rosati-symmetric operators T satisfy the exact linear equations

    T S_A + S_A T + T = 0,
    T^t J_A = J_A T.

Their solution space has dimension two. It is exactly the anti-K part of D. Indeed the known quaternion algebra embeds in this space: Rosati conjugates K, and on the anti-K part it is symmetric. Conversely the dimension-two computation leaves no room for other solutions. Together with 1 and zeta these operators give all of D, not just a suborder of possibly unknown index.

A rational linear combination gives j^2=2 on V_A. Extending by zero on the elliptic components gives the certificate's matrix j. The seven matrices

    P0, S P0, P1, PA, S PA, j, S j

are a Z-basis of a containing maximal order M. They obey the quaternion relations, and all multiplication structure constants are integers. The reduced-trace determinant of the last four is -36, confirming reduced discriminant 6. Thus

    M=O x Z x O_D.

## 4. The full geometric integral order

A rational Hodge endomorphism of a complex abelian variety is an actual integral endomorphism if and only if it preserves integral homology. Accordingly

    R = End^0_Qbar(J) intersect M_8(Z)

in the matrix representation just constructed. This criterion does not discard any gluing information.

To obtain this intersection exactly, put the seven flattened 8-by-8 matrices into a 64-by-7 rational matrix B. If d clears its denominators and H is a row-module basis of dB, then the complete coefficient lattice is

    R_coeff = d H^(-1) Z^7.

Hermite normal form computes H exactly. This is an equality of lattices, not a test of a few proposed generators.

In the maximal-order coordinate basis above, the resulting basis matrix is

    [  1   0  0   0   0  0  0 ]
    [  0   1  0   0   0  0  0 ]
    [ -2  -2  3   0   0  0  0 ]
    [-17   0  0  18   0  0  0 ]
    [  0 -17  0   0  18  0  0 ]
    [  0   0  0   0   0  3  0 ]
    [  0   0  0   0   0  0  3 ].

Equivalently, write a maximal-order element as (z,n,a+bj), with z,a,b in O and n in Z. Then

    R = { (z,n,a+bj):
          a congruent z modulo 18 O,
          b in 3 O,
          n congruent z modulo (1-zeta) O }.

The last congruence identifies O/(1-zeta) with F3, so if z=x+y zeta it reads n congruent x+y modulo 3. This expression explicitly exhibits the couplings between the nonisogenous rational factors.

Its index is

    [M:R]=18^2 * 3^2 * 3 = 8748.

In particular the A-component's projected order is O+3O j; replacing it by a maximal order before computing End(J) would already lose an index of nine, in addition to the inter-factor congruences.

## 5. The geometric two-sided conductor

Every two-sided ideal of the product maximal order decomposes into its three components. The largest ideal inside R is

    C = 18 O x 3 Z x (18 O + 9 O j).

The quaternion component is the two-sided ideal 9j O_D, since j O_D=2O+O j.

For maximality of this conductor, an isolated quaternion element a+bj in R must have a in 18O and b in 3O. Closure under multiplication by j additionally requires 2 bar(b) in 18O, hence b in 9O. These conditions are sufficient for a two-sided ideal, proving the assertion. The isolated K and Q components similarly force 18O and 3Z respectively.

In the maximal-order basis its lattice is diagonal with entries

    18,18,3,18,18,9,9.

Modulo C, the remaining independent additive parameters are z modulo 18O and the anti-K coefficient b in 3O/9O. The other coordinates are forced by the congruences. Hence

    R/C = (O/18O) + (3O/9O)
        = (Z/18)^2 + (Z/3)^2.

The nontrivial invariant factors in divisibility order are [3,3,18,18]. Smith normal form of the exact conductor lattice gives the same answer.

## 6. Rational integral order and conductor

Intersecting with the rational scalar algebra gives

    Rq = { (x,n,u) in Z^3:
           n congruent x modulo 3,
           u congruent x modulo 18 }.

No rational scalar can acquire a nonintegral coordinate: it is integral over Z in each simple factor, so its rational value is an integer. Direct intersection with the three projector matrices independently gives the basis

    [  1  0   0 ]
    [ -2  3   0 ]
    [-17  0  18 ].

Thus [Mq:Rq]=54 for Mq=Z^3. Its largest two-sided ideal in Mq is

    Cq=18Z x 3Z x 18Z.

The quotient is parametrized by x modulo 18, giving Rq/Cq=Z/18. Its single nontrivial invariant factor is [18].

## 7. Independence of the containing maximal order

Mq=Z^3 is unique. For the geometric algebra, a maximal order is the product of maximal orders in its three simple factors, because the central primitive idempotents are integral and belong to every maximal order.

The computed index [M:R]=2^2*3^7 has no other prime factors. At every prime other than 2 and 3, R_l=M_l is already maximal, so any containing maximal order must agree with M locally. At 2 and 3, the quaternion algebra D_l is a division algebra; it has a unique maximal Z_l-order. The field factor K and rational factor also have unique local maximal orders. Consequently any maximal order containing R agrees with M at every prime, and hence equals M as an order in the given rational algebra. In particular both requested indices and both conductor quotients are independent of the containing maximal order.

## Verification and uncertainty

Executed exact checks in integral_verify.py include:

- unimodularity of J, order three and symplecticity of S;
- the exact alpha pushforward, sigma-equivariance, and FG=18;
- the orthogonal idempotents and all quaternion relations;
- integral multiplication and maximal quaternion reduced discriminant 6;
- equality of the entire integral endomorphism lattice with the HNF intersection;
- closure under all ring products;
- the conductor computed as all x for which MxM lies in R;
- rational lattice equality, indices, and Smith invariant factors.

The conductor test uses all left and right multiplication operators for a maximal-order basis, so it proves largest two-sided conductor rather than only verifying a candidate ideal is contained. The explicit ideal argument above gives a second check.

There is no unresolved mathematical obstruction. The period approximations were replaced in the proof by exact real-circle degree arguments. The incremental calculation uses the rational decomposition established in the original frozen attempt; it introduces no further unproved isogeny or maximality assumption.
