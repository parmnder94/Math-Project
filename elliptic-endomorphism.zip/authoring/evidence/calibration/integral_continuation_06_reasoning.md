# Integral endomorphism rings of the actual Jacobian

The answer in `output/integral_structure.json` is

```
{
  "geometric_index": 8748,
  "rational_index": 54,
  "geometric_conductor_quotient": [3, 3, 18, 18],
  "rational_conductor_quotient": [18]
}
```

These calculations use the actual integral homology lattice of C, with its unimodular intersection form. They do not replace J by an isogenous product. Only my own previous files and general mathematical facts were used.

## 1. An integral homology basis

Write the three positive real roots of h in increasing E-coordinate order as

    r < a < b,

where a^3=551232, and r^3,b^3 are the roots of t^2-553014t+816903549. All nine finite branch points are zeta^i r,zeta^i a,zeta^i b for i=0,1,2; the tenth is infinity.

Let A_i be the lifted closed cycle over the radial segment zeta^i[r,a], and B_i the cycle over zeta^i[a,b]. On the positive ray use W=+i sqrt(h) for A_0 and W=+sqrt(-h) for B_0; the closed cycles return on the other sheet. Transport these orientations by sigma(E,W)=(zeta E,W). Let D_i be the lifted cycle over the path zeta^i r -> 0 -> zeta^(i+1)r, with the W(0)>0 sheet used on the forward path. Then D_0+D_1+D_2=0.

Use the ordered basis

    A_0,B_0,A_1,B_1,A_2,B_2,D_0,D_1.

The local intersection calculation at the common branch endpoints gives the matrix

    J =
    [ 0  1  0  0  0  0 -1  0]
    [-1  0  0  0  0  0  0  0]
    [ 0  0  0  1  0  0  1 -1]
    [ 0  0 -1  0  0  0  0  0]
    [ 0  0  0  0  0  1  0  1]
    [ 0  0  0  0 -1  0  0  0]
    [ 1  0 -1  0  0  0  0  1]
    [ 0  0  1  0 -1  0 -1  0].

Its determinant is 1, so these eight cycles give the full integral homology lattice, not a proper finite-index lattice.

The automorphism matrix S cycles the three A_i and the three B_i, and sends D_0 to D_1 and D_1 to -D_0-D_1. Thus S is integral, S^3=1 and S^t J S=J.

## 2. The exact pushforward of the elliptic map

Choose the period basis (w,zeta w) on B0, where w is the positive real period. The degree-18 map constructed in the previous solution has homology pushforward

    H = alpha_* =
    [-1  1  2  0 -1 -1  1  1]
    [-2  0  1  1  1 -1 -1  2].

Here is a path argument fixing the integers in this matrix, independently of numerical rounding. The images of r and b are the real nonzero 2-torsion point P=(cube_root(11),0), while the image of a is O. The rational function X has no pole in the interiors of [r,a] or [a,b]: its other positive pole in the t-coordinate is approximately 568680, which is larger than b^3. Thus the respective images run, up to backtracking, along the imaginary and real fixed circles of B0, without passing through O internally. The sign of Y near a is negative. Consequently

    alpha_*(A_0)=-(1+2zeta)w,
    alpha_*(B_0)=w.

Similarly the path 0 -> r maps from O to P along the real circle; its integral is -w/2, as seen from Y>0 near E=0. The path defining D_0 therefore has image period (1-zeta)w, and D_1 has image period zeta(1-zeta)w=(1+2zeta)w. Equivariance under sigma supplies the other columns. This proves H exactly.

For additional discovery/verification, `integral_periods.py` independently integrated all periods at 75-digit precision. The coefficients agreed with H to more than 30 decimal places, and the Riemann bilinear relation selected the same intersection signs. The final argument and final exact lattice file do not depend on those numerical approximations: `integral_topology.py` writes the matrices from the path description above.

Put J_E=[[0,1],[-1,0]]. The pullback matrix is

    P=J^(-1) H^t J_E,

and direct exact arithmetic gives H P=18 I_2. Define the three central projectors

    e0=P H/18,
    e1=(1+S+S^2)/3,
    eA=1-e0-e1.

The projector e1 comes from beta, and eA is the orthogonal complement. These are rational matrices on this same unimodular lattice. Their denominator least common multiples are 18,3,18.

## 3. Recovering the complete rational endomorphism space

The previous solution proves

    End^0_geometric(J)=K x Q x D,
    K=Q(zeta), D=(-3,2),

where D has discriminant 6, and

    End^0_Q(J)=Q x Q x Q.

The K-action on A has signature (1,1). Its additional quaternionic endomorphisms can be recovered without choosing a product lattice or an isogeny model. On the rational homology space solve the linear equations

    X=eA X eA,
    X S=S^2 X,
    X^t J=J X.

The solution space has dimension two over Q. These are the anti-K, Rosati-self-adjoint Hodge endomorphisms. To recall why they are Hodge endomorphisms: on a rank-two K-module with signature (1,1), the polarization gives the indefinite Hermitian form. The anti-linear self-adjoint operator associated with its alternating volume form exchanges a positive Hodge line with its Hermitian-orthogonal negative line. Anti-linearity then compensates for the opposite complex structures. This produces precisely this two-dimensional rational space. Together with K on A it is the quaternion algebra D.

Thus the complete geometric endomorphism space is spanned by

    e0, S e0, e1, eA, S eA, X1, X2.

It has dimension seven. The rational endomorphism space is spanned by e0,e1,eA.

An analytic homomorphism of a complex abelian variety is integral exactly when it preserves integral homology. Hence the actual rings are

    R  = span_Q(e0,S e0,e1,eA,S eA,X1,X2) intersect M_8(Z),
    Rq = span_Q(e0,e1,eA) intersect M_8(Z).

This is where the integral gluing of the principally polarized Jacobian is retained. Saturation in Z^64 computes each intersection exactly. The script `integral_orders.py` performs this using a Smith normal decomposition followed by column Hermite normal form. It stores full rational matrices for all bases in `integral_orders_data.json`.

## 4. Indices in maximal orders

For R, use the reduced trace of K x Q x D. On its 8-by-8 homology representation this is

    tr_red(x)=Tr(x e0)+Tr(x e1)/2+Tr(x eA)/2.

The determinant of the trace Gram matrix of the saturated integral basis is

    disc(R)=8264970432=2^6*3^17.

A maximal order of K x Q x D has absolute discriminant

    |disc(O_K)| * 1 * disc(D)^2 = 3*36=108=2^2*3^3.

Therefore

    [M:R]=sqrt(2^6*3^17/108)=2^2*3^7=8748.

For Rq, the coordinate columns of an integral basis relative to e0,e1,eA are

    [0 -12  1]
    [3   6 -2]
    [0   6  1].

The maximal order is Z^3 and this determinant has absolute value 54. Thus [Mq:Rq]=54.

## 5. A containing maximal order, and why it is unique

Project R onto its D factor, obtaining the quaternion order R_A. Its trace discriminant is

    disc(R_A)=-2916=-(54)^2.

Its index in any quaternion maximal order is consequently 54/6=9. Thus it is already maximal at every prime other than 3. At 3, D is a division algebra, and a quaternion division algebra over Q_3 has a unique maximal order. It follows that R_A is contained in exactly one global maximal order O_D: at every prime its containing maximal order is uniquely determined. The two field factors also have unique maximal orders.

In particular, the containing maximal order

    M=O_K x Z x O_D

is unique, which is stronger than the requested independence of the invariants. The rational containing maximal order Mq=Z^3 is likewise unique.

An explicit O_D is constructed in `integral_conductor.py`. Enumerate x in (1/3)R_A/R_A and select those with integral reduced trace and integral reduced norm. There are nine such residue classes. Their span with R_A has trace discriminant -36 and is closed under multiplication, so it is the required maximal order. All containment and closure checks are exact.

## 6. The two-sided conductors

The conductor was computed by its defining condition, rather than by assuming it is the intersection with a product of scalar ideals. For a Z-basis m_i of M and a basis r_i of R, an element x in M belongs to C exactly when

    m_i x m_j belongs to R for every i,j.

These are rational linear integrality conditions on the seven M-coordinates of x. The script forms all 49 multiplication pairs, stacks the coordinate conditions, and computes the dual of the lattice generated by their rows and Z^7. This gives the exact largest M-bimodule contained in R, hence the largest two-sided ideal of M contained in R.

The resulting conductor is

    C=18 O_K x 3Z x 9 P_2,

where P_2 is the unique two-sided prime ideal above 2 in O_D (of additive index 4). In particular the index of the conductor's quaternion component is 4*9^4=26244. The larger intersection R intersect D has index 2916 in O_D and is not itself an O_D-ideal; replacing the conductor by that intersection would give the wrong answer.

For a fully reproducible integer certificate, in the particular R basis stored by the scripts the conductor basis has columns

    [ 6 -3  1 -3  0  3  3]
    [ 1  0  0  0  1  0 -1]
    [ 2  1  0  0 -1 -7 -9]
    [ 2 -4  0  3 -1  4  8]
    [-4  2  0 -3  2  4  2]
    [ 0  6  0 -3  0  6  0]
    [ 6 -6  0 -3 -3  0  6].

Its Smith form has absolute diagonal

    1,1,1,3,3,18,18.

Therefore

    R/C = Z/3 + Z/3 + Z/18 + Z/18.

Its order is 2916, also checked as [M:C]/[M:R]=25509168/8748.

For the rational ring, an ideal of Mq=Z^3 is a product of scalar ideals. The least positive integral multiples of e0,e1,eA are respectively 18,3,18, so

    Cq=18Z x 3Z x 18Z.

Expressing these three generators in the saturated Rq basis gives Smith diagonal 1,1,18. Hence

    Rq/Cq = Z/18.

As a check, its order is (18*3*18)/54=18. Also C intersect End^0_Q(J)=Cq, consistently with the displayed factor ideals.

## 7. Reproduction and checks

Run, in order,

```
/workspace/task-tools/bin/python integral_topology.py
/workspace/task-tools/bin/python integral_conductor.py
```

The second script includes the order computation, constructs a maximal overorder, computes the conductor, and writes `output/integral_structure.json`. It checks exact closure of R and M under multiplication, containment R in M, integrality of all conductor coordinates, and the defining m_i C m_j subset R conditions. Complete basis data are saved in `integral_orders_data.json` and `integral_conductor_data.json`.

No mathematical obstruction remains. The initial period calculation was exploratory and numerically corroborative; the final homology pushforward has the exact path justification in section 2. The integral-ring, overorder, index and conductor computations use rational/integer arithmetic throughout. The uniqueness argument above establishes independence of every requested invariant from a containing maximal order.
