# Independent full-task attempt

I worked only from `instruction.md` and `data/jacobian.json` in this assigned directory. The scripts and intermediate files here were produced during this attempt. I did not read another attempt, an author solution, a test, or another task directory. I have not been given model-version or effort metadata.

The final artifact is `output/decomposition.json`. Exact symbolic checks of the map, its differential, the cube identity, and both sixth-power witnesses pass in `verify.py`.

## Map and gluing

Write z=E^3 and put

- a=551232,
- t=z-553707,
- Q=z^2+902286z-836509234176,
- q=225z-124064325.

The map has degree 18. Its x-coordinate is

```
-(z^6-52317738z^5+137541930139845z^4-130688851922762918400z^3
  +53454932630448304961617920z^2-8100189794317793342169727107072z
  +47783298913570122159712398471069696)
 /(324 E^2 (z-551232) Q^2).
```

The multiplier Y is recorded exactly in the JSON and in `map.txt`. A useful, much shorter characterization is

    X'/Y = 9(E^3-120582).

Direct rational-function arithmetic gives

    X^3-11 = -h Y^2/4.

The numerator and denominator of X are coprime, and its degree as a rational map of the E-line is 18. At infinity X has a pole, so the resulting curve map is pointed.

I found the differential first by period integration and an integer relation, then recovered X by exact formal expansion and rational reconstruction. This numerical discovery step is not used to check the resulting map: the displayed identities are exact. In particular, the recovered map is not merely a numerical approximation.

The point and tangent are

    U=(-553707,519750s),  s^2=-11,
    v=s(-225u-124064325).

The identity

    -h+11q^2=-(z-553707)^3

shows that this is a flex and U has order three. For the gluing function, put

```
A=-(z^3-3740121z^2+1411609332672z+187823091368005632)/(18tQ),
B=(673z^2-906377472z+294451250429952)/(6t(z-551232)Q).
```

Then

    f=(A+sWB)/E

satisfies exactly

    f^3=(WY/2-s)/(W-sq).

The JSON therefore encodes `[A/E,0,0,B/E]`.

## Homology, minimality, and the induced polarizations

Here is the integral topological model used for the order computation; it also records the primitivity checks behind the minimum degree.

The three positive real branch radii are r1<r2<r3. Take arcs a_k from r1*zeta^k to r2*zeta^k, b_k from r2*zeta^k to r3*zeta^k, and c_k from r3*zeta^k to infinity. Their lifts are nine cycles with the one relation

    a0+c0+a1+c1+a2+c2=0.

The intersection matrix has entries +1 on (a_k,b_k), (b_k,c_k), and (c_k,c_{k+1}), indices modulo 3, and the opposite entries -1. Deleting c2 gives an integral unimodular rank-eight matrix Q. The order-three automorphism cyclically permutes the three sets of arcs.

In the elliptic basis (Omega,zeta*Omega), the images under alpha of a0,b0,c0 are respectively

    (-1,-2), (1,0), (3,6).

The others are obtained by multiplication by

    Z=[[0,-1],[1,-1]].

These arc images can also be read by lifting the real map; the period integrals provide an independent check. In particular, the b cycle and its zeta translate map to an elliptic lattice basis. If V_alpha is the resulting 2-by-8 matrix, then

    V_alpha Q^{-1} V_alpha^T = -18 [[0,1],[-1,0]].

For beta take the images of a0,b0,c0 to be (1,0),(0,1),(-1,0), repeated on the other rays. The analogous product is -3 times the same alternating matrix; the two subspaces are orthogonal.

The alpha lattice is primitive (its pushforward already contains a basis of H1(B0,Z)). Once the other simple factors are determined below, Hom_Q(J,B0) has rank one, and this primitive map generates it. Thus a nonzero pointed map to B0 over Q has degree at least 18.

The gluing has order exactly 3, not 9. The intersection is killed by 3. A full rank-two 3-torsion graph cannot be isotropic for the product polarization (18,3): on B0[3] the 18-polarization pairing is trivial, whereas the 3-polarization pairing on B1[3] is nondegenerate. The explicit identity supplies the remaining nontrivial cyclic subgroup.

Adjoining this cyclic graph to the product lattice gives the polarization type (1,18). Since J is principally polarized, its connected complement has the same type. The computed complementary alternating matrix is

```
 0 -5 -6 -4
 5  0  3  4
 6 -3  0  6
 4 -4 -6  0
```

whose alternating elementary divisors are 1 and 18.

## Simple factors and integral endomorphism order

The order-three action on the four-dimensional rational homology of A gives a rank-two module over K=Q(zeta_3). The induced Hermitian form has determinant -18. Its special-unitary commutant is the quaternion algebra

    D=(-3,18)=(-3,2),

ramified exactly at 2 and 3 and split at infinity. An explicit antilinear generator j has j^2=18 and j*zeta=zeta^2*j. In an integral basis of H1(A,Z), my matrices are

```
zeta = [-1  0  0 -1]        j = [ 1 -3 -6 -7]
       [-1 -2 -3 -2]            [ 6  9  9 12]
       [ 0  1  1  1]            [ 0 -5 -9 -6]
       [ 1  0  0  0]            [-5  0  3 -1].
```

The ordinary reduction witnesses with two different CM fields exclude extra CM. Since a division quaternion algebra cannot be M2(Q), A cannot be a square of a non-CM elliptic curve either. It is therefore geometrically simple with endomorphism algebra D. B1 is non-CM: its rational j-invariant is 2640279346000/3087, which is not an algebraic integer. Thus the geometric simple factors are B0 with K, B1 with Q, and A with D.

Let e0,e1,eA denote the three rational projectors. For the full rank-eight lattice I saturated the rational algebra with basis

    e0, zeta*e0, e1, eA, zeta*eA, j, zeta*j

inside M8(Z), rather than using an isogenous product's ring. These are the computations in `integral.py` and `conductor.py`.

The order of A itself obtained this way is Z[zeta]+Z[zeta]j, of reduced discriminant 54. A containing maximal quaternion order is

    Z[zeta]+Z[zeta](j/3),

of reduced discriminant 6. Thus a containing maximal order of the complete algebra has basis

    e0,zeta*e0,e1,eA,zeta*eA,j/3,zeta*j/3.

The full order of J has trace discriminant 2^10*3^21, whereas that maximal order has absolute trace discriminant 108. Consequently the geometric index is

    2^4*3^9 = 314928.

In the displayed maximal-order basis, the conductor lattice has columns

```
18  0 0   0  0   0  0
 0 18 0   0  0   0  0
 0  0 3   0  0   0  0
 0  0 0  18  0   0  0
 0  0 0 -18 54   0  0
 0  0 0   0  0  18  0
 0  0 0   0  0 -18 54.
```

I imposed integrality of every left and right maximal-order-basis product to compute this two-sided conductor. The Smith invariants of R/conductor are 3,18,54.

The rational fixed algebra is Q^3, with one scalar on each factor. Its integral order is

    {(a,b,c) in Z^3: a=c mod 18, b=c mod 3}.

It has index 54, conductor 18Z x 3Z x 18Z, and conductor quotient Z/18Z. In particular the rational factor A is still simple but has rational endomorphism algebra Q. The two rational elliptic classes both have algebra Q; they are distinct classes and hence appear as two separate records in the JSON.

## Endomorphism field

For this cyclic cubic cover, the determinant character on the nontrivial cubic eigenspace is the CM character of the Mordell curve with constant term f(0), where f=-h. After removing B0, the finite character on the quaternionic antilinear generator is the sextic Kummer character of

    f(0)/(-11) = -450303377122368/11
               = 18^6 * (-1203587).

Thus

    L=Q(zeta_3,(-1203587)^(1/6)),
    -1203587=-7^3*11^2*29.

The Kummer class has order six over K, so L has degree 12. Its full dihedral action fixes only Q in the quaternion algebra and also supplies the ordinary complex conjugation action on End(B0). This is the full endomorphism field, not a field splitting all branch points.

As a consistency check independent of the local stable model, I counted every good prime between 5 and 100. At the primes 1 modulo 3, the determinant root-of-unity traces extracted from A's quartic Frobenius polynomials agree with this sextic radicand. Among radicands supported on the possible bad primes, the possibilities surviving these checks were precisely this class, its inverse, and the equivalent classes obtained by multiplying by -27 over K. This finite check supports, but does not replace, the determinant-character calculation.

## Reduction witnesses

The exact counts used are

```
p=13: C (21,195), B0 (19,171), B1 (16,192)
p=23: C (18,534), B0 (24,576), B1 (18,540).
```

The quartics for A, written in the eigenvalue variable T, are

    p=13: T^4+T^2+169,
    p=23: T^4-26T^2+529.

The sixth powers have characteristic polynomials

    (T^2-506T+13^6)^2,
    (T^2+23686T+23^6)^2,

respectively. Both elliptic polynomials are ordinary. Their imaginary quadratic fields have fundamental discriminants -3 and -40. The resultant equalities are checked exactly in `verify.py`. The finite-field counts were direct enumerations over Fp and Fp2, with a quadratic nonresidue representation of the latter.

## Local data

All valuations below use v_p(p)=1. I use the exact differential

    omega=9(E^3-120582)dE/W.

### p=5

The three z-roots are mutually at distance 2. Cubing is etale here, so there are three size-three E-clusters, each of depth 2, with distinct centers modulo 5. The stable graph is a genus-one center with three genus-one leaves. Each odd-cluster edge has thickness 1. The curve is already semistable over the maximal unramified extension, so e=1.

The central normalized curve is y^2=2-E^3. Each child, in the coordinate (z-551232)/25, has equation y^2=-t(t^2+3t+3). Both elliptic types have trace 0 over F5. Frobenius fixes one child and exchanges the other two. Therefore L5=(1+5t^2)^4; conductor and Swan are both zero.

The vertical orders are 0 on the center and 1 on each leaf. The branch orders are 0 at the central end and -2 at the child end. On a child, the reduced differential is a linear polynomial times the elliptic invariant differential.

### p=7

There is one even size-six cluster at depth 1/2, with six distinct children. Its complement consists of three unit roots and infinity. The stable components have genera 1 and 2 and are joined by two edges of thickness 1/2. Stable reduction needs e=2.

The outer component is y^2=3-E^3. On the inner component, x=E/sqrt(7), y=W/(7sqrt(7)) gives y^2=3(x^6+5). Inertia acts as (x,y)->(-x,-y). Its invariant elliptic quotient has equation v^2=3u^4+u, and both elliptic invariant pieces have trace -5 over F7. The two graph edges are exchanged by Frobenius, giving the nonsplit torus factor 1+t. Hence

    L7=(1+t)(1+5t+7t^2)^2,
    conductor=3, Swan=0.

The two vertical orders of omega are both 0. Its branch orders on either edge are 0 on the genus-one component and 1 on the genus-two component. These orders need not sum to -2: each annulus contains three zeros of omega, at v7(E)=1/3. Indeed the valuation along an annulus is min(t,1-2t), with both endpoint levels zero.

### p=3

The finite cluster picture is:

- all nine roots at depth 1;
- an even size-six child at depth 4/3;
- its two odd size-three children at depth 3/2;
- the other size-three child of the top cluster at depth 5/2.

The top component has genus 0 and valency 3. The size-six component has genus 0 and valency 4. The three leaves each have genus 1. There are two edges between the two rational components, each of thickness 1/3; one edge from the top component to its elliptic child, of thickness 3/4; and two edges from the other rational component to its elliptic children, each of thickness 1/12. These are unmarked stable components; none of the two rational components is contracted. The minimum stable ramification index is 12.

The vertical orders, in that same vertex order, are

    3/2, 5/6, 3/4, 3/4, 3/4.

On the top component, x=E/3 and normalization y^2=-x give a leading differential proportional to

    (x+1)^3 dx / (x(x-1)^3 y).

It has order -3 at each branch going to the size-six component and order -2 at the remaining node. On the size-six rational component, the leading differential is proportional to dt/((t-a)(t-b)y), with y^2 a scalar times (t-a)(t-b). It has order +1 at each node going upward and -2 at each elliptic child. Each leaf has its invariant elliptic differential and node order 0. Thus the edge order pairs are (-3,1), (-3,1), (-2,0), (-2,0), (-2,0).

The wild inertia is nontrivial on all three elliptic leaves, so none of their H1 contributes inertia invariants. The graph's loop has the nontrivial quadratic inertia character. Therefore L3=1 and dim H1^I=0. The three cubic branch-root fields each have wild discriminant contribution 1: after removing cube powers their units are 4,7,7 modulo 9. The odd-residue-characteristic hyperelliptic Swan formula therefore gives Swan=3. The Artin conductor is 8+3=11.

## Remaining uncertainties

I have no unresolved numerical or algebraic obstruction. The exact identities and lattice calculations are reproducible from the included scripts. The local results use the cluster-model and odd-residue-characteristic conductor formulas as described above; they were not checked by an external stable-reduction package. I have stated the actual reasoning and validation rather than claiming an unavailable external verification.
