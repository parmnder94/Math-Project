# Independent solution

I used only `instruction.md`, `data/jacobian.json`, general installed Python
libraries, and my own calculations. No other participant's files, hidden
verifier, or task-specific external solution was inspected. The requested
artifact is `output/decomposition.json`.

## Result

The minimum arithmetic degree is **18**. The elliptic intersection has order
**3**, and both complementary polarization types are **(1,18)**. Geometrically
there are the two specified, mutually nonisogenous elliptic curves and an
absolutely simple quaternionic surface with quaternion discriminant **6**.
The surface's rational endomorphism algebra is Q. The full endomorphism field
is

\[
 L=\mathbb Q(\zeta_3,\sqrt[6]{32496849})
  =\mathbb Q(\zeta_3,\sqrt{609},\sqrt[3]{3509}),\qquad [L:\mathbb Q]=12.
\]

The local answers, with the Frobenius convention in the question, are

| p | L polynomial | conductor | Swan | least stable e |
|---|---|---:|---:|---:|
| 3 | 1 | 11 | 3 | 12 |
| 5 | (1+5t^2)^4 | 0 | 0 | 1 |
| 7 | (1+t)(1+5t+7t^2)^2 | 3 | 0 | 2 |

The graphs, thicknesses, component valuations, and branch orders are given
explicitly below and in the JSON.

## 1. The map and its construction

Put z=E^3, A=551232, and

\[
 Q=z^2+902286z-836509234176.
\]

Let

\[
\begin{aligned}
P={}&z^6-52317738z^5+137541930139845z^4
 -130688851922762918400z^3\\
 &+53454932630448304961617920z^2
 -8100189794317793342169727107072z\\
 &+47783298913570122159712398471069696.
\end{aligned}
\]

The answer uses

\[
 X=-\frac{P(E^3)}{324E^2(E^3-A)Q(E^3)^2},\qquad
 Y=-\frac{X'(E)}{9(E^3-120582)}.
\]

The second displayed fraction cancels to the rational function with integer
coefficients recorded in the artifact. Direct exact polynomial arithmetic
verifies

\[
 X^3-11=-hY^2/4,\qquad
 \omega=-9(E^3-120582)\frac{dE}{W}.
\]

The numerator and denominator of X are coprime, of degrees 18 and 17.
The induced map of the hyperelliptic quotients has degree 18, hence so does
alpha. At infinity X has a pole and alpha sends infinity to O. Its differential
is regular and nonzero at infinity.

For reproducibility, I found the map using the squared eigenfunction of the
Treibich--Verdier potential with parameters (5,1,1,1). This identification was
an aid to finding the answer; the final map is verified without using that
identification. `derive_tv.py 5 1` computes its polynomial squared eigenfunction
from the third-order differential equation. With the spectral parameter
replaced by -E, its spectral constant is E^2 W^2/893025^2. If F(x) is the degree
8 numerator of that squared eigenfunction, its zero divisor on B0 is represented
by

\[
 u(x)=F(x),\qquad v(x)=W\,E(x^3-11)/F'(x)\pmod {F(x)}.
\]

Elliptic divisor reduction, followed by exact rational interpolation, gives X
above. `derive_map.py` performs these operations over Q, not numerically;
`finalize_map.py` factors the resulting exact square and checks the identity.

### Optimality, rather than just the existence of this cover

First alpha-star is an embedding. Here are details that also guard against a
hidden isogeny in the construction. If its kernel has order k, alpha factors
through a rational elliptic isogeny of degree k, and k divides 18. B0 has no
rational subgroup of order 2. Its only rational order-3 subgroup is x=0: its
3-division polynomial is 3x(x^3-44), whose other cubic has no rational root.
The 3-isogenous curve is y^2=x^3+297, and it too has only its x=0 rational
order-3 subgroup. Thus the possible nontrivial kernels reduce to degree 3 or
a multiplication-by-3 factor. The latter would give a degree-2 pointed cover
of C to B0. Such a cover is impossible: after equivariance under E -> zeta E,
the orbit E^3=A must map to O (the necessary cube at A is not rational), already
accounting for three points in the fiber. Equivariance follows by composing
with the isogeny and evaluating the resulting constant torsion difference at
infinity.

For a degree-3 isogeny factor, one would have a degree-6 cover to
B': y^2=x^3+297. It is likewise equivariant and unramified at infinity. The
three branch points E^3=A must be poles: -297/A is not a rational cube.
The only remaining poles can be the two points E=0. Consequently the map must
have the form

\[
 x=P_2(z)/(E^2(z-A)),\qquad
 y=W Q_2(z)/(2E^3(z-A)^2).
\]

Here both polynomials have degree at most two. Comparing leading coefficients
and rescaling z by 297 reduces the necessary identity to

\[
 (z^2-1862z+9261)(z^2+rz+s)^2-(z^2+pz+q)^3
   =kz^2(z-1856)^3,\quad k\ne0.
\]

The coefficient ideal over Q contains k. This is an exact small elimination
calculation in `solve_degree6.py`: eliminate r using the leading coefficient,
then compute a Groebner basis in p,q,s,k; the basis contains k itself. Thus
this case is also impossible. This argument does not assume the value of the
nonzero elliptic constant k.

Below I prove that B0 occurs geometrically with multiplicity one in J. It
follows that Hom_Q(J,B0) has rank one. Since alpha-star is injective, alpha is
a generator of this rank-one group, and every other nonconstant pointed
rational map has degree 18 n^2 for a nonzero integer n. This proves the stated
minimum, not merely optimality within a chosen rational-function ansatz.

## 2. Exact gluing and the full intersection

For the sign of Y used above, take

\[
 U=(-553707,-519750s),\qquad v=225s\,u+124064325s.
\]

This is a flex, so U has order three. Set q=z-553707 and
L=-225z+124064325. Direct calculation gives

\[
 h(z)-11L(z)^2=q^3.
\]

The function in the JSON is f=f0+sW f3, with

\[
 f_0=\frac{E^9-3740121E^6+1411609332672E^3+187823091368005632}
 {18E(E^3-553707)(E^6+902286E^3-836509234176)},
\]

\[
 f_3=\frac{673E^6-906377472E^3+294451250429952}
 {6E(E^3-553707)(E^3-551232)(E^6+902286E^3-836509234176)}.
\]

Using (sW)^2=11h, expand its cube into the basis 1,sW. The two exact identities
are

\[
 f_0^3+33h f_0f_3^2=\frac{hY/2-11L}{q^3},\qquad
 3f_0^2f_3+11h f_3^3=\frac{1-YL/2}{q^3}.
\]

They prove the precise cube identity requested in the question. They are
checked independently from the encoded JSON by `verify_answer.py`.

B1 is non-CM: its j invariant is

\[
 2640279346000/3087,
\]

which is not an algebraic integer. Thus Hom(B0,B1)=0. Beta-star is injective,
since a failure of injectivity of a degree-three map would leave a degree-one
map of this genus-four curve to an elliptic curve. Any point of the elliptic
intersection is killed by 3, by applying beta-pushforward and using the
vanishing cross homomorphism. The exhibited subgroup has order 3. If the
intersection had order 9, it would identify B0[3] and B1[3] as Galois modules.
That is impossible at 11. B1 is a quadratic twist by 11 of a curve with good
reduction at 11, so its inertia action on 3-torsion has order at most two.
B0[3] requires the ramified cube root of 44 and has inertia of order divisible
by three. Therefore the full intersection has exactly order 3.

On B0 x B1, the polarization pulled back from J is the product (18,3).
Quotienting by the cyclic order-three diagonal subgroup gives type (1,18).
For example, in a symplectic lattice with pairings 18 and 3, adjoin
(a0+a1)/3. The resulting pairing has an entry 1 and Pfaffian 18, hence Smith
invariants (1,18). Complementary abelian surfaces in a principally polarized
fourfold have dual isomorphic polarization kernels; consequently A also has
type (1,18).

## 3. Quaternion algebra, simplicity, and rational factors

The action rho: E -> zeta_3 E induces an O_K action on A, K=Q(sqrt(-3)).
On the four holomorphic differentials the multiplicities of the eigenvalues
(zeta,zeta^2,1) are (2,1,1). Removing alpha and beta leaves signature (1,1)
on A.

For completeness, the standard dimension-two Weil-type argument is as
follows. Choose an O_K basis of its homology lattice (O_K has class number
one), and write the polarization as Tr(H/sqrt(-3)) for a Hermitian form H.
The alternating determinant equals det(H)^2. Thus det(H)=-18, the sign being
fixed by signature (1,1). The Hodge circle lies in SU(H). Its rational
commutant contains the quaternion algebra

\[
 D=(-3,-\det H)=(-3,18)=(-3,2).
\]

Equivalently, the Hermitian alternating-dual operation supplies an antilinear
Hodge endomorphism squaring to 18 and anticommuting with sqrt(-3). Rational
Hodge endomorphisms of an abelian variety are its rational algebraic
endomorphisms. The Hilbert symbols of (-3,2) ramify precisely at 2 and 3;
it is split at the real place.

The only enlargement compatible with dimension two would be the CM, elliptic
square case. The following exact good-reduction witnesses exclude it.

| p | C counts over p,p^2 | B0 counts | B1 counts | characteristic polynomial of A |
|---|---|---|---|---|
| 13 | 21,195 | 19,171 | 16,192 | x^4+x^2+169 |
| 23 | 18,534 | 24,576 | 18,540 | x^4-26x^2+529 |

For p=13, the sixth powers have characteristic polynomial
(x^2-506x+13^6)^2, whose quadratic field is Q(sqrt(-3)). For p=23, it is
(x^2+23686x+23^6)^2, whose field is Q(sqrt(-10)). Both elliptic polynomials
are ordinary. Their fields differ, so there is no common CM center for A.
Indeed further powers do not change the field of an ordinary elliptic Weil
number. This also rules out an enlargement after a further finite extension.
Therefore End^0_geometric(A)=D, and A is absolutely simple. In particular
B0 occurs just once, as used in the minimum-degree argument.

The complete geometric list is consequently B0, B1, and A, with division
algebras Q(sqrt(-3)), Q, and D respectively. Section 4 shows that the rational
fixed algebra of D is Q. Over Q all three factors remain simple, with division
algebra Q for each. There are two distinct dimension-one rational records in
the JSON: they are not combined into multiplicity two, since the two elliptic
curves are not isogenous.

`counts.py` implements projective point counts directly. For F_{p^2}, it uses
F_p[i]/(i^2-n) for a nonsquare n and evaluates the quadratic character via the
norm to F_p. Thus the point counts do not use floating-point approximations.

## 4. Determination of the full endomorphism field

Here is a finite descent calculation, including its bounds, rather than an
unbounded search for a plausible radicand. Over K, Galois fixes the known
K-action on A, so it acts on D by inner automorphisms from K^*/Q^*. Every
finite subgroup of this quotient has order dividing 6: the map
b -> b/conjugate(b) embeds its torsion in the sixth roots of unity of K.
Complex conjugation acts by inversion. Thus the full endomorphism extension
is a dihedral extension, cyclic of degree dividing 6 over K.

For a good prime p split in K, let

\[
 P_A(x)=x^4-a x^3+b x^2-pa x+p^2.
\]

If the rotation induced on D has order n=1,2,3,6, the respective conditions
are

\[
 b=a^2/4+2p;\qquad a=0;\qquad b=a^2-p;\qquad b=a^2/3+p.
\]

These follow by writing the four eigenvalues as r alpha, r^{-1} alpha,
r beta, r^{-1} beta, where alpha beta=p and (r+r^{-1})^2 is 4,0,1,3.
The actual data used have no ambiguity between these conditions. The prime
43 gives order 6; complex conjugation is nontrivial on K, so the full image
has order 12.

A Galois extension of this form has quadratic subextension K(sqrt(q)) with
q rational and cubic subextension K(cuberoot(c)) with c rational. One way to
see the last assertion is Kummer theory: the dihedral condition makes the
Kummer class conjugation-invariant. Since K has class number one, a
conjugation-invariant cube class is represented by a rational number (also
at the prime over 3). The same conclusion for the quadratic part is the
usual biquadratic description.

Endomorphisms are unramified wherever the Jacobian has good reduction. The
polynomial discriminant permits bad primes only 2,3,5,7,11,29, and Section 5
proves good Jacobian reduction at 5. It therefore suffices to enumerate square
classes and cube classes supported on 2,3,7,11,29. This is a finite set.
`field_inference.py` enumerates it exactly, using the direct counts recorded
by `counts.py` and `counts_more.py`. The observed rotation orders are

```
p:     13 19 31 37 43 61 67 73 79 97 103 109 127 139 151 157 163 181 193 199
order:  2  3  3  2  6  3  1  3  2  3   6   3   2   2   3   3   2   6   2   6
```

The surviving rational square classes are 609 and -203, which give the same
extension over K. The surviving cube classes are 3509 and 9251=11*29^2;
they are inverse classes and give the same cubic extension. Hence

\[
 L=K(\sqrt{609},\sqrt[3]{3509}).
\]

The radicand 32496849=3^3*7^3*11^2*29 has the required square and cube classes.
Its quadratic and cubic parts are nontrivial, giving degree 12 over Q. The
fixed subalgebra of D under the full dihedral group is Q. All geometric
endomorphisms of B0 are defined over K, and B1 has only its rational scalar
endomorphisms. There are no cross homomorphisms between the simple factors,
so this L is exactly the endomorphism field of J.

## 5. Local stable curves and the differential

Here is enough cluster information to reconstruct the unmarked stable
models. Set c=cuberoot(11), d=cuberoot(29). The nine finite roots are the
three zeta_3 multiples of each of

\[
 12cd,\qquad 3c(7+2\sqrt7),\qquad 3c(7-2\sqrt7).
\]

All valuations below are normalized by v_p(p)=1. For a cluster of depth d_s,
write nu_s=sum_r min(d_s,v_p(z_s-r)). The valuation of dE/W at its component
is d_s-nu_s/2. Add v_p(-9) and the generic valuation of E^3-120582 to obtain
the listed vertical order of omega. Odd child clusters give one ramified
edge of thickness half the relative depth. Even child clusters give two
unramified edges of thickness equal to the relative depth. The rational
components described below already have at least three nodes, so no branch
point markings are being used to keep an unstable component.

### p=5

There are three disjoint size-three clusters of depth 2, with outer depth 0.
Each gives an elliptic tail. The outer component is also elliptic: its four
branch places are the three odd clusters and infinity. Thus the stable graph
is a star with four genus-one vertices. Each edge has thickness 1. All roots
are defined over an unramified extension and the double-cover scalings are
integral, so the least e is 1.

For the outer component omega has vertical order 0. On a tail E^3-120582
has generic valuation 2, dE has valuation 2, and W has valuation 3, giving
vertical order 1. On each edge, the branch orders are (0,-2), outer first.

For the Frobenius calculation, the outer normalized curve is
w^2=2-E^3 over F5. In a tail take a center rho with rho^3=A and write
E=rho+25t. With q=3rho^2t, the tail equation is

\[
 w^2=-q(q^2+3q+3).
\]

Both this curve and the outer curve have trace 0 over F5. Frobenius fixes one
tail and exchanges two; the latter pair contributes
1+10t^2+25t^4=(1+5t^2)^2. Consequently the full factor is (1+5t^2)^4.
The graph is a tree, so the Jacobian has good reduction and conductor zero.

### p=7

There is a size-six cluster at 0 of depth 1/2. Its six children are distinct
singletons at that depth; the three remaining roots have depth 0. The outer
component has genus 1 and the inner component genus 2. They meet in two
nodes, each of thickness 1/2. Adjoining sqrt(7) supplies the model, and the
thickness forces the least e to be 2.

For the outer component omega has valuation 0. On the inner component the
valuations of E^3-120582, dE, and W are respectively 1,1/2,3/2; thus its
vertical order is also 0. The outer leading differential is regular at both
nodes, and the inner leading differential is proportional to dx/y on a
sextic genus-two model. At each of its two infinities it has order 1. Hence
both edges have branch orders (0,1).

These orders are intentionally not negative complements. The six zeros of
omega lie in the annuli: E^3=120582 has valuation v_7(E)=1/3, strictly between
the two component depths. There are three zeros in each annulus. This also
explains how equal endpoint vertical valuations coexist with the orders
(0,1).

The outer elliptic curve is y^2=x^3+3 over F7. Set E=sqrt(7)x and
W=7sqrt(7)y on the inner component; its equation is

\[
 y^2=3x^6+1.
\]

Inertia acts as (x,y)->(-x,-y). Its invariant elliptic quotient is
w^2=t^3+3, with t=1/x^2, w=y/x^3. Both elliptic invariant factors have
trace -5 over F7. The two attachment points have square y-coordinate equal
to 3, a nonsquare mod 7, so Frobenius acts as -1 on the loop. This gives
(1+t)(1+5t+7t^2)^2. The invariant dimension is 5, the extension is tame, and
the conductor is 8-5=3.

### p=3

Choose sqrt(7) in Q3 so that 7+2sqrt(7) has valuation 1. The top cluster has
size 9 and depth 1. It has an odd size-three child of depth 5/2 and an even
size-six child of depth 4/3. The size-six child has two size-three children,
each of depth 3/2. For the latter assertion, the difference of the two cubes
has valuation 1 after dividing E by 3, whereas differences within an orbit
of zeta_3 have relative valuation 1/2.

Index the components as follows:

* 0: outer rational component, depth 1;
* 1: middle rational component, size 6, depth 4/3;
* 2 and 3: its elliptic tails, depth 3/2;
* 4: the other elliptic tail, depth 5/2.

There are two edges 0--1, each of thickness 1/3, edges 1--2 and 1--3 of
thickness 1/12, and an edge 0--4 of thickness 3/4. The graph has first Betti
number 1, and its three elliptic vertices give total genus 4. Vertices 0 and
1 have respectively three and four nodes; both remain in the unmarked stable
model.

The nu values are 9,11,23/2,23/2,27/2. The generic valuation of
E^3-120582 is 3 at every component and v_3(-9)=2. Thus the vertical orders
in this indexing are

\[
 (3/2,\ 5/6,\ 3/4,\ 3/4,\ 3/4).
\]

The branch orders are (-3,1) on each 0--1 edge, (-2,0) on 1--2 and 1--3,
and (-2,0) on 0--4. These also follow by direct leading-differential
reduction. On the outer rational component the node orders sum to -8 and
there are six remaining zeros, giving canonical degree -2. On the middle
component the node orders sum to -2, and on the elliptic tails the node order
is zero. This supplies an independent check of the differential data.

Over the maximal unramified field, adjoining cuberoot(11) and a fourth root
of 3 gives ramification index 12 and supplies all the above coordinates and
y-scalings. Indeed 29/11 is a cube in Q3, and zeta_3 is already supplied by
the fourth-root extension over the maximal unramified field. Thus this
extension suffices. The edge thickness 1/12 proves that no smaller e suffices
for the unmarked stable curve.

The wild order-three inertia acts nontrivially on each elliptic tail, by a
nonzero translation of the x coordinate in its supersingular cubic model.
Thus no tail H1 contributes inertia invariants. On the outer component write
E=3x and W=3^4 sqrt(3) w. Its normalization in characteristic 3 is a rational
double cover with equation w0^2=-x. Tame inertia changing sqrt(3) to -sqrt(3)
exchanges the two points attached to component 1, so acts by -1 on the loop.
There are therefore no H1 inertia invariants and L3=1.

For odd residue characteristic the Swan conductor of a hyperelliptic
Jacobian is the Swan conductor of the permutation action on the finite
branch roots. Locally our roots give three cubic orbits: one with field
Q3(cuberoot(319)), and two with field Q3(cuberoot(11)). Each is totally
ramified of degree 3 and discriminant exponent 3. (The relevant units are
not congruent to +/-1 modulo 9, so there is no index-three correction to the
cubic power basis.) Each contributes 3-3+1=1 to Swan. The total Swan is 3,
and the Artin conductor is 8-0+3=11.

## 6. Reproducibility and scope of checking

`verify_answer.py` reads the final JSON itself and checks the map, pulled-back
differential, flex, both components of the cube identity, graph genera,
conductor-versus-invariant-dimension relation, and top-level keys.
`counts.py`, `counts_more.py`, and `field_inference.py` supply the independent
finite-field and bounded Kummer calculations. `solve_degree6.py` is the
small exact elimination used to rule out a hidden isogeny. The larger
`map_search.py` explorations were abandoned after the explicit divisor
construction succeeded; no conclusions depend on those unfinished searches.

The local and endomorphism conclusions use the standard cluster-model,
polarized Weil-type, and Kummer-descent arguments explained above, rather
than a black-box stable-reduction or endomorphism package. I did not run a
hidden task verifier. I do not presently have an unresolved mathematical
exception to the submitted result; the preceding sections state the
structural facts and exact computations on which it depends.
