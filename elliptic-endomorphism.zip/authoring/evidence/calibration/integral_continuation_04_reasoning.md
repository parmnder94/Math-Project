# Integral endomorphism rings of the actual Jacobian

The answer saved in `output/integral_structure.json` is

- geometric index: **8748 = 2^2 3^7**;
- rational index: **54 = 2 3^3**;
- geometric conductor quotient invariant factors: **[3,3,18,18]**;
- rational conductor quotient invariant factors: **[18]**.

This is an incremental calculation using only my own original solution and general abelian-variety/order theory. In particular, the calculation retains the gluing defining the principally polarized Jacobian; it does not replace J by its isogenous product.

## 1. Structural input from the original solution

Write K=Q(zeta), O=Z[zeta], where zeta^2+zeta+1=0, and pi=1-zeta. Thus O/pi=F_3.

The three geometrically nonisogenous factors have rational endomorphism algebras

End^0_{̅Q}(J)=K x Q x D,
D=(-3,2), disc(D)=6.

The factors are the embedded elliptic curves E0=alpha*B0, E1=beta*B1, and their orthogonal complementary surface A. Both elliptic pullbacks are injective. Their induced polarization degrees are 18 and 3. Their intersection is the cyclic order-three group identifying T in E0 with U in E1. On E0 this is the kernel of pi. The surface A has polarization type (1,18).

The automorphism tau induced by (E,W)->(zeta E,W) is compatible with the canonical principal polarization. It acts as zeta on E0, as 1 on E1, and gives the O-action of signature (1,1) on A. The three rational simple factors have endomorphism algebra Q over Q, so

End^0_Q(J)=Q x Q x Q.

These facts, including the optimality and the full intersection, were established in my original `attempt.md`.

## 2. The integral quaternion order on A

Let Lambda=H_1(A(C),Z). It is a free rank-two O-module, since O is a PID. The alternating form of the induced polarization is equivalently an integral Hermitian form H on Lambda, using the inverse different 1/sqrt(-3) in the trace construction. Its signature is (1,1). In an O-basis,

det(H)=-18.

Indeed, the determinant of the integral alternating form is det(H)^2; the polarization has elementary divisors (1,18). The alternating form is primitive because its first elementary divisor is 1.

The usual antilinear adjugate operator J_H of this rank-two Hermitian form satisfies

J_H a = bar(a) J_H,  J_H^2=-det(H)=18.

It commutes with the Hodge circle. For example, the Hodge circle has determinant one over K, and the antilinear adjugate operator commutes with SU(H). Thus it is a rational endomorphism of A. In a local basis diagonalizing H as diag(u,v), it has, up to a unit scalar, the form

(v_1,v_2) -> (v bar(v_2),-u bar(v_1)).

This also makes its integrality and its action on the polarization kernel explicit.

At every finite prime the Hermitian lattice has a vector of unit norm:

- Away from 2 and 3 it is unimodular.
- At 2, if both diagonal entries were even, an off-diagonal unit would make the determinant odd. If the off-diagonal entry were also nonunit, the alternating form would be divisible by 2. Both alternatives contradict the known determinant or primitivity.
- At 3, if both diagonal entries were divisible by 3, an off-diagonal unit would give determinant valuation 0. An off-diagonal entry of pi-valuation 1 would give determinant 3-valuation 1. If its pi-valuation were at least 2, all entries would be divisible by 3, contradicting primitivity. The actual determinant valuation is 2.

Consequently local integral Gram-Schmidt gives H=diag(u,v) with u a unit. For an element a+b J_H of D, preservation of the lattice is then equivalent to a,b being integral: the diagonal part forces a to be integral, and the off-diagonal entry involving u forces b to be integral. Changing the local basis changes J_H by an O-unit and does not change this conclusion. Therefore, globally,

O_A=End_{̅Q}(A)=O + O J_H.

Put j=J_H/3. Then j^2=2 and ja=bar(a)j. The order

O_D=O+O j

is maximal. Its reduced discriminant is 6: the trace pairing in the basis 1,zeta,j,zeta j has determinant of absolute value 36, while D has discriminant 6. In this notation

O_A=O+3O j,   [O_D:O_A]=9.

There is exactly one maximal order containing O_A. At every prime other than 3, O_A and O_D coincide locally. At 3, D is a division quaternion algebra and has a unique maximal order.

The same local diagonalization gives

K(lambda_A) ≅ O/18O

as an O-module. The operator J_H kills this kernel: in the diagonal description its coefficient v cancels the denominator of the second coordinate, while the first coordinate is already integral. Thus the action of

x+3y j=x+y J_H in O_A

on K(lambda_A) is multiplication by x modulo 18O.

## 3. Retaining the two stages of gluing

Let S=E0+E1. Since E0 and E1 are geometrically nonisogenous, an endomorphism of S is a pair (a,b) in O x Z that preserves their cyclic intersection. Its exact condition is

a-b in pi O.

Indeed, a acts on ker(pi) by reduction in O/pi=F_3, and b acts on U by reduction modulo 3. Denote this order by O_S.

We need its action on the polarization kernel of S, rather than just this first congruence. The pullback of the polarization of S to E0 x E1 has degrees (18,3). The kernel of lambda_S is obtained as I^perp/I from a subgroup of

E0[18] x E1[3].

It follows that (0,3) acts as zero on K(lambda_S). Write a=r+s zeta. The intersection condition says b=r+s+3t for integers r,s,t. Therefore

(a,b)=r(1,1)+s(zeta,1)+t(0,3).

The first term acts as a scalar, the second is tau, and the last kills the polarization kernel. Consequently (a,b) acts on K(lambda_S) as a through its O-action.

The principal polarization of J realizes J as

(S x A)/Graph(gamma),

where gamma is an anti-isometry between K(lambda_S) and K(lambda_A). The map gamma commutes with tau, because tau preserves the principal polarization and both complementary subvarieties. It is therefore O-linear. No choice of this anti-isometry changes the ensuing scalar compatibility condition.

The second gluing condition is exactly

x-a in 18O,

where x+3y j is the endomorphism of A. We have therefore determined the integral geometric ring of the actual J:

R = { (a,b,x+3y j) : a,x,y in O, b in Z,
                        a-b in pi O, x-a in 18O }.

This is the main place where using the isogenous product alone would give an incorrect answer.

## 4. Maximal orders and their independence

A maximal order in K x Q x D contains the central idempotents and is a product of maximal orders in the three simple algebras. The projection of R to its D-factor is all of O_A: for any x+3y j, take a=x and choose an integer b with b=a modulo pi.

Thus every containing maximal order has D-component containing O_A, whose maximal overorder was proved unique in Section 2. The other components have their usual unique maximal orders. Hence the containing maximal order is in fact unique:

M=O x Z x O_D.

Over Q the unique maximal order is

M_Q=Z x Z x Z.

In particular, all indices and conductor quotients below are independent of the containing maximal order; here this follows from uniqueness, not just from equality of numerical invariants among several choices.

## 5. Geometric index and conductor

The three independent additive restrictions defining R inside M have indices

[O_D:O_A]=9,
[O:18O]=324,
[O:pi O]=3.

Therefore

[M:R]=9*324*3=8748.

A two-sided ideal of M is the product of ideals in its three factors. The largest permissible ideals in the first two factors are plainly 18O and 3Z. In the quaternion factor, an element supported only there must belong to

18O+3O j.

To find the largest O_D-two-sided ideal in this lattice, localize:

- At 2, this lattice is 2O_2+O_2 j=j O_{D,2}, the maximal two-sided ideal of the division maximal order.
- At 3, it is 9O_3+3O_3 j. Let P_3 denote the maximal two-sided ideal of O_{D,3}; then P_3^2=3O_{D,3}. The ideal P_3^4=9O_{D,3} is contained. The next larger ideal P_3^3 is not: its first O_3-coordinate has pi-valuation 3, whereas the displayed lattice requires at least 4. Since all two-sided ideals are powers of P_3, P_3^4 is the largest possible one.
- At every other prime there is no restriction.

The resulting global quaternion ideal is 9j O_D=18O+9O j. Thus the geometric conductor is

C=18O x 3Z x (9j O_D).

Modulo C, a ranges over O/18O, b is determined by its reduction modulo pi, and x is determined by a modulo 18O. The coefficient y of 3j ranges independently over O/3O. Therefore, additively,

R/C ≅ (O/18O) ⊕ (O/3O)
    ≅ (Z/18)^2 ⊕ (Z/3)^2.

The requested invariant factors in divisibility order are [3,3,18,18].

## 6. Rational index and conductor

Intersecting R with Q x Q x Q gives the exact rational integral ring

R_Q={ (a,b,c) in Z^3 : a-c in 18Z, a-b in 3Z }.

Hence

[M_Q:R_Q]=18*3=54.

The largest ideal of Z^3 contained in this ring is

C_Q=18Z x 3Z x 18Z.

All three coordinates of a member of R_Q modulo C_Q are determined by a modulo 18. Thus

R_Q/C_Q ≅ Z/18,

and its nontrivial invariant-factor list is [18].

## 7. Exact lattice checks and uncertainty statement

`integral_check.py` gives a Z-basis of R in the ambient basis

(a_0,a_1,b,x_0,x_1,y_0,y_1)

of M, where a=a_0+a_1 zeta and the quaternion coordinate is x+yj. Its determinant is 8748. The conductor has diagonal ambient basis

(18,18,3,18,18,9,9).

The exact Smith form of the conductor inclusion in R has nontrivial entries 3,3,18,18. The script independently checks multiplicative closure of the proposed order and that the conductor is a two-sided ideal of M.

For the rational ring, the basis (1,1,1), (18,0,0), (0,3,0) has determinant 54. The conductor basis is diag(18,3,18), and the corresponding Smith form has the sole nontrivial entry 18.

All these exact checks passed. No unresolved mathematical uncertainty remains in this incremental calculation. It uses the structural decomposition, optimal maps, and polarizations established in my preceding independent attempt; the new integral-order conclusions are obtained from the actual polarization lattices and the two gluing stages above.
