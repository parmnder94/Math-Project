# Independent solution record

I read only this attempt's `instruction.md` and `data/` for task-specific input. All computations below were performed in this directory with exact integer/rational arithmetic, SymPy, or elementary finite-field arithmetic. I did not use any external solution or task-specific hint. My model-version/effort metadata is not exposed.

The answer is in `output/decomposition.json`. The associated scripts and intermediate calculations in this directory record my own derivation.

## The elliptic map and gluing

Write

- (t=E^3), (A=551232), (B=553014), (C=816903549), and (H(t)=(t-A)(t^2-Bt+C));
- (r=120582), (D=553707), and (Q(t)=t^2+902286t-836509234176).

The elliptic differential is
[
\omega=9(E^3-120582)\frac{dE}{W}.
]
I first recovered the ratio of its two coefficients from the Cartier operator in the order-three eigenspace spanned by (dE/W,E^3dE/W). Rational reconstruction over successive good primes gave (120582). Rational reconstruction of the associated elliptic differential equation then found the degree-18 map. Its leading term at infinity is (-E/324). `exact_map.py` constructs and verifies it, and `map.pkl` stores the exact rational functions used in the JSON.

In smaller coordinates (z=E^3/297), (u=1/z), the map's (x)-coordinate is
[
 X=-\frac E{324}\frac{P(u)}{(1-1856u)(1+3038u-9483264u^2)^2},
]
where
[
\begin{split}
P(u)={}&1-176154u+1559273205u^2-4988491020800u^3\\
&+6870083083960320u^4-3505201172547895296u^5
 +69620547427158196224u^6.
\end{split}
]
I used (Y=X'/[9(E^3-r)]). Exact simplification gives
[
X^3-11+H(E^3)Y^2/4=0.
]
The numerator and denominator of (X) are coprime, and its degree as a rational function of (E) is 18. Equivariance is (X(\zeta_3 E)=\zeta_3X(E)), (Y(\zeta_3E)=Y(E)). The map takes infinity to the identity.

The nonzero three-torsion point and its tangent on (B_1) are
[
 U=(-553707,519750s),\qquad v=-225s\,u-124064325s.
]
The 3-division polynomial has the factor (u+553707), and substitution verifies both the point and tangent. Put (L(t)=225(t-551397)). Then
[
(W-sL(t))(W+sL(t))=-(t-D)^3.
]
The gluing function is (f=a(E)+sWb(E)), with
[
 a=-\frac{E^9-3740121E^6+1411609332672E^3+187823091368005632}
 {18E(E^3-D)Q(E^3)},
]
[
 b=\frac{673E^6-906377472E^3+294451250429952}
 {6E(E^3-D)(E^3-A)Q(E^3)}.
]
`gluing.py` verifies the cube identity exactly. In particular, writing (Z=sW), so (Z^2=11H), it verifies both coefficients in the quadratic algebra and also
[
 a^2-11Hb^2=-X/(t-D).
]

The map (eta) is optimal: a nontrivial isogeny factor of its prime degree 3 would leave a degree-one map from this genus-four curve to an elliptic curve. Thus (eta^*U\ne0). The cube identity proves (alpha^*T=eta^*U\ne0).

The kernel of (alpha^*), if nontrivial, is stable under (mathbb Z[\zeta_3]) and has order dividing 18. The prime 2 is inert in this order, so a nontrivial possible kernel must contain (ker(1-\zeta_3)=\langle T\rangle). This contradicts the displayed nonzero pullback. Hence (alpha) is optimal. Once the simple factors below are identified, (operatorname{Hom}_{\mathbb Q}(J,B_0)) has rank one. Optimality therefore proves that degree 18 is the smallest pointed rational degree.

The intersection is killed by 3. The deck transformation acts as (\zeta_3) on (alpha^*B_0) and as the identity on (eta^*B_1), so the intersection is also killed by (1-\zeta_3). The exhibited nonzero subgroup is therefore the entire intersection, of order 3.

The polarization on (B_0\times B_1) pulls back as ((18,3)). Quotienting by the diagonal gluing subgroup of order 3 gives determinant 18 and first elementary divisor 1: pairing the added gluing vector with a complementary integral vector of the (B_1) lattice already gives 1. Thus (S) has type ((1,18)). Its connected complement in a principally polarized fourfold has the same type, so (A) also has type ((1,18)).

## Simple factors and integral orders

Let (K=\mathbb Q(\sqrt{-3})), (mathcal O=\mathbb Z[\zeta_3]), and (pi=\sqrt{-3}=1+2\zeta_3). The connected Prym complement of (eta^*B_1) is an (mathcal O)-module of rank three with polarization type ((1,1,3)). Its discriminant group is killed by (pi): the deck transformation is the identity on the discriminant group identified with (B_1[3]). A local Hermitian normal form is a unit line plus the (pi)-hyperbolic plane:
[
 H_P=\begin{pmatrix}1&0&0\\0&0&\pi\\0&-\pi&0\end{pmatrix}.
]
The CM elliptic vector has norm 18 and divisor ideal ((pi)); the latter is also read from its order-three intersection with (B_1). It can be represented in this form by
[
 v=(0,1,-3\pi).
]
The orthogonal rank-two Hermitian lattice has form (operatorname{diag}(1,-18)), with complementary vector ((0,1,3\pi)). These normal forms can be checked locally: away from 2 and 3 all the lattices and embeddings are unimodular; at 3 the primitive vector has unit plane coordinate and unit-line coordinate divisible by (pi), which permits integral hyperbolic elimination. The polarization elementary divisors select the unit-line form on the complement at 2 and 3.

For a balanced (K)-Hodge structure of rank two, the determinant-one Hodge circle commutes with the quaternion operation on this Hermitian space. It gives
[
 D=K\oplus K j,\qquad j^2=18,\qquad ja=\bar a j.
]
Thus (D\simeq(-3,2)_{\mathbb Q}), ramified precisely at 2 and 3 and split at infinity. It is a division algebra, so (A) is geometrically simple. The two reduction witnesses below exclude an enlargement to a CM algebra. The elliptic factor (B_0) has CM by (K). The rational nonintegral value
[
 j(B_1)=2640279346000/3087
]
excludes CM for (B_1). In particular, none of these three simple factors are isogenous to another.

For completeness, I computed the integral order on the lattice of (J), not on an isogenous product. The maximal quaternion order is
[
 M_D=\mathcal O\oplus\mathcal O(j/3),
]
whose reduced discriminant is 6. In compatible coordinates the geometric order is
[
 R=\{(a,n,c+d j):a,c,d\in\mathcal O, n\in\mathbb Z,
              c-a\in18\mathcal O, n-a\in\pi\mathcal O\}.
]
Here the rank-two (B_1) lattice with alternating form (3J_2) is glued to the discriminant of (P). Explicit generators of this gluing are
[
 g_1=e_1/3+b/\pi,\qquad g_2=e_2/3+c/\pi.
]
The two pairings (1/3) and (2/3) add to an integer. These generators produce a unimodular rank-eight lattice.

`integral_model.py` constructs the eight-by-eight rational matrices for the seven maximal-order basis elements on this actual glued lattice. It imposes all integrality conditions, computes the largest two-sided ideal by imposing both left and right maximal-order multiplication, and takes Smith normal forms. Independently, the displayed congruence description gives
[
 [M:R]=9\cdot18^2\cdot3=8748.
]
The geometric conductor is
[
 18\mathcal O\ \times\ 3\mathbb Z\ \times\ (18\mathcal O+3\mathcal O j).
]
Consequently its additive quotient is
[
 R/\mathfrak c\simeq(\mathbb Z/18)^2\oplus(\mathbb Z/3)^2,
]
with invariant factors ([3,3,18,18]).

The full Galois action described next fixes only (mathbb Q) in the quaternion factor and only (mathbb Q) in (K). Therefore the three rational division algebras are all (mathbb Q), and all rational multiplicities are one. There are two distinct one-dimensional rational factors, hence two separate records with dimension one in the JSON.

The rational integral order is
[
 \{(a,n,c)\in\mathbb Z^3:c\equiv a\pmod {18},\ n\equiv a\pmod3\}.
]
Its index is 54, conductor is (18\mathbb Z\times3\mathbb Z\times18\mathbb Z), and conductor quotient is (mathbb Z/18).

## Frobenius computations and endomorphism field

`counts.py` enumerates points over both (mathbb F_p) and (mathbb F_{p^2}). For the latter it uses a quadratic model and tests the norm for quadratic character. The chosen witnesses are:

| (p) | (C) counts | (B_0) counts | (B_1) counts | Frobenius polynomial of (A) |
|---|---|---|---|---|
| 13 | 21, 195 | 19, 171 | 16, 192 | (x^4+x^2+169) |
| 23 | 18, 534 | 24, 576 | 18, 540 | (x^4-26x^2+529) |

The sixth-power elliptic polynomials are respectively
[
 x^2-506x+4826809,\qquad x^2+23686x+148035889.
]
Their traces are prime to 13 and 23, and their quadratic fields are (\mathbb Q(\sqrt{-3})) and (\mathbb Q(\sqrt{-10})). Newton sums through degree 12 verify the required repeated-root property. Different ordinary quadratic fields exclude extra geometric CM on the quaternionic surface.

Over (K), the endomorphism-field Galois group acts in the projective centralizer (K^*/\mathbb Q^*) of the deck operator. Its finite cyclic subgroup has order dividing 6. The quartic polynomials determine its Frobenius order: orders 1, 3, and 6 have respectively
[
 P=(x^2-a x+p)^2,quad e_2=s_1^2-p,quad e_2=s_1^2/3+p;
]
order 2 has (s_1=0), with the coincident cases checked separately. At 43 the order is 6. Complex conjugation acts by inversion, so the full group is dihedral of order 12, with fixed algebra (mathbb Q) on (D).

This is a rational Kummer extension (K(\sqrt[6]{m})). One way to see the rational descent of the Kummer class is to use its conjugation invariance: if (ar c/c=d^6), then (N(d)=1), and Hilbert 90 changes (c) by a sixth power to a rational number.

The endomorphism field is unramified where (J) has good reduction. The curve discriminant has prime support (2,3,5,7,11,29); the local calculation at 5 shows that (J) also has good reduction there. Thus, modulo rational sixth powers, (m) is supported on (2,3,7,11,29), with either sign. I enumerated this finite set of (2\cdot6^5) classes, using the exact Frobenius orders
[
 (p,o_p)=(13,2),(19,3),(31,3),(37,2),(43,6),(61,3),
 (67,1),(73,3),(79,2),(97,3),(103,6).
]
The supplementary counts at 103 are ((94,11088),(111,10767),(96,10752)), giving (s_1=9,e_2=130), and hence order 6. `field_certificate.py` leaves exactly four rational radicands:
[
 -1203587,quad -103004180250587,quad 32496849,quad2781112866765849.
]
They all give the same field: the positive representatives differ by the sixth power (-27=(\sqrt{-3})^6), and the second negative representative is the fifth power of the first up to a rational sixth power. I used
[
 m=-7^3\cdot11^2\cdot29=-1203587.
]
The order-six Frobenius and the nontrivial quadratic field prove that the degree is exactly 12 and that the full endomorphism field, rather than just a field of definition, has been found.

## Local models and differentials

The differential used throughout is the exact pullback (9(E^3-r)dE/W), including its factor 9.

### Prime 5

All three (t)-roots coincide modulo 5 and have mutual differences of valuation 2. Because cubing is étale at their nonzero residues, the nine (E)-roots form three size-three clusters of depth 2. The stable model has a central genus-one component and three genus-one tails, joined by edges of thickness 1. All these depths and square-root scalings are integral, so the least stable ramification index is 1.

The central component is (y^2=2-E^3) over (mathbb F_5). With (v=(t-A)/25), each tail is
[
 w^2=-v(v^2+3v+3).
]
Both models have trace 0 over (mathbb F_5) and trace -10 over (mathbb F_{25}). Frobenius fixes one tail and exchanges the other two. The full polynomial is nevertheless ((1+5t^2)^4). The compact-type stable model gives good reduction of (J), conductor 0 and Swan 0.

On the central component the vertical order is 0. On a tail the numerator (E^3-r), differential (dE), and (W) have valuations 2, 2, and 3, respectively, giving vertical order 1. The leading differential orders at each central/tail node are (0,-2).

### Prime 7

There are three unit roots from (t=A). The other six roots have valuation (1/2), making an even cluster of depth (1/2). The stable graph has a genus-one central component and a genus-two component, joined by two edges of thickness (1/2). Thus the least ramification index is 2.

For (arpi^2=7), put (E=arpi z), (W=arpi^3w). The genus-two component has
[
 w^2=A(z^6+c),\qquad c=C/7^3\equiv5\pmod7,
]
and (A\equiv3\pmod7). Inertia acts as ((z,w)\mapsto(-z,-w)). Its elliptic quotient can be written
[
 v^2=A(1+c u^3).
]
Both this quotient and the central curve (y^2=A-E^3) have 13 points over (mathbb F_7), hence trace -5. Frobenius exchanges the two graph edges because (A=3) is a nonsquare. Consequently
[
 L_7(t)=(1+t)(1+5t+7t^2)^2.
]
There are five inertia-invariant dimensions, so the conductor is 3; this is tame and the Swan conductor is 0.

Both component vertical orders are 0. The central leading differential has node order 0. On the genus-two component it is a nonzero multiple of (dz/w), which has order 1 at each point at infinity. The orders (0,1) across an edge do not have to sum to -2: the zeros (E^3=r) occur inside the two annuli, three in each annulus. Their valuation is (1/3), strictly between the two component depths.

### Prime 3

After (E=3z), the three (t)-root valuations are 3, 3, and 6 before rescaling. The exact cluster tree in the original (E)-valuation is:

- the size-nine cluster (R), depth 1;
- a size-six child (S), depth (4/3), and a size-three child (T), depth (5/2);
- inside (S), two size-three children (U,V), each of depth (3/2).

The stable components (R,S) are rational and (T,U,V) are elliptic. There are two (R)-(S) edges, one (R)-(T) edge, and the (S)-(U), (S)-(V) edges. Their thicknesses are respectively (1/3,1/3,3/4,1/12,1/12). The thickness (1/12) supplies the lower bound on the stable ramification index. All centers lie in the common cubic unit-Kummer splitting field with (zeta_3); the required fourth-root scalings add just the tame factor giving index 12. Thus the minimum is 12, without splitting or marking extra ramification points.

The cluster polynomial valuations are
[
 \nu_R=9,quad\nu_S=11,quad\nu_U=\nu_V=23/2,quad\nu_T=27/2.
]
The numerator (9(E^3-r)) has valuation 5 at each of these components. The resulting vertical orders are
[
 R:3/2,quad S:5/6,quad U,V,T:3/4.
]
On (R), the reduced model is (y^2=-z) after removing the square (z^2(z-1)^6). Its differential is proportional to
[
 \frac{(z+1)^3,dz}{z(z-1)^3y}.
]
Thus the orders are -3 at the two branches going to (S), and -2 at the branch going to (T). On (S), after normalization, the differential is proportional to
[
 dz/[(z-a)(z-b)y],\qquad y^2=\text{constant}\,(z-a)(z-b).
]
It has orders 1,1 at the two parent branches and -2 at each elliptic child branch. Each elliptic tail differential has order 0 at its attaching point. These give every branch order in the JSON, and their slopes agree with the stated vertical differences and thicknesses.

The two roots of the quadratic in (t) are already in (mathbb Q_3). After extracting the powers of 3, the three cubic unit classes have representatives 4, 7, 7 modulo 9. Each cubic is irreducible with discriminant exponent 3, contributing (3-3+1=1) to the odd-prime hyperelliptic Swan formula. The Swan conductor is therefore 3. Wild inertia acts nontrivially on each elliptic tail. The remaining graph cycle has nontrivial tame quadratic inertia. There are no inertia-invariant (H^1) dimensions, giving (L_3(t)=1) and Artin conductor (8+3=11).

## Verification status

All rational-function identities, point counts, Newton sums, integral-lattice integrality conditions, conductor ideal conditions, and Smith normal forms were checked by exact computation. The structural steps are the Hermitian Prym normal form, the balanced-rank-two quaternion construction, and the standard odd-prime cluster/wild-conductor descriptions explained above. I have no unresolved numerical value or competing candidate in the submitted artifact.
