import sympy as s
from flint import fmpz_mat
from sympy.matrices.normalforms import hermite_normal_form, smith_normal_form
from functools import reduce
from math import gcd

def imat(M):return fmpz_mat([[int(x) for x in M.row(i)] for i in range(M.rows)])
def smat(M):return s.Matrix([[int(x) for x in r] for r in M.tolist()])
def den(M):return s.ilcm(*[s.denom(x) for x in M])
def integrallattice(matrices):
 B=s.Matrix.hstack(*[s.Matrix(list(m)) for m in matrices]);d=den(B);H=hermite_normal_form((d*B).T.applyfunc(int));C=d*H.T.inv()
 return [sum((matrices[j]*C[j,i] for j in range(len(matrices))),s.zeros(matrices[0].rows)) for i in range(len(matrices))],C
Q=s.zeros(9)
for k in range(3):
 for i,j in [(3*k,3*k+1),(3*k+1,3*k+2),(3*k+2,3*((k+1)%3)+2)]:Q[i,j]=1;Q[j,i]=-1
Q=Q[:8,:8]
S=s.zeros(8)
for i in range(8):
 j=(i+3)%9
 if j<8:S[j,i]=1
 else:
  for h in [0,2,3,5,6]:S[h,i]=-1
Je=s.Matrix([[0,1],[-1,0]]);Se=s.Matrix([[0,-1],[1,-1]])
v=[s.Matrix([-1,-2]),s.Matrix([1,0]),s.Matrix([3,6])]
Va=s.Matrix.hstack(*[(Se**k)*x for k in range(3) for x in v][:8])
Vb=s.Matrix([[1,0,-1,1,0,-1,1,0],[0,1,0,0,1,0,0,1]])
Ua=Q.inv()*Va.T*Je;Ub=Q.inv()*Vb.T*Je
e0=Ua*Va/18;e1=Ub*Vb/3;eA=s.eye(8)-e0-e1
assert Va*Ua==18*s.eye(2) and Vb*Ub==3*s.eye(2) and Va*Ub==s.zeros(2)
VV=Va.col_join(Vb);hh,tt=imat(VV.T).hnf(transform=True);LL=smat(tt)[4:,:].T
assert VV*LL==s.zeros(4)
QA=LL.T*Q*LL;SA=(LL.T*LL).inv()*LL.T*S*LL
print('QA',QA);print('SA',SA);print('QA SNF',smith_normal_form(QA))
# K basis of A
for j in range(1,4):
 K=s.Matrix.hstack(s.eye(4)[:,0],SA[:,0],s.eye(4)[:,j],SA[:,j])
 if K.det():break
print('Kbasis',K,'det',K.det());QK=K.T*QA*K
# H entries in a+b zeta represented 2x2 multiplication matrices
Z=s.Matrix([[0,-1],[1,-1]]);I=s.eye(2)
H=[[QK[2*i,2*j+1]*I+QK[2*i,2*j]*(I+Z) for j in range(2)] for i in range(2)]
conj=s.Matrix([[1,-1],[0,-1]])
C=s.Matrix.vstack(s.Matrix.hstack(-H[1][0],-H[1][1]),s.Matrix.hstack(H[0][0],H[0][1]))
JK=C*s.diag(conj,conj)
JA=K*JK*K.inv()
print('J2',JA*JA);print('JA',JA)
assert JA*SA==(SA**2)*JA
# rational left inverse of LL and extension by zero on S
LP=(LL.T*LL).inv()*LL.T*eA
J=LL*JA*LP
mats=[e0,S*e0,e1,eA,S*eA,J,S*J]
RB,RC=integrallattice(mats)
# Reduced trace scalar on factors; ordinary trace on 8x8 /2 works (E0 deg2 acts once H1, E1 2, D acts twice)
# Total reduced trace: field K trace + scalar on Q + quaternion trd; physical trace = Ktrace+2Qscalar+2trd
# use components: tr(e0 r) + tr(e1 r)/2 + tr(eA r)/2
red=lambda r:s.trace(e0*r)+s.trace(e1*r)/2+s.trace(eA*r)/2
G=s.Matrix([[red(a*b) for b in RB] for a in RB]);print('Rdisc',s.factorint(abs(G.det())),'index',s.sqrt(abs(G.det())/108))
OAB,OAC=integrallattice([s.eye(4),SA,JA,SA*JA]);G_A=s.Matrix([[s.trace(a*b)/2 for b in OAB] for a in OAB]);print('OA disc',G_A.det(),s.factorint(abs(G_A.det())));print('OA coords',OAC)
# save rational matrices for next computations
import json
mat_json=lambda M:[[str(x) for x in M.row(i)] for i in range(M.rows)]
json.dump({'Q':mat_json(Q),'S':mat_json(S),'LL':mat_json(LL),'e0':mat_json(e0),'e1':mat_json(e1),'eA':mat_json(eA),'J':mat_json(J),'JA':mat_json(JA),'SA':mat_json(SA),'RB':[mat_json(m) for m in RB],'RC':mat_json(RC),'mats':[mat_json(m) for m in mats],'OAC':mat_json(OAC)},open('integral_matrices.json','w'))
