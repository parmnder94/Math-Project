# Private author-side disagreement audit

The provisional index **314928** is explained by a missing coefficient
conjugation in the candidate's anti-linear quaternion operator. Correcting that
one construction, while retaining its homology lattice, alternating form,
order-three action, elliptic projectors, and exact saturation method, gives
**8748**. This disagreement exposes no flaw in the reference integral-order
calculation.

This is an author audit of a snapshot, **not difficulty calibration** and not
classification of the blind solver's eventual frozen artifact. Only
`integral.py` and `integral_matrices.json` were read from that attempt. Local
copies and SHA-256 hashes preserve exactly the audited state. No attempt or
task-bundle file was edited, and no findings were sent to the blind solver.

## Exact construction error

Write (F=L^tQL), (T=S_A), and (A=J_A) for the candidate matrices. Its basic
checks succeed: (Q) is unimodular, (S^tQS=Q), (SL=LT),

\[
T^tFT=F,\qquad T^2+T+1=0,\qquad A^2=18,\qquad AT=T^2A,
\]

and (F) has alternating elementary divisors (1,18). Thus the simple
quaternion-relation checks do not detect the error.

Its selected ordered basis ((u,\zeta u,v,\zeta v)) has determinant one.
With \(\lambda=\zeta-\bar\zeta\), use the convention

\[
E(x,y)=\operatorname{Tr}_{K/\mathbf Q}(\bar x^{\,t}My/\lambda).
\]

If (m=a+b\zeta), then
\(\operatorname{Tr}(m/\lambda)=b\) and
\(\operatorname{Tr}(m\zeta/\lambda)=a-b\). Consequently the candidate's
extraction formula constructs (M), not \(\bar M\):

\[
M_{ij}=E(e_i,\zeta e_j)+(1+\zeta)E(e_i,e_j),\qquad
M=\begin{pmatrix}1&-1-5\zeta\\4+5\zeta&3\end{pmatrix},
\quad \det M=3-21=-18.
\]

For \(J_0=\left(\begin{smallmatrix}0&1\\-1&0\end{smallmatrix}\right)\),
the correct Hodge construction is
\(J_0\bar M\circ\mathrm{conj}\), up to an overall sign. The candidate instead
uses \(-J_0M\circ\mathrm{conj}\). Both square to 18 and conjugate the
(K)-action, so neither of its assertions catches the omitted conjugation.

In the candidate's notation, replace

```python
JK = C * diag(conj, conj)
```

by

```python
JK = diag(conj, conj) * C
```

This is solely an audit description; the attempt was not modified. Transporting
the corrected map back to its integral basis gives

\[
A_{\rm corr}=\begin{pmatrix}
-4&-3&-6&-2\\-4&-6&-6&-8\\0&5&6&4\\5&0&3&4
\end{pmatrix}.
\]

It squares to 18, satisfies (A_{\rm corr}T=T^2A_{\rm corr}), and is
Rosati self-adjoint. By contrast the candidate has the exact nonzero residual

\[
A^tF-FA=\begin{pmatrix}
20&30&45&40\\30&60&90&75\\45&90&90&90\\40&75&90&80
\end{pmatrix}.
\]

The corrected map also sends the entire alternating dual lattice into the
original lattice: (A_{\rm corr}F^{-1}) is integral. The candidate's
(AF^{-1}) has denominator 18.

## Why this rejects the candidate as Hodge, with the necessary hypothesis

**Non-self-adjointness alone does not refute an arbitrary abelian-variety
endomorphism.** The argument uses the already established geometric equality
\(\operatorname{End}^0(A)=D=(-3,18)\), as well as the fact that the
order-three automorphism preserves the polarization. The latter gives
\(a^\dagger=\bar a\) on (K). The geometric equality is independently
established in the bundle's `endomorphism_proof.md`, using the different
ordinary reduction centers at 43 and 61 to exclude a CM elliptic square.
This audit does not replace or reprove that geometric upper bound.

Write (D=K\oplus Kj), where (ja=\bar a j) and (j^2=18). Rosati maps
the anti-(K) line (Kj) to itself, so (j^\dagger=cj). Applying Rosati
twice gives

\[
j=(cj)^\dagger=j^\dagger\bar c=cj\bar c=c^2j.
\]

Thus (c=\pm1), and positivity of
\(\operatorname{Trd}(jj^\dagger)=36c\) forces (c=1). Every element
of (Kj) is therefore self-adjoint:
\((bj)^\dagger=j\bar b=bj\). If the candidate were a Hodge
endomorphism, its anti-(K) relation would put it in that line. The displayed
residual contradicts this necessary identity.

This use of the full geometric algebra matters: in a CM specialization with
larger algebra, an anti-linear Hodge endomorphism need not satisfy this
conclusion. We do not infer impossibility merely from the polarization and
the candidate's two quaternion relations.

The corrected operator's Hodge property also follows directly from the
Hermitian construction. For the actual (K)-linear real complex structure
(I), signature ((1,1)) gives (\operatorname{tr}I=0), while
polarization compatibility gives
\(\bar M\bar I=-I^t\bar M\). Since
\(IJ_0=-J_0I^t\), one obtains
\(I(J_0\bar M)=(J_0\bar M)\bar I\), the required commutation for the
anti-linear operator.

## Exact saturation comparison

`diagnostic.py` does not execute or import candidate code. It reconstructs the
two operators from the matrix snapshot and independently saturates their
seven-dimensional rational spans inside (M_8(\mathbf Z)). It uses the
reduced trace of (K\times\mathbf Q\times D); the absolute maximal-order
trace discriminant is (3\cdot1\cdot6^2=108).

| Quantity | Candidate operator | Corrected operator |
|---|---:|---:|
| Determinant of integral coefficient lattice | 34992 | 972 |
| Absolute full-order trace discriminant | 10711401679872 | 8264970432 |
| Maximal-order index | 314928 | 8748 |
| Surface-order trace discriminant | -2916 | -2916 |
| Denominator of extension to full homology | 18 | 1 |

Both surface orders have reduced discriminant 54 and maximal-order index 9.
The factor 36 discrepancy arises in the full-lattice gluing calculation with
the wrong operator, rather than the abstract quaternion presentation.

The corrected coefficient basis gives exactly the expected congruences

\[
a_0=r+s\zeta,\quad n\equiv r+s\pmod3,\quad
a\equiv a_0\pmod{18\mathcal O},
\]

with the two coefficients of (b j) unrestricted in \(\mathcal O\).
The coefficient-lattice determinant is (3\cdot18^2=972), giving
\(972\cdot9=8748\).

Reproduce the audit with:

```sh
python authoring/evidence/calibration/integral_disagreement/diagnostic.py
```

All exact assertions pass. `diagnostic.json` contains the input hashes,
matrices, integral coefficient lattices, and discriminants for both cases.
