# Integral endomorphism structure: independent incremental solution

I used only my own preceding solution and files. The original submission is unchanged. The additional result is

```json
{
  "geometric_index": 8748,
  "rational_index": 54,
  "geometric_conductor_quotient": [3, 3, 18, 18],
  "rational_conductor_quotient": [18]
}
```

These are the integral rings of the actual principally polarized Jacobian, not of the product of its isogeny factors. In particular, the gluing conditions below are essential. `integral_verify.py` verifies the resulting indices and quotient invariant factors with exact integer matrices and writes `output/integral_structure.json`.

## 1. Facts from the preceding independently derived solution

Write E0 for the embedded alpha elliptic curve, E1 for the embedded beta elliptic curve, and A for their connected orthogonal complement. Both elliptic embeddings are optimal. Their induced polarization degrees are 18 and 3. Their intersection is cyclic of order 3. The induced polarization on A has type (1,18).

The rational geometric endomorphism algebra is

\[
 K\oplus\mathbb Q\oplus D,\qquad
 K=\mathbb Q(\sqrt{-3}),\quad D=(-3,2),
\]

where D is the quaternion division algebra ramified at exactly 2 and 3. The algebra over Q is the scalar subalgebra \(\mathbb Q^3\). The three simple factors are pairwise nonisogenous geometrically. Thus every rational endomorphism respects these factors; its integrality on the full Jacobian is a lattice condition, not an additional off-diagonal Hom condition.

Let \(\mathcal O=\mathbb Z[\zeta_3]\), and put \(\pi=\sqrt{-3}=1+2\zeta_3\). The actual automorphism sigma of C gives an integral O-action on E0 and A. It acts trivially on E1. On A its signature is (1,1). All integral homology lattices used below are those inherited from these actual abelian subvarieties of J.

## 2. The Prym lattice retains the gluing information

Let P be the connected complement of E1 in J. It is a threefold with polarization type (1,1,3). The addition map E1 x P -> J has kernel the graph of an anti-isometry between E1[3] and the polarization kernel of P. Therefore sigma acts trivially on that entire kernel of P: it is trivial on E1[3], and the graph is sigma-stable.

The addition map E0 x A -> P has degree

\[
 \sqrt{\frac{18^2\,18^2}{3^2}}=108=2^2 3^3.                 \tag{1}
\]

Indeed its pulled-back polarization is the orthogonal product of the restrictions to E0 and A. Both inclusions are primitive, so this kernel is the graph of the actual intersection E0 cap A. As an O-submodule of E0's polarization kernel, it is uniquely determined locally: at 2 it is E0[2], of order four, and at 3 it is E0[pi^3], of order 27. This uses that the elliptic Tate lattice has rank one over O locally, and that O_2 is an unramified quadratic DVR while O_3 is a ramified quadratic DVR.

This two-stage description is particularly useful. It encodes the full principal Jacobian lattice using first E0 x A -> P and then E1 x P -> J. It does not discard the original order-three intersection of E0 and E1.

## 3. The integral quaternion order on A

An O-stable homology lattice of A is locally free of rank two over O. Express its alternating polarization as the trace of a hermitian form, using the inverse different 1/pi. The determinant magnitude is 18, and its signature is (1,1).

The needed local normal form at 2 and 3 is

\[
 \Lambda_A=\mathcal O f\oplus\mathcal O g,\qquad
 H_A=\operatorname{diag}(1,-18).                         \tag{2}
\]

Here and below O denotes the corresponding completion when discussing a prime. Some justification at the ramified prime is important. The polarization is primitive and has type (1,18). At 3 this forces a unit hermitian entry and a unit norm vector. Otherwise a first-power-pi off-diagonal entry would force determinant valuation two rather than four; if every entry were divisible by pi^2, the alternating polarization would be divisible by 3, contradicting its first elementary divisor 1. One can therefore diagonalize with a unit first coefficient and a second coefficient of pi-valuation four.

The order-pi^3 isotropic gluing in (1) forces that unit coefficient to be a norm unit. To see this, write the unit coefficient as a and the other diagonal coefficient as -18 times a norm unit divided by a. The norm of a glued vector (e+c g)/pi^3 must be integral, where H(e,e)=18. Reducing this integrality condition modulo 3 shows that a is 1 modulo 3, the unit norm class in the ramified quadratic extension. Unit rescalings give (2). At 2 the unit norm map of the unramified quadratic extension is surjective, giving the same form. Away from 2 and 3 the lattice is unimodular.

In the model (2), the conjugate-linear Hodge endomorphism

\[
 J(f)=g,\qquad J(g)=18f,\qquad J(\lambda x)=\bar\lambda J(x)
\]

satisfies J^2=18 and J lambda=bar(lambda) J. Together with scalar K it gives all D. A rational quaternion endomorphism u+vJ preserves the lattice if and only if both u and v are in O; necessity follows already by applying it to f, and sufficiency follows on both basis vectors and their O multiples. Thus

\[
 R_A=\mathcal O\oplus\mathcal O J.                         \tag{3}
\]

The order in (3) has reduced discriminant 54. The algebra discriminant is 6, so its maximal-order index is 9. More explicitly, put j=J/3, so j^2=2. At 3,

\[
 M_A=\mathcal O\oplus\mathcal O j,\qquad
 R_A=\mathcal O\oplus3\mathcal O j.                        \tag{4}
\]

This M_A has reduced discriminant 6 and is maximal. At 2, division by 3 is a unit operation, so R_A is already maximal. It is also maximal at every other prime. These statements are local, and do not require asserting a global diagonalization of the hermitian lattice.

The action of (3) on the discriminant module of A is simple. This module is carried by the g-coordinate, and is O/(18). The J term sends a representative g/18 to f, hence is zero on the discriminant module. Therefore the induced action is multiplication by u.

## 4. The complete Jacobian order at 3

First form P from E0 and A. The preceding isotropic gluing can be put into the exact form

\[
 \Lambda_P=\mathcal O f\oplus\mathcal O e\oplus\mathcal O h,
 \qquad h=(e+g)/\pi^3,\quad H(e,e)=18.                    \tag{5}
\]

Here is why a unit in the gluing does not change this normal form. Initially one can have h=(e+c g)/pi^3. Integrality gives N(c)=1 modulo 3. The requirement, proved in section 2, that sigma be trivial on the polarization kernel of P strengthens this to N(c)=1 modulo 9: otherwise H(h,h) is a unit and the hermitian discriminant module would be O/pi^2, on which sigma is nontrivial. The norm map from 1+pi^3 O onto 1+9 Z_3 then lets one replace c, without changing its class modulo pi^3, by a norm-one unit. Rescaling g by this norm-one unit gives (5).

The e,h part of the Gram matrix is

\[
 \begin{pmatrix}18&-2\pi\\2\pi&0\end{pmatrix}.             \tag{6}
\]

Consequently the polarization kernel of P is

\[
 \Lambda_P^\#/\Lambda_P
 =\mathbb F_3[e/\pi]\oplus\mathbb F_3[h/\pi].              \tag{7}
\]

Let a act on E0 and q=u+vJ act on A, with a,u,v in O. Acting on h shows that this pair preserves P if and only if

\[
 a-u\in\pi^3\mathcal O.                                  \tag{8}
\]

Indeed

\[
 q(h)=u h+\frac{a-u}{\pi^3}e-2\pi v f,
\]

where the left side denotes the combined action of a and q. On the two classes in (7) the matrix is

\[
 \begin{pmatrix}
 a\bmod\pi &(a-u)/\pi^3\bmod\pi\\
 0&u\bmod\pi
 \end{pmatrix}.                                          \tag{9}
\]

For the second column one can directly use

\[
 q(h/\pi)=u h/\pi+\frac{a-u}{\pi^4}e+2vf.
\]

Now glue E1 to P to obtain the actual J. Its endomorphism n is a scalar in Z_3, and it acts as n times the identity on E1[3]. Irrespective of the chosen anti-isometry defining this graph, (9) must be this same scalar matrix. Hence the exact conditions are

\[
 a-u\in\pi^4\mathcal O=9\mathcal O,
 \qquad n\equiv u\pmod\pi.                               \tag{10}
\]

In maximal-order coordinates q=u+bj, condition (3) additionally says b is in 3O. Thus the full local order is

\[
 R_3=\{(a,n,u+bj):
 a,u\in\mathcal O,\ n\in\mathbb Z_3,\ b\in3\mathcal O,
 \ a-u\in9\mathcal O,\ n-u\in\pi\mathcal O\}.            \tag{11}
\]

The three independent additive indices in (11) are 9, 81, and 3. Therefore

\[
 [M_3:R_3]=3^2\,3^4\,3=3^7.                              \tag{12}
\]

This additional 81-condition is why merely retaining the order-three elliptic gluing, or merely using an isogenous product, would give the wrong integral ring.

## 5. The local order at 2 and at other primes

At 2, E1 splits off integrally because its polarization degree 3 is a unit. The E0-A gluing is the graph on their full polarization kernels, each isomorphic to O/2=F_4. The induced quaternion action is u modulo 2. Therefore

\[
 R_2=\{(a,n,u+bj)\in\mathcal O\oplus\mathbb Z_2\oplus M_A:
                  a\equiv u\pmod2\}.                    \tag{13}
\]

Its maximal-order index is four. At every prime other than 2 and 3 all the polarization degrees and gluing degrees in question are units and the surface order is maximal, so R is maximal there. Combining (12) and (13),

\[
 [M:R]=4\cdot3^7=8748.                                   \tag{14}
\]

## 6. Largest two-sided conductor ideal and its geometric quotient

A maximal order of the product algebra contains the central factor idempotents. Thus any two-sided ideal is a product of ideals in its three factors. The conductor can be found by asking which elements supported on a single factor lie in R.

At 3, let P_3=pi M_A denote the unique maximal two-sided ideal of the quaternion maximal order. From (11), the conductors on the first and second factors are 9O and 3Z_3. In the isolated quaternion factor the necessary coordinate bounds are u in 9O and b in 3O. All two-sided ideals of this division maximal order are powers of P_3. The largest one satisfying both bounds is

\[
 P_3^4=9M_A.
\]

Consequently

\[
 C_3=9\mathcal O\oplus3\mathbb Z_3\oplus9M_A.
\]

Modulo this ideal, a is determined by u modulo 9, n is determined by u modulo pi, and b ranges through 3O/9O. Hence, additively,

\[
 R_3/C_3\cong(\mathcal O/9\mathcal O)
              \oplus(3\mathcal O/9\mathcal O)
 \cong(\mathbb Z/9)^2\oplus(\mathbb Z/3)^2.               \tag{15}
\]

At 2, let P_2=jM_A=2O+Oj. It is the kernel of M_A -> F_4. The fiber-product condition (13) gives

\[
 C_2=2\mathcal O\oplus\mathbb Z_2\oplus P_2,
 \qquad R_2/C_2\cong\mathbb F_4
 \cong(\mathbb Z/2)^2.                                  \tag{16}
\]

There is no quotient at any other prime. Combining (15) and (16) into invariant-factor order yields

\[
 R/C\cong\mathbb Z/3\oplus\mathbb Z/3
             \oplus\mathbb Z/18\oplus\mathbb Z/18.        \tag{17}
\]

## 7. Rational integral ring

The rational algebra is Q^3, embedded by scalar actions on E0, E1, and A. Intersecting the exact local orders with this scalar subalgebra gives, globally,

\[
 R_{\mathbb Q}
 =\{(a,n,c)\in\mathbb Z^3:
             a\equiv c\pmod{18},\quad n\equiv c\pmod3\}.
                                                               \tag{18}
\]

For example, the pi^4 congruence in (10) becomes a congruence modulo 9 on rational scalars, while the pi congruence becomes one modulo 3. The prime-2 condition supplies the other factor of 18.

The maximal order is Z^3, and (18) has index

\[
 [M_{\mathbb Q}:R_{\mathbb Q}]=18\cdot3=54.
\]

The largest ideal of Z^3 contained in (18) is

\[
 C_{\mathbb Q}=18\mathbb Z\oplus3\mathbb Z\oplus18\mathbb Z.
\]

Modulo this ideal every allowed triple is determined by the common scalar c modulo 18. Therefore

\[
 R_{\mathbb Q}/C_{\mathbb Q}\cong\mathbb Z/18.             \tag{19}
\]

## 8. Independence of containing maximal order

In fact the containing maximal order is unique in each of the two rational algebras in this example. In the geometric algebra, the K and Q factors have unique maximal orders. At 2 and 3 the quaternion algebra is division and its local maximal order is unique. At every other prime the order R itself is already maximal, so any containing maximal order must agree with it locally. These local specifications determine the same global maximal order. The rational algebra Q^3 has the unique maximal order Z^3. Thus all four requested invariants are independent of a choice of containing maximal order; this is stronger than merely proving numerical invariance between choices.

## Verification and uncertainty statement

`integral_verify.py` assembles an additive integer-lattice model with exactly these local normal forms. It checks index 8748, index 54, inclusion of both conductor ideals, and the Smith forms giving (17) and (19). This computation verifies the arithmetic following the lattice derivation; it is not used to guess the actual Jacobian lattice. The geometric identification uses the primitive embeddings, the actual principal polarization, the O-action, and both stages of gluing described above. I have no remaining unresolved mathematical uncertainty in this additional submission.
