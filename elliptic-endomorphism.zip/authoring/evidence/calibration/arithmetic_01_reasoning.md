# Blind solution and derivation

The completed artifact is `output/decomposition.json`. I used only the assigned instruction and data files, general mathematical facts, and the installed Python/SymPy library. I did not inspect another attempt or a hidden checker. The discovery scripts are retained. Some early scripts deliberately explore unsuccessful map ansätze; the successful construction is in `reconstruct_map.py`, `gluing.py`, and `assemble.py`.

The answer is a degree-18 elliptic map, a cyclic intersection of order 3, polarization types (1,18) on both surfaces, and an absolutely simple quaternionic surface with quaternion discriminant 6. The endomorphism field is

\[
 L=\mathbb Q(\zeta_3,\sqrt[6]{-1203587}),\qquad [L:\mathbb Q]=12.
\]

The local conductors at 3, 5, and 7 are 11, 0, and 3. The wild contributions are 3, 0, and 0.

## 1. Constructing and checking the map

Put
\[
 t=E^3/297,\qquad a=1856,\qquad H(t)=(t-a)(t^2-1862t+9261).
\]
Thus \(h(E)=297^3H(t)\). Define
\[
\begin{aligned}
 N(t)={}&t^6-176154t^5+1559273205t^4-4988491020800t^3\\
 &+6870083083960320t^2-3505201172547895296t
 +69620547427158196224,\\
 Q(t)={}&t(t-1856)(t^2+3038t-9483264)^2.
\end{aligned}
\]
Then the map used in the artifact is
\[
 X=-\frac E{324}\frac{N(t)}{Q(t)},\qquad
 Y=-\frac{X'(E)}{9(E^3-120582)}.
\]
The script expands these into the exact integer-coefficient rational-function encoding. Direct symbolic arithmetic gives
\[
 -hY^2=4X^3-44,\qquad X'/Y=-9(E^3-120582).
\]
Consequently \((X,WY/2)\) lies on \(v^2=x^3-11\), and
\[
 \omega=-9(E^3-120582)\,dE/W.                 \tag{1}
\]
There is no indeterminacy on the smooth projective curve: a rational map from a smooth projective curve to an elliptic curve extends. At infinity, \(X\sim-E/324\), so infinity maps to the identity. The reduced rational function X has degree 18; composing with the degree-two x-coordinates of the two hyperelliptic curves shows that the morphism degree is 18.

For completeness, the map can be discovered by writing \(X=-r^2E F(w)\), \(w=297/E^3\), and using the differential \(-\frac1{2r}(E^3-c)\,dE/W\). The resulting equation is
\[
 (1-3718w+3465133w^2-17188416w^3)(F-3wF')^2
 =(1-cw/297)^2(F^3+\lambda w),
\quad \lambda=1/(27r^6).
\]
The rational solution above has \(c=120582\), \(r=1/18\), and \(\lambda=1259712\). Modular Cartier calculations first suggested c; rational reconstruction was followed by the exact identity, so those discovery calculations are not being used as proof.

## 2. A constructive gluing identity

Write \(s^2=-11\), and choose
\[
 U=(-553707,-519750s),\qquad m=225s,\quad n=124064325s.
\]
The tangent is \(v=mu+n\). In fact
\[
 P(u)-(mu+n)^2=(u+553707)^3
\]
for the cubic P defining \(B_1\). Thus U is a nonzero point of order three.

Put
\[
 D=E^3-553707,\quad R=E^6+902286E^3-836509234176,
\]
and
\[
\begin{aligned}
 a_0(E)&=\frac{E^9-3740121E^6+1411609332672E^3+187823091368005632}{18EDR},\\
 b_0(E)&=\frac{673E^6-906377472E^3+294451250429952}{6ED(E^3-551232)R}.
\end{aligned}
\]
The function in the artifact is \(f=a_0+sWb_0\), encoded as \([a_0,0,0,b_0]\). With \(L=-225E^3+124064325\), its exact identity is
\[
 (W-sL)f^3=WY/2-s.                         \tag{2}
\]
An economical symbolic check uses \((sW)^2=11h\), \(-h+11L^2=-D^3\), and
\[
\begin{aligned}
 a_0^2-11hb_0^2&=-X/D,\\
 a_0^3+33ha_0b_0^2&=(hY/2-11L)/D^3,\\
 3a_0^2b_0+11hb_0^3&=(1-LY/2)/D^3.
\end{aligned}
\]
All three are zero-remainder rational-function identities in the retained script.

The two elliptic curves are geometrically nonisogenous: B0 has CM, whereas
\[
 j(B_1)=2640279346000/3087
\]
is a nonintegral rational number, hence B1 does not have CM. The degree-three map beta is optimal: a nontrivial isogeny factor would leave a degree-one map from C to an elliptic curve.

Alpha is also optimal. A kernel of its pullback would give an isogeny factor with degree dividing 18, defined over Q. B0 has no rational subgroup of order two. Its unique rational subgroup of order three is generated geometrically by T=(0,s), as follows from its 3-division polynomial \(3x(x^3-44)\). Equation (2) and injectivity of beta* show that T is not in the kernel. An isogeny factor of degree 9 or 18 would leave a map of degree at most two to an elliptic curve. A hyperelliptic curve of genus four cannot be bielliptic: the degree-two maps to P1 and an elliptic curve would give the Castelnuovo-Severi bound g<=3. These possibilities exhaust the divisors of 18.

The intersection is contained in both elliptic polarization kernels, hence in B0[3] and B1[3]. It contains the cyclic group in (2). It cannot contain the full B1[3]: the restriction of the degree-18 pairing to B0[3] is trivial (9 divides 18), whereas the degree-three pairing on B1[3] is nondegenerate, contradicting isotropy of the kernel of the addition isogeny. Thus the full intersection has order exactly 3.

The pullback polarization on B0 x B1 has type (3,18). Quotienting its kernel by the displayed diagonal cyclic subgroup and its orthogonal gives type (1,18). One can see the 3-primary calculation in
\((\mathbb Z/9)^2\oplus(\mathbb Z/3)^2\): quotienting the perpendicular to \((3e_1,f_1)\) by that element leaves \((\mathbb Z/9)^2\). The 2-primary part remains \((\mathbb Z/2)^2\). The connected complementary surface in a principally polarized fourfold has the same elementary divisors. This proves both reported polarization types.

## 3. Simple factors and minimality

The automorphism \(\sigma(E,W)=(\zeta_3E,W)\) has eigenvalues \(\zeta_3,\zeta_3^2,1,\zeta_3\) on
\(dE/W,E\,dE/W,E^2dE/W,E^3dE/W\). The beta factor is invariant and the alpha factor has eigenvalue zeta3. Thus A has O_K action of signature (1,1), where K=Q(sqrt(-3)). This action preserves its polarization.

Here is the standard dimension-two unitary linear-algebra argument for the additional endomorphisms. Write the alternating polarization as the trace of a K-hermitian form of signature (1,1), using the inverse different of K. Since O_K has class number one, an O_K basis can be chosen. The determinant of this hermitian form, modulo norms, is minus the product of the polarization elementary divisors. The conjugate-linear adjugate operator on K^2 commutes with the Hodge circle (whose determinant is one in signature (1,1)); its square is the positive determinant magnitude. It is therefore a rational Hodge endomorphism, hence an abelian-variety endomorphism up to isogeny. Together with K it generates
\[
 D=(-3,18)\simeq(-3,2).
\]
Its Hilbert symbols are negative exactly at 2 and 3, and it is split at infinity. This is the indefinite quaternion division algebra of discriminant 6.

The only possible enlargement in dimension two is the CM-square case. The exact reduction witnesses exclude it. The counts, in the prescribed order C, B0, B1, are

| p | C over p,p^2 | B0 over p,p^2 | B1 over p,p^2 |
|---|---|---|---|
| 13 | 21,195 | 19,171 | 16,192 |
| 23 | 18,534 | 24,576 | 18,540 |

After subtraction the characteristic polynomials of A are
\[
 z^4+z^2+169,\qquad z^4-26z^2+529.
\]
Taking sixth powers of the roots gives, respectively,
\[
 (z^2-506z+4826809)^2,
 \qquad (z^2+23686z+148035889)^2.
\]
Their elliptic discriminants are \(-3\cdot2520^2\) and \(-40\cdot882^2\), and the traces are prime to 13 and 23. Thus the ordinary CM fields differ. A fixed CM elliptic curve cannot have these two ordinary reduction fields. Therefore A is absolutely simple and End^0(A)=D, with no larger algebra.

Consequently the geometric factors are B0 with algebra Q(sqrt(-3)), B1 with algebra Q, and A with algebra D. There is only one B0 factor. Hence Hom_Q(J,B0) has rank one. If alpha were a nontrivial integer multiple of its generator, its degree 18 would be divisible by the square of that integer. The only possibility is multiplication by 3, leaving a degree-two map, already excluded. This proves the requested minimum degree, not merely existence of a degree-18 map.

## 4. The field of all endomorphisms

For clarity, the determinant fact used to compute the field is the following cyclic-cover identity. For a smooth family
\[
 y^2=x^9+b x^6+c x^3+d,
\]
let V denote its nontrivial cubic-character part, a rank-three K representation. Then
\[
 \det_K V\simeq \mathbb Q_\ell(-1)\otimes H^1(y^2=x^3+d)_K.        \tag{3}
\]
The compatible choice of cubic eigenspace is understood; reversing it conjugates both sides. One way to prove (3) is to compare determinant monodromy in the coefficient space. Collisions of nonzero roots of the cubic in x^3 give transvections, hence determinant one. The remaining boundary monodromy is the sextic character of d. Thus the quotient of the two sides is geometrically constant. Specializing to x^9+d determines that constant: the three Jacobi-sum factors with ninth characters congruent modulo three have product q times the corresponding cubic Jacobi sum by Hasse-Davenport. The apparent quadratic factor is (-3/q)=1 over fields containing zeta3. This gives (3), including its twist.

In this problem d=450303377122368. Removing alpha's elliptic character from (3), the determinant character on A divided by cyclotomic is the sextic twist character between the elliptic curves with constants d and -11. Its Kummer radicand is
\[
 d/(-11)=18^6(-7^3\,11^2\,29).
\]
Thus its kernel field over K is obtained by adjoining the sixth root of
\(m=-7^3\,11^2\,29=-1203587\).

For a signature-(1,1) surface the same determinant character describes Galois action on the two-dimensional complement of K in D: identify the conjugate eigenspace with the cyclotomic dual, and use the two-dimensional adjugate identity. The K part is fixed over K, so the character's kernel is exactly the field of all quaternion endomorphisms. Complex conjugation acts nontrivially on K itself. Therefore the full endomorphism field is precisely L stated above.

The Kummer class has order six: its valuation at 29 is one, and it is neither square nor cube over K. Hence [L:K]=6 and [L:Q]=12. The nontrivial rotational action over K has fixed algebra K, while complex conjugation fixes only Q inside K; thus End_Q^0(A)=Q. Also End_Q^0(B0)=Q and End_Q^0(B1)=Q. The two identical dimension-one rational records in the JSON are the two distinct elliptic isogeny classes, not a repeated class.

## 5. Stable reduction and differential data

All valuations below satisfy v_p(p)=1. For a root cluster s of depth d_s, put
\(\nu_s=\sum_r\min(d_s,v(z_s-r))\), since the leading coefficient is a unit. At its component, dE/W has vertical valuation \(d_s-\nu_s/2\). Apply (1) to obtain the listed vertical orders. Odd-child cluster edges have half their relative depth as thickness; even-child edges occur twice, with the full relative depth.

A convenient explicit description of the branch roots is
\[
 E=12\sqrt[3]{319}\,\zeta_3^i,
 \qquad
 E=3\sqrt[3]{11}(7+2\sqrt7)\zeta_3^i,
 \qquad
 E=3\sqrt[3]{11}(7-2\sqrt7)\zeta_3^i.
                                                        \tag{4}
\]
This also verifies that the chosen witness primes are good.

### At 3

The total nine-root cluster has depth 1. Its children are a six-root cluster of depth 4/3 and a triple of depth 5/2. The six-root cluster has two triples, each of depth 3/2. Its stable graph has two rational vertices joined by two edges and three elliptic tails. With the JSON vertex indices, 0 is the total cluster, 1 the six-cluster, 2 and 3 its triples, and 4 the remaining triple.

The values (d,nu) are
\[
 (1,9),\quad(4/3,11),\quad(3/2,23/2),\quad(3/2,23/2),\quad(5/2,27/2).
\]
At every component v_3(E^3-120582)=3, and v_3(9)=2. Thus the differential vertical orders are
\[
 3/2,\quad5/6,\quad3/4,\quad3/4,\quad3/4.
\]
The two central edges have thickness 1/3 and differential orders (-3,1). The two inner tail edges have thickness 1/12 and orders (-2,0). The remaining tail edge has thickness 3/4 and orders (-2,0). The rational vertex 0 also has the six zeros of the leading differential, counted with multiplicity; these explain its node-order total -8 rather than -2.

The least stable ramification index is 12. The thickness 1/12 proves necessity. Sufficiency follows from (4): over the maximal unramified field, the required cubic root fields coincide because 29/11 is a cube in Q_3; adjoining that cubic extension and the tame fourth-root scaling supplies all displayed coordinates and y-scalings. There is no need to split additional marked ramification points.

Wild inertia acts nontrivially by an order-three automorphism on each elliptic tail. The cycle has nontrivial ramified quadratic character (the two edges are exchanged). Hence H^1 has no inertia invariants, so L_3=1. For odd residue characteristic, the wild conductor of a hyperelliptic Jacobian is the Swan conductor of the branch-root permutation representation. The nine roots here give three ramified cubic orbits, each with discriminant exponent 3 and tame contribution 2. Each contributes Swan 1. Thus Swan=3 and conductor=8+3=11.

### At 5

There are three triples of depth 2, with distinct reductions of their centers. The total-cluster component and each of the three tails have genus one. The graph is a star, and all three edges have thickness 1. No ramified extension is required: e=1.

The top component has equation \(w^2=-(E^3-2)\) over F_5. For the rational tail one can put E=18+25z and W=125w; reduction gives \(w^2=2z^3+1\). The other two tails are its conjugates and become isomorphic to it over F_25. Both elliptic equations have trace zero at 5. The fixed tail and the pair of conjugate tails contribute (1+5t^2)^3; the central component contributes another (1+5t^2). Thus
\[
 L_5=(1+5t^2)^4,
\]
with conductor and Swan zero.

On the top component the leading differential is a nonzero holomorphic elliptic differential, so its vertical order is 0 and its three branch orders are 0. On every tail, v_5(E^3-120582)=2 and v_5(dE/W)=-1. The vertical order is therefore 1; the leading differential is proportional to z dz/w and has order -2 at its node. These are the three pairs (0,-2) in the artifact.

### At 7

Six roots form a depth-1/2 cluster at zero; the remaining three roots are units. The top component has genus one, the six-root component genus two, and the two are joined by two edges, each of thickness 1/2. This gives e=2, both necessary and sufficient.

The top equation is \(q^2=3-E^3\). With E=sqrt(7)z and W=7^(3/2)w, the other component is \(w^2=3z^6+1\). Inertia acts on it as (z,w)->(-z,-w). Its invariant elliptic quotient, using r=1/z^2 and q=w/z^3, is
\[
 q^2=r^3+3.
\]
Both invariant elliptic components therefore have trace -5 over F_7. The two nodes have q=+/-sqrt(3), so Frobenius exchanges them and the graph factor is 1+t. Consequently
\[
 L_7=(1+5t+7t^2)^2(1+t)
 =1+11t+49t^2+109t^3+119t^4+49t^5.
\]
The invariant dimension is five, so the conductor is three. The extension is tame, hence Swan=0.

The top differential has vertical order zero and order zero at both nodes. On the genus-two component v_7(E^3-120582)=1 and v_7(dE/W)=-1, again giving vertical order zero; its leading differential is proportional to dz/w and has order one at both infinities. Thus both edges have differential orders (0,1). Their sum is not -2 because each annulus contains three zeros of the original differential: v_7(E^3)=1 there, at depth 1/3 inside an edge of length 1/2. The slope changes account for the equal endpoint vertical orders.

## Verification and limits

The curve-map identity, derivative identity, three cube-root identities, tangent identity, finite-field counts, and sixth-power characteristic-polynomial identities were verified with exact arithmetic. `verify.py` checks these directly from the final JSON. The graph genera and coefficient bounds are also checked. The endomorphism and stable-reduction conclusions use the mathematical arguments given above, not a numerical inference or hidden verifier. No unresolved mathematical obstruction remains in this submission.
