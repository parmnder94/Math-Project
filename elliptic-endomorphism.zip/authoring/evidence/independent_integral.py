"""Integral-order invariants from explicit finite residue groups.

This implementation imports neither the reference solver nor its verifier.
It uses no lattice determinant or Smith normal form. The proof in
integral_order_proof.md identifies the conductor by closure under j1;
the code enumerates its p-primary quotient and recovers invariant factors
from the exact numbers of elements killed by successive powers of p.
"""

import itertools
import json
import math


def _valuation(n, p):
    result = 0
    while n % p == 0:
        n //= p
        result += 1
    return result


def _prime_divisors(n):
    result = []
    p = 2
    while p * p <= n:
        if n % p == 0:
            result.append(p)
            while n % p == 0:
                n //= p
        p += 1
    if n > 1:
        result.append(n)
    return result


def _exact_log(n, p):
    exponent = 0
    while n > 1 and n % p == 0:
        n //= p
        exponent += 1
    assert n == 1
    return exponent


def _primary_factors(elements, moduli, p):
    """Recover a finite p-group from its successive annihilator counts."""
    assert len(elements) == len(set(elements))
    zero = (0,) * len(moduli)
    assert zero in elements
    maximum = max(_valuation(m, p) for m in moduli)
    logarithms = [0]
    for exponent in range(1, maximum + 2):
        multiplier = p ** exponent
        killed = sum(
            all(multiplier * a % m == 0 for a, m in zip(element, moduli))
            for element in elements
        )
        logarithms.append(_exact_log(killed, p))
    # The successive differences count cyclic summands of exponent >= k.
    ranks = [logarithms[k] - logarithms[k - 1]
             for k in range(1, len(logarithms))]
    assert ranks[-1] == 0
    assert all(a >= b for a, b in zip(ranks, ranks[1:]))
    factors = []
    for exponent in range(1, len(ranks)):
        factors.extend([p ** exponent] * (ranks[exponent - 1] - ranks[exponent]))
    assert math.prod(factors) == len(elements)
    return factors


def _combine_primary(primary):
    length = max((len(factors) for factors in primary), default=0)
    result = [1] * length
    for factors in primary:
        padded = [1] * (length - len(factors)) + factors
        result = [a * b for a, b in zip(result, padded)]
    assert all(b % a == 0 for a, b in zip(result, result[1:]))
    return [n for n in result if n > 1]


def solve(polarization=(1, 18), intersection_order=3,
          quaternion_ramified_primes=(2, 3)):
    """Compute the requested invariants from the proved geometric inputs.

    In O=Z[zeta], the polarized O-lattice has determinant -d. Its full
    order is O+Oj, j^2=d, and reduced discriminant 3d. The overorder is
    O+Oj1 with j=s*j1. Preservation of the two gluing graphs gives
    n=a0 mod lambda and a=a0 mod dO.
    """
    assert tuple(polarization) == (1, 18)
    assert intersection_order == 3
    assert tuple(sorted(quaternion_ramified_primes)) == (2, 3)
    d = math.prod(polarization)
    maximal_discriminant = math.prod(quaternion_ramified_primes)
    order_discriminant = 3 * d
    assert order_discriminant % maximal_discriminant == 0
    overorder_index = order_discriminant // maximal_discriminant
    scale = math.isqrt(overorder_index)
    assert scale * scale == overorder_index and d % (scale * scale) == 0
    j1_square = d // (scale * scale)

    # In the pure quaternion coordinate R meets the maximal order in
    # dO+sOj1. Multiplication by j1 forces j1_square*c into dO.
    # Thus its largest two-sided ideal is dO+hOj1, with h as below.
    conductor_j1 = math.lcm(scale, d // math.gcd(d, j1_square))
    assert d % scale == 0 and conductor_j1 % scale == 0
    assert (j1_square * conductor_j1) % d == 0
    assert d % conductor_j1 == 0 and d % intersection_order == 0

    geometric_index = rational_index = 1
    geometric_primary = []
    rational_primary = []
    for p in _prime_divisors(d * intersection_order * conductor_j1):
        D = p ** _valuation(d, p)
        N = p ** _valuation(intersection_order, p)
        H = p ** _valuation(conductor_j1, p)
        B = H // math.gcd(H, scale)
        # Ambient conductor quotient coordinates are
        # (a0_x,a0_y,n,a_x,a_y,c_x,c_y), with c the j1 coefficient.
        moduli = (D, D, N, D, D, H, H)
        elements = []
        for ax, ay, bx, by in itertools.product(range(D), range(D),
                                               range(B), range(B)):
            # zeta is 1 modulo lambda. The only n congruence occurs at 3.
            n = (ax + ay) % N
            elements.append((ax, ay, n, ax, ay,
                             scale * bx % H, scale * by % H))
        ambient_size = math.prod(moduli)
        assert ambient_size % len(elements) == 0
        geometric_index *= ambient_size // len(elements)
        geometric_primary.append(_primary_factors(elements, moduli, p))

        rational_moduli = (D, N, D)
        rational_elements = [(m, m % N, m) for m in range(D)]
        rational_ambient_size = math.prod(rational_moduli)
        assert rational_ambient_size % len(rational_elements) == 0
        rational_index *= rational_ambient_size // len(rational_elements)
        rational_primary.append(
            _primary_factors(rational_elements, rational_moduli, p))

    return {
        'geometric_index': geometric_index,
        'rational_index': rational_index,
        'geometric_conductor_quotient': _combine_primary(geometric_primary),
        'rational_conductor_quotient': _combine_primary(rational_primary),
    }


if __name__ == '__main__':
    print(json.dumps(solve(), indent=2))
