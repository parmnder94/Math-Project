# The minimal field defining all geometric endomorphisms

Assume the separately proved geometric decomposition and End^0(A)=D=(-3,2). Put K=Q(zeta), zeta^2+zeta+1=0. The known order-three curve automorphism defines K inside D over K, and its generator is not rational. Thus the minimal endomorphism field L contains K.

## A finite, exhaustive classification, not a prime-pattern guess

For g in Gal(Qbar/K), its action on D fixes K pointwise. By Skolem-Noether and the centralizer of K in D, it is conjugation by a in K^*/Q^*. The faithful map a -> a/bar(a) embeds this quotient's finite subgroups into the roots of unity of K. The geometric endomorphisms are defined over a finite number field, so the actual image is finite, hence contained in mu_6. Therefore L/K is cyclic of degree dividing six.

Complex conjugation acts nontrivially on K. Conjugating an inner automorphism from K by it inverts that automorphism. Thus Gal(L/Q) is the corresponding generalized dihedral group. In particular the Kummer class M in K^*/K^{*6} defining its character is fixed by conjugation. To check this last assertion directly, conjugation inverts both mu_6 and the character under conjugation on the Galois group, so the two inversions cancel in the Kummer class.

The curve has good reduction outside S={2,3,5,7,11,29}, as follows by factoring its polynomial discriminant. Thus J and its factor A have good reduction there. By the Neron-Ogg-Shafarevich criterion and a Tate module with coefficient prime different from the local prime, inertia acts trivially on every endomorphism. Consequently L/K is unramified outside primes above S. At a prime away from 2 and 3, a Kummer extension of degree dividing six is unramified only if the valuation of its radicand is divisible by six. At 2 and 3 we permit every valuation. All valuations outside S can therefore be removed by sixth powers.

O_K is a PID. Write a class supported above S using the unit zeta_6, the ramified prime lambda=sqrt(-3), conjugate prime pairs above split rational primes, and inert rational primes. Conjugation invariance forces equal exponents modulo six on each split pair. Its remaining unit constraint is

    zeta_6^(-2u+3e)=1,

where e is the exponent of lambda. Hence e is even and u is zero or three modulo six. Every such class has a rational representative. Because lambda^6=-27, it has a unique representative of the form

    (-1)^epsilon * 2^a * 3^b * 5^c * 7^d * 11^e * 29^f,

with epsilon in {0,1}, b in {0,1,2}, and a,c,d,e,f in {0,...,5}. There are exactly 46,656 classes. Uniqueness follows again by prime valuations and the unit equation. This is a proved exhaustive search space, independent of the observed Frobenius data.

## Recovering the faithful character from exact point counts

On V_l(A), let rho(g) be its two-dimensional K-linear Galois matrix for g fixing K, and let c(g) be the cyclotomic character. The invariant polarization matrix satisfies bar(rho)^t M rho=c M. With the rational Hodge endomorphism j=J0*bar(M)*conjugation from the quaternion construction, the two-by-two determinant identity gives

    rho j rho^(-1) = (det_K(rho)/c) j.

Thus chi=det_K(rho)/c is precisely the character of the action on j. Together K and j generate D, so chi is faithful on Gal(L/K), not merely a quotient character.

For a split good rational prime p choose r in F_p with r^2+r+1=0, identifying zeta with r. For n=1,2 and q=p^n, count fixed points of sigma^k Frob_q, k=0,1, by the quotient coordinate z=E^3. For nonzero z, three E-roots are fixed precisely when

    z^((q-1)/3)=r^(-k).

Each contributes the number of W solutions of W^2=-H(z), with H(z)=(z-551232)(z^2-553014z+816903549). Include the source points above z=0 and its one infinity point separately. The identical procedure on B0 counts v^2=z-11. Ordinary counts on B1 give the sigma-invariant trace.

If S0,S1 are the traces on sigma^0 Frob and sigma^1 Frob after removing the invariant part, the trace on the zeta eigenspace is

    (S0-S1)/3 + ((-S0-2S1)/3)*zeta.

Subtract the B0 eigenspace trace from the Prym trace. Call the resulting traces on A at Frob and its square t1,t2. Then

    chi(Frob_p)=(t1^2-t2)/(2p).

The record determinant_character_table.json contains these exact values at ten split good primes below 100. Weighted FLINT enumeration independently computes every point count; no guessed Frobenius factor pairing is used.

## Finite certificate and conclusion

For each of the 46,656 possible rational classes, compare its sextic residue m^((p-1)/6) modulo each certified p with the residue of chi(Frob_p). Exactly one class survives:

    (epsilon,a,b,c,d,e,f)=(1,0,0,0,3,4,5),
    M=-7^3*11^4*29^5.

The exact inverse class has the smaller representative

    m=-7^3*11^2*29=-1203587,

since M*m=(7*11*29)^6. A Kummer character and its inverse have the same kernel, so both yield the same minimal field:

    L=Q(zeta, sixth_root(-1203587)).

At p=43 the computed chi value is -zeta, of exact order six. Thus [L:K]=6 and [L:Q]=12. Its Galois group is the dihedral group of order twelve. This is the minimal field defining all endomorphisms of J as well: B0's geometric CM endomorphisms require K, B1 contributes only rational multiplication, and A requires exactly L.

The unique-class conclusion is an exhaustive consequence of the proven ramification and descent constraints; the finite prime computations are a certificate distinguishing every possible field in that class, not statistical support for an unrestricted guess.

## Independent linear certificate for exhaustiveness

Enumeration can be replaced by a tiny matrix-rank certificate. Use columns (-1,2,3,5,7,11,29), and the following sextic-residue logarithms, relative to the primitive sixth root 1+r at each listed prime. The final column is the independently counted character logarithm.

    p       -1  2  3  5  7  11 29 | chi
    13       0  1  4  3  5   1  4 | 3
    19       3  1  1  4  0   0  5 | 4
    31       3  0  5  4  2   1  3 | 4
    37       0  5  4  1  4   0  3 | 3
    61       0  5  0  2  5   3  1 | 2
    67       3  5  3  3  1   1  4 | 0

Modulo two, the six-by-seven matrix has rank six, with kernel generated by (1,0,1,0,0,0,0). This is precisely the relation -27=(sqrt(-3))^6, taking account of the odd exponent three on the prime 3. Modulo three, delete the -1 column: the resulting six-by-six matrix has rank six. Thus the residue map is injective on the entire Kummer class group under consideration. Checking that the proposed class satisfies these six character values proves uniqueness without enumerating the 46,656 candidates. The machine-readable matrix is field_matrix_certificate.json.
