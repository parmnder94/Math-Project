"""Independent pure-integer character counts and modular linear reconstruction.

No reference/verifier imports; no FLINT or Kummer-class enumeration.
"""
from itertools import product
from math import prod,gcd,lcm

def table_row(data,p,n):
    q=p**n;r=next(x for x in range(2,p) if (x*x+x+1)%p==0)
    nonresidue=next(x for x in range(2,p) if pow(x,(p-1)//2,p)==p-1)
    def mul(x,y):return ((x[0]*y[0]+nonresidue*x[1]*y[1])%p,(x[0]*y[1]+x[1]*y[0])%p)
    def add(x,y):return ((x[0]+y[0])%p,(x[1]+y[1])%p)
    def power(x,k):
        a=(1,0)
        while k:
            if k&1:a=mul(a,x)
            x=mul(x,x);k//=2
        return a
    def solutions(x):
        if x==(0,0):return 1
        if n==1:leg=pow(x[0],(p-1)//2,p)
        else:leg=pow((x[0]*x[0]-nonresidue*x[1]*x[1])%p,(p-1)//2,p)
        return 2 if leg==1 else 0
    h=data['curve_h'];assert h['den']==[1]
    hs=h['num'][::3];c=data['target_E']['a6']
    affine=[[0,0,0],[0,0,0]];countB=1
    for a,b in product(range(p),range(p) if n==2 else [0]):
        z=(a,b);hz=(0,0)
        for co in reversed(hs):hz=add(mul(hz,z),(co%p,0))
        vals=[((-hz[0])%p,(-hz[1])%p),add(z,(c%p,0))]
        ns=[solutions(v) for v in vals];countB+=ns[0]
        if z==(0,0):
            for ci in [0,1]:
                for j in [0,1,2]:affine[ci][j]+=ns[ci]
        else:
            character=power(z,(q-1)//3)
            for j in [0,1,2]:
                if character==(pow(r,-j,p),0):
                    for ci in [0,1]:affine[ci][j]+=3*ns[ci]
    tb=q+1-countB
    trace=[[q-a for a in row] for row in affine]
    # Removing B leaves only the two nontrivial sigma eigenspaces.
    whole=[trace[0][j]-tb-trace[1][j] for j in [0,1,2]]
    assert sum(whole)==0
    a,b=whole[:2]
    assert (a-b)%3==(-a-2*b)%3==0
    return ((a-b)//3,(-a-2*b)//3),r

def kmul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]-a[1]*b[1])
def linear(rows,values,p):
    matrix=[[v%p for v in row]+[b%p] for row,b in zip(rows,values)]
    rank=0;pivots=[];width=len(rows[0])
    for col in range(width):
        pivot=next((i for i in range(rank,len(matrix)) if matrix[i][col]),None)
        if pivot is None:continue
        matrix[rank],matrix[pivot]=matrix[pivot],matrix[rank]
        inv=pow(matrix[rank][col],-1,p);matrix[rank]=[(v*inv)%p for v in matrix[rank]]
        for i in range(len(matrix)):
            if i!=rank:
                a=matrix[i][col];matrix[i]=[(x-a*y)%p for x,y in zip(matrix[i],matrix[rank])]
        pivots.append(col);rank+=1
    assert all(any(row[:-1]) or row[-1]==0 for row in matrix)
    assert rank==width
    answer=[0]*width
    for i,col in enumerate(pivots):answer[col]=matrix[i][-1]
    return answer

def solve(data):
    import sympy as s
    E=s.symbols('E');h=sum(s.Integer(c)*E**i for i,c in enumerate(data['curve_h']['num']))
    assert data['curve_h']['den']==[1]
    primes=sorted(map(int,s.factorint(abs(int(s.discriminant(h,E))))))
    assert primes==[2,3,5,7,11,29]
    basis=[-1]+primes;records=[];rows=[];rhs=[]
    for p in [13,19,31,37,61,67]:
        t1,r=table_row(data,p,1);t2,_=table_row(data,p,2);square=kmul(t1,t1)
        nums=[a-b for a,b in zip(square,t2)];assert all(x%(2*p)==0 for x in nums)
        chi=[x//(2*p) for x in nums];v=(chi[0]+chi[1]*r)%p
        logs={pow(1+r,j,p):j for j in range(6)};assert len(logs)==6
        rows.append([logs[pow(b%p,(p-1)//6,p)] for b in basis]);rhs.append(logs[v])
        records.append({'prime':p,'trace':t1,'trace_square':t2,'character':chi})
    # Modulo three the sign disappears; solve for all prime exponents.
    e3=linear([row[1:] for row in rows],rhs,3)
    i3=primes.index(3)+1
    # Normalize exponent of 3 to 0..2; -27 is already a sixth power in K.
    positions=[i for i in range(len(basis)) if i!=i3]
    e2=linear([[row[i] for i in positions] for row in rows],[b-row[i3]*e3[i3-1] for row,b in zip(rows,rhs)],2)
    exponents=[0]*len(basis);exponents[i3]=e3[i3-1]
    for j,i in enumerate(positions):
        if i==0:exponents[i]=e2[j]
        else:exponents[i]=next(k for k in range(6) if k%2==e2[j] and k%3==e3[i-1])
    assert all(sum(x*y for x,y in zip(row,exponents))%6==b for row,b in zip(rows,rhs))
    M=prod(p**e for p,e in zip(basis,exponents))
    # Return the inverse class, often smaller; this does not change the field.
    inv=[exponents[0]]+[(-e)%6 for e in exponents[1:]]
    if inv[i3]>=3:inv[i3]-=3;inv[0]^=1
    N=prod(p**e for p,e in zip(basis,inv))
    order=lcm(*(6//gcd(6,b) for b in rhs))
    return {'radicand':[min([M,N],key=abs),1],'degree':2*order},records
