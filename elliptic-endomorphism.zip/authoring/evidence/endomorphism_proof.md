# Geometric endomorphism algebra of the complementary surface

This proof is conditional only on the explicit gluing computation discussed in Section 1. Every later step is independent of the gluing-function implementation. The finite-field data in Section 6 were independently computed by exhaustive FLINT enumeration; the complete degree-eight characteristic polynomial at 43 was also checked by counts over all four extensions through degree four.

## 1. Geometric input required from the gluing calculation

Let

\[
C: W^2=-(E^3-551232)(E^6-553014E^3+816903549),\qquad J=\operatorname{Jac}(C).
\]

Let \(B_0:y^2=4(x^3-11)\), and let \(\alpha:C\to B_0\) be the already verified degree-18 covering. Let

\[
B_1:z^2=x^3+1104246x^2+305655916797x+450303377122368,
\qquad \beta(E,W)=(-E^3,W).
\]

The degree of \(\beta\) is three. The following facts must be proved by the separate exact gluing calculation:

1. \(\alpha^*:B_0\to J\) and \(\beta^*:B_1\to J\) are injective.
2. Their images meet in a cyclic group of order three.
3. Consequently their sum \(S\subset J\) has the induced polarization of type \((1,18)\).

The third consequence can also be checked directly on lattices. On the product the induced alternating forms have elementary divisors 18 and 3. Adjoining the common order-three point enlarges the product lattice by index three. In suitable symplectic bases the new generator is \((u+r)/3\), with pairings 6 against the partner of \(u\), and 1 against the partner of \(r\). The elementary divisors are therefore 1 and 18: their product is \(18\cdot3/3=18\), and the first is 1.

Let \(A=S^\perp\) be the complementary abelian surface inside the principally polarized \(J\). It has induced polarization type \((1,18)\), since complementary subvarieties in a principally polarized abelian variety have isomorphic polarization kernels, with opposite Weil pairings. Both \(S\) and \(A\) are defined over \(\mathbb Q\).

## 2. The Eisenstein action and its signature

Over \(\mathbb Q(\zeta)\), where \(\zeta^2+\zeta+1=0\), the curve automorphism

\[
\sigma(E,W)=(\zeta E,W)
\]

preserves the canonical principal polarization. Its eigenvalues on the basis

\[
\frac{dE}{W},\ \frac{E\,dE}{W},\ \frac{E^2dE}{W},\ \frac{E^3dE}{W}
\]

are \(\zeta,\zeta^2,1,\zeta\). The pullback from \(B_0\) is \(9(E^3-120582)dE/W\), of eigenvalue \(\zeta\), and the pullback from \(B_1\) is \(-3E^2dE/W\), of eigenvalue 1. Thus the two-dimensional space of holomorphic forms on \(A\) has eigenvalues \(\zeta,\zeta^2\). In particular \(K=\mathbb Q(\sqrt{-3})\) acts on \(A\) with signature \((1,1)\); \(1+\sigma+\sigma^2=0\) on \(A\).

## 3. The Hermitian determinant is minus 18

Put \(s=\sqrt{-3}\), \(O=\mathbb Z[\zeta]\), \(V=H_1(A,\mathbb Q)\), and \(\Lambda=H_1(A,\mathbb Z)\). The lattice is a torsion-free rank-two \(O\)-module. Since \(O\) is a principal ideal domain, it has an \(O\)-basis. In such a basis \(V=K^2\).

Let \(\psi\) denote the alternating form of the induced polarization. Its invariance under \(\sigma\) gives

\[
\psi(kv,w)=\psi(v,\bar k w),\qquad k\in K.
\]

There is a unique Hermitian form \(H(v,w)=\bar v^{\,t} M w\) such that

\[
\psi(v,w)=\operatorname{Tr}_{K/\mathbb Q}\bigl(H(v,w)/s\bigr).
\]

The integrality of \(\psi(v,kw)\) for every \(k\in O\), together with the codifferent \(O^\vee=s^{-1}O\), implies \(H(\Lambda,\Lambda)\subset O\). Thus \(M\) is Hermitian with entries in \(O\).

In the ordered integral basis \((e_1,\zeta e_1,e_2,\zeta e_2)\), direct expansion gives \(\operatorname{Pfaff}(\psi)=\det M\), up to orientation. Equivalently, \(\det(\psi)=(\det M)^2\). The polarization type gives \(|\det M|=1\cdot18=18\). The signature \((1,1)\) makes the determinant negative, so

\[
\det M=-18.
\]

This is a determinant calculation on the actual integral homology lattice. No assumption that the polarization is principal on \(A\) is being made.

## 4. An explicit rational Hodge endomorphism

Set \(J_0=\begin{pmatrix}0&1\\-1&0\end{pmatrix}\). Define a \(K\)-antilinear rational map on \(V\) by

\[
j(v)=J_0\bar M\,\bar v.
\]

Writing \(M=\begin{pmatrix}a&b\\\bar b&d\end{pmatrix}\), direct matrix multiplication proves

\[
j^2=-\det(M)\,I=18I,\qquad j\,s=-s\,j,
\]

and

\[
H(v,jv)=\bar v^{\,t}M J_0\bar M\bar v
=\det(M)\,\bar v^{\,t}J_0\bar v=0.
\]

To verify that \(j\) is a Hodge endomorphism, regard \(V\otimes\mathbb R\) as \(\mathbb C^2\) using the fixed complex embedding of \(K\). The abelian variety's complex structure \(I\) is \(K\)-linear and preserves \(H\). Its two complex eigenspaces for \(+i,-i\) are distinct lines, because the signature is \((1,1)\); they are orthogonal for \(H\) and individually nondegenerate. The identity \(H(v,jv)=0\) shows that \(j\) exchanges these two lines. Since \(j\) is complex-antilinear, this exchange is exactly the equality \(jI=Ij\).

Every rational map of homology commuting with the complex structure is an algebraic endomorphism up to isogeny: after multiplication by an integer it preserves the integral lattice and gives a holomorphic homomorphism of complex tori; homomorphisms of abelian varieties are algebraic. Such endomorphisms descend from \(\mathbb C\) to \(\overline{\mathbb Q}\). Therefore \(j\in\operatorname{End}^0_{\overline{\mathbb Q}}(A)\).

With \(i=s\) and \(j_1=j/3\), the relations become

\[
i^2=-3,\qquad j_1^2=2,\qquad ij_1=-j_1i.
\]

They embed the quaternion algebra \(D=(-3,2)_{\mathbb Q}\) in \(\operatorname{End}^0_{\overline{\mathbb Q}}(A)\). The algebra is ramified exactly at 2 and 3: its Hilbert symbols there are both \(-1\), while it is split at the real place and at all other primes. It is a division algebra of reduced discriminant 6. For an elementary nonsplitting check, a rational norm equation \(a^2+3b^2=2\) would give coprime integers \(A,B,C\) with \(A^2+3B^2=2C^2\); reduction modulo three and then division by three force all three integers divisible by three, a contradiction.

## 5. The only remaining possibility is an elliptic CM square

If \(A\) is geometrically simple, its endomorphism algebra is a division algebra acting faithfully on the four-dimensional rational space \(V\). Its rational dimension is therefore at most four. It contains the four-dimensional division algebra \(D\), so it equals \(D\).

If \(A\) is not geometrically simple, it is isogenous to a product of elliptic curves. Two nonisogenous elliptic factors have commutative endomorphism algebra and cannot contain \(D\). An isogenous square of a non-CM elliptic curve has endomorphism algebra \(M_2(\mathbb Q)\), which also cannot contain the four-dimensional division algebra \(D\). The only possibility left is

\[
A\sim E_F^2,\qquad \operatorname{End}^0(A)=M_2(F),
\]

for one imaginary quadratic CM field \(F\). Section 6 excludes this possibility using two independent good reductions.

## 6. Exact good-reduction certificate at 43 and 61

For a good prime \(p\), write \(N_C(n),N_0(n),N_1(n)\) for the point counts over \(\mathbb F_{p^n}\). Since \(J\sim B_0\times B_1\times A\), the residual traces are

\[
s_n=(p^n+1-N_C(n))-(p^n+1-N_0(n))-(p^n+1-N_1(n)).
\]

The surface characteristic polynomial is

\[
f_p(T)=T^4-s_1T^3+\frac{s_1^2-s_2}{2}T^2-p s_1T+p^2.
\]

The independently enumerated counts are:

| \(p\) | \(n\) | \(N_C(n)\) | \(N_0(n)\) | \(N_1(n)\) |
|---:|---:|---:|---:|---:|
|43|1|33|52|40|
|43|2|1953|1872|1920|
|61|1|61|76|52|
|61|2|3573|3648|3744|

The defining polynomial of \(C\) is squarefree modulo both primes, as checked by polynomial GCD; the elliptic discriminants are nonzero there. All relevant abelian varieties have good reduction.

Thus

\[
f_{43}=T^4-15T^3+118T^2-645T+1849,
\quad
f_{61}=T^4-5T^3-36T^2-305T+3721.
\]

The exact resultant identities are

\[
\operatorname{Res}_T(f_{43}(T),X-T^6)
=(X^2+59686X+6321363049)^2,
\]

\[
\operatorname{Res}_T(f_{61}(T),X-T^6)
=(X^2-170138X+51520374361)^2.
\]

Each inner quadratic has constant term \(p^6\), negative discriminant, and trace prime to \(p\). These are ordinary elliptic Weil polynomials. The discriminants have square classes \(-291\) and \(-219\), respectively. By the finite-field isogeny classification, over \(\mathbb F_{p^6}\) the residual surface is an ordinary elliptic square. Consequently

\[
\operatorname{End}^0_{\overline{\mathbb F}_{43}}(A_{43})
=M_2(\mathbb Q(\sqrt{-291})),\qquad
\operatorname{End}^0_{\overline{\mathbb F}_{61}}(A_{61})
=M_2(\mathbb Q(\sqrt{-219})).
\]

Geometric endomorphisms specialize injectively at good reduction. If \(\operatorname{End}^0(A)=M_2(F)\), its specialization into either displayed algebra is an injective map between eight-dimensional rational algebras, hence an isomorphism. Their centers would force \(F=\mathbb Q(\sqrt{-291})\) and \(F=\mathbb Q(\sqrt{-219})\) simultaneously. The fields differ, a contradiction.

Therefore \(A\) is geometrically simple and

\[
\operatorname{End}^0_{\overline{\mathbb Q}}(A)=(-3,2)_{\mathbb Q}.
\]

## 7. The full Jacobian

The elliptic curve \(B_0\) has CM field \(\mathbb Q(\sqrt{-3})\). The other quotient has

\[
j(B_1)=2640279346000/3087,
\]

which is not an algebraic integer; hence it has no complex multiplication. Thus these elliptic curves are geometrically nonisogenous. The geometrically simple surface \(A\) has no elliptic factor. Therefore all cross homomorphisms between the three isogeny factors vanish, and

\[
\operatorname{End}^0_{\overline{\mathbb Q}}(J)
\cong \mathbb Q(\sqrt{-3})\times\mathbb Q\times(-3,2)_{\mathbb Q}.
\]

The argument determines the rational geometric endomorphism algebra. It does not claim an integral endomorphism ring, its field of definition, or an explicit algebraic correspondence representing \(j\). Those require additional proofs, supplied in integral_order_proof.md and endomorphism_field_proof.md.

## 8. Endomorphisms defined over the rational numbers

At the good prime 13, the residual characteristic polynomial is

\[
f_{13}(T)=(T^2-5T+13)(T^2+5T+13).
\]

The two factors are distinct ordinary elliptic Weil polynomials, both with CM field \(K=\mathbb Q(\sqrt{-3})\). Thus over the base field, rather than its algebraic closure,

\[
\operatorname{End}^0_{\mathbb F_{13}}(A_{13})=K\times K.
\]

Every endomorphism defined over \(\mathbb Q\) specializes to an endomorphism defined over \(\mathbb F_{13}\). Hence \(R=\operatorname{End}^0_{\mathbb Q}(A)\) is a commutative subalgebra of \(D\), and is a field because \(D\) is a division algebra. It is either \(\mathbb Q\) or a quadratic field. In the quadratic case its projections into either factor of \(K\times K\) are unital embeddings, so \(R\cong K\) would be imaginary quadratic.

On the other hand complex conjugation acts nontrivially on \(D\), taking the known automorphism generator \(i=\sqrt{-3}\) to \(-i\). By the Skolem–Noether theorem this action is conjugation by an element \(u\in D^\times\) with \(ui=-iu\). Writing \(D=K\oplus K j_1\), the anticommutation forces \(u=a j_1\) for some \(a\in K^\times\). Thus

\[
u^2=2a\bar a>0.
\]

This positive rational number cannot be a rational square: otherwise \((u-r)(u+r)=0\) in the division algebra for some rational \(r\), forcing the noncentral \(u\) to be scalar. The fixed subalgebra of complex conjugation is the centralizer of \(u\), namely the real quadratic field \(\mathbb Q(u)\). Therefore \(R\), being fixed by complex conjugation, is contained in a real quadratic field. The imaginary quadratic possibility from reduction at 13 is impossible, and \(R=\mathbb Q\).

Both elliptic factors have rational endomorphism algebra \(\mathbb Q\) over \(\mathbb Q\). The factorization \(J\sim B_0\times B_1\times A\) is defined over \(\mathbb Q\), and there are no geometric cross homomorphisms. Consequently

\[
\operatorname{End}^0_{\mathbb Q}(J)\cong\mathbb Q\times\mathbb Q\times\mathbb Q.
\]
