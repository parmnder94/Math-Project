# Integral endomorphism orders and conductor quotients

The geometric decomposition has pairwise nonisogenous, multiplicity-one factors E0, B, and A. Their rational geometric endomorphism algebras are K, Q, and D=(-3,18), where K=Q(sqrt(-3)) and D has finite ramification {2,3}. The embedded elliptic curves intersect in the order-three subgroup identified by the gluing certificate. The induced polarizations on S and A have type (1,18). The curve automorphism sigma acts on S as (zeta,1) and supplies O=Z[zeta] action of signature (1,1) on A. The rational endomorphism algebra of J is Q^3.

From these data we prove

    End(A)=O+3O j1,  j1^2=2,  j1 a=bar(a)j1,

    End(J)={(a0,n,a+3b j1):
       a0,a,b in O, n in Z,
       a0 mod sqrt(-3)=n mod 3,
       a=a0 mod 18O}.

The unique containing maximal order is O x Z x (O+O j1). Its index over End(J) is 8748. The largest two-sided ideal contained in End(J) is

    C=18O x 3Z x (18O+9O j1),

and the additive quotient has invariant factors [3,3,18,18]. Over Q the maximal-order index is 54, the conductor is 18Z x 3Z x 18Z, and its quotient has invariant factors [18].

## 1. Hermitian lattice normalization and content

Let Lambda=H_1(A(C),Z). It is a torsion-free rank-two O-module, and hence free because O is a PID. Use the embedding of O supplied by sigma on A, and fix an O-basis. Every integral sigma-invariant alternating form has a unique expression

    E(x,y) = Tr_(K/Q)(bar(x)^t M y / lambda),

where M is an integral Hermitian matrix. This is precisely where the inverse different matters: the trace-dual of O is lambda^(-1)O. No factor of three or lambda is missing from the formula.

For the standard O-basis, the alternating form obtained from M=(1) is unimodular. Consequently det(E)=Norm(det(M))=(det(M))^2. The polarization type (1,18) gives |det(M)|=18. The signature (1,1) gives det(M)=-18. The alternating dual lattice is exactly

    Lambda# = M^(-1) O^2.

Indeed integrality of E(y,x) for every y in O^2 is equivalent, by the inverse-different computation, to Mx in O^2.

Write M=[[u,v],[bar(v),w]], with u,w rational integers. Its entry-content ideal is conjugation-stable. If its prime factorization contains both primes over a split rational prime, or a prime over an inert rational prime, a rational prime divides every entry. Then E is divisible by that rational prime, contradicting first elementary divisor one.

Only the ramified prime (lambda) requires a separate check. If lambda divides every entry, then 3 divides u and w. If v has lambda-adic valuation exactly one, v bar(v) has 3-adic valuation one while uw has valuation at least two; det(M) would have 3-adic valuation one, contrary to det(M)=-18. Otherwise v is divisible by lambda^2, hence by 3, and all entries of M are divisible by 3, again impossible. Therefore the entry-content is O.

Since O is a PID, this also proves

    Lambda#/Lambda ≅ coker(M) ≅ O/(18)

as O-modules. Its additive cardinality is 18^2, agreeing with the polarization kernel.

## 2. The full integral order on A

Put J0=[[0,1],[-1,0]] and define the anti-K-linear map

    j(x)=J0 bar(M) bar(x).

It preserves Lambda, satisfies ja=bar(a)j, and has j^2=-det(M)=18. It is a rational Hodge endomorphism. For completeness, if I is the real complex structure on K tensor R squared, signature (1,1) makes tr(I)=0 and polarization compatibility gives M I=-I* M. The identities I J0=-J0 I^t and bar(M)bar(I)=-I^t bar(M) then show Ij=jI.

The established equality End^0(A)=D means that every rational Hodge endomorphism has a unique expression a+bj, a,b in K. Suppose it preserves Lambda. Comparing its values on v and zeta v gives

    b(bar(zeta)-zeta) j(v) in Lambda.

The difference bar(zeta)-zeta is a unit times lambda. Since the entries of the matrix of j have content one, this forces lambda b in O. Integrality then also gives lambda a in O. Write a+bj=(a0+b0 j)/lambda with a0,b0 in O.

Modulo lambda, conjugation is trivial and the matrix B=J0 bar(M) is a nonzero rank-one nilpotent. Nonzero follows from content one, determinant zero follows from det(M)=-18, and trace zero follows from Hermitian symmetry. Integrality of (a0+b0j)/lambda therefore implies

    a0 I+b0 B=0 over F3.

A nonzero nilpotent rank-one matrix is not scalar, so I and B are linearly independent. Thus both a0 and b0 vanish modulo lambda. This excludes all possible denominators, proving the complete equality

    End(A)=O+O j=O+3O j1, j1=j/3.

There is no unsupported assumption here that an arbitrary endomorphism preserves the polarization: the argument directly tests preservation of the integral homology lattice.

The reduced-trace Gram determinant of the basis (1,zeta,j,zeta j) is -54^2. The reduced discriminant is therefore 54. For j1^2=2 the analogous determinant is -6^2, so O+O j1 is a maximal order in the quaternion algebra of discriminant 6, and its index over End(A) is 54/6=9.

### Uniqueness of the containing maximal order

This example has a unique maximal overorder, not merely maximal overorders of equal index. At every rational prime other than 3, End(A) is already maximal, because the above index is 9. At 3 the quaternion algebra is division, and a central division algebra over a nonarchimedean local field has a unique maximal order, its valuation ring. Thus every maximal overorder has the same localizations at every prime. Their intersection in D is the same global order, namely O+O j1.

A maximal order of K x Q x D contains the three central idempotents and consequently is the product of maximal orders in the three factors. Using the description proved in Sections 3 and 4, every maximal overorder of End(J) contains its three projected orders O, Z, and End(A). The quaternion argument therefore also gives uniqueness of the maximal product overorder relevant here.

## 3. Integral lifting: no missing endomorphisms

The lifting claim is correct because the embedded abelian subvarieties involved are pairwise nonisogenous isotypical factors. Every rational endomorphism preserves E0, B, S, and A. For an actual endomorphism of J, restriction to each preserved abelian subvariety is an actual morphism of abelian varieties, and hence an integral endomorphism. These restrictions provide a lift to S x A that commutes with the addition isogeny.

Likewise every endomorphism of S restricts integrally to its embedded E0 and B and therefore lifts to E0 x B. This would not be automatic for arbitrary chosen factors in a repeated isogeny class, but there is no repeated isogeny class here. Thus the proposed restriction argument does not lose endomorphisms with denominators introduced by the isogeny.

The kernel of E0 x B -> S is the diagonal cyclic group generated by the common order-three class. On the E0 side it is O/(lambda), and on the B side multiplication acts modulo 3. Preservation of this graph is exactly

    a0 mod lambda = n mod 3.

It follows that End(S) is exactly the claimed congruence order, of index three in O x Z.

## 4. Discriminant-module preservation and final gluing

Preservation of a polarization discriminant group by arbitrary endomorphisms of a nonprincipally polarized abelian variety is not automatic. It is true here, and the following explicit arguments should be retained.

On A, scalar a in O preserves M^(-1)O^2 and acts by a modulo 18 on the quotient. Moreover,

    j(M^(-1)v)=J0 bar(v) in O^2.

Thus j sends the entire dual lattice into the original lattice and acts as zero on the discriminant module. Every element of End(A)=O+O j therefore preserves the dual lattice, with induced action equal to its scalar coefficient modulo 18.

The principal polarization on J identifies the discriminant groups of S and A by an anti-isometry phi. The curve automorphism sigma preserves the principal polarization and both subvarieties, so phi is sigma-equivariant. The relation 1+sigma+sigma^2 vanishes on A and hence on its discriminant group; it therefore also vanishes on the discriminant group of S. On S this endomorphism is (0,3).

For a0=r+s zeta and (a0,n) in End(S), the congruence condition says n-r-s=3k for an integer k. Hence

    (a0,n)=r+s sigma+k(0,3).

All these operators preserve the dual lattice: sigma does because it preserves the polarization, and (0,3) is the polynomial 1+sigma+sigma^2. This proves preservation for the complete End(S), rather than assuming it. Its discriminant action is scalar a0 under the O-module structure induced by sigma.

Since phi is O-linear, descent through the graph of phi is now equivalent to equality of scalar residues:

    a=a0 modulo 18O.

The particular O-linear anti-isometry does not affect this condition, because scalar multiplication commutes with every O-linear isomorphism. An arbitrary unit used to identify the cyclic modules likewise cancels. Thus no unproved lifting or choice-independence assumption remains in the fiber-product description.

The first congruence has index 3. The second is equality in O/(18), whose cardinality is 324. This gives 972 in O x Z x End(A), and multiplication by the maximal-order index 9 gives 8748. Intersecting with the established rational algebra Q^3 gives integer triples m,n,c with n=m modulo 3 and c=m modulo 18, of index 54 in Z^3.

## 5. The conductor: maximality, not just inclusion

Write the maximal product order as

    Mmax=O x Z x Qmax, Qmax=O+O j1.

Any two-sided ideal of a product ring decomposes under its central idempotents. Therefore its largest ideal contained in End(J) can be found independently in the three coordinates.

* In the first coordinate, (a0,0,0) lies in End(J) precisely when a0 is in 18O. The condition modulo lambda is then automatic.
* In the second coordinate, (0,n,0) lies in End(J) precisely when n is in 3Z.
* In the quaternion coordinate, the pure-coordinate intersection with End(J) is the lattice L=18O+3O j1. Suppose an element a+cj1 belongs to a two-sided Qmax-ideal contained in L. Membership already forces a in 18O and c in 3O. Multiplication by j1 gives scalar coefficient 2 bar(c), which must lie in 18O. Consequently c lies in 9O. Thus every such ideal is contained in 18O+9O j1.

The latter lattice is itself a two-sided ideal: multiplication by O preserves it, and multiplication by j1 sends its scalar coefficient into 18O because 2 times 9O is 18O, and its j1 coefficient into 9O because 18O is contained in 9O. The same calculation holds on the other side. This proves maximality of the claimed conductor, not merely its containment.

## 6. Additive conductor quotients by explicit residues

Modulo C, the scalar residue a0 in O/(18) determines both the n residue in Z/3 and the A-scalar residue in O/(18). The j1 coefficient is 3b modulo 9O, so b supplies one independent residue in O/(3). Therefore there is an explicit additive isomorphism

    End(J)/C -> O/(18) direct-sum O/(3),
    [(a0,n,a+3b j1)] -> (a0 mod 18, b mod 3).

It is well-defined, injective, and surjective directly from the congruences. Since O is free of rank two over Z, the invariant factors are [3,3,18,18]. Its cardinality is 18^2*3^2=2916. No matrix determinant is needed for this argument.

Over Q, the conductor is 18Z x 3Z x 18Z. The residue m modulo 18 determines the other two residues, giving an additive (indeed ring) isomorphism of the rational conductor quotient with Z/18. The invariant factors are [18].

## 7. Independent finite-group computation

`independent_integral.py` imports neither the reference solver nor a verifier and uses no matrix determinant or Smith normal form. It derives the conductor coefficient from closure under multiplication by j1, then enumerates the p-primary residues in the conductor quotient. The ambient local coordinates are the two coordinates of a0, n, the two scalar quaternion coordinates, and the two j1 coordinates. The gluing congruences determine all but a0 and the j1 coefficient residues.

At p=2 the geometric ambient conductor quotient has order 16 and the endomorphism-order quotient has order 4, contributing index 4. Its invariant factors are [2,2]. At p=3 those orders are 1594323 and 729, contributing index 2187. Its invariant factors are [3,3,9,9]. These combine to index 8748 and invariant factors [3,3,18,18]. The rational local indices are 2 and 27, and the rational quotient factors [2] and [9] combine to [18].

The program recovers the cyclic factors from exact annihilator counts: log_p |G[p^k]|-log_p |G[p^(k-1)]| is the number of cyclic summands with exponent at least k. Thus the independent check uses explicit finite-group arithmetic, rather than reproducing the reference lattice determinant and Smith calculation. `independent.py` passes its computed polarization, intersection order, and quaternion ramification data to this module and places its result in `integral_structure`.
