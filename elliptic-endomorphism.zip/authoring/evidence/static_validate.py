#!/usr/bin/env python3
"""Check visible package requirements, without claiming private platform gates."""
import argparse
import hashlib
import json
import re
import stat
import tomllib
from pathlib import Path


def validate(root):
    checks = []
    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        checks.append(name)
    allowed = {'instruction.md','task.toml','README.md','environment','solution','tests','authoring'}
    check('only allowed root entries', set(p.name for p in root.iterdir()) <= allowed)
    required = ['instruction.md','task.toml','README.md','environment/Dockerfile','solution/solve.sh','tests/test.sh','tests/Dockerfile']
    check('all required files', all((root/p).is_file() for p in required))
    t = tomllib.loads((root/'task.toml').read_text())
    check('schema 1.4', t['schema_version']=='1.4')
    check('declared artifact', t['artifacts']==['/app/output/decomposition.json'])
    check('namespaced at-most-three-word task slug', re.fullmatch(r'[a-z0-9]+/[a-z0-9]+(?:-[a-z0-9]+){0,2}',t['task']['name']) is not None)
    m = t['metadata']
    keys = ['author_name','author_email','author_organization','author_profile','conflicts_of_interest','relevant_experience','domain','field','subfield','category','subcategory','tags','expert_time_estimate_hours','difficulty_explanation','solution_explanation','verification_explanation']
    check('all required metadata present', all(m.get(k) for k in keys))
    check('author fields agree', t['task']['authors']==[{'name':m['author_name'],'email':m['author_email']}])
    check('tags agree', t['task']['keywords']==m['tags'] and len(m['tags'])>0)
    check('declared field mapping', m['domain']=='mathematical-sciences' and m['field']=='applied-mathematics' and m['category']=='Science' and m['subcategory']=='Applied Mathematics & Scientific Computing')
    check('synthetic input disclosure', 'synthetic' in m['difficulty_explanation'].lower())
    check('separate offline verifier', t['verifier']['environment_mode']=='separate' and t['verifier']['environment']['network_mode']=='no-network')
    check('public agent network', t['environment']['network_mode']=='public')
    check('legal timeouts', 3600<=t['agent']['timeout_sec']<=28800 and 0<t['verifier']['timeout_sec']<=28800)
    e=t['environment']
    check('legal resources', e['cpus'] in [1,2,4,8,16] and e['memory_mb'] in [1024,2048,4096,8192,16384] and 0<e['storage_mb']<=40960 and e['gpus']==0)
    check('no deprecated network field', 'allow_internet' not in (root/'task.toml').read_text())
    instruction=(root/'instruction.md').read_text()
    check('instruction uses prose without headings', re.search(r'^\s{0,3}#{1,6}(?:\s|$)',instruction,re.M) is None)
    check('instruction has no decorative bold labels', '**' not in instruction)
    check('instruction uses dollar math delimiters', all(token not in instruction for token in [chr(92)+'(',chr(92)+')',chr(92)+'[',chr(92)+']']))
    suffix=f"You have {int(t['agent']['timeout_sec'])} seconds to complete this task. Do not cheat by using online solutions or hints specific to this task."
    check('exact terminal instruction sentence', instruction.endswith('\n\n'+suffix+'\n') or instruction.endswith('\n\n'+suffix))
    check('artifact named in instruction and public encoding', all(t['artifacts'][0] in (root/p).read_text() for p in ['instruction.md','environment/data/README.md']))
    readme=(root/'README.md').read_text()
    check('required README headings', all('\n## '+h+'\n' in readme for h in ['Difficulty','Reference solution','Verification']))
    for directory in ['environment','tests']:
        docker=(root/directory/'Dockerfile').read_text()
        check(directory+' has no FROM platform override', re.search(r'^FROM\s+--platform',docker,re.M|re.I) is None)
        check(directory+' uses offline hash-verified wheel installation', all(s in docker for s in ['--no-index','--require-hashes','--find-links=']))
        lines=(root/directory/'requirements.txt').read_text().splitlines()
        dependencies=[line for line in lines if line.strip() and not line.lstrip().startswith(('#','--'))]
        check(directory+' dependencies exactly pinned', all(re.match(r'^[A-Za-z0-9_.-]+==[0-9][^ ]*\s+--hash=sha256:[a-f0-9]{64}$',line) for line in dependencies))
        check(directory+' makes artifact parent', 'RUN mkdir -p /app/output' in docker)
    vr=(root/'tests/requirements.txt').read_text()
    check('mandated pytest pins', 'pytest==8.4.1 ' in vr and 'pytest-json-ctrf==0.3.5 ' in vr)
    check('tests baked into verifier', 'COPY . /tests/' in (root/'tests/Dockerfile').read_text())
    ed=(root/'environment/Dockerfile').read_text()
    check('public image copies only wheels, pins and data', all(line.split()[1] in ['wheels','requirements.txt','data'] for line in ed.splitlines() if line.startswith('COPY ')))
    ts=(root/'tests/test.sh').read_text()
    check('no verifier runtime package installation', re.search(r'\b(?:pip|uv|apt-get)\s+install\b',ts) is None)
    check('reward initialized before pytest', ts.index("printf '0")<ts.index('pytest --ctrf'))
    check('CTRF requested', 'pytest --ctrf /logs/verifier/ctrf.json' in ts)
    check('entrypoint scripts executable', all((root/p).stat().st_mode & stat.S_IXUSR for p in ['solution/solve.sh','tests/test.sh']))
    public_files=sorted(p.relative_to(root).as_posix() for p in (root/'environment/data').rglob('*') if p.is_file())
    check('public data allowlist', public_files==['environment/data/README.md','environment/data/jacobian.json'])
    for directory in ['solution','tests','environment/data']:
        for p in (root/directory).rglob('*'):
            if p.is_file() and p.suffix in ['.py','.md','.json','.sh','.txt']:
                value=p.read_bytes()
                check('no unexpected control characters: '+str(p.relative_to(root)),not any(c<32 and c not in [9,10,13] for c in value))
    hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in required}
    return {'scope':'Visible mechanical requirements only; not the unpublished rubric, author eligibility, global similarity, AI screening, official quality or difficulty gates.','checks':checks,'all_passed':True,'file_sha256':hashes}


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    result=validate(args.root)
    output=args.output or args.root/'authoring/evidence/static_results.json'
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'checks':len(result['checks']),'all_passed':True,'output':str(output)}))
