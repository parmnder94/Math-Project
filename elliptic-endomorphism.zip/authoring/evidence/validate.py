import copy
import json
import sys
import tempfile
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
import check_submission as checker

original=json.loads((ROOT/'authoring/evidence/reference-output.json').read_text())
cases=[]
def add(name,expected,mutator):
    value=copy.deepcopy(original)
    mutator(value)
    cases.append((name,expected,json.dumps(value).encode()))
def set_path(value,path,new):
    for key in path[:-1]:value=value[key]
    value[path[-1]]=new
def change(name,path,new):add(name,False,lambda v:set_path(v,path,new))

add('reference',True,lambda v:None)
def reorder(v):
    for key in ('geometric_factors','rational_factors','reduction_witnesses','local_data'):v[key].reverse()
    v['geometric_factors'][0]['algebra']['quaternion_ramification']['finite'].reverse()
add('unordered_factors_primes_and_records',True,reorder)
def graphs(v):
    for data in v['local_data']:
        n=len(data['vertices']);perm=list(reversed(range(n)))
        data['vertices']=[data['vertices'][i] for i in perm]
        inverse={old:new for new,old in enumerate(perm)}
        for edge in data['edges']:
            edge['ends']=[inverse[i] for i in reversed(edge['ends'])]
            edge['differential_orders'].reverse()
        data['edges'].reverse()
add('graph_relabel_and_edge_reversal',True,graphs)
def mul_poly(a,b):
    out=[0]*(len(a)+len(b)-1) if a else []
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return out
def fractions(v):
    for rf in v['gluing']['function']:
        for key in ('num','den'):rf[key]=[-7*x for x in mul_poly(rf[key],[1,2,1])]+[0,0]
    for key in ('point','tangent'):
        for scalar in v['gluing'][key]:
            for rat in scalar:rat[:]=[-3*rat[0],-3*rat[1]]
    for local in v['local_data']:
        local['L_polynomial'] += [0,0]
        for vertex in local['vertices']:vertex['vertical_order']=[-5*x for x in vertex['vertical_order']]
        for edge in local['edges']:edge['thickness']=[-5*x for x in edge['thickness']]
add('equivalent_rf_scalar_and_graph_fractions',True,fractions)
def alternate(v):
    v['reduction_witnesses']=[{'prime':p,'counts':[list(row) for row in zip(checker.point_counts(p,1),checker.point_counts(p,2))]} for p in (43,61)]
add('alternate_valid_primes_43_61',True,alternate)
def boundary(v):
    rf=v['gluing']['function'][1]
    rf['num']=[];rf['den']=[(1<<2048)-1]
add('largest_allowed_integer_in_zero_rf',True,boundary)
change('wrong_intersection',['intersection_order'],1)
change('wrong_polarization',['polarization_A'],[3,6])
change('wrong_geometric_multiplicity',['geometric_factors',0,'multiplicity'],2)
change('wrong_rational_quaternion',['rational_factors',2,'algebra','quaternion_ramification'],{'finite':[2,3],'infinity':False})
change('wrong_cube',['gluing','function',0,'num',0],0)
change('wrong_point',['gluing','point',0,0,0],-553706)
change('wrong_tangent',['gluing','tangent',0,1,0],224)
change('empty_denominator',['gluing','function',1,'den'],[])
change('zero_denominator',['gluing','function',1,'den'],[0,0])
change('float_coefficient',['gluing','function',1,'num'],[0.0])
change('boolean_coefficient',['gluing','function',1,'num'],[False])
change('string_coefficient',['gluing','function',1,'num'],['0'])
change('too_many_coefficients',['gluing','function',1,'num'],[0]*130)
change('too_large_integer',['gluing','function',1,'den'],[1<<2048])
change('zero_scalar_denominator',['gluing','point',0,0],[1,0])
change('bad_prime',['reduction_witnesses',0,'prime'],7)
change('large_prime',['reduction_witnesses',0,'prime'],(1<<2048)-1)
change('wrong_count',['reduction_witnesses',0,'counts',0,0],22)
change('count_float',['reduction_witnesses',0,'counts',0,0],21.0)
def repeat(v):v['reduction_witnesses'][1]=copy.deepcopy(v['reduction_witnesses'][0])
add('repeated_prime',False,repeat)
def same_field(v):
    v['reduction_witnesses'][1]={'prime':19,'counts':[list(row) for row in zip(checker.point_counts(19,1),checker.point_counts(19,2))]}
add('same_geometric_cm_field',False,same_field)
change('wrong_L',['local_data',1,'L_polynomial',1],1)
change('wrong_conductor',['local_data',2,'conductor'],2)
change('wrong_swan',['local_data',2,'swan'],1)
change('marked_extension_instead_of_stable',['local_data',2,'stable_extension_e'],6)
change('wrong_vertical_order',['local_data',1,'vertices',1,'vertical_order'],[0,1])
change('wrong_thickness',['local_data',2,'edges',0,'thickness'],[1,1])
change('wrong_branch_differential_order',['local_data',2,'edges',0,'differential_orders'],[0,-2])
change('dangling_vertex',['local_data',2,'edges',0,'ends'],[0,2])
change('wrong_vertex_genus',['local_data',2,'vertices',1,'genus'],1)
change('boolean_conductor',['local_data',1,'conductor'],False)
change('infinity_integer_not_bool',['geometric_factors',2,'algebra','quaternion_ramification','infinity'],0)
add('extra_top_key',False,lambda v:v.update(extra=1))
add('extra_rf_key',False,lambda v:v['gluing']['function'][0].update(extra=1))
raw=json.dumps(original).encode()
cases.extend([
 ('duplicate_json_key',False,raw.replace(b'"intersection_order": 3',b'"intersection_order": 3, "intersection_order": 3')),
 ('invalid_utf8',False,b'\xff'+raw),
 ('over_byte_limit',False,raw+b' '*(checker.MAX_BYTES+1-len(raw))),
 ('nonfinite',False,raw.replace(b'"intersection_order": 3',b'"intersection_order": NaN')),
])
def negative_map(v):
    q=v['elliptic_map']['y_multiplier'];q['num']=[-a for a in q['num']]
    for scalar in [v['gluing']['point'][1]]+v['gluing']['tangent']:
        for rat in scalar:rat[0]*=-1
    for i in (0,2):v['gluing']['function'][i]['num']=[-a for a in v['gluing']['function'][i]['num']]
add('negative_minimal_map_with_compatible_gluing',True,negative_map)
def equivalent_maps(v):
    for q in [v['elliptic_map']['x'],v['elliptic_map']['y_multiplier']]:
        for k in ('num','den'):q[k]=mul_poly(q[k],[-2,-2])+[0]
add('map_common_factors_and_scaling',True,equivalent_maps)
for label,rat in [('inverse',[1,-1203587]),('fifth_power',[-1203587**5,1]),('K_sixth_power',[1203587*27,1]),('Q_sixth_power',[-1203587*64,1]),('rational_sixth_power',[-1203587,729])]:
    add('endomorphism_field_'+label,True,lambda v,rat=rat:set_path(v,['endomorphism_field','radicand'],rat))
change('wrong_map_degree',['elliptic_map','degree'],36)
change('wrong_map_x',['elliptic_map','x','num',0],0)
change('wrong_map_ordinate',['elliptic_map','y_multiplier','num',0],0)
change('constant_map',['elliptic_map'],{'x':{'num':[1],'den':[1]},'y_multiplier':{'num':[],'den':[1]},'degree':18})
change('wrong_endomorphism_field',['endomorphism_field','radicand'],[-1203588,1])
change('zero_endomorphism_field',['endomorphism_field','radicand'],[0,1])
change('wrong_endomorphism_field_degree',['endomorphism_field','degree'],6)
change('endomorphism_field_boolean_degree',['endomorphism_field','degree'],True)
change('wild3_wrong_swan',['local_data',0,'swan'],0)
change('wild3_wrong_conductor',['local_data',0,'conductor'],8)
change('wild3_root_split_extension_instead_of_stable',['local_data',0,'stable_extension_e'],6)
change('wild3_wrong_local_polynomial',['local_data',0,'L_polynomial'],[1,0,3])
change('wild3_wrong_vertical_order',['local_data',0,'vertices',1,'vertical_order'],[1,1])
change('wild3_wrong_node_length',['local_data',0,'edges',3,'thickness'],[1,6])
change('wild3_wrong_differential_order',['local_data',0,'edges',1,'differential_orders'],[-2,0])

change('product_order_instead_of_J_order',['integral_structure','geometric_index'],9)
change('maximal_surface_order_assumption',['integral_structure','geometric_index'],972)
change('wrong_rational_order_index',['integral_structure','rational_index'],1)
change('wrong_geometric_conductor_quotient',['integral_structure','geometric_conductor_quotient'],[3,3,9,9])
change('wrong_rational_conductor_quotient',['integral_structure','rational_conductor_quotient'],[3,6])
change('boolean_order_index',['integral_structure','geometric_index'],True)
change('trivial_factors_in_conductor_quotient',['integral_structure','rational_conductor_quotient'],[1,18])
add('extra_integral_structure_key',False,lambda v:v['integral_structure'].update(extra=1))

started=time.monotonic();results=[]
with tempfile.TemporaryDirectory(dir='/tmp') as directory:
    for name,expected,raw in cases:
        path=Path(directory)/'submission.json';path.write_bytes(raw)
        try:checker.verify_path(path);accepted=True;message=''
        except checker.VerificationError as exc:accepted=False;message=str(exc)
        assert accepted==expected,(name,expected,accepted,message)
        results.append({'name':name,'accepted':accepted,'expected':expected,'reason':message})
report={'cases':len(results),'total':len(results),'accepted':sum(r['accepted'] for r in results),'rejected':sum(not r['accepted'] for r in results),'seconds':time.monotonic()-started,'results':results}
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'authoring/evidence/validation_results.json')
args=parser.parse_args()
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
