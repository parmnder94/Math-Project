# Independent local arithmetic calculation

Put $a=551232$, $b=553014$, $c=816903549$, and $r=120582$. The
curve is $W^2=-(E^3-a)(E^6-bE^3+c)$ and the specified differential is
$\omega=9(E^3-r)dE/W$. The identity for the differential must additionally
be checked from the supplied map, as $X'(E)/Y(E)=9(E^3-r)$; the calculations
here do not use the differential-operator construction.

All valuations below satisfy $v_p(p)=1$. Equations of components are over
the algebraic closure of the residue field unless descent is mentioned.
The stable models are unmarked. `reduction.py` checks the polynomial
identities, separability and small finite-field counts independently of
the global solution and verifier. Its output includes more audit details
than the submission requires. `local_solver.py` selects precisely the
fields in the current instruction and checks graph representations up to
vertex relabeling, edge reversal and rational-number equivalence.

## At five

The three roots of $E^3=a$ are unramified units: modulo five their
polynomial has one linear and one irreducible quadratic factor. Near any
one of these roots use

$$z=(E^3-a)/25,\qquad v=W/125.$$

This is a legitimate local coordinate change since $3E^2$ is a unit.
The exact identities

$$2a-b=25\cdot21978,\qquad
 a^2-ab+c=625\cdot(-264627)$$

give

$$v^2=-z(z^2+21978z-264627).$$

Its reduction is the smooth elliptic curve

$$T:\quad v^2=-z(z^2+3z+3)=1-(z+1)^3.$$

Thus the nine finite branch points form exactly three clusters of size
three and depth two. Each cluster has pairwise distinct residues in its
$z$ coordinate, so there are no deeper subclusters. Away from these
clusters put $q=W/(E^3-a)$. The central component is the smooth elliptic
curve

$$B:\quad q^2=2-E^3.$$

There is one tail $T$ for each residue root of $E^3=2$. It attaches at
its unique infinity point to $(E,q)=(\bar a_i,0)$ on $B$. The graph is a
three-edge tree with four genus-one vertices. All components are stable.
Near a tail infinity, $z$ has a double pole and $v$ a triple pole; since
$q=5v/z$, the product of a parameter at that infinity and a central
parameter is five times a unit. Every node therefore has thickness one,
not two. These smooth charts and nodal overlaps give stable reduction
over an unramified extension, and the minimal ramification index is one.

The central reduction of $\omega$ is $4dE/q$, so its vertical valuation
is zero and its differential order at every node is zero. Since
$a-r=25\cdot17226$, on a tail

$$\omega=\frac{15}{E^2}(z+17226)\frac{dz}{v}.$$

Its vertical valuation is one and, after division by five, its leading
form is $3\bar a_i^{-2}(z+1)dz/v$. It has a pole of order two at the
node and two simple zeros, at $(z,v)=(-1,1),(-1,-1)$. These account for
all six generic ramification points; no marked-node refinement is used.

The stable special fiber is of compact type. Its Jacobian is a product
of its four elliptic Jacobians, and inertia acts trivially. This proves
good reduction of the Jacobian even though the curve itself has several
components. Hence the Artin and Swan conductor exponents are both zero.

The central elliptic curve and the common tail equation each have six
points over $\mathbb F_5$, hence trace zero and Frobenius polynomial
$1+5t^2$. Frobenius fixes one tail and exchanges the other two. The
equation and coordinate $z$ of the tails do not depend on the chosen
cube root, so this exchange has no additional twist. On a two-tail
orbit the square of Frobenius is the square of the ordinary elliptic
Frobenius, whose trace is $0^2-2\cdot5=-10$; its contribution is
$1+10t^2+25t^4$. Therefore

$$L_5(t)=(1+5t^2)^4.$$

## At seven

The first cubic has three distinct nonzero residue roots. The remaining
six roots form a cluster of depth one half. Take $\pi^2=7$ and set

$$E=\pi u,\qquad W=\pi^3v.$$

Since $v_7(b)=2$, $v_7(c)=3$, $a\equiv3$, and $c/343\equiv5$,
the tail equation is the smooth genus-two curve

$$T:\quad v^2=3u^6+1.$$

The sextic is separable and has nonzero roots, proving there is no
further subcluster. On the central chart $q=W/E^3$, the component is

$$B:\quad q^2=3-E^3,$$

a smooth elliptic curve. The two tail points at infinity are
$v/u^3=\pm\sqrt3$. They attach respectively to the two central points
$(E,q)=(0,\pm\sqrt3)$. The graph has two vertices of genera one and two
and two parallel edges, hence first Betti number one. With tail
parameter $t=1/u$, the relation $Et=\pi$ proves each node has thickness
one half. Every component is stable.

The nontrivial ramified automorphism sends $\pi$ to $-\pi$. It fixes the
central component and acts on the tail by

$$\sigma(u,v)=(-u,-v).$$

It fixes each of the two infinity points, because $v/u^3$ is invariant.
This action is nontrivial on tail cohomology, so stable reduction cannot
already occur over an unramified extension. The exhibited quadratic
extension suffices, proving the minimal stable ramification index is
exactly two. The extension is tame; the Swan conductor is zero.

On the central component the leading differential is $2dE/q$. On the
tail, using $r=7\cdot17226$,

$$\omega=9(\pi u^3-17226)\frac{du}{v},$$

whose leading differential is $2du/v$. Both vertical valuations are
zero. The central form is nonzero at both nodes and has differential
order zero there. The tail form has order one at each infinity, as
$u$ has a simple pole and $v$ a triple pole. Thus each edge carries
branch orders $(0,1)$.

There is no rule requiring these two orders to add to $-2$ in this
unmarked model: the generic zeros of the differential specialize into
the nodes. In fact $E^3=r$ has valuation $v_7(E)=1/3$, within each node
annulus of length one half. Three zeros lie on each annulus, at distance
one third from the central component. Marking and separating these
points would require a further extension and refinement; that is not
the invariant requested in the instruction.

To compute inertia and Frobenius, the invariant quotient of the tail
under $\sigma$ is exhibited by

$$X=u^{-2},\qquad Y=v/u^3,\qquad Y^2=X^3+3.$$

It has genus one, so the invariant tail cohomology has dimension two
and the negative inertia eigenspace also has dimension two. The
complementary elliptic quotient, by $(u,v)\mapsto(-u,v)$, is
$v^2=3z^3+1$, with $z=u^2$. These two quotient pullbacks split the
four-dimensional tail cohomology; the assertions can also be read off
from the signs of $du/v$ and $u\,du/v$.

The central curve becomes $Y^2=X^3+3$ under $X=-E$, $Y=q$. It and the
invariant tail quotient each have thirteen points over $\mathbb F_7$,
hence trace $-5$ and polynomial $1+5t+7t^2$. For audit purposes the
other quotient has nine points and trace $-1$.

The two nodes are conjugate over $\mathbb F_{49}$, since three is a
nonsquare modulo seven. Frobenius fixes the vertices and exchanges the
parallel edges. Its action on graph cohomology is therefore $-1$, giving
the nonsplit toric factor $1+t$.

The usual cohomology filtration of a nodal semistable curve consists
of graph cohomology (dimension one), the component cohomologies
(dimensions two and four), and the dual graph piece (dimension one).
The unipotent monodromy has rank one between the two graph pieces. Of
the component cohomology only the two-dimensional negative tail space
fails to be invariant under finite inertia. Consequently the full
inertia-invariant space has dimension $1+2+2=5$, not six or seven.
The tame Artin conductor is $8-5=3$, and

$$L_7(t)=(1+t)(1+5t+7t^2)^2
=1+11t+49t^2+109t^3+119t^4+49t^5.$$

## Specification review

The current instruction defines the Frobenius trace convention,
normalization of valuations, unmarked minimal stable extension, branch
orders of the leading differential, and representation invariances
correctly. In particular it avoids confusing the curve's bad reduction
with the Jacobian's conductor at five, or confusing the extension needed
to separate differential zeros with the unmarked stable extension at
seven. Component equations and coordinates are proof data rather than
required answer keys, so arbitrary equivalent graph labels remain fair.
