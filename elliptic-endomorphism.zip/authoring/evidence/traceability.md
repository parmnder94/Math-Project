# Mathematical contract and verification

| Requirement | Constructive route | Independent route / proof | Verifier gate |
|---|---|---|---|
| Minimum pointed elliptic map | Stationary-density recursion and Hermite interpolation | Rational pencil, successive divisor reduction; minimum_map_proof.md and primitive_cover_proof.md | Exact target identity, infinity pole, degree |
| Full elliptic intersection | Flex division polynomial and trace cubic | Divisor-interpolation nullspace; automorphism bounds intersection | Flex tangent and four-basis function cube identity |
| Induced polarizations | Finite alternating module quotient | Integral overlattice elementary-divisor argument | Both polarization types |
| Complete geometric algebra | Hermitian homology and two ordinary reductions | Explicit rational Hodge operator; distinct specialization centers | Factor classification and fresh point-count witnesses |
| Rational algebra | Complex conjugation and good reduction | Real fixed algebra versus imaginary specialization at thirteen | Rational factors; recomputed descent polynomial |
| Integral orders and conductors | Integral Hermitian lattice, gluing congruences and Smith forms | Separate local-primary arithmetic; integral_order_proof.md | Both order indices and additive conductor quotient invariant factors |
| Minimum endomorphism field | Exhaustive finite Kummer class group and twisted FLINT counts | Integer-pair twisted counts and modular linear reconstruction | Exact field-class equivalence via sixth roots |
| Local factors and conductors | Explicit stable charts and inertia | Separate symbolic chart calculations; cubic discriminant for Swan part | Exact local polynomials, Artin/Swan values, extension indices |
| Stable graphs and differential | Cluster charts and normalized leading forms | Independent depths, differential divisors and weighted graph construction | Graph isomorphism, genus, thickness and branch orders |
| Serialization | One instruction file | Malformed and equivalent-encoding controls | Strict bounded inert JSON parser |

The public image contains only the task input, mathematical libraries and their dependency pins. Reference, independent and verifier implementations are separate. Acceptance is invariant under both minimum-map signs, equivalent fractions, permitted field presentations, factor ordering and graph labeling.

Private platform quality, author eligibility, similarity screening and a particular external model’s performance are not established by these mathematical checks.
