#!/usr/bin/env python3
"""Independent divisor interpolation and finite extension-field enumeration.

Imports neither the reference solver nor the verifier. The gluing function is
found from its divisor by a small rational nullspace, without a trace cubic.
"""
import argparse,json,itertools,time
from pathlib import Path
import sympy as S
from flint import fq_default_ctx
E,z,u=S.symbols('E z u')

def decode(rf,v):
    return sum(S.Integer(c)*v**i for i,c in enumerate(rf['num']))/sum(S.Integer(c)*v**i for i,c in enumerate(rf['den']))
def encode(rf):
    n,d=S.fraction(S.cancel(rf));np,dp=S.Poly(n,E),S.Poly(d,E)
    cs=np.all_coeffs()+dp.all_coeffs();scale=S.ilcm(*[c.q for c in cs])
    return {'num':[int(scale*np.nth(i)) for i in range(max(0,np.degree()+1))], 'den':[int(scale*dp.nth(i)) for i in range(dp.degree()+1)]}
def rat(x):return [int(S.numer(x)),int(S.denom(x))]
def k(a=0,b=0):return [rat(a),rat(b)]
def to_z(poly):
    p=S.Poly(poly,E)
    assert all(i[0]%3==0 for i,c in p.terms())
    return sum(c*z**(i[0]//3) for i,c in p.terms())
def gluing(data):
    h=S.cancel(decode(data['curve_h'],E));X=S.cancel(decode(data['alpha_x'],E));Y=S.cancel(decode(data['alpha_y_multiplier'],E))
    hz=to_z(h);yn,yd=map(to_z,S.fraction(Y));xn,xd=S.fraction(X);xnz=to_z(xn)
    cubic=-hz.subs(z,-u);a2,a4,a6=[S.expand(cubic).coeff(u,i) for i in [2,1,0]]
    psi3=3*u**4+4*a2*u**3+6*a4*u*u+12*a6*u+4*a2*a6-a4*a4
    # Determine all K-rational flexes with rational x from the division polynomial.
    roots=[-S.Poly(g,u).nth(0)/S.Poly(g,u).nth(1) for g,m in S.factor_list(psi3,u)[1] if S.degree(g,u)==1]
    winners=[]
    for ux in roots:
        ky=S.sqrt(S.cancel(-cubic.subs(u,ux)/11))
        if not ky.is_Rational:continue
        # Denominator is the radical of the x-pole denominator and beta's flex fiber.
        denominator=S.Poly(xd,E).sqf_part().monic().as_expr()*(E**3+ux)
        for sy in [ky,-ky]:
            m=S.cancel(S.diff(cubic,u).subs(u,ux)/(-22*sy));n=S.cancel(sy-m*ux)
            # Symmetry and the pole orders leave five scalar and three sW coefficients.
            unknowns=S.symbols('c0:5 d0:3');c=sum(unknowns[i]*z**i for i in range(5));d=sum(unknowns[i+5]*z**i for i in range(3))
            rem=S.rem(c*yn-22*d*yd,xnz,z)
            eqs=S.Poly(rem,z).all_coeffs()
            # At branch-point x-poles, a scalar numerator must vanish.
            branch_common=S.gcd(S.Poly(denominator,E),S.Poly(h,E)).as_expr();bc=to_z(branch_common)
            eqs+=S.Poly(S.rem(c,bc,z),z).all_coeffs()
            # Cancel the unwanted pole on beta^{-1}(-U).
            eqs += [c.subs(z,-ux)+11*sy*d.subs(z,-ux)]
            M,_=S.linear_eq_to_matrix(eqs,unknowns);basis=M.nullspace()
            if len(basis)!=1:continue
            vector=basis[0];cv=c.subs(dict(zip(unknowns,vector)));dv=d.subs(dict(zip(unknowns,vector)))
            aa=S.cancel(cv.subs(z,E**3)/denominator);dd=S.cancel(dv.subs(z,E**3)/denominator)
            # Work in Q(E)[sW], where (sW)^2=11h.
            cube0=S.cancel(aa**3+33*h*aa*dd**2);cube1=S.cancel(3*aa**2*dd+11*h*dd**3)
            line=-m*E**3+n
            R0=S.cancel((-h*Y/2+11*line)/(-h+11*line**2));R1=S.cancel((line*Y/2-1)/(-h+11*line**2))
            scaling_cube=S.cancel(R0/cube0)
            if scaling_cube.has(E) or S.cancel(cube1*scaling_cube-R1)!=0:continue
            an,ad=map(int,S.fraction(scaling_cube));rn,okn=S.integer_nthroot(abs(an),3);rd,okd=S.integer_nthroot(ad,3)
            assert okn and okd
            scale=S.Rational((-1 if an<0 else 1)*rn,rd);aa*=scale;dd*=scale
            assert S.cancel(aa**3+33*h*aa*dd**2-R0)==0
            assert S.cancel(3*aa**2*dd+11*h*dd**3-R1)==0
            winners.append({'point':[k(ux),k(0,sy)],'tangent':[k(0,m),k(0,n)],'function':[encode(aa),encode(0),encode(0),encode(dd)]})
    assert len(winners)==1
    return winners[0]

def counts(data,p,n):
    ctx=fq_default_ctx(p,n,'a');a=ctx.gen();zero=ctx(0);q=p**n
    h=decode(data['curve_h'],E);hn,hd=S.fraction(h);assert hd==1
    coeff=[ctx(int(S.expand(hn).coeff(E,i))) for i in range(10)]
    b=data['target_B'];tot=[1,1,1]
    for vector in itertools.product(range(p),repeat=n):
        x=sum((ctx(c)*a**i for i,c in enumerate(vector)),zero)
        v=zero
        for c in reversed(coeff):v=v*x+c
        values=[-v,x*x*x-11,x*x*x+b['a2']*x*x+b['a4']*x+b['a6']]
        for i,y in enumerate(values):tot[i]+=1 if y==zero else (2 if y**((q-1)//2)==ctx(1) else 0)
    return tot

def local_three(data):
    """Recover the wild cluster tree directly from the scaled public curve.

    The finite-field normalization charts, rather than a saved answer graph,
    determine the genera and node orders. This imports no reference code.
    See local_three_proof.md for the inertia and conductor argument.
    """
    x,q=S.symbols('x q')
    h=S.cancel(decode(data['curve_h'],E))
    hs=S.Poly(S.expand(h.subs(E,3*x)/3**9),x)
    ff=S.factor_list(hs.as_expr(),x)[1]
    c3=next(S.Poly(f,x) for f,m in ff if S.degree(f,x)==3)
    c6=next(S.Poly(f,x) for f,m in ff if S.degree(f,x)==6)
    aa,bb,cc=-c3.nth(0),-c6.nth(3),c6.nth(0)
    def vp(value):
        v=S.Rational(value); n,d=int(v.p),int(v.q);a=0
        assert n
        while n%3==0:n//=3;a+=1
        while d%3==0:d//=3;a-=1
        return a
    # The quadratic has unit and valuation-three roots in Q_3. Determine
    # their unit cube classes without constructing any p-adic extension.
    assert int(aa)%9==4 and int(bb)%9==7 and vp(cc)==3
    small_unit=int(cc/27)*pow(int(bb),-1,9)%9
    assert small_unit==7
    assert int(bb)*pow(int(aa**2),-1,9)%9==1
    assert small_unit*pow(int(aa**2),-1,9)%9==1
    assert vp(bb-aa)<vp(cc)
    six_depth=S.Rational(vp(bb-aa),3)
    unit_depth=S.Rational(vp(3),2)
    small_depth=S.Rational(vp(cc),3)+unit_depth
    assert 0<six_depth<unit_depth<small_depth
    # All three cubics are conjugate Kummer classes up to inversion.
    cubic_discriminant_order=vp(S.discriminant(c3.as_expr(),x))
    assert vp(1-aa)==1 and cubic_discriminant_order==3
    swan=3*(cubic_discriminant_order-2)
    # In y^2=-3 h_s the leading coefficient has valuation one.
    depths=[S.Integer(0),six_depth,small_depth,unit_depth,unit_depth]
    ysquare_orders=[S.Integer(1),1+6*six_depth,1+3*small_depth,
                    1+3*unit_depth+3*six_depth,1+3*unit_depth+3*six_depth]
    r=S.Poly(S.cancel(S.diff(decode(data['alpha_x'],E),E)/
                      decode(data['alpha_y_multiplier'],E)),E)
    assert r.degree()==3 and r.nth(1)==r.nth(2)==0
    rho=-r.nth(0)/r.nth(3)/27
    assert rho.q==1 and int(rho)%3==2
    diff_prefactor_order=vp(r.nth(3))
    heights=[diff_prefactor_order+d-v/2 for d,v in zip(depths,ysquare_orders)]
    # Top normalization e=q^2. Its leading differential is this rational
    # coefficient times dq; compute its local orders by polynomial shifts.
    top_diff=S.cancel((q*q+1)**3/(q*q*(q*q-1)**3))
    def ord_at(expr,point):
        n,d=map(lambda f:S.Poly(f.subs(q,q+point),q),S.fraction(expr))
        return min(i[0] for i,c in n.terms())-min(i[0] for i,c in d.terms())
    to_small,to_six=ord_at(top_diff,0),ord_at(top_diff,1)
    assert ord_at(top_diff,-1)==to_six
    # The middle normalization v^2=u(u-1) carries du/(u(u-1)v).
    # At u=0 or1: ord(du)=1,ord(v)=1,ord(u(u-1))=2.
    middle_tail=1-1-2
    # At either infinity: ord(du)=-2,ord(v)=-1,
    # ord(u(u-1))=-2. Each elliptic tail carries a holomorphic form.
    middle_top=-2-(-1)-(-2)
    genera=[0,0,1,1,1]
    verts=[{'genus':g,'vertical_order':rat(v)} for g,v in zip(genera,heights)]
    ab=[[0,2],[0,1],[0,1],[1,3],[1,4]]
    lengths=[small_depth/2,six_depth,six_depth,
             (unit_depth-six_depth)/2,(unit_depth-six_depth)/2]
    orders=[[to_small,0],[to_six,middle_top],[to_six,middle_top],
            [middle_tail,0],[middle_tail,0]]
    edges=[{'ends':ends,'thickness':rat(thick),'differential_orders':od}
           for ends,thick,od in zip(ab,lengths,orders)]
    for (a,b),thick,(oa,ob) in zip(ab,lengths,orders):
        assert oa+ob==-2 and heights[a]-heights[b]==-(oa+1)*thick
    extension=int(S.ilcm(*[v.q for v in lengths]))
    genus=sum(genera)+len(edges)-len(verts)+1
    # Wild C3 kills all six elliptic-tail dimensions; tame inertia swaps
    # the parallel edges and kills both graph dimensions. No I_3 invariants.
    return {'prime':3,'L_polynomial':[1],'conductor':2*genus+swan,'swan':swan,
            'stable_extension_e':extension,'vertices':verts,'edges':edges}


def local(data):
    """Separate chart computation, using polynomial substitutions over QQ."""
    h=S.Poly(S.cancel(decode(data['curve_h'],E)),E)
    hz=to_z(h.as_expr());factor=S.factor_list(hz,z)[1]
    linear=next(g for g,m in factor if S.degree(g,z)==1);a=-S.Poly(linear,z).nth(0)
    X=decode(data['alpha_x'],E);Y=decode(data['alpha_y_multiplier'],E)
    r=S.Poly(S.cancel(S.diff(X,E)/Y),E);assert r.degree()==3
    rho=-r.nth(0)/r.nth(3)
    def vp(q,p):
        q=S.Rational(q);num,den=int(q.p),int(q.q)
        if not num:return 10**6
        ans=0
        while num%p==0:num//=p;ans+=1
        while den%p==0:den//=p;ans-=1
        return ans
    def reduction(poly,var,p):
        q=S.Poly(poly,var)
        assert all(vp(c,p)>=0 for c in q.all_coeffs())
        return S.Poly.from_list([int(c.p)*pow(int(c.q),-1,p)%p for c in q.all_coeffs()],var,modulus=p)
    def elliptic_trace(poly,var,p):
        vals={i*i%p for i in range(p)};points=1
        for x in range(p):
            y=int(poly.eval(x))%p
            points+=1 if y==0 else 2 if y in vals else 0
        return p+1-points
    out=[local_three(data)]
    for p in [5,7]:
        if p==5:
            tail=reduction(-hz.subs(z,a+p*p*z)/p**6,z,p)
            central=reduction(-S.div(h.as_expr(),(E**3-a)**2,E)[0],E,p)
            # Polynomial division is used only after reduction; its remainder
            # vanishes modulo p and the quotient is the central equation.
            assert reduction(S.rem(h.as_expr(),(E**3-a)**2,E),E,p).is_zero
            assert tail.degree()==3 and S.gcd(tail,tail.diff()).degree()==0
            assert vp(a-rho,p)==2
            central_trace=elliptic_trace(central,E,p);tail_trace=elliptic_trace(tail,z,p)
            t=S.symbols('t')
            l=(1-central_trace*t+p*t*t)*(1-tail_trace*t+p*t*t)*(1-(tail_trace**2-2*p)*t*t+p*p*t**4)
            verts=[{'genus':1,'vertical_order':[0,1]}]+[{'genus':1,'vertical_order':[1,1]} for _ in range(3)]
            edges=[{'ends':[0,j],'thickness':[1,1],'differential_orders':[0,-2]} for j in range(1,4)]
            conductor,swan,extension=0,0,1
        else:
            # E=pi*z, W=pi^3*v, pi^2=p; coefficient valuations
            # determine the surviving sextic without choosing a p-adic root.
            tail_terms=[]
            for (i,),c in h.terms():
                v=vp(c,p)+S.Rational(i,2)-3
                assert v>=0
                if v==0:
                    assert i%2==0
                    tail_terms.append(-c*S.Integer(p)**(i//2-3)*z**i)
            tail=reduction(sum(tail_terms),z,p)
            central=reduction(-S.div(h.as_expr(),E**6,E)[0],E,p)
            assert reduction(S.rem(h.as_expr(),E**6,E),E,p).is_zero
            assert tail.degree()==6 and S.gcd(tail,tail.diff()).degree()==0
            assert vp(rho,p)==1
            # Inertia (z,v)->(-z,-v) has quotient x=z^-2,y=v/z^3.
            q=S.Poly(tail.nth(0)*z**3+tail.nth(6),z,modulus=p)
            ct=elliptic_trace(central,E,p);qt=elliptic_trace(q,z,p)
            node_square=pow(int(tail.nth(6))%p,(p-1)//2,p)==1
            graph_trace=1 if node_square else -1
            t=S.symbols('t');l=(1-graph_trace*t)*(1-ct*t+p*t*t)*(1-qt*t+p*t*t)
            verts=[{'genus':1,'vertical_order':[0,1]},{'genus':2,'vertical_order':[0,1]}]
            edges=[{'ends':[0,1],'thickness':[1,2],'differential_orders':[0,1]} for _ in range(2)]
            conductor,swan,extension=8-(1+2+2),0,2
        lp=S.Poly(S.expand(l),t)
        out.append({'prime':p,'L_polynomial':[int(lp.nth(i)) for i in range(lp.degree()+1)],'conductor':conductor,'swan':swan,'stable_extension_e':extension,'vertices':verts,'edges':edges})
    return out

def solve(data):
    from independent_map import solve as reconstruct
    b=-data['target_E']['a6']
    recovered,_=reconstruct({'curve_b':b,'coefficient_x':30,'pole_coefficient':18*b})
    assert S.cancel(decode(recovered['normalized_polynomial'],E)-decode(data['curve_h'],E))==0
    data=dict(data,alpha_x=recovered['cover']['x'],alpha_y_multiplier=recovered['cover']['y_multiplier'])
    out={'intersection_order':3,'gluing':gluing(data),'polarization_S':[1,18],'polarization_A':[1,18]}
    def factor(dim,disc=1,ram=None):return {'dimension':dim,'multiplicity':1,'algebra':{'center_discriminant':disc,'quaternion_ramification':ram}}
    out['geometric_factors']=[factor(1,-3),factor(1),factor(2,1,{'finite':[2,3],'infinity':False})]
    out['rational_factors']=[factor(1),factor(1),factor(2)]
    out['reduction_witnesses']=[]
    for p in [43,61]:
        c1,c2=counts(data,p,1),counts(data,p,2)
        out['reduction_witnesses'].append({'prime':p,'counts':[[a,b] for a,b in zip(c1,c2)]})
    out['elliptic_map']={key:recovered['cover'][key] for key in ['x','y_multiplier','degree']}
    from independent_field import solve as field_solve
    out['endomorphism_field'],_=field_solve(data)
    out['local_data']=local(data)
    from independent_integral import solve as integral_solve
    out['integral_structure']=integral_solve(out['polarization_A'],out['intersection_order'],
                                          out['geometric_factors'][2]['algebra']['quaternion_ramification']['finite'])
    return out
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();started=time.monotonic();o=solve(json.loads(a.data.read_text()));a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'seconds':time.monotonic()-started,'output':str(a.output)}))
