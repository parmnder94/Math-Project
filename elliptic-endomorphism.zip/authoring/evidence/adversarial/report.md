# Final adversarial verifier review

**Result:** No invalid mathematical submission that passes, or permitted representation that fails, was found in this bounded review. The task bundle was not changed.

Reviewed the final `instruction.md`, `tests/check_submission.py`, `tests/test_submission.py`, `tests/test.sh`, both Dockerfiles and Docker ignore files. The checker reviewed has SHA-256 `8f2e07aa01d495750bf773ffb3945ad45f2d7f4f13b78ab6e991dfd80b60b50d`.

## Executed mathematical and encoding probes

Run `python probe_math.py --root /path/to/bundle --output /path/to/audit-results` with the bundle's Python dependencies installed. The script saves only compact results by default; add `--keep-inputs` to retain all generated inert JSON submissions. Exact case names, sizes, elapsed times, outcomes and rejection messages are in `math_results.json`.

| Probe | Actual result |
| --- | --- |
| 45 full-artifact probes | 10 valid cases accepted; 35 invalid cases rejected; zero unexpected results |
| Multiply every map/gluing fraction by `(1+E)^100`, then pad every numerator and denominator to exactly 129 coefficients | Accepted after cancellation |
| Zero rational function with denominator `-(2^2048-1)` and 129 coefficient slots | Accepted |
| Either sign of `2^2048`; 130 zero coefficients | Rejected at the published bound |
| 10,000 trailing zero coefficients on the local polynomial at 3 | Accepted; the 129 limit applies only to rational-function numerators/denominators |
| Artifact padded to exactly 2,097,152 bytes; one further byte | First accepted; second rejected |
| 1,200 nested arrays; repeated integral/field keys including a Unicode-escaped duplicate; NaN | Rejected |
| Booleans in new integer positions, empty/split/reversed/nontrivial-factor violations, both order indices shifted by one, zero field denominator, extra field member | Rejected |
| Large rational sixth-power rescalings, inverse class times a sixth power from `Q(sqrt(-3))`, canonical fifth power divided by `-27`, and a 2048-bit unreduced rational encoding | Accepted |
| Wrong square/cube/sign/ramified-square multipliers, proper-subfield radicands, and trivial sixth-power class | Rejected |
| All signed exponent vectors on primes `2,3,5,7,11,29`, exponents `0..5` (93,312 calls to `verify_endomorphism_field`) | Exactly four expected integer representatives accepted; zero mismatches |
| All 120, 24 and 2 vertex permutations at 3, 5 and 7, respectively, with reversed edge endpoints/branch orders and edge order | All 146 accepted by graph equivalence |
| Independent exact lattice determinants and Smith forms for the orders/conductors described in `integral_order_proof.md` | Indices 8748 and 54; quotient factors `[3,3,18,18]` and `[18]` |

The four accepted exponent-vector representatives were `-1203587`, `32496849`, `-103004180250587`, and `2781112866765849`. They are the canonical/inverse classes and their `-27` multiples, after removal of rational sixth powers.

## Mathematical criteria reviewed

The field acceptance criterion is complete for the requested encoding. Over `K=Q(zeta_3)`, a degree-six Kummer extension corresponds to a cyclic subgroup of order six in `K*/K*6`; its generators are the original class and its inverse. A rational number is a sixth power in `K` precisely when it is a positive rational sixth power or `-27` times one. This gives exactly the check on `m/m0` or `m*m0`, with `m0=-1203587`. The canonical class has order six, as its valuation at the prime above 29 is one. The fixed degree 12 therefore agrees with every accepted class.

The invariant-factor representation for the integral conductor quotients is unique under the instruction's nontrivial-entry and divisibility-order requirements. Rejecting `[2,9]` in place of `[18]`, for example, is required by that encoding contract even though those groups are abstractly isomorphic. The independently computed determinants and Smith forms support the hardcoded values. Identification of these lattices with the actual Jacobian orders relies on the separately reviewed authoring proof; this arithmetic check is not an independent geometric derivation.

The map is tested by an exact curve identity, a pole at source infinity, and its reduced rational-function degree; the gluing check is an exact field identity with a nonzero affine flex. No tolerance, probabilistic evaluation or executable submission content is used. Equivalent rational fractions, allowable signs, rational-number signs and graph labeling conventions do not expose a mismatch in the tested set.

## Wrapper and container controls

The delegated static/runtime audit passed 20 isolated copied-wrapper controls. These exercise all-pass reports; stale reward initialization; simulated pytest exits 1 and 139; missing, empty, malformed and duplicate-key reports; NaN/infinite/negative durations; Boolean counts; zero tests; mismatched counts; skips and failures; reversed timestamps; empty tool/test names; and unknown statuses. Every negative case produced reward zero and a nonzero wrapper exit. These are synthetic wrapper branch controls, not artifact exploits or actual induced crashes. Exact results and invocation details are `wrapper/results.json` and `wrapper/summary.json`. Reproduce with `python wrapper/probe_wrapper.py --root /path/to/bundle --output /path/to/wrapper-results`; `--python` optionally selects the interpreter used by the copied wrapper.

A fresh verifier container used image `sha256:731f98033a7b60d8e08abc67ceac49b6ebe383bf394c53fa7377b82ba5786123`, whose three verifier source files match this bundle byte for byte. It ran with network disabled, no mounts, 2 CPUs and a 4 GiB limit. Only `reference-output.json` was copied to `/app/output/decomposition.json`. Actual pytest result: **1 passed in 0.08 seconds**, exit zero, reward one, a valid CTRF report and no fallback report.

The existing solver image `sha256:76f7b5d0ae962b9d76ca6a56af7daa056c31581149603d9633ad27f682901165` matched the current public input hash. Its `/app` contained only `/app/data/README.md` and `/app/data/jacobian.json`; `/tests`, `/solution`, `/solutions`, `/authoring`, and `/workspace` were absent. Docker bases and dependency artifacts are digest/hash pinned, and task configuration transfers only the inert output JSON into the separate verifier.

Exact Docker commands, timestamps and outputs are in `wrapper/docker_commands.json`; consolidated image/hash/isolation outcomes are in `wrapper/docker_results.json`. Existing images were used; this audit did not rebuild them.

## Scope

This was an author-side adversarial verifier review, not a solver calibration attempt. No workspace blind-attempt directory was opened. An initial broad authoring search inadvertently returned archived calibration excerpts; that subtree was excluded thereafter and none of those excerpts is used as evidence above. Authoring proofs were read only to assess the integral-order and endomorphism-field criteria. No online task-specific hints, resource-exhaustion tests, task edits or shared grading output writes were used. The review establishes the recorded tests and mathematical checks; it does not claim exhaustive adversarial coverage.
