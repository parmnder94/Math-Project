"""Probe wrapper failure handling using controlled pytest output, without Docker.

Usage: python probe_wrapper.py --root /path/to/task --output /path/to/probe-results
"""
import argparse
import copy
import hashlib
import json
import pathlib
import shlex
import shutil
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', required=True, type=pathlib.Path,
                    help='Task bundle containing tests/test.sh (read only).')
parser.add_argument('--output', type=pathlib.Path,
                    default=pathlib.Path(__file__).resolve().parent / 'wrapper_probe_results',
                    help='Directory for generated controls, logs and summary results.')
parser.add_argument('--python', default=sys.executable,
                    help='Python executable for controlled pytest and wrapper postprocessing.')
args = parser.parse_args()
BUNDLE = args.root.resolve()
ROOT = args.output.resolve()
python_path = shutil.which(args.python)
if python_path is None:
    parser.error('--python must name an available Python executable')
PYTHON = str(pathlib.Path(python_path).resolve())
source_path = BUNDLE / 'tests' / 'test.sh'
if not source_path.is_file():
    parser.error('--root does not contain tests/test.sh')
if ROOT == BUNDLE or BUNDLE in ROOT.parents:
    parser.error('--output must be outside the task bundle')
SOURCE = source_path.read_text()
for marker in ('pytest --ctrf', 'python - "$status"', 'logs = Path("/logs/verifier")'):
    if SOURCE.count(marker) != 1:
        parser.error('Unsupported wrapper layout: expected exactly one ' + repr(marker))
ROOT.mkdir(parents=True, exist_ok=True)
BASE = {'results': {'tool': {'name': 'pytest'}, 'summary': {
    'tests': 1, 'passed': 1, 'failed': 0, 'skipped': 0, 'pending': 0, 'other': 0,
    'start': 1, 'stop': 2}, 'tests': [{'name': 'control', 'status': 'passed', 'duration': 0}]}}
CASES = []

def case(name, change=None, status=0, raw=None, accepted=False):
    report = copy.deepcopy(BASE)
    if change:
        change(report['results'])
    CASES.append((name, json.dumps(report) if raw is None else raw, status, accepted))

case('valid_all_pass', accepted=True)
case('pytest_nonzero', status=1)
case('pytest_crash', status=139)
case('missing', raw='MISSING')
case('empty', raw='')
case('malformed', raw='{')
case('wrong_root', raw='[]')
case('duplicate_key', raw=json.dumps(BASE).replace('"tool":', '"tool": {}, "tool":', 1))
case('nan_duration', lambda r: r['tests'][0].update(duration=float('nan')))
case('infinite_duration', lambda r: r['tests'][0].update(duration=float('inf')))
case('negative_duration', lambda r: r['tests'][0].update(duration=-1))
case('bool_counts', lambda r: r['summary'].update(tests=True))
case('zero_tests', lambda r: (r['summary'].update(tests=0, passed=0), r.update(tests=[])))
case('mismatched_counts', lambda r: r['summary'].update(tests=2, passed=2))
case('skipped', lambda r: (r['summary'].update(passed=0, skipped=1), r['tests'][0].update(status='skipped')))
case('failed', lambda r: (r['summary'].update(passed=0, failed=1), r['tests'][0].update(status='failed')), status=1)
case('reversed_time', lambda r: r['summary'].update(start=3))
case('empty_tool', lambda r: r['tool'].update(name=''))
case('empty_test_name', lambda r: r['tests'][0].update(name=''))
case('unknown_test_status', lambda r: r['tests'][0].update(status='unknown'))

results = []
for name, raw, status, accepted in CASES:
    here = ROOT / name
    here.mkdir(exist_ok=True)
    logs = here / 'logs'
    logs.mkdir(exist_ok=True)
    # Seed stale success to ensure it is replaced on all ordinary failure paths.
    (logs / 'reward.txt').write_text('1\n')
    (logs / 'ctrf.json').write_text(json.dumps(BASE))
    fake = here / 'pytest-control'
    fake.write_text('import pathlib\n'
                    + ('' if raw == 'MISSING' else f'pathlib.Path({str(logs / "ctrf.json")!r}).write_text({raw!r})\n')
                    + f'raise SystemExit({status})\n')
    script = here / 'test.sh'
    rewritten = SOURCE.replace('logs = Path("/logs/verifier")', f'logs = Path({str(logs)!r})')
    rewritten = rewritten.replace('/logs/verifier', shlex.quote(str(logs)))
    rewritten = rewritten.replace('pytest --ctrf', shlex.join([PYTHON, str(fake)]) + ' --ctrf')
    rewritten = rewritten.replace('python - "$status"', shlex.quote(PYTHON) + ' - "$status"')
    script.write_text(rewritten)
    proc = subprocess.run(['bash', str(script)], cwd=here, text=True, capture_output=True, timeout=10)
    reward = (logs / 'reward.txt').read_text().strip()
    meta = json.loads((logs / 'wrapper_status.json').read_text())
    passed = reward == str(int(accepted)) and (proc.returncode == 0) == accepted
    results.append({'name': name, 'control_passed': passed, 'exit': proc.returncode,
                    'reward': reward, 'wrapper': meta, 'stderr': proc.stderr})
    assert passed, results[-1]
(ROOT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
summary = {'cases': len(results), 'passed': sum(x['control_passed'] for x in results),
           'root': str(BUNDLE), 'output': str(ROOT), 'python': PYTHON,
           'wrapper_sha256': hashlib.sha256(source_path.read_bytes()).hexdigest(),
           'invocation': [sys.executable, *sys.argv],
           'scope': 'Isolated path-rewritten wrapper with controlled reports and simulated pytest exit statuses, including 139; no actual pytest crash, Docker or artifact-boundary claim.'}
(ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
