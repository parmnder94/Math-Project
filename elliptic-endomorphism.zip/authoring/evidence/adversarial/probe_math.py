"""Bounded author-side verifier audit. No task-bundle writes or solver execution."""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import itertools
import json
import math
import random
import sys
import tempfile
import time
from fractions import Fraction

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', required=True, type=Path, help='Task bundle root')
parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent,
                    help='Directory for the compact JSON results')
parser.add_argument('--keep-inputs', action='store_true',
                    help='Retain each generated inert artifact in output/inputs')
args = parser.parse_args()
ROOT = args.root.resolve()
OUT = args.output.resolve()
OUT.mkdir(parents=True, exist_ok=True)
temporary_inputs = tempfile.TemporaryDirectory(prefix='math-audit-', dir=OUT)
INPUTS = OUT/'inputs' if args.keep_inputs else Path(temporary_inputs.name)
INPUTS.mkdir(exist_ok=True)
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('audited_checker', ROOT/'tests/check_submission.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
original = json.loads((ROOT/'authoring/evidence/reference-output.json').read_text())
results = []

def check(name, value, expected=True):
    raw = value if isinstance(value, bytes) else json.dumps(value).encode()
    path = INPUTS/(name+'.json')
    path.write_bytes(raw)
    start = time.perf_counter()
    try:
        checker.verify_path(path)
        accepted, reason = True, ''
    except Exception as exc:
        accepted, reason = False, type(exc).__name__+': '+str(exc)
    result = dict(name=name, expected=expected, accepted=accepted, reason=reason,
                  bytes=len(raw), seconds=round(time.perf_counter()-start,6))
    results.append(result)
    assert accepted == expected, result

def mutate(name, path, value, expected=False):
    obj=copy.deepcopy(original)
    target=obj
    for part in path[:-1]: target=target[part]
    target[path[-1]]=value
    check(name,obj,expected)

def mul(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): out[i+j]+=x*y
    return out

check('baseline',original)

# Polynomial encoding at the advertised raw degree boundary, after cancellation.
obj=copy.deepcopy(original)
common=[math.comb(100,i) for i in range(101)]
for rf in [obj['elliptic_map']['x'],obj['elliptic_map']['y_multiplier'],*obj['gluing']['function']]:
    for key in ('num','den'):
        rf[key]=mul(rf[key] or [0],common)
        rf[key]+=[0]*(129-len(rf[key]))
        assert len(rf[key])==129
check('all_rf_degree_boundary_cancelled',obj)

limit=(1<<2048)-1
obj=copy.deepcopy(original)
obj['gluing']['function'][1]={'num':[0]*129,'den':[-limit]+[0]*128}
check('negative_2048_bit_boundary_zero_rf',obj)
mutate('positive_2049_bit_rejected',['gluing','function',1,'den'],[1<<2048])
mutate('negative_2049_bit_rejected',['gluing','function',1,'den'],[-(1<<2048)])
mutate('130_zero_rf_coefficients_rejected',['gluing','function',1,'num'],[0]*130)
mutate('L_polynomial_10000_trailing_zeros',['local_data',0,'L_polynomial'],[1]+[0]*10000,True)
raw=json.dumps(original).encode()
check('exact_byte_boundary',raw+b' '*(checker.MAX_BYTES-len(raw)))
check('byte_boundary_plus_one_rejected',raw+b' '*(checker.MAX_BYTES+1-len(raw)),False)
check('bounded_excess_nesting_rejected',b'['*1200+b'0'+b']'*1200,False)
check('duplicate_nested_integral_key_rejected',raw.replace(b'"rational_index": 54',b'"rational_index": 54, "rational_index": 54'),False)
check('duplicate_nested_field_key_rejected',raw.replace(b'"degree": 12',b'"degree": 12, "degree": 12'),False)
check('escaped_duplicate_field_key_rejected',raw.replace(b'"degree": 12',b'"degree": 12, "degr\\u0065e": 12'),False)
check('field_NaN_rejected',raw.replace(b'"degree": 12',b'"degree": NaN'),False)

# New integral and field members: every integer position rejects Boolean values.
for field in ('geometric_index','rational_index'):
    mutate('bool_'+field,['integral_structure',field],True)
for field in ('geometric_conductor_quotient','rational_conductor_quotient'):
    mutate('bool_'+field,['integral_structure',field,0],True)
    mutate('empty_'+field,['integral_structure',field],[])
    value=original['integral_structure'][field]
    mutate('extra_trivial_'+field,['integral_structure',field],[1]+value)
    mutate('split_cyclic_'+field,['integral_structure',field],([3,3,2,2,9,9] if field.startswith('geometric') else [2,9]))
mutate('reversed_geometric_invariant_factors',['integral_structure','geometric_conductor_quotient'],[18,18,3,3])
for field in ('geometric_index','rational_index'):
    for delta in (-1,1):
        mutate(field+('_below' if delta<0 else '_above'),['integral_structure',field],original['integral_structure'][field]+delta)
for i in (0,1):
    mutate('field_boolean_radicand_'+str(i),['endomorphism_field','radicand',i],True)
mutate('field_zero_denominator',['endomorphism_field','radicand'],[1,0])
mutate('field_extra_member',['endomorphism_field'],dict(original['endomorphism_field'],extra=0))

# Full-artifact Kummer encodings with large integers and uncancelled rational signs.
m0=Fraction(-1203587)
radicands = {
    'large_Q_sixth':m0*Fraction((1<<337)-1)**6,
    'large_rational_sixth':m0*Fraction((1<<160)+123,(1<<159)-1)**6,
    'inverse_large_K_sixth':Fraction(-27,m0)*Fraction((1<<160)+123,(1<<159)-1)**6,
    'canonical_fifth_power_divided_27':m0**5/Fraction(-27),
    'negative_rational_square_wrong':m0*Fraction(4),
    'negative_rational_cube_wrong':m0*Fraction(8),
    'sign_flip_wrong':-m0,
    'ramified_square_wrong':m0*Fraction(-3),
    'proper_subfield_square_wrong':m0*m0,
    'proper_subfield_cube_wrong':m0**3,
    'trivial_K_sixth_wrong':Fraction(-27),
}
for name,m in radicands.items():
    mutate('field_'+name,['endomorphism_field','radicand'],[-m.numerator,-m.denominator],not name.endswith('wrong'))
scale=limit//abs(m0.numerator)
mutate('field_unreduced_2048_bit',['endomorphism_field','radicand'],[m0.numerator*scale,scale],True)

# Independently classify supported rational sixth-power classes by valuations.
# A sign/exponent vector represents the same field iff it is +/- the
# canonical vector modulo rational sixth powers and (-27)=sqrt(-3)^6.
primes=(2,3,5,7,11,29)
canonical=(1,0,0,0,3,2,1)  # sign; prime valuations mod 6
classes=[]
for inverse in (False,True):
    base=[(-v)%6 if inverse else v for v in canonical[1:]]
    for relation in (0,1):
        vals=base[:]
        vals[1]=(vals[1]+3*relation)%6
        classes.append(((canonical[0]+relation)%2,*vals))
expected_classes=set(classes)
field_rows=[]
start=time.perf_counter()
for sign in (0,1):
    for exponents in itertools.product(range(6),repeat=6):
        vector=(sign,*exponents)
        m=(-1 if sign else 1)*math.prod(p**e for p,e in zip(primes,exponents))
        try:
            checker.verify_endomorphism_field({'radicand':[m,1],'degree':12})
            accepted=True
        except checker.VerificationError:
            accepted=False
        expected=vector in expected_classes
        if accepted or accepted!=expected:
            field_rows.append({'vector':vector,'radicand':m,'accepted':accepted,'expected':expected})
        assert accepted==expected,(vector,m,accepted,expected)
field_sweep={'classes':2*6**6,'expected_accepted':len(expected_classes),
             'accepted':sum(row['accepted'] for row in field_rows),'mismatches':0,
             'seconds':round(time.perf_counter()-start,6),'accepted_rows':field_rows}

# Vary every graph labeling, while edge orientation/order is changed as well.
graph_counts={}
for row in original['local_data']:
    vertices=[(v['genus'],Fraction(*v['vertical_order'])) for v in row['vertices']]
    edges=[(*e['ends'],Fraction(*e['thickness']),*e['differential_orders']) for e in row['edges']]
    n=len(vertices)
    count=0
    for permutation in itertools.permutations(range(n)):
        inverse={old:new for new,old in enumerate(permutation)}
        vv=[vertices[i] for i in permutation]
        ee=[(inverse[b],inverse[a],t,v,u) for a,b,t,u,v in reversed(edges)]
        assert checker.equivalent_graph(vv,ee,checker.LOCAL[row['prime']])
        count+=1
    graph_counts[row['prime']]=count

# Independent integer-lattice arithmetic for the explicitly described orders.
from sympy import Matrix, ZZ
from sympy.matrices.normalforms import smith_normal_form
R=Matrix([[1,0,0,0,0,0,0], [0,1,0,0,0,0,0], [1,1,3,0,0,0,0],
          [1,0,0,18,0,0,0], [0,1,0,0,18,0,0], [0,0,0,0,0,3,0], [0,0,0,0,0,0,3]])
C=Matrix.diag(18,18,3,18,18,9,9)
RQ=Matrix([[1,0,0],[1,3,0],[1,0,18]])
CQ=Matrix.diag(18,3,18)
def quotient(B,D):
    inclusion=B.inv()*D
    assert all(e.q==1 for e in inclusion)
    S=smith_normal_form(inclusion,domain=ZZ)
    return [abs(int(S[i,i])) for i in range(S.rows) if abs(S[i,i])>1]
integral={'geometric_index':abs(int(R.det())),'rational_index':abs(int(RQ.det())),
          'geometric_conductor_quotient':quotient(R,C),'rational_conductor_quotient':quotient(RQ,CQ)}
assert integral==original['integral_structure']

report={'checker_sha256':hashlib.sha256((ROOT/'tests/check_submission.py').read_bytes()).hexdigest(),
        'artifact_cases':len(results),'artifact_accepted':sum(r['accepted'] for r in results),
        'artifact_rejected':sum(not r['accepted'] for r in results),
        'artifact_mismatches':0,'results':results,'field_sweep':field_sweep,
        'graph_labelings':graph_counts,'integral_arithmetic':integral}
(OUT/'math_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
temporary_inputs.cleanup()
