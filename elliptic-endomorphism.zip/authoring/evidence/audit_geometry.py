#!/usr/bin/env python3
"""Recheck the exact map and primitivity premises of the global proof."""
import json
from pathlib import Path
from independent_map import RF
from primitive_arithmetic import build_certificate,verify
r=Path(__file__).resolve().parents[2]
d=json.loads((r/'environment/data/jacobian.json').read_text())
o=json.loads((r/'authoring/evidence/independent-output.json').read_text())
def rf(a):return RF(a['num'],a['den'])
h=rf(d['curve_h']);X=rf(o['elliptic_map']['x']);Y=rf(o['elliptic_map']['y_multiplier'])
assert not(-h*Y*Y-4*X*X*X+44)
pb=X.diff()/Y;assert pb.d.degree()==0
rho=pb/RF(pb.n.leading_coefficient())
cover={'x':X.dump(),'y_multiplier':Y.dump(),'degree':max(X.n.degree(),X.d.degree()),'pullback':pb.dump(),'ramification_polynomial':rho.dump(),'infinity_ramification_order':h.n.degree()-3-2*pb.n.degree()}
a={'cover':cover,'normalized_polynomial':h.dump()}
c=build_certificate(a,RF);v=verify(a,c)
report={'curve_identity':True,'degree':cover['degree'],'differential':pb.dump(),'primitivity':v,'certificate':c}
(r/'authoring/evidence/primitive_geometry_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'exact_identity':True,'degree':cover['degree'],'primitive':True}))
