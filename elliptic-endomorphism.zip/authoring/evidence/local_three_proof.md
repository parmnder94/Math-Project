# Wild stable reduction at three

This independently derived local record completes the local calculation
at the wild prime three.

Put $E=3e$, $W=81w$. The curve and differential become

$$w^2=-3h_0(e),\quad
h_0(e)=(e^3-a)(e^6-be^3+c),\quad
\omega=9(e^3-4466)de/w,$$

where $a=20416$, $b=20482$, $c=1120581$.

## Root fields and exact clusters

The polynomial $t^2-bt+c$ has two roots in $\mathbb Q_3$: a unit root
$t_1$ and a root $t_2$ of valuation three. This follows either from
Hensel's lemma at the two distinct residue roots zero and one, or from
the Newton polygon. Moreover

$$t_1\equiv7\pmod9,\qquad
t_2=27q,\quad q\equiv7\pmod9,\qquad a\equiv4\pmod9.$$

Indeed $t_1=b-t_2\equiv b\pmod{27}$ and
$q=(c/27)/t_1$, where $c/27\equiv4\pmod9$.
The rational three-adic unit cube criterion is that a unit be congruent
to $1$ or $-1$ modulo nine. It follows that $t_1/a^2$ and $q/a^2$ are
cubes in $\mathbb Q_3$. Thus all nine branch roots split in the same
extension $\mathbb Q_3(\sqrt[3]a,\zeta_3)$, of ramification index six.

Within each triple of cube roots, pairwise differences have valuations
$1/2$ for the unit triples and $3/2$ for the small triple. Between the
two unit triples, cube differences have valuation one because
$v_3(t_1-a)=v_3(b-a)=v_3(66)=1$. If unit roots differ by $d$, and
$v_3(d)<1/2$, the term $d^3$ in their cube difference has strictly
smallest valuation. Hence their pairwise distances have valuation
$1/3$. These facts give the complete cluster tree:

- top depth zero;
- a small triple of depth $3/2$;
- a six-root cluster of depth $1/3$, containing two triples of depth
  $1/2$.

There are no other proper clusters. The leading coefficient of the
scaled equation is $-3$, of valuation one.

## Explicit components and graph

Write $\delta^2=-3$. On the top chart the normalization of the reduction
is obtained with

$$q=w/(\delta e(e-1)^3),\qquad q^2=e.$$

This is a rational component. Its small-tail node is $q=0$; the two
nodes toward the six-root cluster are $q=1,-1$.

Choose unit cube roots $a_0^3=a$, $b_0^3=t_1$ and put
$\lambda=b_0-a_0$, of valuation $1/3$. On the six-root chart let
$u=(e-a_0)/\lambda$. After dividing by the indicated leading constants,
the double cover has equation $q_6^2=u^3(u-1)^3$. Its normalization is

$$v^2=u(u-1),\qquad q_6=u(u-1)v.$$

This is another rational component. The two unit tails attach at
$(u,v)=(0,0),(1,0)$; the two top nodes are its two infinity points.

For any of the three triples, center at one of its roots $d$ and set
$U=(e/d-1)/(\zeta_3-1)$. The triple reduces to the distinct roots
$0,1,-1$. Its normalized component has equation
$V^2=k(U^3-U)$ for a nonzero residue constant $k$, hence is smooth of
genus one. Over the algebraic closure of the residue field one can
absorb $k$ by rescaling $V$. Each tail attaches at its unique infinity.

The graph therefore has five vertices: two of genus zero and three of
genus one. It has two parallel edges between the rational vertices,
one edge from the top to the small tail, and one edge from the six-root
vertex to each unit tail. The first Betti number is one and the total
genus is $3+1=4$. All rational vertices have at least three branches,
so the model is stable without contracting any vertex.

For an odd child cluster the double cover is branched over the node,
so source thickness is half the difference of cluster depths; for the
even six-root child it is unramified and produces two nodes, each with
the full depth difference. The thicknesses are respectively

$$3/4,\quad 1/3,1/3,\quad 1/12,1/12.$$

The root-splitting extension together with a square root of $\delta$
has ramification index twelve and supplies all required powers for the
charts: the square-root heights are $1/2,3/2,7/4,11/4$. Units have square
roots after an unramified extension. Conversely a stable node of
thickness $1/12$ forces the ramification index to be divisible by twelve.
Thus the least stable ramification index over the maximal unramified
extension is exactly twelve.

## Differential valuations and branch orders

At a cluster of depth $d$ the order of $w^2$ is its leading-coefficient
valuation plus the sum of distances to all nine roots. The respective
values on the top, six-root, unit-tail and small-tail components are

$$\nu=1,\ 3,\ 7/2,\ 11/2.$$

The factor $e^3-4466$ is a unit at the generic point of every one of
these components. Therefore the vertical order of $\omega$ is
$2+d-\nu/2$. In the same order the answers are

$$3/2,\quad5/6,\quad3/4,\quad3/4.$$

On the top rational component, up to a nonzero constant the leading
differential is

$$\frac{(q^2+1)^3}{q^2(q^2-1)^3}\,dq.$$

It has order $-2$ at the small-tail node and order $-3$ at both nodes
toward the six-root component. Its six zeros are two points of
multiplicity three, the specializations of the six generic zeros of
$\omega$.

On the six-root component the leading differential is, up to a nonzero
constant,

$$\frac{du}{u(u-1)v},\qquad v^2=u(u-1).$$

Its orders are $-2$ at each tail node and $1$ at each infinity. On all
three elliptic tails the leading form is a nonzero scalar multiple of
$dU/V$, with order zero at their node. Thus the edge branch orders are

- top/small tail: $(-2,0)$;
- top/six-root: $(-3,1)$ on each of the two edges;
- six-root/unit tail: $(-2,0)$ on both edges.

## Inertia, wild conductor and local polynomial

The wild group is cyclic of order three. It sends $a_0$ to $\zeta_3a_0$
and the roots of both other triples to $\zeta_3^2$ times themselves.
On their tail charts its reduction is $U\mapsto U+1$ or $U\mapsto U-1$,
with $V$ fixed. This is a nontrivial automorphism of order three fixing
infinity on each elliptic tail. The quotient has genus zero, so each
tail's two-dimensional cohomology has no wild-invariant vector. Over a
coefficient extension its two characters are the two nontrivial
characters of the wild cyclic group. Wild inertia acts trivially on
the graph and rational components.

Tame inertia sends $\delta$ to $-\delta$. On the top chart it sends
$q$ to $-q$, and hence exchanges the two parallel edges of the graph.
It acts by $-1$ on graph cohomology and also by $-1$ on its dual graph
piece. Consequently none of the eight cohomology dimensions survives
full inertia: the six component dimensions are excluded by wild
inertia and the two graph dimensions by tame inertia. Thus

$$L_3(t)=1.$$

The Swan exponent can be checked without guessing it from the graph.
For the cubic field defined by $x^3-a$, the translated polynomial
$(x+1)^3-a$ is Eisenstein because $v_3(1-a)=1$. Its root generates the
ring of integers and its discriminant has valuation three. The Artin
conductor of the three-dimensional root permutation representation is
therefore three (the conductor-discriminant identity). Its constant
subrepresentation contributes zero. On the remaining two-dimensional
augmentation representation inertia has no fixed vector, so its tame
conductor is two and its Swan conductor is one.

Each elliptic tail has the same two nontrivial wild characters as this
augmentation representation. All positive ramification groups are
contained in the same cyclic group of order three, so their Swan
conductors coincide. A further tame extension does not change this
upper-numbered ramification calculation. The three tails therefore
contribute one each; graph pieces contribute zero. The Swan conductor
of the curve is three, and its full Artin conductor is

$$8-\dim H^1{}^{I_3}+3=8+3=11.$$

`wild_three.py` checks the exact integer valuations and residues behind
this proof and constructs the graph, differential heights and local
record from the cluster data. It does not invoke the global solver or
the submission verifier.
