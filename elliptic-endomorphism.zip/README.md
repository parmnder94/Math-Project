# Elliptic endomorphism audit

Reconstruct a minimum-degree elliptic map from an exact genus-four curve, then determine the Jacobian’s integral endomorphism orders, algebras and field of definition, and local degeneration data. The complete contract and output encoding are in `instruction.md`.

Local calibration did not meet the requested difficulty target; see `authoring/evidence/RESULTS.md`.

## Difficulty

Researchers in arithmetic geometry use computations like this to identify the simpler pieces of an algebraic curve and determine which symmetries a calculation has actually established. The data here are synthetic and exact. The main map is not supplied: the solver must reconstruct it and prove that no map of smaller degree exists.

Finding the pieces is only the start. They have a finite overlap, so treating them as independent changes the geometric structure being classified. Some apparent symmetries become valid only after division by an integer. Recovering the symmetries that act on the original object requires tracing the finite overlap through the integer structure of each piece. A symmetry may exist only after extending the number field; identifying the smallest such field requires ruling out every competing possibility. At the bad primes, parts of the curve collide and split. The solver must track those changes, including wild ramification, to recover consistent local invariants. A few successful numerical examples cannot establish these global claims. The calculations fit comfortably on a laptop; the difficulty is connecting reconstruction, integral structure, completeness, field of definition and degeneration.

## Reference solution

The reference reconstructs the missing map through an exact elliptic differential equation and checks that its normalized spectral curve is the supplied curve. This is a construction of a candidate, not a restriction on accepted methods. The remaining proof establishes its minimum degree among every rational pointed map to the target elliptic curve.

A flex point on the second elliptic curve supplies a possible common torsion class. Factoring a cubic over a rational-function field constructs the function whose divisor certifies that overlap. A finite alternating-module calculation gives both induced polarization types. The polarization defines a Hermitian form on homology; an explicit conjugate-linear Hodge endomorphism then gives quaternion multiplication on the complementary surface. Two good reductions exclude a larger geometric algebra. Complex conjugation and a third reduction determine the rational algebra.

The integral calculation identifies all lattice-preserving quaternion endomorphisms and the congruences imposed by gluing the polarized subvarieties. It proves uniqueness of the containing maximal order and computes its largest two-sided ideal inside the actual endomorphism ring. Exact Smith normal forms give the order indices and additive conductor quotients.

The field calculation first proves that every possible endomorphism field belongs to a finite Kummer class group supported at bad primes. Exact twisted point counts distinguish every class. Thus the selected field is a proved minimum, not an empirical fit. At three, five and seven, explicit stable charts determine components, node lengths and differential orders. Their inertia and Frobenius actions give local polynomials and conductors; a cubic discriminant calculation supplies the wild contribution at three.

The independent solver uses a rational differential pencil and successive divisor reductions for the map, a divisor-interpolation nullspace for gluing, and a modular linear system for the endomorphism field. Its point-count implementations use different arithmetic from the corresponding reference paths. It imports neither the reference solver nor the verifier.

## Verification

The sealed verifier checks the map equation, pointedness and degree exactly; a separate proof establishes global minimum degree. It checks the flex point, tangent and full rational-function gluing identity. Geometric arguments independently establish the intersection bound, polarization and complete algebra classification. Any admissible pair of reduction primes is accepted after fresh finite-field point counts.

Equivalent map signs, rational functions, fractions, field radicands, factor orders and graph labels are accepted. Field equivalence is checked by exact sixth roots, avoiding factorization of submitted large integers. Graph checks include genera, node lengths, differential valuations and branch orders. Only bounded inert JSON is read; submitted code is never executed.

`tests/test.sh` initializes reward zero and grants reward one only after a successful test process and a valid, nonempty, passing CTRF report. The verifier is a separate offline container and installs nothing at runtime. Actual mathematical controls, container outcomes and blind-probe limitations are recorded in `authoring/evidence/RESULTS.md`.

## Setup and reproduction

The compact ZIP omits dependency wheels. Docker builds fetch immutable wheel URLs with SHA-256 checks, then install from those files with exact pins and hash enforcement. Initial image preparation needs internet and modern Docker BuildKit; verification runs offline. The tested platform is Linux x86_64 with Python 3.12.

```sh
bash authoring/setup.sh /tmp/elliptic-endomorphism-tools
/tmp/elliptic-endomorphism-tools/bin/python -B authoring/evidence/static_validate.py
/tmp/elliptic-endomorphism-tools/bin/python -B authoring/evidence/validate.py
/tmp/elliptic-endomorphism-tools/bin/python -B authoring/evidence/container_validate.py
```

The seeded input constructor is `authoring/generate.py`. Its output contains only the public curve coefficients. Solutions, verification code, proofs, construction history and evidence are excluded from the solver image.
