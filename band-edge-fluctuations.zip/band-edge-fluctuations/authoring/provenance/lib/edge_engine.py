"""Exact resummation engine for finite-size statistics of Tr[h(H_N)Q_N], h = Lorentzian at z=x0+i eta.
All quantities are first built for the resolvent g_z(x)=1/(z-x) at z and at conj(z)."""
import numpy as np, itertools
from fs import Lin
INV=[1,0,3,2]
class Point:
    """resolvent data at one complex z: Phi_s, G, Omega matrices (F(y)=tr(Om[(f,l)] Phi_y))"""
    def __init__(s,B,lam,z):
        L=Lin(B,lam);s.K=K=L.K
        H=L.iterate(complex(z.real,max(abs(z.imag),0.3))*1 if z.imag>0 else complex(z.real,-max(abs(z.imag),0.3)))
        sgn=1 if z.imag>0 else -1
        for e in [0.3,0.2,0.1,0.05,0.03,0.02,0.01,0.005]:
            if abs(z.imag)<e: H,_=L.newton(H,complex(z.real,sgn*e))
        H,ok=L.newton(H,z);assert ok
        s.Phi=np.array([H[a]@L.A[a] for a in range(4)]);s.G=L.Gfull(H,z);s.z=z
        KK=K*K;Ak=[np.kron(s.Phi[a],s.Phi[INV[a]].T) for a in range(4)]
        T=np.zeros((4*KK,4*KK),complex)
        for a in range(4):
            for b in range(4):
                if a!=INV[b]: T[a*KK:(a+1)*KK,b*KK:(b+1)*KK]=Ak[a]
        s.conj_spr=max(abs(np.linalg.eigvals(T)))
        g=np.zeros((K,K),complex);g[:2,:]=s.G[:,:2].T;gv=g.ravel()
        adj=np.linalg.solve((np.eye(4*KK)-T).T,np.concatenate([gv]*4))
        s.Om={}
        for f in range(4):
            for l in range(4):
                if l==INV[f]: continue
                om=gv.copy()
                for t in range(4):
                    if t!=INV[f] and t!=l: om=om+Ak[t].T@adj[t*KK:(t+1)*KK]
                s.Om[(f,l)]=om.reshape(K,K).T     # F(y) = sum_ij om[i,j] Y[i,j] = tr(Om Y)
        s.trce=np.trace(s.G[:2,:2])
    def F(s,y):
        M=np.eye(s.K,dtype=complex)
        for x in y: M=M@s.Phi[x]
        return np.trace(s.Om[(y[0],y[-1])]@M)
def kron_all(ms):
    out=ms[0]
    for m in ms[1:]: out=np.kron(out,m)
    return out
def cyc_closure(p,K):
    """matrix C on (C^K)^{(x)p} with tr[(A1 x...x Ap) C] = tr(A1 A2 ... Ap)"""
    D=K**p;C=np.zeros((D,D))
    for idx in itertools.product(range(K),repeat=p):
        # out index (i1..ip) -> in index (i2,...,ip,i1)
        r=np.ravel_multi_index(idx,(K,)*p);c=np.ravel_multi_index(idx[1:]+idx[:1],(K,)*p)
        C[c,r]=1
    return C
class Transfer:
    """slots: list of per-letter matrix lists; X[a][b] = sum over reduced words a..b of tensor products"""
    def __init__(s,slots):
        s.D=int(np.prod([sl[0].shape[0] for sl in slots]))
        s.Dl=[kron_all([sl[a] for sl in slots]) for a in range(4)]
        D=s.D;T=np.zeros((4*D,4*D),complex)
        for a in range(4):
            for b in range(4):
                if b!=INV[a]: T[a*D:(a+1)*D,b*D:(b+1)*D]=s.Dl[b]
        s.spr=max(abs(np.linalg.eigvals(T))) if 4*D<=1000 else None
        W=np.linalg.inv(np.eye(4*D)-T)
        s.X=[[s.Dl[a]@W[a*D:(a+1)*D,b*D:(b+1)*D] for b in range(4)] for a in range(4)]

def M_d(pt,d):
    """sum over cyclically reduced y of F(y^d)"""
    K=pt.K;tr=Transfer([list(pt.Phi)]*d);C=cyc_closure(d,K);I=np.eye(K**(d-1))
    tot=0
    for f in range(4):
        for l in range(4):
            if l==INV[f]: continue
            tot+=np.trace(np.kron(pt.Om[(f,l)],I)@tr.X[f][l]@C)
    return tot
def Psi2(A,B,p1,p2,inverse=False):
    """sum_{r CR} sum_{k=0}^{l-1} F_A(r^p1) F_B(rot_k(r)^p2); inverse: rot_k(r^-1)"""
    K=A.K
    slotsB=[ [B.Phi[INV[a]].T for a in range(4)] ]*p2 if inverse else [list(B.Phi)]*p2
    tr=Transfer([list(A.Phi)]*p1+slotsB)
    Close=np.kron(cyc_closure(p1,K),cyc_closure(p2,K))
    IA=np.eye(K**p1);IB1=np.eye(K**(p2-1));IA1=np.eye(K**(p1-1))
    def OmB(prev,nxt,start=False):
        if not inverse: return B.Om[(nxt,prev)]
        return B.Om[(INV[prev],INV[nxt])].T
    tot=0
    for f in range(4):
        for l in range(4):
            if l==INV[f]: continue
            SA=np.kron(A.Om[(f,l)],IA1)
            # k=0
            Start0=np.kron(SA,np.kron(OmB(l,f),IB1))
            tot+=np.trace(Start0@tr.X[f][l]@Close)
            # k>=1
            Start=np.kron(SA,np.eye(K**p2))
            for prev in range(4):
                for nxt in range(4):
                    if nxt==INV[prev]: continue
                    Ins=np.kron(IA,np.kron(OmB(prev,nxt),IB1))
                    tot+=np.trace(Start@tr.X[f][prev]@Ins@tr.X[nxt][l]@Close)
    return tot
# ---------- brute-force references ----------
def cr_words(lmax):
    out=[]
    for l in range(1,lmax+1):
        ws=[[]]
        for i in range(l): ws=[w+[x] for w in ws for x in range(4) if not (w and x==INV[w[-1]])]
        out+=[tuple(w) for w in ws if w[-1]!=INV[w[0]]]
    return out
def winv(w): return tuple(INV[x] for x in reversed(w))
def brute_M_d(pt,d,lmax): return sum(pt.F(y*d) for y in cr_words(lmax))
def brute_Psi2(A,B,p1,p2,lmax,inverse=False):
    tot=0
    for r in cr_words(lmax):
        fa=A.F(r*p1);l=len(r)
        for k in range(l):
            if inverse:
                P,S=r[:k],r[k:];rr=winv(P)+winv(S)
            else: rr=r[k:]+r[:k]
            tot+=fa*B.F(rr*p2)
    return tot

def Psi3(A,B,C,invB=False,invC=False):
    """sum_{r CR} sum_{k1,k2} F_A(r) F_B(rot_k1 r [or of r^-1]) F_C(rot_k2 r [or of r^-1]) (first powers)"""
    K=A.K;I=np.eye(K)
    sl=lambda P,inv: [P.Phi[INV[a]].T for a in range(4)] if inv else list(P.Phi)
    tr=Transfer([list(A.Phi),sl(B,invB),sl(C,invC)]);X=tr.X
    def Om(P,inv,prev,nxt):
        return P.Om[(INV[prev],INV[nxt])].T if inv else P.Om[(nxt,prev)]
    k3=lambda a,b,c: np.kron(a,np.kron(b,c))
    pairs=[(p,n) for p in range(4) for n in range(4) if n!=INV[p]]
    InsB={pn:k3(I,Om(B,invB,*pn),I) for pn in pairs};InsC={pn:k3(I,I,Om(C,invC,*pn)) for pn in pairs}
    InsBC={pn:k3(I,Om(B,invB,*pn),Om(C,invC,*pn)) for pn in pairs}
    # one-cut kernels: Y[a][b] = sum_{(p,n)} X[a][p] Ins(p,n) X[n][b]
    def onecut(Ins):
        return [[sum(X[a][p]@Ins[(p,n)]@X[n][b] for (p,n) in pairs) for b in range(4)] for a in range(4)]
    YB=onecut(InsB);YC=onecut(InsC);YBC=onecut(InsBC)
    # two ordered cuts: Z[a][b] = sum X[a][p1] InsB X[n1][p2] InsC X[n2][b] = sum_{(p2,n2)} YB[a][p2] InsC X[n2][b]
    ZBC=[[sum(YB[a][p]@InsC[(p,n)]@X[n][b] for (p,n) in pairs) for b in range(4)] for a in range(4)]
    ZCB=[[sum(YC[a][p]@InsB[(p,n)]@X[n][b] for (p,n) in pairs) for b in range(4)] for a in range(4)]
    tot=0
    for f in range(4):
        for l in range(4):
            if l==INV[f]: continue
            OA=A.Om[(f,l)];OB0=Om(B,invB,l,f);OC0=Om(C,invC,l,f)
            tot+=np.trace(k3(OA,OB0,OC0)@X[f][l])
            tot+=np.trace(k3(OA,OB0,I)@YC[f][l])
            tot+=np.trace(k3(OA,I,OC0)@YB[f][l])
            SA=k3(OA,I,I)
            tot+=np.trace(SA@(YBC[f][l]+ZBC[f][l]+ZCB[f][l]))
    return tot
def brute_Psi3(A,B,C,lmax,invB=False,invC=False,bylen=False):
    out=np.zeros(lmax+1,complex)
    for r in cr_words(lmax):
        l=len(r);fa=A.F(r)
        rotB=[(winv(r[:k])+winv(r[k:])) if invB else r[k:]+r[:k] for k in range(l)]
        rotC=[(winv(r[:k])+winv(r[k:])) if invC else r[k:]+r[:k] for k in range(l)]
        fb=sum(B.F(x) for x in rotB);fc=sum(C.F(x) for x in rotC)
        out[l]+=fa*fb*fc
    return out if bylen else out.sum()
