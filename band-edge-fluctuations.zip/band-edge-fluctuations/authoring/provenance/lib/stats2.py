import numpy as np, time, sys
from stats import Stats
from classes import primitive_classes, winv, ndiv
def sigma(n): return sum(d for d in range(1,n+1) if n%d==0)
class Fast(Stats):
    def rot_products(s,u):
        """returns list of (first,last,Yprod (nodes,K,K)) for all rotations of u"""
        l=len(u);K=s.K;Ph=s.Phi
        pre=[np.broadcast_to(np.eye(K,dtype=complex),(s.nodes,K,K))]
        for x in u: pre.append(pre[-1]@Ph[:,x])
        suf=[np.broadcast_to(np.eye(K,dtype=complex),(s.nodes,K,K))]
        for x in reversed(u): suf.append(Ph[:,x]@suf[-1])
        out=[]
        for k in range(l):
            # rot_k u = u[k:]+u[:k] ; product = (prod u[k:]) (prod u[:k]) = suf[l-k] @ pre[k]
            out.append((u[k],u[k-1],suf[l-k]@pre[k]))
        return out
    def Tlist(s,u,nmax):
        T=np.zeros(nmax+1)
        for word in (u,winv(u)):
            for f,l,Y in s.rot_products(word):
                om=s.Om[(f,l)];Yn=Y
                for n in range(1,nmax+1):
                    if n>1: Yn=Yn@Y
                    T[n]+=np.sum(s.w*np.einsum('nk,nk->n',om,Yn.reshape(s.nodes,-1))).real
        return T
    def run2(s,lmax,lnmax,verbose=True):
        acc={k:0.0 for k in ['M','V','K3','V_noinv','V_j1','K3_j1','M_d2only']}
        per={}
        t0=time.time()
        for u in primitive_classes(lmax):
            l=len(u);nmax=max(1,lnmax//l)
            T=s.Tlist(u,nmax)
            m=sum((ndiv(n)-1)*T[n] for n in range(2,nmax+1))
            acc['M']+=m;acc['M_d2only']+=sum(T[n] for n in range(2,nmax+1))
            v=0;k3=0
            for j in range(1,nmax+1):
                S=sum(T[j*mm] for mm in range(1,nmax//j+1))
                v+=j*S*S;k3+=j*j*S**3
                if j==1: acc['V_j1']+=S*S;acc['K3_j1']+=S**3
            acc['V']+=v;acc['K3']+=k3
            pp=per.setdefault(l,[0,0,0]);pp[0]+=m;pp[1]+=v;pp[2]+=k3
        if verbose:
            for l in sorted(per): print(f"  l={l:2d} M {per[l][0]:+.3e} V {per[l][1]:+.3e} K3 {per[l][2]:+.3e}")
            print("  time",time.time()-t0)
        return acc
if __name__=="__main__":
    B,lam,beta=float(sys.argv[1]),float(sys.argv[2]),float(sys.argv[3]);lmax=int(sys.argv[4]);lnmax=int(sys.argv[5])
    S=Fast(B,lam,beta,nodes=160)
    Z=np.trace(S.c_e()).real/2
    acc=S.run2(lmax,lnmax)
    print(f"Z_inf={Z:.15f}")
    print(f"M(2N convention)={acc['M']-2*Z:.15f}   [M_old={acc['M']:.15f}]")
    print(f"V={acc['V']:.15f}\nK3={acc['K3']:.15f}")
    print("ablations: M_d2only",acc['M_d2only'],"V_j1",acc['V_j1'],"K3_j1",acc['K3_j1'])
