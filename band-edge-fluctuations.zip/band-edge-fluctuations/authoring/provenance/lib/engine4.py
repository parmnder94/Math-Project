"""K=4 exact-resummation engine with general small powers."""
import numpy as np, itertools
from lin4 import Lin4
INV=[1,0,3,2]
PAIRS=[(p,n) for p in range(4) for n in range(4) if n!=INV[p]]
class Point:
    def __init__(s,B,lam,z):
        L=Lin4(B,lam);s.K=K=L.K;s.z=z
        sgn=1 if z.imag>0 else -1
        H=L.iterate(complex(z.real,sgn*0.5))
        for e in [0.3,0.2,0.1,0.05,0.03,0.02,0.01,0.005]:
            if abs(z.imag)<e: H,_=L.newton(H,complex(z.real,sgn*e))
        H,ok=L.newton(H,z);assert ok
        s.Phi=np.array([H[a]@L.A[a] for a in range(4)]);s.G=L.Gfull(H,z);s.trce=np.trace(s.G[:2,:2])
        KK=K*K;Ak=[np.kron(s.Phi[a],s.Phi[INV[a]].T) for a in range(4)]
        T=np.zeros((4*KK,4*KK),complex)
        for a in range(4):
            for b in range(4):
                if a!=INV[b]: T[a*KK:(a+1)*KK,b*KK:(b+1)*KK]=Ak[a]
        s.conj_spr=max(abs(np.linalg.eigvals(T)))
        g=np.zeros((K,K),complex);g[:2,:]=s.G[:,:2].T;gv=g.ravel()
        adj=np.linalg.solve((np.eye(4*KK)-T).T,np.concatenate([gv]*4));s.Om={}
        for f in range(4):
            for l in range(4):
                if l==INV[f]: continue
                om=gv.copy()
                for t in range(4):
                    if t!=INV[f] and t!=l: om=om+Ak[t].T@adj[t*KK:(t+1)*KK]
                s.Om[(f,l)]=om.reshape(K,K).T
    def F(s,y):
        M=np.eye(s.K,dtype=complex)
        for x in y: M=M@s.Phi[x]
        return np.trace(s.Om[(y[0],y[-1])]@M)
def kron_all(ms):
    out=ms[0]
    for m in ms[1:]: out=np.kron(out,m)
    return out
_CC={}
def cyc_closure(p,K):
    if (p,K) in _CC: return _CC[(p,K)]
    D=K**p;C=np.zeros((D,D))
    for idx in itertools.product(range(K),repeat=p):
        C[np.ravel_multi_index(idx[1:]+idx[:1],(K,)*p),np.ravel_multi_index(idx,(K,)*p)]=1
    _CC[(p,K)]=C;return C
class Transfer:
    def __init__(s,slots):
        Dl=[kron_all([sl[a] for sl in slots]) for a in range(4)];D=Dl[0].shape[0]
        T=np.zeros((4*D,4*D),complex)
        for a in range(4):
            for b in range(4):
                if b!=INV[a]: T[a*D:(a+1)*D,b*D:(b+1)*D]=Dl[b]
        s.spr=None
        W=np.linalg.inv(np.eye(4*D)-T)
        s.X=[[Dl[a]@W[a*D:(a+1)*D,b*D:(b+1)*D] for b in range(4)] for a in range(4)]
def M_d(pt,d):
    K=pt.K;tr=Transfer([list(pt.Phi)]*d);C=cyc_closure(d,K);I=np.eye(K**(d-1))
    return sum(np.trace(np.kron(pt.Om[(f,l)],I)@tr.X[f][l]@C) for f in range(4) for l in range(4) if l!=INV[f])
def slot_mats(P,inv): return [P.Phi[INV[a]].T for a in range(4)] if inv else list(P.Phi)
def cut_om(P,inv,prev,nxt): return P.Om[(INV[prev],INV[nxt])].T if inv else P.Om[(nxt,prev)]
def PsiMarked(slots):
    """slots: list of (Point, inv, power). Slot 0 is the unrotated reference (inv must be False).
    Returns sum_{r cyc. reduced} prod_i [sum_{k_i} F_i(rot_{k_i}(r or r^-1)^{p_i})] with the k_0 = 0 fixed."""
    K=slots[0][0].K
    tr=Transfer(sum([[slot_mats(P,inv)]*p for (P,inv,p) in slots],[]));X=tr.X
    dims=[K**p for (_,_,p) in slots]
    Close=kron_all([cyc_closure(p,K) for (_,_,p) in slots])
    def op(i,M):   # operator acting as M (x) I on slot i's first copy, identity elsewhere
        mats=[]
        for j,(P,inv,p) in enumerate(slots):
            mats.append(np.kron(M,np.eye(K**(p-1))) if j==i else np.eye(dims[j]))
        return kron_all(mats)
    nS=len(slots);tot=0
    # each rotated slot i>=1 is either at cut 0 (start) or at some interior cut; interior cuts are ordered
    # positions; several slots may share a cut. Enumerate: subset at start; ordered set partition of the rest.
    rest=list(range(1,nS))
    def ordered_partitions(items):
        if not items: yield [];return
        for k in range(1,len(items)+1):
            for first in itertools.combinations(items,k):
                remaining=[x for x in items if x not in first]
                for tail in ordered_partitions(remaining): yield [list(first)]+tail
    for f in range(4):
        for l in range(4):
            if l==INV[f]: continue
            for mask in range(1<<len(rest)):
                at0=[rest[i] for i in range(len(rest)) if mask>>i&1];inner=[x for x in rest if x not in at0]
                S=op(0,slots[0][0].Om[(f,l)])
                for i in at0: S=S@op(i,cut_om(slots[i][0],slots[i][1],l,f))
                for blocks in ordered_partitions(inner):
                    # chain: S X[f][p1] Ins1 X[n1][p2] Ins2 ... X[nm][l] Close
                    def chain(cur,a,bi):
                        if bi==len(blocks): return np.trace(cur@X[a][l]@Close)
                        s=0
                        for (p,n) in PAIRS:
                            Ins=np.eye(cur.shape[0],dtype=complex)
                            for i in blocks[bi]: Ins=Ins@op(i,cut_om(slots[i][0],slots[i][1],p,n))
                            s+=chain(cur@X[a][p]@Ins,n,bi+1)
                        return s
                    tot+=chain(S,f,0)
    return tot
def cr_words(lmax):
    out=[]
    for l in range(1,lmax+1):
        ws=[[]]
        for i in range(l): ws=[w+[x] for w in ws for x in range(4) if not (w and x==INV[w[-1]])]
        out+=[tuple(w) for w in ws if w[-1]!=INV[w[0]]]
    return out
def winv(w): return tuple(INV[x] for x in reversed(w))
def brute_marked(slots,lmax,bylen=True):
    out=np.zeros(lmax+1,complex)
    for r in cr_words(lmax):
        l=len(r);prod=slots[0][0].F(r*slots[0][2])
        for (P,inv,p) in slots[1:]:
            prod*=sum(P.F(((winv(r[:k])+winv(r[k:])) if inv else r[k:]+r[:k])*p) for k in range(l))
        out[l]+=prod
    return out
