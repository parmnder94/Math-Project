import numpy as np
from scipy.optimize import fsolve
# letters: (i,+1)/(i,-1) for generator i. Word = tuple of letters (length 0,1,2)
def inv_letter(l): return (l[0],-l[1])
def linearize(k, d, c0, lin, quad):
    """P = c0 + sum_{l} lin[l] (x) lambda(l) + sum_{(s,t)} [quad[(s,t)] (x) lambda(s)lambda(t) + h.c.]
       lin must be hermitian-closed (lin[inv l] = lin[l]^*). quad lists one member of each hermitian pair.
       Returns K, b0, dict letter->b (K x K), with L = b0 + sum b_l lambda(l), P = Schur complement on first k."""
    q=len(quad); K=k*(1+2*q)
    letters=[(i,e) for i in range(d) for e in (1,-1)]
    b0=np.zeros((K,K),complex); B={l:np.zeros((K,K),complex) for l in letters}
    b0[:k,:k]=c0
    for l,a in lin.items(): B[l][:k,:k]+=a
    for j,((s,t),c) in enumerate(quad.items()):
        r1=slice(k*(1+2*j),k*(2+2*j)); r2=slice(k*(2+2*j),k*(3+2*j))
        # Q block [[0,I],[I,0]] at (r1,r2)
        b0[r1,r2]=np.eye(k); b0[r2,r1]=np.eye(k)
        # Y rows: y1 = -I lambda(s^-1) in row r1 ; y2 = c lambda(t) in row r2 ; L = [[L0, Y^*],[Y,Q]]
        B[inv_letter(s)][r1,:k]+=-np.eye(k)          # Y block (row r1, col 0): coefficient on letter s^-1
        B[s][:k,r1]+=-np.eye(k)                      # Y^* block: adjoint, letter s
        B[t][r2,:k]+=c
        B[inv_letter(t)][:k,r2]+=np.array(c).conj().T
    return K,b0,B,letters
def check_herm(b0,B):
    assert np.allclose(b0,b0.conj().T)
    for l in B: assert np.allclose(B[l], B[inv_letter(l)].conj().T)
class Tree:
    def __init__(s,K,b0,B,letters,k):
        s.K=K;s.b0=b0;s.letters=letters;s.A=[B[l] for l in letters];s.k=k
        s.inv=[letters.index(inv_letter(l)) for l in letters]; s.m=len(letters)
    # convention: H_l = (Lam - b0 - sum_{l'!=l^-1} A_{l'}^* H_{l'} A_{l'})^{-1}
    # here A_l is coefficient of lambda(l): matrix element <delta_{l w}, L delta_w> = A_l
    def F(s,H,Lam):
        out=[]
        for a in range(s.m):
            Sig=sum(s.A[t].conj().T@H[t]@s.A[t] for t in range(s.m) if t!=s.inv[a])
            out.append(np.linalg.inv(Lam-s.b0-Sig))
        return out
    def Gfull(s,H,Lam):
        Sig=sum(s.A[t].conj().T@H[t]@s.A[t] for t in range(s.m))
        return np.linalg.inv(Lam-s.b0-Sig)
    def Lam(s,z,eps):
        L=1j*eps*np.eye(s.K,dtype=complex); L[:s.k,:s.k]=z*np.eye(s.k); return L
    def solve(s,z,eps=1e-9,H0=None,iters=20000,newton=True):
        Lam=s.Lam(z,eps)
        H=H0 if H0 is not None else [-1j*np.eye(s.K) for _ in range(s.m)]
        for it in range(iters):
            Hn=s.F(H,Lam); err=max(np.abs(Hn[a]-H[a]).max() for a in range(s.m))
            H=[0.5*H[a]+0.5*Hn[a] for a in range(s.m)]
            if err<1e-13: break
        if newton:
            K=s.K;m=s.m
            def unpack(v): return [v[i*K*K:(i+1)*K*K].reshape(K,K) for i in range(m)]
            def res(vr):
                v=vr[:len(vr)//2]+1j*vr[len(vr)//2:]
                r=np.concatenate([h.ravel() for h in s.F(unpack(v),Lam)])-v
                return np.concatenate([r.real,r.imag])
            v=np.concatenate([h.ravel() for h in H]);vr=np.concatenate([v.real,v.imag])
            vr=fsolve(res,vr,xtol=1e-14)
            H=unpack(vr[:len(vr)//2]+1j*vr[len(vr)//2:])
        return H,it
    def Gp(s,z,eps=1e-9,H0=None,**kw):
        H,it=s.solve(z,eps,H0,**kw); G=s.Gfull(H,s.Lam(z,eps)); return G[:s.k,:s.k],H,it
