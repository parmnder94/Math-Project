import numpy as np, sys, json
from stats2 import Fast
from fs import Lin
from edge_engine import Point
from edge_assemble import assemble
class TwoPoint(Fast):
    def __init__(s,B,lam,z):
        s.L=Lin(B,lam);s.K=s.L.K
        pts=[Point(B,lam,z),Point(B,lam,np.conj(z))]
        s.w=np.array([0.5j,-0.5j]);s.Phi=np.array([p.Phi for p in pts]);s.G=np.array([p.G for p in pts]);s.nodes=2
        s._omega()
if __name__=="__main__":
    B,lam=1.5,0.6;x0,eta=float(sys.argv[1]),float(sys.argv[2]);z=complex(x0,eta)
    S=TwoPoint(B,lam,z);tr=np.einsum('n,nii->',S.w,S.G[:,:2,:2]).real
    acc=S.run2(int(sys.argv[3]),int(sys.argv[4]),verbose=False)
    enum={"z_inf":tr/2,"mean_correction":acc['M']-tr,"variance":acc['V'],"third_cumulant":acc['K3']}
    res,info=assemble(B,lam,x0,eta,lmax=int(sys.argv[5]),lnmax=int(sys.argv[4]))
    for k in enum: print(f"{k:16s} enumeration {enum[k]:+.12e}  exact-resummed {res[k]:+.12e}  rel diff {abs(enum[k]-res[k])/abs(res[k]):.1e}")
