import numpy as np, time, sys
from fs import Lin
from words import INV
from classes import primitive_classes, rotations, winv, ndiv
class Stats:
    def __init__(s,B,lam,beta,center=0.5,ra=8.0,rb=3.5,nodes=400):
        s.L=Lin(B,lam);K=s.L.K;s.K=K
        zs,dz,data=s.L.contour(center,ra,rb,nodes)
        s.w=np.exp(-beta*zs)*dz                       # quadrature weights incl. h(z)
        s.Phi=np.array([[d[2][a] for a in range(4)] for d in data])   # (nodes,4,K,K)
        s.G=np.array([d[3] for d in data])                             # (nodes,K,K)
        s.nodes=nodes
        s._omega()
    def _omega(s):
        """Omega[(f,l)] (nodes,K,K): F(y)=sum_nodes w * sum_ij Omega[i,j] Y[i,j] for cyclically reduced y with first f,last l"""
        K=s.K;N=s.nodes;s.Om={}
        I=np.eye(4*K*K)
        # superoperator T on (Psi_s)_s: Psi_s += A_s(Psi_s') if s != INV[s'] ; A_s(X)=Phi_s X Phi_{INV s}
        # vec(Phi_s X Phi_t) = (Phi_s kron Phi_t^T) vec(X) (row-major)
        for n in range(N):
            Ph=s.Phi[n];Gn=s.G[n]
            Ak=[np.kron(Ph[a],Ph[INV[a]].T) for a in range(4)]
            T=np.zeros((4*K*K,4*K*K),complex)
            for a in range(4):
                for b in range(4):
                    if a!=INV[b]: T[a*K*K:(a+1)*K*K,b*K*K:(b+1)*K*K]=Ak[a]
            Minv=np.linalg.inv(I-T)
            # functional on Total = Y + sum_s Psi_s : f = tr([Total G]_{11}) = sum_ij Total[i,j]*(G[j,i] for i<2)
            g=np.zeros((K,K),complex);g[:2,:]=Gn[:,:2].T     # f(X)=sum_ij X[i,j] g[i,j] with i<2 rows
            gv=g.ravel()
            for f in range(4):
                for l in range(4):
                    if l==INV[f]: continue
                    allowed=[t for t in range(4) if t!=INV[f] and t!=l]
                    # b(Y) = [allowed_s * A_s vec(Y)]; Psi = Minv b ; f(Total)=gv.(vecY + sum_s Psi_s)
                    # => Omega vec = gv + sum_s (Minv^T [gv,gv,gv,gv])_s restricted... use adjoint
                    big=np.concatenate([gv]*4)
                    adj=Minv.T@big          # (4KK,)
                    om=gv.copy()
                    for t in allowed: om=om+Ak[t].T@adj[t*K*K:(t+1)*K*K]
                    s.Om.setdefault((f,l),np.zeros((N,K*K),complex))[n]=om
    def F(s,y_letters,n):
        """F for y = r^n where r cyclically reduced word (tuple). returns integrated value"""
        K=s.K
        M=np.broadcast_to(np.eye(K,dtype=complex),(s.nodes,K,K)).copy()
        for x in y_letters: M=M@s.Phi[:,x]
        Y=np.linalg.matrix_power(M,n) if n>1 else M
        om=s.Om[(y_letters[0],y_letters[-1])]
        return np.sum(s.w*np.einsum('nk,nk->n',om,Y.reshape(s.nodes,K*K)))
    def c_e(s): return np.einsum('n,nij->ij',s.w,s.G[:,:2,:2])
    def T(s,u,n):
        return sum(s.F(r,n) for r in rotations(u))+sum(s.F(r,n) for r in rotations(winv(u)))
    def run(s,lmax,lnmax):
        cls=primitive_classes(lmax);Mtot=0;V=0;K3=0;per_len={}
        for u in cls:
            l=len(u);nmax=max(1,lnmax//l)
            Tn={n:s.T(u,n) for n in range(1,nmax+1)}
            Mtot+=sum((ndiv(n)-1)*Tn[n] for n in Tn if n>=2)
            for j in range(1,nmax+1):
                S=sum(Tn[j*m] for m in range(1,nmax//j+1))
                V+=j*S*S;K3+=j*j*S**3
            pl=per_len.setdefault(l,[0,0,0])
            pl[0]+=sum((ndiv(n)-1)*Tn[n] for n in Tn if n>=2);pl[1]+=sum(j*(sum(Tn[j*m] for m in range(1,nmax//j+1)))**2 for j in range(1,nmax+1))
        return Mtot,V,K3,per_len
if __name__=="__main__":
    B,lam,beta=float(sys.argv[1]),float(sys.argv[2]),float(sys.argv[3])
    lmax=int(sys.argv[4]);lnmax=int(sys.argv[5])
    t0=time.time();S=Stats(B,lam,beta);print("setup",time.time()-t0)
    ce=S.c_e();print("Z_inf=",np.trace(ce).real/2)
    M,V,K3,pl=S.run(lmax,lnmax)
    print("M=",M,"V=",V,"K3=",K3,"t=",time.time()-t0)
    for l in sorted(pl): print(l,pl[l][0].real,pl[l][1].real)
