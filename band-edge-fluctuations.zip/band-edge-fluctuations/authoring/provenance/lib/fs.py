# Finite-size statistics machinery: linearized tree resolvent along a contour
import numpy as np
from lin import linearize, inv_letter
from cactus import R, sx, sy, sz, I2, modelA as cactus_model
LETTERS=[(0,1),(0,-1),(1,1),(1,-1)]   # a, a^-1, b, b^-1
def model(B,lam):
    Ta=R(sx,lam);Tb=R(sy,lam);Tc=R(sz,lam)
    lin={(0,1):Ta,(0,-1):Ta.conj().T,(1,1):Tb,(1,-1):Tb.conj().T}
    quad={((0,1),(1,1)):Tc}   # Tc (x) lambda(a)lambda(b) + h.c.
    K,b0,Bm,letters=linearize(2,2,B*sz,lin,quad)
    A=[Bm[l] for l in LETTERS]
    inv=[LETTERS.index(inv_letter(l)) for l in LETTERS]
    return K,b0,A,inv
class Lin:
    def __init__(s,B,lam):
        s.K,s.b0,s.A,s.inv=model(B,lam);s.m=4
    def Lam(s,z):
        L=np.zeros((s.K,s.K),complex);L[0,0]=L[1,1]=z;return L
    def F(s,H,z):
        Lz=s.Lam(z);out=[]
        for a in range(4):
            Sig=sum(s.A[t].conj().T@H[t]@s.A[t] for t in range(4) if t!=s.inv[a])
            out.append(np.linalg.inv(Lz-s.b0-Sig))
        return out
    def newton(s,H,z,tol=1e-14,maxit=60):
        K=s.K
        def vec(H): return np.concatenate([h.ravel() for h in H])
        def mat(v): return [v[i*K*K:(i+1)*K*K].reshape(K,K) for i in range(4)]
        v=vec(H)
        for it in range(maxit):
            Hm=mat(v);Fs=s.F(Hm,z);r=vec(Fs)-v
            if np.abs(r).max()<tol: return mat(v),True
            # analytic Jacobian (holomorphic): dF_a = F_a (sum A^* dH A) F_a
            n=len(v);J=np.zeros((n,n),complex)
            for t in range(4):
                for j in range(K*K):
                    E=np.zeros(K*K,complex);E[j]=1;E=E.reshape(K,K)
                    X=s.A[t].conj().T@E@s.A[t]
                    col=[(Fs[a]@X@Fs[a] if t!=s.inv[a] else np.zeros((K,K))) for a in range(4)]
                    J[:,t*K*K+j]=vec(col)
            J-=np.eye(n)
            v=v-np.linalg.solve(J,r)
        return mat(v),False
    def iterate(s,z,H=None,iters=20000,tol=1e-13):
        H=H if H is not None else [-1j*np.eye(s.K) for _ in range(4)]
        for it in range(iters):
            Hn=s.F(H,z);err=max(np.abs(Hn[a]-H[a]).max() for a in range(4))
            H=[0.5*H[a]+0.5*Hn[a] for a in range(4)]
            if err<tol: break
        return H
    def Gfull(s,H,z):
        Sig=sum(s.A[t].conj().T@H[t]@s.A[t] for t in range(4))
        return np.linalg.inv(s.Lam(z)-s.b0-Sig)
    def contour(s,center,ra,rb,nodes):
        """ellipse z=center+ra cos t + i rb sin t; returns z, dz/dt*dt/(2 pi i) weights, H list, Phi, G"""
        ts=np.pi/2+2*np.pi*np.arange(nodes)/nodes   # start at top
        zs=center+ra*np.cos(ts)+1j*rb*np.sin(ts)
        dz=(-ra*np.sin(ts)+1j*rb*np.cos(ts))*(2*np.pi/nodes)/(2j*np.pi)
        H=s.iterate(zs[0]);H,ok=s.newton(H,zs[0]);assert ok
        out=[]
        for z in zs:
            H,ok=s.newton(H,z)
            if not ok:
                raise RuntimeError("newton failed at %s"%z)
            Phi=[H[a]@s.A[a] for a in range(4)]
            out.append((z,H,Phi,s.Gfull(H,z)))
        return zs,dz,out
if __name__=="__main__":
    B,lam=1.5,0.6
    L=Lin(B,lam);c=cactus_model(B,lam)
    for z in [1+2j,-3+0.5j,6+1j]:
        H=L.iterate(z);H,ok=L.newton(H,z);G=L.Gfull(H,z)[:2,:2]
        Sig,_=c.solve(z,iters=200000,tol=1e-15);Gc=c.G(Sig,z)
        print(z,ok,np.abs(G-Gc).max())
