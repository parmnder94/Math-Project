"""Optimized marked transfers (<=3 slots, small powers) + exact assembly with K=4."""
import numpy as np, itertools, time
from math import gcd
from engine4 import Point, Transfer, M_d, kron_all, cyc_closure, slot_mats, cut_om, PAIRS, INV, cr_words, winv
def psi_marked(slots):
    """sum_{r cyc.red.} F_0(r^p0) * prod_{i>=1} sum_{k_i} F_i(rot_{k_i}(r or r^-1)^{p_i}); slots=[(Point,inv,p)]"""
    K=slots[0][0].K;n=len(slots)
    X=Transfer(sum([[slot_mats(P,inv)]*p for (P,inv,p) in slots],[])).X
    dims=[K**p for (_,_,p) in slots];Close=kron_all([cyc_closure(p,K) for (_,_,p) in slots])
    def op(i,M): return kron_all([np.kron(M,np.eye(K**(p-1))) if j==i else np.eye(dims[j]) for j,(P,inv,p) in enumerate(slots)])
    ins_cache={}
    def Ins(block,pn):
        key=(block,pn)
        if key not in ins_cache:
            M=None
            for i in block:
                O=op(i,cut_om(slots[i][0],slots[i][1],*pn));M=O if M is None else M@O
            ins_cache[key]=M
        return ins_cache[key]
    def onecut(block,L):   # sum_{(p,n)} L[a][p] Ins X[n][b]
        return [[sum(L[a][p]@Ins(block,(p,n))@X[n][b] for (p,n) in PAIRS) for b in range(4)] for a in range(4)]
    rest=tuple(range(1,n))
    def ordered_partitions(items):
        if not items: yield [];return
        for k in range(1,len(items)+1):
            for first in itertools.combinations(items,k):
                remaining=tuple(x for x in items if x not in first)
                for tail in ordered_partitions(remaining): yield [first]+tail
    kernels={}
    def kernel(blocks):
        key=tuple(blocks)
        if key not in kernels:
            if not blocks: kernels[key]=X
            else:
                prev=kernel(blocks[:-1]) if len(blocks)>1 else X
                kernels[key]=onecut(blocks[-1],prev)
        return kernels[key]
    tot=0
    for mask in range(1<<len(rest)):
        at0=tuple(rest[i] for i in range(len(rest)) if mask>>i&1);inner=tuple(x for x in rest if x not in at0)
        for blocks in ordered_partitions(inner):
            Kb=kernel(blocks)
            for f in range(4):
                for l in range(4):
                    if l==INV[f]: continue
                    S=op(0,slots[0][0].Om[(f,l)])
                    for i in at0: S=S@op(i,cut_om(slots[i][0],slots[i][1],l,f))
                    tot+=np.trace(Close@S@Kb[f][l])
    return tot
# ---------------- class table (fast tails)
from classes import primitive_classes, rotations
def class_table(pt,lmax,lnmax):
    K=pt.K;tab={}
    for u in primitive_classes(lmax):
        l=len(u);nmax=max(1,lnmax//l);T=np.zeros(nmax+1,complex)
        for word in (u,winv(u)):
            for r in rotations(word):
                M=np.eye(K,dtype=complex)
                for x in r: M=M@pt.Phi[x]
                Om=pt.Om[(r[0],r[-1])];Mn=M
                for k in range(1,nmax+1):
                    if k>1: Mn=Mn@M
                    T[k]+=np.trace(Om@Mn)
        tab[u]=T
    return tab
def divs(n): return [d for d in range(1,n+1) if n%d==0]
def assemble4(B,lam,x0,eta,lmax=11,lnmax=26,exact_max=4,verbose=False):
    t0=time.time();z=complex(x0,eta);A=Point(B,lam,z);Ab=Point(B,lam,np.conj(z))
    trce_h=float(-np.imag(A.trce))
    tab=class_table(A,lmax,lnmax)
    Tg=lambda u,k: tab[u][k] if k<len(tab[u]) else 0.0
    PT={'+':A,'-':Ab}
    def Tsig(u,k,s): t=Tg(u,k);return t if s=='+' else np.conj(t)
    # generic Pi over sign patterns: Sigma_kappa prod_i T^{(s_i)}(n_i), exact if sum(n)<=exact_max (with Moebius), else enumeration
    memo={}
    def Pi(ns,signs):
        key=(ns,signs)
        if key in memo: return memo[key]
        if sum(ns)>exact_max:
            val=sum(np.prod([Tsig(u,k,s) for k,s in zip(ns,signs)]) for u in tab)
        else:
            psi=0
            for invs in itertools.product([False,True],repeat=len(ns)-1):
                slots=[(PT[signs[0]],False,ns[0])]+[(PT[s],iv,k) for k,s,iv in zip(ns[1:],signs[1:],invs)]
                psi+=psi_marked(slots)
            corr=sum(q**(len(ns)-1)*Pi(tuple(q*k for k in ns),signs) for q in range(2,lnmax//min(ns)+1) if q*max(ns)<=lnmax)
            val=psi-corr
        memo[key]=val;return val
    # mean
    Md={}
    for d in range(2,lnmax+1):
        Md[d]=M_d(A,d) if d<=exact_max else sum(Tg(u,q*d) for u in tab for q in range(1,lnmax//d+1))
    m=sum(-np.imag(v) for v in Md.values())-trce_h
    # variance
    def ImIm(n1,n2): return 0.5*np.real(Pi((n1,n2),('+','-'))-Pi((n1,n2),('+','+')))
    v=sum(sum(divs(gcd(n1,n2)))*ImIm(n1,n2) for n1 in range(1,lnmax) for n2 in range(1,lnmax) if n1+n2<=lnmax)
    # third cumulant: sum_kappa prod Im T = (1/(-8i)) sum_s (-1)^{#-} Pi(ns,s)
    def ImImIm(ns):
        tot=0
        for s in itertools.product('+-',repeat=3):
            tot+=(-1)**s.count('-')*Pi(ns,s)
        return np.real(tot/(-8j))
    k=0.0
    for n1 in range(1,lnmax):
        for n2 in range(1,lnmax):
            for n3 in range(1,lnmax):
                if n1+n2+n3>lnmax: continue
                k+=sum(d*d for d in divs(gcd(gcd(n1,n2),n3)))*(-ImImIm((n1,n2,n3)))
    res={"z_inf":trce_h/2,"mean_correction":float(m),"variance":float(v),"third_cumulant":float(k)}
    if verbose: print("time",time.time()-t0,"conj_spr",A.conj_spr)
    return res
if __name__=="__main__":
    import sys,json
    x0,eta,lmax,em=float(sys.argv[1]),float(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4])
    res=assemble4(1.5,0.6,x0,eta,lmax=lmax,lnmax=26,exact_max=em,verbose=True)
    print(json.dumps({k:round(v,13) for k,v in res.items()}))
