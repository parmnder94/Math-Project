import numpy as np, time, sys, json
from math import gcd
from edge_engine import Point, M_d, Psi2, Psi3, INV
from classes import primitive_classes, rotations, winv
def sigma(n): return sum(d for d in range(1,n+1) if n%d==0)
def J2(n): return sum(d*d for d in range(1,n+1) if n%d==0)
def ndiv(n): return sum(1 for d in range(1,n+1) if n%d==0)
def class_table(pt,lmax,lnmax):
    K=pt.K;tab={}
    for u in primitive_classes(lmax):
        l=len(u);nmax=max(1,lnmax//l);T=np.zeros(nmax+1,complex)
        for word in (u,winv(u)):
            for k in range(l):
                r=word[k:]+word[:k];M=np.eye(K,dtype=complex)
                for x in r: M=M@pt.Phi[x]
                Om=pt.Om[(r[0],r[-1])];Mn=M
                for n in range(1,nmax+1):
                    if n>1: Mn=Mn@M
                    T[n]+=np.trace(Om@Mn)
        tab[u]=T
    return tab
def assemble(B,lam,x0,eta,lmax=11,lnmax=26,verbose=True):
    t0=time.time();z=complex(x0,eta)
    A=Point(B,lam,z);Ab=Point(B,lam,np.conj(z))
    info={"conj_spr":float(A.conj_spr)}
    trce_h=float(-np.imag(A.trce))           # tr c_e for h = (i/2)(R(z)-R(zbar))
    z_inf=trce_h/2
    tab=class_table(A,lmax,lnmax)
    def Tget(u,n): T=tab[u];return T[n] if n<len(T) else 0.0
    # ---------------- mean
    Md={d:M_d(A,d) for d in (2,3)}
    for d in range(4,lnmax+1):   # M_d = sum_kappa sum_q T(qd)
        Md[d]=sum(Tget(u,q*d) for u in tab for q in range(1,lnmax//d+1))
    m=sum(-np.imag(Md[d]) for d in Md)-trce_h
    info["M_d"]={d:complex(Md[d]) for d in Md}
    # ---------------- variance
    def Pi2_enum(n1,n2,conj2):
        return sum(Tget(u,n1)*(np.conj(Tget(u,n2)) if conj2 else Tget(u,n2)) for u in tab)
    Pi2={}
    for (n1,n2) in [(1,1),(1,2),(2,1)]:
        for conj2,BB in [(False,A),(True,Ab)]:
            psi=Psi2(A,BB,n1,n2,False)+Psi2(A,BB,n1,n2,True)
            corr=sum(q*Pi2_enum(q*n1,q*n2,conj2) for q in range(2,lnmax//(n1+n2)+2))
            Pi2[(n1,n2,conj2)]=psi-corr
    def Pi2h(n1,n2):
        if (n1,n2,False) in Pi2: a,b=Pi2[(n1,n2,True)],Pi2[(n1,n2,False)]
        else: a,b=Pi2_enum(n1,n2,True),Pi2_enum(n1,n2,False)
        return 0.5*np.real(a-b)
    nmax=lnmax
    v=0.0
    for n1 in range(1,nmax+1):
        for n2 in range(1,nmax+1):
            if n1+n2>lnmax: continue
            v+=sigma(gcd(n1,n2))*Pi2h(n1,n2)
    # ---------------- third cumulant
    def Pi3h_enum(n1,n2,n3):
        return -sum(np.imag(Tget(u,n1))*np.imag(Tget(u,n2))*np.imag(Tget(u,n3)) for u in tab)
    S3=Psi3(A,A,A,False,False)+Psi3(A,A,A,True,False)+Psi3(A,A,A,False,True)+Psi3(A,A,A,True,True)
    S21=Psi3(A,A,Ab,False,False)+Psi3(A,A,Ab,True,False)+Psi3(A,A,Ab,False,True)+Psi3(A,A,Ab,True,True)
    # Moebius: Pi3(1,1,1) = Psi3 - sum_{q>=2} q^2 Pi3(q,q,q)
    def P3enum(q,conj3):
        return sum(Tget(u,q)*Tget(u,q)*(np.conj(Tget(u,q)) if conj3 else Tget(u,q)) for u in tab)
    S3p=S3-sum(q*q*P3enum(q,False) for q in range(2,lnmax//3+2))
    S21p=S21-sum(q*q*P3enum(q,True) for q in range(2,lnmax//3+2))
    Pi3_111=0.25*(np.imag(S3p)-3*np.imag(S21p))
    k=J2(1)*Pi3_111
    for n1 in range(1,lnmax+1):
        for n2 in range(1,lnmax+1):
            for n3 in range(1,lnmax+1):
                if (n1,n2,n3)==(1,1,1) or n1+n2+n3>lnmax: continue
                k+=J2(gcd(gcd(n1,n2),n3))*Pi3h_enum(n1,n2,n3)
    info["seconds"]=time.time()-t0
    return {"z_inf":z_inf,"mean_correction":float(m),"variance":float(v),"third_cumulant":float(k)},info
if __name__=="__main__":
    B,lam,x0,eta=1.5,0.6,float(sys.argv[1]),float(sys.argv[2]);lmax=int(sys.argv[3])
    res,info=assemble(B,lam,x0,eta,lmax=lmax,lnmax=int(sys.argv[4]) if len(sys.argv)>4 else 26)
    print(json.dumps(res,indent=1));print("conj_spr",info["conj_spr"],"time",info["seconds"])
