import numpy as np
from fs import Lin
from cactus import R, sx, sy, sz, I2
from lin import inv_letter
LET=[(0,1),(0,-1),(1,1),(1,-1)]
def model4(B,lam):
    Ta,Tb,Tc=R(sx,lam),R(sy,lam),R(sz,lam)
    K=4;m,x=slice(0,2),slice(2,4)
    b0=np.zeros((K,K),complex);A=[np.zeros((K,K),complex) for _ in range(4)]
    b0[m,m]=B*sz-2*I2; b0[x,x]=-I2
    A[0][m,m]+=Ta;A[1][m,m]+=Ta.conj().T;A[2][m,m]+=Tb;A[3][m,m]+=Tb.conj().T
    A[0][m,x]+=I2;  A[1][x,m]+=I2        # Y has I lambda(a^-1) (main->aux); Y* has I lambda(a)
    A[2][x,m]+=Tc;  A[3][m,x]+=Tc.conj().T
    for s in range(4): assert np.allclose(A[s],A[[1,0,3,2][s]].conj().T)
    return K,b0,A
class Lin4(Lin):
    def __init__(s,B,lam):
        s.K,s.b0,s.A=model4(B,lam);s.inv=[1,0,3,2];s.m=4
if __name__=="__main__":
    from cactus import modelA
    from words import P_elem, ga_mul
    B,lam=1.5,0.6;L=Lin4(B,lam);c=modelA(B,lam)
    for z in [1+2j,5.6+0.06j,-3+0.5j]:
        H=L.iterate(complex(z.real,0.5));
        for e in [0.3,0.1,0.05]:
            if z.imag<e: H,_=L.newton(H,complex(z.real,e))
        H,ok=L.newton(H,z);G=L.Gfull(H,z)[:2,:2]
        Sig,_=c.solve(z,iters=400000,tol=1e-15);Sig,_=c.newton(z,Sig);Gc=c.G(Sig,z)
        print("resolvent",z,ok,np.abs(G-Gc).max())
    zs,dz,data=L.contour(0.5,8.0,3.5,300)
    P=P_elem(B,lam);Pk={():np.eye(2,dtype=complex)}
    for k in range(1,6):
        Pk=ga_mul(Pk,P)
        err=0
        for w in [(),(0,),(0,2),(0,0),(2,1,3),(0,2,0,2),(3,1)]:
            num=sum(q*(z**k)*np.linalg.multi_dot([np.eye(L.K)]+[d[2][x] for x in w]+[d[3]])[:2,:2] for (z,H,Phi,G),q,d in zip(data,dz,data))
            err=max(err,np.abs(num-Pk.get(w,0)).max()/max(1,np.abs(Pk.get(w,np.zeros(2))).max()))
        print("moments k",k,"max rel err",err)
