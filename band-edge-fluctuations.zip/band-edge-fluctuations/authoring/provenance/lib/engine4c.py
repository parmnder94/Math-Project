"""Vectorized exact assembly (K=4 linearization)."""
import numpy as np, itertools, time, sys, json
from math import gcd
from engine4 import Point, M_d
from engine4b import psi_marked, class_table


def divs(n): return [d for d in range(1, n + 1) if n % d == 0]


def assemble4(B, lam, x0, eta, lmax=11, lnmax=26, exact_max=4, verbose=False, return_parts=False):
    t0 = time.time(); z = complex(x0, eta); A = Point(B, lam, z); Ab = Point(B, lam, np.conj(z))
    trce_h = float(-np.imag(A.trce))
    tab = class_table(A, lmax, lnmax)
    us = list(tab); TA = np.zeros((len(us), lnmax + 1), complex)
    for i, u in enumerate(us): TA[i, :len(tab[u])] = tab[u]
    IT = TA.imag
    t1 = time.time()
    PT = {'+': A, '-': Ab}
    memo = {}

    def Pi(ns, signs):
        key = (ns, signs)
        if key in memo: return memo[key]
        if sum(ns) > exact_max:
            val = np.sum(np.prod([TA[:, k] if s == '+' else np.conj(TA[:, k]) for k, s in zip(ns, signs)], axis=0))
        else:
            psi = 0
            for invs in itertools.product([False, True], repeat=len(ns) - 1):
                psi += psi_marked([(PT[signs[0]], False, ns[0])] + [(PT[s], iv, k) for k, s, iv in zip(ns[1:], signs[1:], invs)])
            corr = sum(q ** (len(ns) - 1) * Pi(tuple(q * k for k in ns), signs) for q in range(2, lnmax + 1) if q * max(ns) <= lnmax)
            val = psi - corr
        memo[key] = val; return val

    def ImIm(n1, n2):
        if n1 + n2 > exact_max: return float(np.sum(IT[:, n1] * IT[:, n2]))
        return 0.5 * np.real(Pi((n1, n2), ('+', '-')) - Pi((n1, n2), ('+', '+')))

    def ImImIm(ns):
        if sum(ns) > exact_max: return float(np.sum(IT[:, ns[0]] * IT[:, ns[1]] * IT[:, ns[2]]))
        tot = sum((-1) ** s.count('-') * Pi(ns, s) for s in itertools.product('+-', repeat=3))
        return float(np.real(tot / (-8j)))

    Md = {d: (M_d(A, d) if d <= exact_max else np.sum(TA[:, [q * d for q in range(1, lnmax // d + 1)]])) for d in range(2, lnmax + 1)}
    m = sum(-np.imag(v) for v in Md.values()) - trce_h
    v = 0.0; parts = {}
    for n1 in range(1, lnmax):
        for n2 in range(1, lnmax - n1 + 1):
            t = sum(divs(gcd(n1, n2))) * ImIm(n1, n2); v += t; parts[(n1, n2)] = t
    k = 0.0
    for n1 in range(1, lnmax):
        for n2 in range(1, lnmax - n1 + 1):
            for n3 in range(1, lnmax - n1 - n2 + 1):
                t = sum(d * d for d in divs(gcd(gcd(n1, n2), n3))) * (-ImImIm((n1, n2, n3))); k += t; parts[(n1, n2, n3)] = t
    res = {"z_inf": trce_h / 2, "mean_correction": float(m), "variance": float(v), "third_cumulant": float(k)}
    if verbose: print("time", round(time.time() - t0, 1), "(class table", round(t1 - t0, 1), ") conj_spr", A.conj_spr, "classes", len(us), flush=True)
    return (res, parts, Md) if return_parts else res


if __name__ == "__main__":
    x0, eta, lmax, em = float(sys.argv[1]), float(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
    res = assemble4(1.5, 0.6, x0, eta, lmax=lmax, lnmax=int(sys.argv[5]), exact_max=em, verbose=True)
    print(json.dumps({k: round(v, 13) for k, v in res.items()}))
